<?php


class dbConnection {
    public $locked = false;
    public $FConDB;
    
    function __construct() {
        $this->FConDB = new ConDB();
        $this->FConDB->StartDBs();
    }
}