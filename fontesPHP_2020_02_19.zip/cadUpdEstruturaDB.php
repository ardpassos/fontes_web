<?php

class cadUpdEstruturaDB extends cadBase {
    
    public $FConEspelho;
    
    function __construct($_ACon) {
    	parent::__construct($_ACon);
        $this->connectDBEspelho();
    }
    
    function connectDBEspelho(){
        $ini = parse_ini_file('configpassos.ini', true);
        
        /*            $url = "mysql:host=localhost;dbname=id8202109_wp_e6d799528f216a95b17e3a886e298411";
         $user = "id8202109_wp_e6d799528f216a95b17e3a886e298411";
         $senha = "171717";
         */
        // print_r($ini);
        $url = "mysql:host=" . $ini['conexao']['servidor'] . ";dbname=" . $ini['conexao']['nomebanco_pay4me']; // "mysql:host=localhost;dbname=passos_teste";
        $user = $ini['conexao']['usuario_pay4me']; //"root";
        $senha = $ini['conexao']['senha_pay4me']; //"root";
        
        
        /*            dbHost = getenv("OPENSHIFT_POSTGRESQL_DB_HOST");
         $ARemote = (dbHost != null);
         if (ARemote) {
         $user = "root";
         $senha = "root";
         $url = "jdbc:postgresql://" + dbHost + ":" + dbPort + "/hello";
         }*/
        try {
            $this->FConEspelho = new PDO($url, $user, $senha);
            
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }
    
    function ExecDDLinDB($_ASql) {
        $AResult = '';
        try {
            $stmt = $this->FConEspelho->prepare(strtolower($_ASql));
            $stmt->execute();
            
            $AResult = '';
        }
        catch (Exception $e) {
            $this->FLastMessageError = $e->getMessage();
            $AResult = $this->FLastMessageError;
        }
        
        $ObjRet = new MensagemRetorno();
        $ObjRet->retorno = 1;
        $ObjRet->mensagem = $AResult;
        $this->FLastMessage = $this->getJSONFromObj($ObjRet);
        
        return $this->FLastMessage; //$this->getLastMessage();
    }
    
    function OpenSQLCons($_ASql) {
    	$AResult = false;
    	try {
    		$this->FQuery = $this->FConEspelho->prepare( $_ASql );
    		$this->FQuery->execute();
    		
    		$this->FillDataCons();
    	} catch (Exception $e) {
    		$AResult = false;
    	}
    	return $AResult;
    }
    
    function getConsFromClient($_ASql) {
        $this->OpenSQLCons($_ASql);
        return $this->getJSONRecords();
    }
    
    function executaDDL(){
        $this->FLastMessageError = "";
        $act = $_GET['act'];
        $AResult = "";
        if ($act == constCads::ACTION_EST)
            $AResult = $this->ExecDDLinDB($_GET['ddl']);
        else if ($act == constCads::ACTION_CONS)
            $AResult = $this->getConsFromClient($_GET['sql']);
        else
            $AResult = $this->ExecDDLinDB($_POST['sql']);
            
        return $AResult;
    }
    
}