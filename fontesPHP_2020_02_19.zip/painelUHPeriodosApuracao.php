<?php

class RecordRelPainelUH {
	public $codemp = "";
	public $codperiodo = "";
	public $coduh = "";
	public $descuh = "";
	public $descricao = "";
	public $valor = "";
}

class painelUHPeriodosApuracao extends cadBase {
	public $FRecLctos = array();
	public $FCodUH = 0;
	public $FDataInicio = "1900-01-01";
	
	function getTabela(){
		return strtolower("TabPeriodoApuracao");
	}
	
	function getCampoChave(){
		return strtolower("CodPeriodo");
	}
	
	function AddRecLcto(int $_ACodEmp, int $_ACodPeriodo, int $_ACodUH, string $_ADescUH, string $_ADesc, float $_AValor){
		$ARec = new RecordRelPainelUH();
		$ARec->codemp = $_ACodEmp;
		$ARec->codperiodo = $_ACodPeriodo;
		$ARec->coduh = $_ACodUH;
		$ARec->descuh = $_ADescUH;
		$ARec->descricao = utf8_encode($_ADesc);
		$ARec->valor = number_format ($_AValor, 2);
		array_push($this->FRecLctos, $ARec);
	}
	
	function setDadosUH($_ACodEmp, $_ADescUH){
		$ASql = " select * from tabuhs " .
				"  where codemp = " . $_ACodEmp .
				"    and descricao = " . $_ADescUH;
		$AQuery = $this->OpenSQLToResultSet(strtolower($ASql));
		while ($row = $AQuery->fetch(PDO::FETCH_ASSOC)) {
			$this->FCodUH = $row["coduh"];
			$this->FDataInicio = $row["datainicio"];
			//	$this->logMe("total moradores:". $this->FCondTotalMoradores);
		}
	}

	function OpenDadosPeriodoApuracao($_ACodEmp, $_ADescUH){
		$ASql = " select tpa.codperiodo, tpa.datainicio, tpa.descricao, " . 
				"       coalesce(".
				"                  (Select Max(trpa.valor) " .
				"          from tabrelperiodoapuracao trpa " .
				"         where trpa.codperiodo = tpa.codperiodo " . 
				"           and trpa.coduh = ". $this->FCodUH .
				"           and trpa.tiporegistro = 't' " .
				"       ), 0) as valor " .           
				"  from tabperiodoapuracao tpa " .
				"  where tpa.codemp = " . $_ACodEmp .
				"    and tpa.datainicio >= '" . $this->FDataInicio . "'" .
				" order by tpa.datainicio desc";
		$AQuery = $this->OpenSQLToResultSet(strtolower($ASql));
		while ($row = $AQuery->fetch(PDO::FETCH_ASSOC)) {
			$this->logMe("1");
			$this->AddRecLcto($_ACodEmp, $row["codperiodo"], $this->FCodUH, $_ADescUH, $row["descricao"], $row["valor"] );
		}
	}
	
	function openDadosUHCond($_ACodEmp, $_ADescUH){
		$this->setDadosUH($_ACodEmp, $_ADescUH);
	}
	
	function openLctos($_ACodEmp, $_ACodUH){
		$this->openDadosUHCond($_ACodEmp, $_ACodUH);
		$this->OpenDadosPeriodoApuracao($_ACodEmp, $_ACodUH);
		
		//		$this->logMe($this->getJSONFromObj($this->FRecLctos));
		return $this->getJSONFromObj($this->FRecLctos);
	}
	
	function getLctos($_ACodEmp, $_ACodPeriodo, $_ACodUH){
		return $this->openLctos($_ACodEmp, $_ACodPeriodo, $_ACodUH);
	}
	
	function getCons() {
		$ACodEmp = $this->getParameterInt( "CodEmp");
		$AConsPart = $this->getParameterInt( "conspart");
		
		if ($AConsPart == constCads::REL_PAINEL_UH_PERIODOS_APURACAO){
			$ACodUH = $this->getParameterInt( "coduh");
			return $this->openLctos($ACodEmp, $ACodUH);
		}
	}
	
}