<?php
$ATo = $_GET["email"];
$AAssunto = $_GET["assunto"];
$AMsg = $_GET["msg"];
$AHeaders = $_GET["headers"];

mail($ATo, $AAssunto, $AMsg, $AHeaders);