<?php

include_once("br/com/passos/dao/conDB.php");
include_once("br/com/passos/dao/constCads.php");
include_once("br/com/passos/dao/FieldDef.php");
include_once("dbConnection.php");
include_once("conStm.php");
//sistema de condom�nio
include_once("cadUpdateDB.php");
include_once("cadUpdEstruturaDB.php");
include_once("cadLogin.php");
include_once("cadFunc.php");
include_once("cadEmpresa.php");
include_once("cadUH.php");
include_once("cadDespFixas.php");
include_once("cadPeriodoApuracao.php");
include_once("cadLctoGas.php");
include_once("cadLctoLuz.php");
include_once("cadLctoAgua.php");
include_once("cadDespesasUH.php");
include_once ("relCobrancasCliente.php");
include_once ("relPeriodoApuracao.php");
include_once ("cadSolicitaContato.php");
include_once ("cadAreaComum.php");
include_once ("cadACPeriodos.php");
include_once ("cadReservasAC.php");
include_once ("painelUHPeriodosApuracao.php");
//sistema de varejo
include_once ("varejo/cadFuncionarios.php");
include_once ("varejo/cadPessoas.php");
include_once ("varejo/cadCidades.php");
include_once ("varejo/cadUnMedidas.php");
include_once ("varejo/cadMarcas.php");
include_once ("varejo/cadLocalAmox.php");
include_once ("varejo/cadGruposProdutos.php");
include_once ("varejo/cadProdutos.php");

$ACad = new cad();
$ACad->processaDisp();

class cad {
    
    private $serialVersionUID = 1145727360505885022;
    private $FConnections;
//    private Semaphore semaforo;
    public $FLogger;
    
    function __construct()
    {
        $this->FConnections = new ArrayObject();
       // $this->createConnections();
    }
     
    function createConnections(){
        for ($i = 0; $i < constCads::MAX_CONNECTIONS; $i++) {
            $ADBCon = new dbConnection();
            $this->FConnections->append($ADBCon);
        }
    }
    
    function createLogger(){
       $this->FLogger = fopen("CadLog.log", "a");
    }
    
    function getConnectionDisp(){
        return new dbConnection();
/*        if (semaforo == null)
            semaforo = new Semaphore(1);
            try {
                semaforo.acquire();
                try{
                    boolean AFind = false;
                    int ACount = 1;
                    
                   
                    while ((!AFind) & (ACount <= 5)){
                        for (int i = 0; i < FConnections.size(); i++) {
                            if (!FConnections.get(i).locked){
                                FConnections.get(i).locked = true;
                                AResult = FConnections.get(i);
                                AFind = true;
                                break;
                            }
                        }
                        if (AFind){
                            break;
                        }
                        else {
                            try {
                                ACount += 1;
                                Thread.currentThread().sleep(300);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
                finally {
                    semaforo.release();
                }
            } catch (InterruptedException e1) {
                e1.printStackTrace();
            }
            return AResult;*/
    }
    
    function processaCondominio(dbConnection $_AConDisp)  {
    	header("Content-type: text/html; charset=utf-8");
    	
        $AConDB = $_AConDisp->FConDB;
        $ASchemaName = $_GET[constCads::SCHEMA_NAME];
        $AConDB->setToSchema($ASchemaName);
        
        $AOp = $_GET[constCads::CAD];
        $AAction = $_GET[constCads::ACTION];
        $AResult = "";
        if (strcasecmp($AOp, constCads::CAD_RECREATE_DB) == 0) {
            $aUpd = new cadUpdateDB($AConDB);
            $AResult = $aUpd->updateDB();
        }        
        else if (strcasecmp($AOp, constCads::CAD_LOGIN) == 0) {
            $aCad = new cadLogin($AConDB);
            $AResult = $aCad->process($AAction);
        }
        else if (strcasecmp($AOp, constCads::CAD_FUNC) == 0) {
            $aCad = new cadFunc($AConDB);
            $AResult = $aCad->process($AAction);
        }
        else if (strcasecmp($AOp, constCads::CAD_EMPRESA) == 0) {
        	$aCad = new cadEmpresa($AConDB);
        	$AResult = $aCad->process($AAction);
        }
        else if (strcasecmp($AOp, constCads::CAD_UHS) == 0) {
        	$aCad = new cadUH($AConDB);
        	$AResult = $aCad->process($AAction);
        }
        else if (strcasecmp($AOp, constCads::CAD_DESPFIXAS) == 0) {
        	$aCad = new cadDespFixas($AConDB);
        	$AResult = $aCad->process($AAction);
        }
        else if (strcasecmp($AOp, constCads::CAD_PERIODOAPURACAO) == 0) {
        	$aCad = new cadPeriodoApuracao($AConDB);
        	$AResult = $aCad->process($AAction);
        }
        else if (strcasecmp($AOp, constCads::CAD_LCTOGAS) == 0) {
        	$aCad = new cadLctoGas($AConDB);
        	$AResult = $aCad->process($AAction);
        }
        else if (strcasecmp($AOp, constCads::CAD_LCTOLUZ) == 0) {
        	$aCad = new cadLctoLuz($AConDB);
        	$AResult = $aCad->process($AAction);
        }
        else if (strcasecmp($AOp, constCads::CAD_LCTOAGUA) == 0) {
        	$aCad = new cadLctoAgua($AConDB);
        	$AResult = $aCad->process($AAction);
        }
        else if (strcasecmp($AOp, constCads::CAD_DESPESASUH) == 0) {
        	$aCad = new cadDespesasUH($AConDB);
        	$AResult = $aCad->process($AAction);
        }
        else if (strcasecmp($AOp, constCads::CAD_UPD_ESTRUTURA_DB) == 0) {
        	$aUpd = new cadUpdEstruturaDB($AConDB);
        	$AResult = $aUpd->executaDDL();
        }
        else if (strcasecmp($AOp, constCads::REL_COBRANCAS_CLIENTE) == 0) {
        	$aUpd = new relCobrancasCliente($AConDB->getConEspelho());
        	$AResult = $aUpd->getConsPM();
        }
        else if (strcasecmp($AOp, constCads::REL_LISTAGEM_PERIODO_APURACAO) == 0) {
        	$aUpd = new relPeriodoApuracao($AConDB);
        	$AResult = $aUpd->getCons();
        }
        else if (strcasecmp($AOp, constCads::CAD_SOLICITACONTATO) == 0) {
        	$aCad = new cadSolicitaContato($AConDB);
        	$AResult = $aCad->process($AAction);
        }
        else if (strcasecmp($AOp, constCads::CAD_AREACOMUM) == 0) {
        	$aCad = new cadAreaComum($AConDB);
        	$AResult = $aCad->process($AAction);
        }
        else if (strcasecmp($AOp, constCads::CAD_AC_PERIODOS) == 0) {
        	$aCad = new cadACPeriodos($AConDB);
        	$AResult = $aCad->process($AAction);
        }
        else if (strcasecmp($AOp, constCads::CAD_RESERVAS_AC) == 0) {
        	$aCad = new cadReservasAC($AConDB);
        	$AResult = $aCad->process($AAction);
        }
        else if (strcasecmp($AOp, constCads::REL_PAINEL_UH_PERIODOS_APURACAO) == 0) {
        	$aUpd = new painelUHPeriodosApuracao($AConDB);
        	$AResult = $aUpd->getCons();
        }            
        return $AResult;
    }
    
    function processaVarejo(dbConnection $_AConDisp)  {
    	header("Content-type: text/html; charset=utf-8");
    	
    	$AConDB = $_AConDisp->FConDB;
    	$ASchemaName = $_GET[constCads::SCHEMA_NAME];
    	$AConDB->setToSchema($ASchemaName);
    	
    	$AOp = $_GET[constCads::CAD];
    	$AAction = $_GET[constCads::ACTION];
    	$AResult = "";
    	if (strcasecmp($AOp, constCads::CAD_LOGIN) == 0) {
    		$aCad = new cadLogin($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_FUNCIONARIOS) == 0) {
    		$aCad = new cadFuncionarios($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_PESSOAS) == 0) {
    		$aCad = new cadPessoas($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_CIDADES) == 0) {
    		$aCad = new cadCidades($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_UNMEDIDAS) == 0) {
    		$aCad = new cadUnMedidas($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_GRUPOSPRODUTOS) == 0) {
    		$aCad = new cadGruposProdutos($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_LOCALALMOX) == 0) {
    		$aCad = new cadLocalAmox($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_MARCAS) == 0) {
    		$aCad = new cadMarcas($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_PRODUTOS) == 0) {
    		$aCad = new cadProdutos($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	return $AResult;
    }
    
    function processa(dbConnection $_AConDisp)  {
    	header("Content-type: text/html; charset=utf-8");
    	if (isset($_GET[constCads::SISTEMA]))
    	  $ASys = $_GET[constCads::SISTEMA];
    	else
    	  $ASys = 'c';
    	$AResult = "";
    	    	
    	if (strcasecmp($ASys, constCads::SISTEMA_VAREJO) == 0) {
    		$AResult = $this->processaVarejo($_AConDisp);
    	}
    	else {
    		$AResult = $this->processaCondominio($_AConDisp);
    	}    
    	
    	if ($AResult != ""){
    		echo $AResult;
    	}
    }
    
    function processaDisp() {
    	if (!isset($_SESSION))
    		session_start();
        $AConDisp = $this->getConnectionDisp();
        try{
            $this->processa($AConDisp);
        }
        finally{
            $AConDisp->locked = false;
        }
    }

}
    