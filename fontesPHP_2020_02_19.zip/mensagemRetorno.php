<?php

class MensagemRetorno{
    public $retorno;
    public $mensagem;
    
    function __construct(){
        $this->retorno = 0;
        $this->mensagem = "";
    }
}
