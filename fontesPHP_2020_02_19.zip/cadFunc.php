<?php

class cadFunc extends cadBase {

    function getTabela(){
        return "tabfunc";
    }
    
    function getCampoChave(){
        return "codfunc";
    }
    
    function getCons() {
        $this->FSqlInitial = "Select * from tabfunc";
        $this->addFieldDef(strtolower("CodFunc"), "C�d. Func.", constCads::FIELD_INTEGER, "", "");
        $this->addFieldDef("NomeFunc", "Nome", constCads::FIELD_STRING, "", "");
        $this->addFieldDef("CPF", "CPF", constCads::FIELD_STRING, "", "");
        $this->addFieldDef("Email", "Email", constCads::FIELD_STRING, "", "");
        $this->addFieldDef("UserName", "UserName", constCads::FIELD_STRING, "", "");
        $this->addFieldDef("CodClienteCobranca", "CodClienteCobranca", constCads::FIELD_INTEGER, "", "");
        $this->addFieldDef("codempresa", "C�d. Empresa", constCads::FIELD_INTEGER, "", "");
        $this->addFieldDef("ehadministrador", "Administrador", constCads::FIELD_INTEGER, "", "");
        return parent::getCons();
    }
    
    function keyExists($_ACod) {
        $AResult = false;
        try {
            $AQuery = $this->OpenSQLToResultSet(strtolower("Select Count(*) as NumRec from TabFunc where CodFunc = ") . $_ACod);
            if ( $dados = $AQuery->fetch() ){
                $AResult = ($dados["NumRec"] > 0);
            }
            else
                $AResult = false;
        }
        catch (Exception $e) {
            $AResult = false;
        }
        return $AResult;
    }
    
    function getPost(){
        $ACodFunc = $this->getParameter( "CodFunc");
        $ANomeFunc = $this->getParameter( "NomeFunc");
        $ACPF = $this->getParameter( "CPF");
        $AEmail = $this->getParameter( "Email");
        $AUserName = $this->getParameter( "UserName");
        $APassword = $this->getParameter( "Password");
        $ACodClienteCobranca = $this->getParameter( "CodClienteCobranca");
        $Acodempresa = $this->getParameter( "codempresa");
        $Aehadministrador = $this->getParameter( "ehadministrador");
        
        $ASql = strtolower("Update tabfunc set nomefunc = '") . $ANomeFunc . "', " .
        " cpf = '" . $ACPF . "', " .
        " email = '" . $AEmail . "', " .
        " username = '" . $AUserName . "', " .
        " password = '" . $APassword . "', " .
        " codclientecobranca = " . $ACodClienteCobranca . ", " .
        " codempresa = " . $Acodempresa . ", " .
        " ehadministrador = " . $Aehadministrador . " " .
        " where codfunc = " . $ACodFunc;
        
        if ($this->ExecSQL($ASql))
            return "[{\"retorno\":1}]";
        else
            return "[{\"retorno\":0," .
                   "\"mensagem\":\"" . $this->getLastMessage() . "\"}]";
    }
    
    function getInsert(){
        
        $ANomeFunc = $this->getParameter( "NomeFunc");
        $ACPF = $this->getParameter( "CPF");
        $AEmail = $this->getParameter( "Email");
        $AUserName = $this->getParameter( "UserName");
        $APassword = $this->getParameter( "Password");
        $ACodClienteCobranca = $this->getParameter( "CodClienteCobranca");
        $Acodempresa = $this->getParameter( "codempresa");
        $Aehadministrador = $this->getParameter( "ehadministrador");
        
        $ASql = strtolower("Insert into TabFunc (CodFunc, NomeFunc, CPF, Email, UserName, Password, CodClienteCobranca, codempresa, ehadministrador) " .
        "Values (" .
        "(Select Coalesce(Max(tf.CodFunc), 0) from TabFunc tf)+1, ") .
        "'" . $ANomeFunc . "'," .
        " '" . $ACPF . "', " .
        " '" . $AEmail . "', " .
        " '" . $AUserName . "', " .
        " '" . $APassword . "', " .
        " " . $ACodClienteCobranca . ", " .
        " " . $Acodempresa . ", " .
        " " . $Aehadministrador . " " .
        ")";
        
        $ObjRet = new MensagemRetorno();
        if ($this->ExecSQL($ASql)) {
            $ObjRet->retorno = 1;
            $ObjRet->mensagem = "";
        }
        else {
            $ObjRet->retorno = 0;
            $ObjRet->mensagem = $this->getLastMessage();
        }
        return $this->getJSONFromObj($ObjRet);
    }
}
