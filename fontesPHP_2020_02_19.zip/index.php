<?php

$exec = new index();
$exec->Exec();

class index
{

    private $dsn = 'mysql:host=localhost;dbname=dbteste';

    private $user = 'root';

    private $pass = 'root';

    function Exec()
    {
        try {
            $pdo = new PDO($this->dsn, $this->user, $this->pass);

            $FQuery = $pdo->prepare("select * from tabuser");
            $FQuery->execute();

            $Records = new ArrayObject();
            while ($row = $FQuery->fetch(PDO::FETCH_ASSOC)) {
                $AFields = new ArrayObject();

                try {
                    for ($i = 1; $i <= count($row); $i ++) {
                        foreach ($row as $field => $value) {
                            $AFieldName = $field;
                            $AFieldValue = $value;
                        }
                        $AFields->offsetSet($AFieldName, $AFieldValue);
                    }
                } catch (Exception $e) {}

                $Records->append($AFields);
            }
            
            $AStr = json_encode($Records);

            print_r($AStr);
            print("<br>");
        } catch (Exception $e) {

            echo 'erro: ' . $e->getMessage();
        }
    }
}