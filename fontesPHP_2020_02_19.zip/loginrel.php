<?php
include_once("br/com/passos/dao/conDB.php");
include_once("cadLogin.php");
include_once("br/com/passos/dao/constCads.php");

if (!isset($_SESSION)) 
	session_start();

if (isset ($_SESSION['usuario'])){
	if ($_POST["username"] != $_SESSION['usuario']){
	  unset ($_SESSION['usuario']);
	  unset ($_SESSION['senha']);
	  unset ($_SESSION['codusersistcobranca']);
	}
}
if ((!isset ($_SESSION['usuario'])) or (!isset ($_SESSION['senha'])))
{
	unset($_SESSION['usuario']);
	unset($_SESSION['senha']);	
	unset($_SESSION['codusersistcobranca']);
	
	$ALogin = new efetuaLogin();
	$ALogin->efetuaLoginSistema();
}

if ((isset ($_SESSION['usuario'])) and (isset ($_SESSION['senha'])))
{
	//echo $_SESSION['usuario'].$_SESSION['codusersistcobranca'];
	$ARel = "http://www.passosti.com.br/demo/cad.php?-2=passos_teste&cad=1050&act=1050pdf&cod_cliente=".$_SESSION['codusersistcobranca'];
	
	echo '<html>
<head>
<title>xxxxxxxxxx</title>
</head>
<FRAMESET ROWS="1%,*,1%" FRAMEBORDER="0" FRAMESPACING="0">
<FRAME SRC="" NAME="superior" NORESIZE SCROLLING="NO" Height=0>
<FRAME SRC="'.$ARel.'" NAME="central" MARGINWIDTH="2" MARGINHEIGHT="3" NORESIZE SCROLLING="YES">
<FRAME SRC="" NAME="inferior" NORESIZE SCROLLING="NO" Height=0>
</FRAMESET>
<noframes>
<body>
</body>
</noframes>
</frameset>
</html>';
//	header('Location:http://www.passosti.com.br/demo/cad.php?-2=passos_teste&cad=1050&act=1050pdf&cod_cliente='.$_SESSION['codusersistcobranca']);
}

class efetuaLogin {
	function efetuaLoginSistema(){
		$AConDB = new ConDB();
		$aCad = new cadLogin($AConDB->getCon());
		$aCad->process(constCads::ACTION_CONS);
	}
}