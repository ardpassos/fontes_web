<?php
class cadACPeriodos extends cadBase {
	
	
	function getTabela(){
		return "tabacperiodos";
	}
	
	function getCampoChave(){
		return "codacperiodo";
	}
	
	function getCons() {
		$this->FOrderBy = "order by descricao, horaini";
		$this->FSqlInitial = "Select * from tabacperiodos";
		$this->addFieldDef(strtolower("CodACPeriodo"), "C�d. �rea Comum", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("codac", "C�d �rea Comum", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("descricao", "Descri��o", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("horaini", "Descri��o", constCads::FIELD_TIME, "", "");
		$this->addFieldDef("horafim", "Descri��o", constCads::FIELD_TIME, "", "");
		$this->addFieldDef("valorreserva", "Descri��o", constCads::FIELD_FLOAT, "", "");
		return parent::getCons();
	}
	
	function keyExists($_ACod) {
		$AResult = false;
		try {
			$AQuery = $this->OpenSQLToResultSet(strtolower("Select Count(*) as NumRec from tabacperiodos where codacperiodo = ") . $_ACod);
			if ( $dados = $AQuery->fetch() ){
				$AResult = ($dados["NumRec"] > 0);
			}
			else
				$AResult = false;
		}
		catch (Exception $e) {
			$AResult = false;
		}
		return $AResult;
	}
	
	function getPost(){
		$ACodACPeriodo = $this->getParameter( "codacperiodo");
		$ACodAC = $this->getParameter( "codac");
		$ADescricao = $this->getParameter( "Descricao");
		$AHoraIni = $this->getParameter( "horaini");
		$AHoraFim = $this->getParameter( "horafim");
		$AValorReserva = $this->getParameter( "valorreserva");
		
		$ASql = "update tabacperiodos set " .
				" codac = " . $ACodAC . ", " .
				" Descricao = '" . $ADescricao . "', " .
				" horaini = '" . $AHoraIni . "', " .
				" horafim = '" . $AHoraFim . "', " .
				" valorreserva = " . $AValorReserva . 
				" where codacperiodo = " . $ACodACPeriodos;
		
		if ($this->ExecSQL($ASql))
			return "[{\"retorno\":1}]";
			else
				return "[{\"retorno\":0," .
				"\"mensagem\":\"" . $this->getLastMessage() . "\"}]";
	}
	
	function getInsert(){
		$ACodAC = $this->getParameter( "codac");
		$ADescricao = $this->getParameter( "Descricao");
		$AHoraIni = $this->getParameter( "horaini");
		$AHoraFim = $this->getParameter( "horafim");
		$AValorReserva = $this->getParameter( "valorreserva");
		
		$ASql = strtolower("Insert into tabacperiodos (codacperiodo, codac, descricao, horaini, horafim, valorreserva) " .
				"Values (" .
				"(Select Coalesce(Max(tac.codacperiodo), 0) from tabacperiodos tac)+1, ") .
				" " . $ACodAC . "," .
				" '" . $ADescricao . "', " .
				" '" . $AHoraIni . "'," .
				" '" . $AHoraFim . "', " .
				" " . $AValorReserva . 
				")";
		
		$ObjRet = new MensagemRetorno();
		if ($this->ExecSQL($ASql)) {
			$ObjRet->retorno = 1;
			$ObjRet->mensagem = "";
		}
		else {
			$ObjRet->retorno = 0;
			$ObjRet->mensagem = $this->getLastMessage();
		}
		return $this->getJSONFromObj($ObjRet);
	}
}
