<?php

include_once('./reports/repcobranca.php');

class relCobrancasCliente extends cadBase {

	function __construct($_ACon) {
		$this->FCon = $_ACon;
	}
	
	
	function getCobrancasFromCli($_ACodCliente){
		$ASql = "";
		$ASql =  ' select tc.CodCobranca, '.
		'        tc.CodCliente, tpCredor.Nome as Credor, ' .
		'        tc.CodInad, tpDevedor.Nome as Devedor, ' .
		'        tc.NumDoc, ' .
		'        tc.DataLanc, ' .
		'        tc.DataVencDoc, ' .
		'        (CURRENT_DATE - tc.DataVencDoc) as DiasAtraso, ' .
		'        tc.ValorDoc, ' .
		'        tc.ValProtesto ' .
		'   from tabcobranca tc ' .
		'   join tabpessoas tpCredor ' .
		'     on tpCredor.CodPessoa = tc.CodCliente ' .
		'   join tabpessoas tpDevedor ' .
		'     on tpDevedor.CodPessoa = tc.CodInad ' .
		
		'  where tc.CodCobranca > -1 ' .
		'    and tc.Status <> ' . constCads::STATUS_COB_CANCELADO .
		'    and (tc.CodAgrupadora is null or tc.CodAgrupadora = 0) '.		
		'    and tc.CodCliente = '. $_ACodCliente;
		
		//$this->logMe($ASql);
		$this->OpenSQLCons($ASql);
		return $this->getJSONRecords();
	}
	
	function getRelCobrancasPorClientePdf(){
		/*$rep = new showreport();
		$rep->getreport();*/
		$rep = new repcobranca($this->FCon);
		return $rep->getReport();
	}
	
	function getConsPM(){
		$this->FLastMessageError = "";
		$act = $_GET['act'];
		$AResult = "";
		if ($act == constCads::ACTION_GET_COBRANCAS_FROM_CLI)
		  $AResult = $this->getCobrancasFromCli($_POST['codcliente']);
		else if ($act == constCads::ACTION_GET_COBRANCAS_FROM_CLI_PDF)
			$AResult = $this->getRelCobrancasPorClientePdf();
		  	
		return $AResult;
	}
	
}
	