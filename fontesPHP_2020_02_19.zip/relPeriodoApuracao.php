<?php

class RecordRel {
	public $descricao = "";
	public $valor = "";
}

class relPeriodoApuracao extends cadBase {
	public $FRecLctos = array();
	public $FCodEmp = 0;
	public $FCodPeriodo = 0;
	public $FCodUH = 0;
	public $FTotal = 0.00;
	public $FCondTotalUHs = 0;
	public $FCondTotalMoradores = 0;
	public $FCodUHCond = 0;
	public $FCondValorLuz = 0.00;
	public $FCondValorAgua = 0.00;
	public $RecordsPeriodoApuracao = array();

	function getTabela(){
		return strtolower("TabPeriodoApuracao");
	}
	
	function getCampoChave(){
		return strtolower("CodPeriodo");
	}
	
	function LimpaDadosTabRel(int $_ACodEmp, int $_ACodPeriodo, int $_ACodUH){
		$ASql = "delete from tabrelperiodoapuracao ".
				"where codemp = " . $_ACodEmp .
				"  and codperiodo = " . $_ACodPeriodo .
				"  and coduh = " . $_ACodUH;
		$this->ExecSQL($ASql);
	}
	
	function interDadosTabRel(int $_ACodEmp, int $_ACodPeriodo, int $_ACodUH, string $_ADescricao, float $_AValor, string $_ATipoRegistro) {
		$ASql = "insert into tabrelperiodoapuracao (codigo, codemp, codperiodo, coduh, descricao, valor, tiporegistro ) ".
				"values ".
				"(".
				    "NULL, " .
				    $_ACodEmp .", ".
					$_ACodPeriodo .", ".
					$_ACodUH .", ".
					"'" . $_ADescricao ."', ".
					$_AValor .", ".
					"'" . $_ATipoRegistro ."'".
				" ) ";
		$this->logMe($ASql);
		$this->ExecSQLSimple($ASql);
	}

	function AddRecLcto(string $_ADesc, float $_AValor, string $_ATipoRegistro = "l"){
		$this->FTotal += $_AValor;
		
		$this->interDadosTabRel($this->FCodEmp, $this->FCodPeriodo, $this->FCodUH, $_ADesc, $_AValor, $_ATipoRegistro);
		
	}
	
	function AddRecLctoInArray(string $_ADesc, float $_AValor){
		$ARec = new RecordRel();
		$ARec->descricao = utf8_encode($_ADesc);
		$ARec->valor = number_format ($_AValor, 2);
		array_push($this->FRecLctos, $ARec);
	}
	
	function PreencherArray(){
		$ASql = " select * from tabrelperiodoapuracao " .
				"  where codemp = ". $this->FCodEmp . 
				"    and codperiodo = " . $this->FCodPeriodo .
				"    and coduh = " . $this->FCodUH .
				"  order by codigo ";
		$AQuery = $this->OpenSQLToResultSet($ASql);
		while ($row = $AQuery->fetch(PDO::FETCH_ASSOC)) {
			$this->AddRecLctoInArray($row['descricao'], $row['valor']);
		}
	}
	
	function openAluguelECondUH($_ACodPeriodo, $_ACodUH){
		$ASql = " select * from tabuhs " .
				"  where coduh = " . $_ACodUH .
				"  order by coduh";
		$AQuery = $this->OpenSQLToResultSet($ASql);
		while ($row = $AQuery->fetch(PDO::FETCH_ASSOC)) {
			if (strtolower($row['ehaluguel']) == strtolower('s'))
			  $this->AddRecLcto("Aluguel", $row['valoraluguel'], "al");
			$this->AddRecLcto("Condominio", $row['valorcond'], "co");
		}
	}
	
	function openDespesasUH($_ACodPeriodo, $_ACodUH){
		$ASql = " select tduh.descricaodespesa, tduh.valor, tuh.ehcond from tabdespesasuh tduh " .
				"   join tabuhs tuh  " .
				"    on tuh.coduh = tduh.coduh " .
				"  where tduh.codPeriodo = " . $_ACodPeriodo .
				"    and tduh.coduh in (" . $_ACodUH . ", ". $this->FCodUHCond . ")" .
				"  order by tduh.coduh";
		$AQuery = $this->OpenSQLToResultSet($ASql);
		while ($row = $AQuery->fetch(PDO::FETCH_ASSOC)) {
			$AValor = $row['valor'];
			if ($row['ehcond'] == "s")
				$AValor = $AValor / $this->FCondTotalUHs;
			$this->AddRecLcto($row['descricaodespesa'], $AValor, "dg");
		}		
	}
	
	function openLuz($_ACodPeriodo, $_ACodUH, $_AEhCond=false){
		$ASql = " select tluz.*, tuh.numpessoasuh, tpa.datainicio, tpa.datafim, tpa.valorunluz,
						(Select max(tluzl.ValorLeitura) 
						   from TabLctoLuz tluzl
						  join TabPeriodoApuracao tpal
						    on tpal.codperiodo = tluzl.codperiodo  
						 where tluzl.codemp = tluz.codemp 
                           and tluzl.coduh = tluz.coduh
                           and tluzl.codmedidor = tluz.codmedidor 
						   and tpal.datainicio < tpa.datainicio ) as ultleitura
				  from tablctoluz tluz
				  join TabPeriodoApuracao tpa
				    on tpa.codperiodo = tluz.codperiodo 
				  join Tabuhs tuh
    			    on tuh.coduh = tluz.coduh  " .
				"  where tluz.codPeriodo = " . $_ACodPeriodo .
				"    and tluz.coduh = " . $_ACodUH .
				"  order by tluz.coduh";
		$AQuery = $this->OpenSQLToResultSet(strtolower($ASql));
		$AValor = 0;
		$ANumPessoasUH = 0;
		$AData = "";
		while ($row = $AQuery->fetch(PDO::FETCH_ASSOC)) {
			$ANumPessoasUH = $row["numpessoasuh"];
			$AData = date("d/m/Y", strtotime($row["dataleitura"]));
			$AValor += ($row["valorleitura"] - $row["ultleitura"]) * $row["valorunluz"];
		}
		if ($_AEhCond)
			$this->FCondValorLuz += $AValor; // j� est� com os valores da band. amarela, etc
		else {
			$AValor += ($this->FCondValorLuz / $this->FCondTotalUHs); // na luz, o valor do cond � por uh
//			$this->logMe("ValorTotalCond: ". $this->FCondValorLuz . " - Moradores: " . $this->FCondTotalMoradores . " nesta uh ". $_ACodUH. ": " . $ANumPessoasUH );
			$this->AddRecLcto("Luz (DataLeirura: ".$AData.")", $AValor, "lu");
		}
	}
	
	function openAgua($_ACodPeriodo, $_ACodUH){
		$ASql = " select tuh.* from tabuhs tuh".
		        "   left join tablctoagua tla " .
		        "     on tla.coduh = tuh.coduh " .
				"    and tla.codPeriodo = " . $_ACodPeriodo .
				"  where tuh.coduh = " . $_ACodUH .
				"  order by tuh.coduh";
		$AQuery = $this->OpenSQLToResultSet(strtolower($ASql));
		$AValor = 0;
		$ANumPessoasUH = 0;
		$AData = "";
		while ($row = $AQuery->fetch(PDO::FETCH_ASSOC)) {
			$ANumPessoasUH = $row["numpessoasuh"];
			//$AData = date("d/m/Y", strtotime($row["dataleitura"]));
			//$AValor += ($row["valorleitura"] - $row["UltLeitura"]) * $row["valorunluz"];
		}
		$AValor += ($this->FCondValorAgua / $this->FCondTotalMoradores) * $ANumPessoasUH; // a �gua � por pessoa da uh
		//$this->logMe("total moradores:". $this->FCondTotalMoradores. " total �gua: ". $this->FCondValorAgua . " n�m moradores uh:". $ANumPessoasUH);
		$this->AddRecLcto("Agua", $AValor, "ag");		
	}
	
	function openGas($_ACodPeriodo, $_ACodUH){
		$ASql = " select tg.*, tuh.numpessoasuh, tpa.datainicio, tpa.datafim, tpa.valorrateiogas,
						(Select max(tgl.ValorLeitura) 
						   from tablctogas tgl
						  join TabPeriodoApuracao tpal
						    on tpal.codperiodo = tgl.codperiodo  
						 where tgl.codemp = tg.codemp 
                           and tgl.coduh = tg.coduh
						   and tpal.datainicio < tpa.datainicio ) as ultleitura " .
				"   from tablctogas tg " .		  
				"   join TabPeriodoApuracao tpa
				      on tpa.codperiodo = tg.codperiodo 
				    join Tabuhs tuh
    			      on tuh.coduh = tg.coduh  " .
				"  where tg.codPeriodo = " . $_ACodPeriodo .
				"    and tg.coduh = " . $_ACodUH .
				"  order by tg.coduh";
		$AQuery = $this->OpenSQLToResultSet(strtolower($ASql));
		while ($row = $AQuery->fetch(PDO::FETCH_ASSOC)) {
			$AData = date("d/m/Y", strtotime($row["dataleitura"]));
			$AValor = ($row["valorleitura"] - $row["ultleitura"]) * $row["valorrateiogas"];
			$this->AddRecLcto("Gas (DataLeirura: ".$AData.")", $AValor, "ga");
		}
	}
	
	function setDadosCond($_ACodEmp){
		$ASql = " select * from tabuhs " .
				"  where codemp = " . $_ACodEmp .
				"    and lower(ehcond) = 's'";
		$AQuery = $this->OpenSQLToResultSet($ASql);
		while ($row = $AQuery->fetch(PDO::FETCH_ASSOC)) {
			$this->FCodUHCond = $row["coduh"];
		}
	}
	
	function setDadosUHS($_ACodEmp){
		$ASql = " select sum(1) as numuhs, sum(numpessoasuh) as numpessoas from tabuhs " .
				"  where codemp = " . $_ACodEmp . 
				" and (ehcond <> 's' or ehcond is null)";
		$AQuery = $this->OpenSQLToResultSet(strtolower($ASql));
		while ($row = $AQuery->fetch(PDO::FETCH_ASSOC)) {
			$this->FCondTotalUHs = $row["numuhs"];
			$this->FCondTotalMoradores = $row["numpessoas"];
		//	$this->logMe("total moradores:". $this->FCondTotalMoradores);
		}
	}
	
	function AddRecordPeriodoApucacao($_ARec){
		array_push($this->RecordsPeriodoApuracao, $_ARec);
	}
	
	function setDadosPeriodoApuracao($_ACodEmp, $ACodPeriodo){
		$ASql = " select tpa.*, te.nomefantasia from tabperiodoapuracao tpa " .
				" join tabempresa te " .
				"	on te.codempresa = tpa.codemp" .	
				"  where tpa.codemp = " . $_ACodEmp .
				"    and tpa.codperiodo = " . $ACodPeriodo;
		$AQuery = $this->OpenSQLToResultSet(strtolower($ASql));
		while ($row = $AQuery->fetch(PDO::FETCH_ASSOC)) {
			$this->FCondValorLuz = $row["valoradbandamarela"] + $row["valoradbandvermelha"] + $row["valorcosip"];
			$this->FCondValorAgua = $row["valortotalagua"];
			$this->AddRecordPeriodoApucacao($row);
		}
	}
	
	function openDadosUHCond($_ACodEmp, $_ACodPeriodo){
		$this->setDadosCond($_ACodEmp);
		$this->setDadosUHS($_ACodEmp);
		$this->setDadosPeriodoApuracao($_ACodEmp, $_ACodPeriodo);
	}
	
	function GenLctos($_ACodEmp, $_ACodPeriodo, $_ACodUH){
		$this->openDadosUHCond($_ACodEmp, $_ACodPeriodo);
		$this->openAluguelECondUH($_ACodPeriodo, $_ACodUH);
		$this->openDespesasUH($_ACodPeriodo, $_ACodUH);
		$this->openLuz($_ACodPeriodo, $this->FCodUHCond, true);
		$this->openLuz($_ACodPeriodo, $_ACodUH);
		$this->openAgua($_ACodPeriodo, $_ACodUH);
		$this->openGas($_ACodPeriodo, $_ACodUH);
		$this->AddRecLcto("Total: ", $this->FTotal, "t");
	}
	
	function getJReturnJSON(){
		return $this->getJSONFromObj($this->FRecLctos);
	}
	
	function openUHs($ACodEmp){
		$ASql = " select * from tabuhs " .
				"  where codemp = " . $ACodEmp .
				"    and (lower(ehcond) <> 's' || lower(ehcond) is null) ".
				"  order by descricao";
		$AQueryUHs = $this->OpenSQLToResultSet(strtolower($ASql));
		$this->FillDataCons($AQueryUHs);
	}
	
	function getUHs($_ACodEmp){
		$this->openUHs($_ACodEmp);
		return $this->getJSONRecords();
	}
	
	function InserirDados($_AQuery){
		try {
			while ($row = $_AQuery->fetch(PDO::FETCH_ASSOC)) {
				$this->FCodUH = $row["coduh"];
				$this->FTotal = 0;
				$this->LimpaDadosTabRel($this->FCodEmp, $this->FCodPeriodo, $row["coduh"]);
				$this->GenLctos($this->FCodEmp, $this->FCodPeriodo, $row["coduh"]);
			}
		} catch (Exception $e) {
			$this->logMe($e->getMessage());
		}
	}
	
	function GenUHsAndDatas($ACodEmp){
		$ASql = " select * from tabuhs " .
				"  where codemp = " . $ACodEmp .
				"    and (lower(ehcond) <> 's' || lower(ehcond) is null) ".
				"  order by descricao";
		$AQueryUHs = $this->OpenSQLToResultSet(strtolower($ASql));
		$this->InserirDados($AQueryUHs);
	}
	
	function enviarEmailsCondominos(){
		$this->openUHs($this->FCodEmp);
		$this->setDadosPeriodoApuracao($this->FCodEmp, $this->FCodPeriodo);
		$ARecPA = $this->RecordsPeriodoApuracao[0];
		for ($i = 0; $i<count($this->Records); $i++){
			$ARec = $this->Records[$i];
			
			$AEmail = $ARec["emailcontato"];
			if ($AEmail != ""){
				$AAssunto = "Demonstrativo de condom�nio";
				$AHeaders = implode("\n", array("Content-Type: text/html"));
				$ANomeFantasia = $ARecPA["nomefantasia"];
				$AText ="<html>". 
						"<meta charset='UTF-8'>".
						"<body>".
						"Condom�nio: " . utf8_decode($ANomeFantasia) . "<br>".
						"UH: " . $ARec["descricao"] . "<br>" .
						"Nome: " . $ARec["nomecontato"] . "<br>" .
						"Seu demonstrativo de condom�nio est� pronto para ser visualisado no site http://www.passosti.com.br".
						"</body></html>";
				
				$AURL = "http://www.passosti.com.br/demo/enviar_email.php?email=". $AEmail . 
						"&assunto=$AAssunto".
						"&msg=". $AText .
						"&headers=". $AHeaders;
				$AURL = preg_replace("/ /", "%20", $AURL);
				$array = file($AURL);
				$AStr = "";
				foreach($array as $line){
					$AStr = $AStr.$line;
				}
			}
		}
	}
	
	function getCons() {
		$ACodEmp = $this->getParameterInt( "CodEmp");
		$ACodPeriodo = $this->getParameterInt( "CodPeriodo");
		$AConsPart = $this->getParameterInt( "conspart");
		$this->FCodEmp = $ACodEmp;
		$this->FCodPeriodo = $ACodPeriodo;
		
		$this->logMe($AConsPart);
		if ($AConsPart == constCads::REL_LISTAGEM_PERIODO_APURACAO_UHS){
			return $this->getUHs($ACodEmp); //lista de uhs no condom�nio
		}
		else if ($AConsPart == constCads::REL_LISTAGEM_PERIODO_APURACAO_LCTOS){
			$this->GenUHsAndDatas($ACodEmp);//ir� inserir na base de dados os lctos para posterior leitura
			$this->AddRecLctoInArray("retorno", 1);
			return $this->getJReturnJSON();
		}
		else if ($AConsPart == constCads::REL_LISTAGEM_PERIODO_APURACAO_LCTOS_GERADOS){
			$ACodUH = $this->getParameterInt( "coduh"); //lista de lan�amentos gerados na base
			$this->FCodUH = $ACodUH;
			
			$this->PreencherArray();
			return $this->getJReturnJSON();
		}
		else if ($AConsPart == constCads::REL_LISTAGEM_PERIODO_APURACAO_EMAILS_CONDOMINOS){
			$this->enviarEmailsCondominos();
			$this->AddRecLctoInArray("retorno", 1);
			return $this->getJReturnJSON();
		}
	}
	
}