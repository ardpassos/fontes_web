<?php

class cadCidades extends cadBase {
	
	function getTabela(){
		return "tabcidades";
	}
	
	function getCampoChave(){
		return "codfuncionario";
	}
	
	function getCons() {
		$this->FOrderBy = "  order by tc.cidade";
		$this->FSqlInitial = "select tc.codcidade, tc.cidade, te. estprov ".
                             "  from tabcidades tc ".
                             "  join tabestprov te ".
                             "    on te.codestprov = tc.codestprov ";
		$this->addFieldDef($this->getCampoChave(), "C�d. Cidade", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("cidade", "Cidade", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("estprov", "UF", constCads::FIELD_STRING, "", "");
		return parent::getCons();
	}
	
	function getConsLkp() {
		$this->FOrderBy = "  order by tc.cidade";
		$this->FSqlInitial = "select tc.codcidade as codigo, concat(tc.cidade, '/', te.estprov) as descricao ".
				"  from tabcidades tc ".
				"  join tabestprov te ".
				"    on te.codestprov = tc.codestprov ";
		$this->addFieldDef($this->getCampoChave(), "C�d. Cidade", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("cidade", "Cidade", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("estprov", "UF", constCads::FIELD_STRING, "", "");
		return parent::getConsLkp();
	}
	
	
	function keyExists($_ACod) {
		$AResult = false;
		try {
			$AQuery = $this->OpenSQLToResultSet(strtolower("Select Count(*) as NumRec ".
					"  from " . $this->getTabela() .
					" where " . $this->getCampoChave() . " = " . $_ACod));
			if ( $dados = $AQuery->fetch() ){
				$AResult = ($dados["NumRec"] > 0);
			}
			else
				$AResult = false;
		}
		catch (Exception $e) {
			$AResult = false;
		}
		return $AResult;
	}
	
}
