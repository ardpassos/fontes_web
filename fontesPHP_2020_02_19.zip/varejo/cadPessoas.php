<?php

class cadPessoas extends cadBase {
	
	function getTabela(){
		return "tabpessoas";
	}
	
	function getCampoChave(){
		return "codpessoa";
	}
	
	function getCons() {
		$this->FSqlInitial = "Select * from ". $this->getTabela();
		$this->addFieldDef($this->getCampoChave(), "C�d. Pessoa", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("nome", "Nome", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("nomefantasia", "Nome Fantasia", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("endereco", "Endere�o", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("complemento", "Complemento", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("bairro", "Bairro", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("cep", "CEP", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("codcidade", "C�d. Cidade", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("fonecomercial", "Fone Comercial", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("cliente", "� Cliente", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("fornecedor", "� Fornecedor", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("cpfcnpj", "CPF/CNPJ", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("email", "Email", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("www", "Site", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("pessoafisica", "Pessoa F�sica", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("datanasc", "Data Nasc.", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("rg", "RG", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("fonecelular", "Celular", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("inscmun", "Inscr. Mun.", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("inscrestadual", "Inscr. Estadual", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("seriecert", "S�rie do Certificado", constCads::FIELD_STRING, "", "");
		return parent::getCons();
	}
	
	function keyExists($_ACod) {
		$AResult = false;
		try {
			$AQuery = $this->OpenSQLToResultSet(strtolower("Select Count(*) as NumRec ".
					"  from " . $this->getTabela() .
					" where " . $this->getCampoChave() . " = " . $_ACod));
			if ( $dados = $AQuery->fetch() ){
				$AResult = ($dados["NumRec"] > 0);
			}
			else
				$AResult = false;
		}
		catch (Exception $e) {
			$AResult = false;
		}
		return $AResult;
	}
	
	function getPost(){
		$ACodPessoa = $this->getParameterInt( "CodPessoa");
		$ANome = $this->getParameter( "Nome");
		$ANomeFantasia = $this->getParameter( "nomefantasia");
		$Aendereco = $this->getParameter( "endereco");
		$Acomplemento = $this->getParameter( "complemento");
		$Abairro = $this->getParameter( "bairro");
		$Acep = $this->getParameter( "cep");
		$Acodcidade = $this->getParameterInt( "codcidade");
		$Afonecomercial = $this->getParameter( "fonecomercial");
		$Acliente = $this->getParameter( "cliente");
		$Afornecedor = $this->getParameter( "fornecedor");
		$Acpfcnpj = $this->getParameter( "cpfcnpj");
		$Aemail = $this->getParameter( "email");
		$Awww = $this->getParameter( "www");
		$Apessoafisica = $this->getParameter( "pessoafisica");
		$Adatanasc = $this->getParameter( "datanasc");
		$Arg = $this->getParameter( "rg");
		$Afonecelular = $this->getParameter( "fonecelular");
		$Ainscmun = $this->getParameter( "inscmun");
		$Ainscrestadual = $this->getParameter( "inscrestadual");
		$Aseriecert = $this->getParameter( "seriecert");
		
		$ASql = strtolower("Update tabpessoas set nome = '") . $ANome . "', " .
				" nomefantasia = '" . $ANomeFantasia . "', " .
				" endereco = '" . $Aendereco . "', " .
				" complemento = '" . $Acomplemento . "', " .
				" bairro = '" . $Abairro . "', " .
				" cep = '" . $Acep . "', " .
				" codcidade = " . $Acodcidade . ", " .
				" fonecomercial = '" . $Afonecomercial . "', " .
				" cliente = '" . $Acliente . "', " .
				" fornecedor = '" . $Afornecedor . "', " .
				" cpfcnpj = '" . $Acpfcnpj . "', " .
				" email = '" . $Aemail . "', " .
				" www = '" . $Awww . "', " .
				" pessoafisica = '" . $Apessoafisica . "', " .
				" datanasc = '" . $Adatanasc . "', " .
				" rg = '" . $Arg . "', " .
				" fonecelular = '" . $Afonecelular . "', " .
				" inscmun = '" . $Ainscmun . "', " .
				" inscrestadual = '" . $Ainscrestadual . "', " .
				" seriecert = '" . $Aseriecert . "' " .
				" where codpessoa = " . $ACodPessoa;
		
		if ($this->ExecSQL($ASql))
			return "[{\"retorno\":1}]";
		else
			return "[{\"retorno\":0," .
				"\"mensagem\":\"" . $this->getLastMessage() . "\"}]";
	}
	
	function getInsert(){
		
		$ANome = $this->getParameter( "Nome");
		$ANomeFantasia = $this->getParameter( "nomefantasia");
		$Aendereco = $this->getParameter( "endereco");
		$Acomplemento = $this->getParameter( "complemento");
		$Abairro = $this->getParameter( "bairro");
		$Acep = $this->getParameter( "cep");
		$Acodcidade = $this->getParameterInt( "codcidade");
		$Afonecomercial = $this->getParameter( "fonecomercial");
		$Acliente = $this->getParameter( "cliente");
		$Afornecedor = $this->getParameter( "fornecedor");
		$Acpfcnpj = $this->getParameter( "cpfcnpj");
		$Aemail = $this->getParameter( "email");
		$Awww = $this->getParameter( "www");
		$Apessoafisica = $this->getParameter( "pessoafisica");
		$Adatanasc = $this->getParameterDateTime( "datanasc");
		$Arg = $this->getParameter( "rg");
		$Afonecelular = $this->getParameter( "fonecelular");
		$Ainscmun = $this->getParameter( "inscmun");
		$Ainscrestadual = $this->getParameter( "inscrestadual");
		$Aseriecert = $this->getParameter( "seriecert");
		
		$ASql = strtolower("Insert into tabpessoas " .
				" (codpessoa, nome, nomefantasia, endereco, complemento, bairro, cep, codcidade, fonecomercial, cliente, fornecedor, cpfcnpj, email, www,".
				" pessoafisica, datanasc, rg, fonecelular, inscmun, inscrestadual, seriecert) " .
				"Values (" .
				"(" . $this->getFieldKeyMaxInSQL() . ")+1, ") .
				"'" . $ANome . "'," .
				"'" . $ANomeFantasia . "'," .
				"'" . $Aendereco . "'," .
				"'" . $Acomplemento . "'," .
				"'" . $Abairro . "'," .
				"'" . $Acep . "'," .
				      $Acodcidade . "," .
				"'" . $Afonecomercial . "'," .
				"'" . $Acliente . "'," .
				"'" . $Afornecedor . "'," .
				"'" . $Acpfcnpj . "'," .
				"'" . $Aemail . "'," .
				"'" . $Awww . "'," .
				"'" . $Apessoafisica . "'," .
				"'" . $Adatanasc . "'," .
				"'" . $Arg . "'," .
				"'" . $Afonecelular . "'," .
				"'" . $Ainscmun . "'," .
				"'" . $Ainscrestadual . "'," .
				"'" . $Aseriecert . "'" .
				")";
		
		$ObjRet = new MensagemRetorno();
		if ($this->ExecSQL($ASql)) {
			$ObjRet->retorno = 1;
			$ObjRet->mensagem = "";
		}
		else {
			$ObjRet->retorno = 0;
			$ObjRet->mensagem = $this->getLastMessage();
		}
		return $this->getJSONFromObj($ObjRet);
	}
}
