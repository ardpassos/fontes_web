<?php

class cadProdutos extends cadBase {
	
	function getTabela(){
		return "tabinsumos";
	}
	
	function getCampoChave(){
		return "codinsumo";
	}
	
	function getCons() {
		$this->FSqlInitial = "Select * from ". $this->getTabela();
		$this->addFieldDef($this->getCampoChave(), "C�d. Produto", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("insumo", "Produto", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("obs", "Obs", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("codgrupo", "C�d. Grupo", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("codlocalalm", "C�d. Local Alm.", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("codunmedida", "C�d. Un. Medida", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("qtdemin", "Qtde M�n.", constCads::FIELD_FLOAT, "", "");
		$this->addFieldDef("qtdemax", "Qtde M�x.", constCads::FIELD_FLOAT, "", "");
		$this->addFieldDef("status", "Status", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("numoriginal", "Numera��o original", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("ncm", "NCM", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("codbarras", "C�d. Barras", constCads::FIELD_STRING, "", "");
		return parent::getCons();
	}
	
	function getConsLkp() {
		$this->FOrderBy = "  order by insumo";
		$this->FSqlInitial = "select codinsumo as codigo, insumo as descricao ".
				"  from tabinsumos ";
		$this->addFieldDef($this->getCampoChave(), "C�d. Produto", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("insumo", "Produto", constCads::FIELD_STRING, "", "");
		return parent::getConsLkp();
	}
	
	function getPost(){
		$ACodInsumo = $this->getParameterInt( "codinsumo");
		$AInsumo = $this->getParameter("insumo");
		$AObs = $this->getParameter("obs");
		$ACodGrupo = $this->getParameter("codgrupo");
		$ACodLocalAlm = $this->getParameter("codlocalalm");
		$ACodUnMedida = $this->getParameter("codunmedida");
		$AQtdeMin = $this->getParameter("qtdemin");
		$AQtdeMax = $this->getParameter("qtdemax");
		$AStatus = $this->getParameter("status");
		$ANumOriginal = $this->getParameter("numoriginal");
		$ANCM = $this->getParameter("ncm");
		$ACodBarras = $this->getParameter("codbarras");
		
		$ASql = "Update tabinsumos set insumo = '" . $AInsumo . "', " .
						" obs = '" . $AObs . "', " .
						" codgrupo = " . $ACodGrupo . ", " .
						" codlocalalm = " . $ACodLocalAlm . ", " .
						" codunmedida = " . $ACodUnMedida . ", " .
						" qtdemin = " . $AQtdeMin . ", " .
						" qtdemax = " . $AQtdeMax . ", " .
						" status = '" . $AStatus . "', " .
						" numoriginal = '" . $ANumOriginal . "', " .
						" ncm = '" . $ANCM . "', " .
						" codbarras = '" . $ACodBarras . "' " .
				" where codinsumo = " . $ACodInsumo;
		
		if ($this->ExecSQL($ASql))
			return "[{\"retorno\":1}]";
			else
				return "[{\"retorno\":0," .
				"\"mensagem\":\"" . $this->getLastMessage() . "\"}]";
	}
	
	function getInsert(){
		$AInsumo = $this->getParameter("insumo");
		$AObs = $this->getParameter("obs");
		$ACodGrupo = $this->getParameterInt("codgrupo");
		$ACodLocalAlm = $this->getParameterInt("codlocalalm");
		$ACodUnMedida = $this->getParameterInt("codunmedida");
		$AQtdeMin = $this->getParameterFloat("qtdemin");
		$AQtdeMax = $this->getParameterFloat("qtdemax");
		$AStatus = $this->getParameter("status");
		$ANumOriginal = $this->getParameter("numoriginal");
		$ANCM = $this->getParameter("ncm");
		$ACodBarras = $this->getParameter("codbarras");
		
		$ASql = "insert into tabinsumos " .
				" (codinsumo, insumo, obs, codgrupo, codlocalalm, codunmedida, qtdemin, qtdemax, status, numoriginal, ncm, codbarras) " .
				"Values (" .
				"(" . $this->getFieldKeyMaxInSQL() . ")+1, " .
				"'" . $AInsumo . "'," .
				"'" . $AObs . "'," .
				$ACodGrupo . "," .
				$ACodLocalAlm . "," .
				$ACodUnMedida . "," .
				$AQtdeMin . "," .
				$AQtdeMax . "," .
				"'" . $AStatus . "'," .
				"'" . $ANumOriginal . "'," .
				"'" . $ANCM . "'," .
				"'" . $ACodBarras . "'" .
				")";
		
		$ObjRet = new MensagemRetorno();
		if ($this->ExecSQL($ASql)) {
			$ObjRet->retorno = 1;
			$ObjRet->mensagem = "";
		}
		else {
			$ObjRet->retorno = 0;
			$ObjRet->mensagem = $this->getLastMessage();
		}
		return $this->getJSONFromObj($ObjRet);
	}
}