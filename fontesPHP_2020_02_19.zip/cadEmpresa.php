<?php

class cadEmpresa extends cadBase {
	

	function getTabela(){
		return "TabEmpresa";
	}
	
	function getCampoChave(){
		return "CodFunc";
	}
	
	function getCons() {
		$this->FSqlInitial = "Select * from tabempresa";
		$this->addFieldDef(strtolower("CodEmpresa"), "C�d. Empresa", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("RazaoSocial", "Raz�o Social", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("NomeFantasia", "Noma Fantasia", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("CNPJ", "CNPJ", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("servidor_db", "Servidor DB", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("nome_db", "Nome DB", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("usuario_db", "Usuario DB", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("senha_db", "Senha DB", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("ehsistemavarejo", "Sistema Varejo", constCads::FIELD_STRING, "", "");
		return parent::getCons();
	}
	
	function keyExists($_ACod) {
		$AResult = false;
		try {
			$AQuery = $this->OpenSQLToResultSet(strtolower("Select Count(*) as NumRec from TabEmpresa where CodEmpresa = ") . $_ACod);
			if ( $dados = $AQuery->fetch() ){
				$AResult = ($dados["NumRec"] > 0);
			}
			else
				$AResult = false;
		}
		catch (Exception $e) {
			$AResult = false;
		}
		return $AResult;
	}
	
	function getPost(){
		$ACodEmpresa = $this->getParameter( "CodEmpresa");
		$ARazaoSocial = $this->getParameter( "RazaoSocial");
		$ANomeFantasia = $this->getParameter( "NomeFantasia");
		$ACNPJ = $this->getParameter( "CNPJ");
		$AServidor_DB = $this->getParameter( "Servidor_DB");
		$ANome_DB = $this->getParameter( "Nome_DB");
		$AUsuario_DB = $this->getParameter( "Usuario_DB");
		$ASenha_DB = $this->getParameter( "Senha_DB");
		$AEhSistemaVarejo = $this->getParameter( "EhSistemaVarejo");
		
		$ASql = strtolower("Update TabEmpresa set RazaoSocial = '") . $ARazaoSocial . "', " .
				" NomeFantasia = '" . $ANomeFantasia . "', " .
				" CNPJ = '" . $ACNPJ . "', " .
				" Servidor_DB = '" . $AServidor_DB . "', " .
				" Nome_DB = '" . $ANome_DB . "', " .
				" Usuario_DB = '" . $AUsuario_DB . "', " .
				" Senha_DB = '" . $ASenha_DB . "', " .
				" EhSistemaVarejo = '" . $AEhSistemaVarejo . "' " .				
				" where CodEmpresa = " . $ACodEmpresa;
		
		if ($this->ExecSQL($ASql))
			return "[{\"retorno\":1}]";
			else
				return "[{\"retorno\":0," .
				"\"mensagem\":\"" . $this->getLastMessage() . "\"}]";
	}
	
	function getInsert(){
		
		$ARazaoSocial = $this->getParameter( "RazaoSocial");
		$ANomeFantasia = $this->getParameter( "NomeFantasia");
		$ACNPJ = $this->getParameter( "CNPJ");
		$AServidor_DB = $this->getParameter( "Servidor_DB");
		$ANome_DB = $this->getParameter( "Nome_DB");
		$AUsuario_DB = $this->getParameter( "Usuario_DB");
		$ASenha_DB = $this->getParameter( "Senha_DB");
		$AEhSistemaVarejo = $this->getParameter( "EhSistemaVarejo");
		
		$ASql = strtolower("Insert into TabEmpresa (CodEmpresa, RazaoSocial, NomeFantasia, CNPJ, Servidor_DB, Nome_DB, Usuario_DB, Senha_DB, EhSistemaVarejo) " .
				"Values (" .
				"(Select Coalesce(Max(te.CodEmpresa), 0) from TabEmpresa te)+1, ") .
				"'" . $ARazaoSocial . "'," .
				"'" . $ANomeFantasia . "'," .
				" '" . $ACNPJ . "', " .
				" '" . $AServidor_DB . "', " .
				" '" . $ANome_DB . "', " .
				" '" . $AUsuario_DB . "', " .
				" '" . $ASenha_DB . "', " .
				" '" . $AEhSistemaVarejo . "' " .
				")";
		
		$ObjRet = new MensagemRetorno();
		if ($this->ExecSQL($ASql)) {
			$ObjRet->retorno = 1;
			$ObjRet->mensagem = "";
		}
		else {
			$ObjRet->retorno = 0;
			$ObjRet->mensagem = $this->getLastMessage();
		}
		return $this->getJSONFromObj($ObjRet);
	}
}
