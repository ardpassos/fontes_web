<?php
include ("cadBase.php");
// Para chamar o link de troca de vers�o, cuidar para ser uma nova sess�o no browser
// ou fazer login pelo cadlogin.php antes para definir a base de dados a ser atualizada
// http://localhost/demo/cad.php?-2=passos_teste&cad=100123&act=0
// http://localhost/demo/cad.php?-2=passos_teste&cad=100123&act=0

class cadUpdateDB extends cadBase {
    
    private $FLastMessageError = "";
    private $FLastCodVersao = 0;
    private $FLastCodUpdate = 0;
    
    private $FLastCodVersaoUpdated = 0;
    private $FLastCodUpdateUpdated = 0;
    
    
    function setLastDBVersion(){
        try {       
            $stmt = $this->FCon->prepare(strtolower("Select * from tabversao ".
                " where CodVersao = (Select Max(CodVersao) ".
                "order by CodUpdate desc "));
            $stmt->execute();
            while ( $dados = $stmt->fetch() ){
              $this->FLastCodVersao = $dados["CodVersao"];
              $this->FLastCodUpdate = $dados["CodUpdate"];
            }
        }
        catch  (Exception $e) {
            $this->FLastCodVersao = 0;
            $this->FLastCodUpdate = 0;
        }
    }
    
    function updateVersao($_ACodVersao, $_ACodUpdate){
        $this->ExecDDLinDB(" insert into TabVersao (CodVersao, CodUpdate)".
            " Values (" . $_ACodVersao . ", " . $_ACodUpdate .")", 0, 0);
        $this->FLastCodVersaoUpdated = $_ACodVersao;
        $this->FLastCodUpdateUpdated = $_ACodUpdate;
        return true;
    }
    
    function ExecDDLinDB($_ASql, $_ACodVersao, $_ACodUpdate) {
        $AResult = false;
        try {
            $stmt = $this->FCon->prepare(strtolower($_ASql));
            $stmt->execute();
            
            if ($_ACodVersao > 0)
                $this->updateVersao($_ACodVersao, $_ACodUpdate);
                $AResult = true;
        }
        catch (Exception $e) {
            $this->FLastMessageError = $e->getMessage();
        }
        return $AResult;
    }
    
    function createTableVersao(){
        $ACodVersao = 1;
        $ACodUpdate = 1;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                $this->ExecDDLinDB("Create Table TabVersao ".
                    "(".
                    "  CodVersao Integer not null,".
                    "  CodUpdate Integer,".
                    "  constraint pk_Versao primary key(CodVersao, CodUpdate) ".
                    ")", $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function createTabFunc() {
        $ACodVersao = 1;
        $ACodUpdate = 2;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->createTableVersao())
                    $this->ExecDDLinDB("Create table tabfunc" .
                        "(" .
                        "  CodFunc integer not null," .
                        "  NomeFunc VarChar(255)," .
                        "  constraint pk_Func primary key(CodFunc)" .
                        ")", $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function createTabTipoAnimais(){
        $ACodVersao = 1;
        $ACodUpdate = 3;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->createTabFunc())
                    $this->ExecDDLinDB("Create table tabtipoanimais" .
                        "(" .
                        "  CodTipoAnimal integer not null," .
                        "  TipoAnimal VarChar(255)," .
                        "  constraint pk_TipoAnimal primary key(CodTipoAnimal)" .
                        ")", $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function createTabFuncaoFunc(){
        $ACodVersao = 1;
        $ACodUpdate = 4;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->createTabTipoAnimais())
                    $this->ExecDDLinDB("Create table TabFuncaoFunc " .
                        "(" .
                        "  CodFuncaoFunc integer not null," .
                        "  FuncaoFunc VarChar(255)," .
                        "  constraint pk_FuncaoFunc primary key(CodFuncaoFunc)" .
                        ")", $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function updateTabFunc () {
        $ACodVersao = 1;
        $ACodUpdate = 5;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->createTabFuncaoFunc())
                    $this->ExecDDLinDB("alter table tabfunc " .
                        " add CPF varchar(40), " .
                        " add CodFuncaoResp Integer, " .
                        " add Email varchar(255) ", $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function createTabUF(){
        $ACodVersao = 1;
        $ACodUpdate = 6;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->updateTabFunc())
                    $this->ExecDDLinDB("Create table TabUf " .
                        "(" .
                        "  CodUF integer not null," .
                        "  UF VarChar(255)," .
                        "  constraint pk_UF primary key(CodUF)" .
                        ")", $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function createTabCidade(){
        $ACodVersao = 1;
        $ACodUpdate = 7;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->createTabUF())
                    $this->ExecDDLinDB("Create table TabCidade " .
                        "(" .
                        "  CodCidade integer not null," .
                        "  Cidade VarChar(255)," .
                        "  constraint pk_Cidade primary key(CodCidade)" .
                        ")", $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function createTabGrupoEmpresa(){
        $ACodVersao = 1;
        $ACodUpdate = 8;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->createTabCidade())
                    $this->ExecDDLinDB("Create table TabGrupoEmpresa " .
                        "(" .
                        "  CodGrupoEmpresa integer not null," .
                        "  GrupoEmpresa VarChar(255)," .
                        "  constraint pk_GrupoEmpresa primary key(CodGrupoEmpresa)" .
                        ")", $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function createTabEmpresa () {
        $ACodVersao = 1;
        $ACodUpdate = 9;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->createTabGrupoEmpresa())
                    $this->ExecDDLinDB("Create table TabEmpresa " .
                        "(" .
                        "  CodEmpresa integer not null," .
                        "  RazaoSocial VarChar(255)," .
                        "  NomeFantasia VarChar(255)," .
                        
                        "  Cnpj VarChar(40)," .
                        "  InscricaoEstadual VarChar(40)," .
                        "  Endereco VarChar(255)," .
                        "  Numero Integer," .
                        "  Complemento VarChar(255)," .
                        "  Bairro VarChar(255)," .
                        "  CodCidade Integer," .
                        "  CEP VarChar(15)," .
                        "  Telefone VarChar(40)," .
                        "  Fax VarChar(40)," .
                        "  site VarChar(1024)," .
                        
                        "  CodFuncResp Integer," .
                        
                        "  CodGrupoEmpresa Integer," .
                        "  Logo blob," .
                        
                        "  constraint pk_Empresa primary key(CodEmpresa)" .
                        ")", $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function updateTabCidadeUF () {
        $ACodVersao = 1;
        $ACodUpdate = 10;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->createTabEmpresa())
                    $this->ExecDDLinDB("alter table TabCidade " .
                        " add CodUF Integer ", $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function updateTabFuncUser () {
        $ACodVersao = 1;
        $ACodUpdate = 11;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->updateTabCidadeUF())
                    $this->ExecDDLinDB("alter table TabFunc " .
                        " add UserName VarChar(40), " .
                        " add Password VarChar(40) ", $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function updateTabFuncInsAdmin () {
        $ACodVersao = 1;
        $ACodUpdate = 12;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->updateTabFuncUser())
                    $this->ExecDDLinDB("Insert into TabFunc (CodFunc, NomeFunc, UserName, Password)" .
                        " Values ( " .
                        "         (Select Coalesce(Max(CodFunc), 0) from TabFunc)+1, " .
                        "         'Admin', " .
                        "         'admin', " .
                        "         'admin' " .
                        "        ) ", $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function updateDBUTF8() {
        $ACodVersao = 1;
        $ACodUpdate = 13;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->updateTabFuncInsAdmin())
                    $this->ExecDDLinDB("SET CLIENT_ENCODING TO 'UTF8' ", $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function createTabRaca() {
        $ACodVersao = 1;
        $ACodUpdate = 14;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->updateDBUTF8())
                    $this->ExecDDLinDB("Create table TabRaca " .
                        "( " .
                        "  CodRaca Integer not null," .
                        "  Raca VarChar(255)," .
                        "  constraint pk_Raca primary key (CodRaca)" .
                        ")", $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function createTabCor() {
        $ACodVersao = 1;
        $ACodUpdate = 15;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->createTabRaca())
                    $this->ExecDDLinDB("Create table TabCor " .
                        "( " .
                        "  CodCor Integer not null," .
                        "  Cor VarChar(255)," .
                        "  constraint pk_Cor primary key (CodCor)" .
                        ")", $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function createTabAnimal() {
        $ACodVersao = 1;
        $ACodUpdate = 16;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->createTabCor())
                    $this->ExecDDLinDB("Create table TabAnimal " .
                        "( " .
                        "  CodAnimal Integer not null," .
                        "  CodEmpresa Integer," .
                        "  NomeBatismo VarChar(255)," .
                        "  DataNascimento TimeStamp," .
                        "  CodRaca Integer," .
                        "  Sexo VarChar(1)," . //M=Macho F=F�mea
                        "  CodPai Integer," .
                        "  CodMae Integer," .
                        "  NumRP VarChar(40)," .
                        "  NumRD VarChar(40)," .
                        "  CodCor Integer," .
                        "  Destaque VarChar(1)," .
                        "  Ativo VarChar(1)," .
                        "  constraint pk_Animal primary key (CodAnimal)" .
                        ")", $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function deleteAnimalMaiorDezoito() {
        $ACodVersao = 1;
        $ACodUpdate = 17;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->createTabAnimal())
                    $this->ExecDDLinDB("delete from TabAnimal where CodAnimal > 18", $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function deleteAnimalMaiorDezoito1() {
        $ACodVersao = 1;
        $ACodUpdate = 18;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->deleteAnimalMaiorDezoito())
                    $this->ExecDDLinDB("delete from TabAnimal where CodAnimal > 18", $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function createTabAgendaInsem() {
        $ACodVersao = 1;
        $ACodUpdate = 19;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->deleteAnimalMaiorDezoito1())
                    $this->ExecDDLinDB("Create table TabAgendaInsem " .
                        "( " .
                        "  CodAgendaInsem Integer not null," .
                        "  DataPrevista TimeStamp," .
                        "  DataRealizada TimeStamp," .
                        "  DataVerificacao TimeStamp," .
                        "  Status varchar(1)," . // A=Agenda R=Realizada F=Finalizada
                        "  CodFuncVeterinario Integer," .
                        "  constraint pk_AgendaInsem primary key (CodAgendaInsem)" .
                        ")", $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function createTabAnimalInsem() {
        $ACodVersao = 1;
        $ACodUpdate = 20;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->createTabAgendaInsem())
                    $this->ExecDDLinDB("Create table TabAnimalInsem " .
                        "( " .
                        "  CodInsem Integer not null," .
                        "  CodAgendaInsem Integer," .
                        "  CodAnimal Integer," .
                        "  DataInsem TimeStamp," .
                        "  DataVerificacao TimeStamp," .
                        "  Status varchar(1)," . //A=Agenda I=Inseminada P=Prenha F=Falha G=Ganhou
                        "  CodPai Integer," .
                        "  CodMae Integer," .
                        "  Prenha varchar(1)," . //S=Sim N=N�o
                        "  DataPrevNasc TimeStamp," .
                        "  DataNasc TimeStamp," .
                        "  CodAnimalNasceu Integer," .
                        "  constraint pk_AnimalInsem primary key (CodInsem)" .
                        ")", $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function AlteraTabRacaPeriodoPrenhez() {
        $ACodVersao = 1;
        $ACodUpdate = 21;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->createTabAnimalInsem())
                    $this->ExecDDLinDB("alter table TabRaca " .
                        "  add NumDiasPrenhez Integer",
                        $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function AlteraTabAgendaInsemEmpresa() {
        $ACodVersao = 1;
        $ACodUpdate = 22;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->AlteraTabRacaPeriodoPrenhez())
                    $this->ExecDDLinDB("alter table TabAgendaInsem " .
                        "  add CodEmpresa Integer",
                        $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function alterTabAnimalInsemAgenda() {
        $ACodVersao = 1;
        $ACodUpdate = 23;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->AlteraTabAgendaInsemEmpresa())
                    $this->ExecDDLinDB("alter table TabAnimalInsem " .
                        "  drop CodAgendaInsem," .
                        "  add CodAgenda Integer",
                        $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    
    function createTabPC() {
        $ACodVersao = 1;
        $ACodUpdate = 24;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->alterTabAnimalInsemAgenda())
                    $this->ExecDDLinDB("create table TabPC " .
                        "( CODPC Integer not null, " .
                        "  PC varchar(255), " .
                        "  RD varchar (1), " .
                        " constraint pk_TabPC primary key (CODPC) " .
                        ")",
                        $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function createTabCRP() {
        $ACodVersao = 1;
        $ACodUpdate = 25;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->createTabPC())
                    $this->ExecDDLinDB("create table TabCRP " . //CRP = ContasReceberPagar
                        "( CodCRP Integer not null, " .
                        "  RP varchar (1), " .
                        "  CodPC Integer, " .
                        "  NumDoc VarChar(255), " .
                        "  Parcela Integer, " .
                        "  Status varchar (1), " .
                        "  DataLcto TimeStamp, " .
                        "  DataVcto TimeStamp, " .
                        "  Valor Float, " .
                        "  ValorPendente Float, " .
                        " constraint pk_TabCRP primary key (CODCRP) " .
                        ")",
                        $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function createTabPgtoCRP() {
        $ACodVersao = 1;
        $ACodUpdate = 26;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->createTabCRP())
                    $this->ExecDDLinDB("create table TabPgtoCRP " .
                        "( CodPgtoCRP Integer not null, " .
                        "  CodCRP Integer, " .
                        "  DataPgto TimeStamp, " .
                        "  Valor Float, " .
                        "  Tipo Varchar(1), " . //(Total / Parcial)
                        "  Status Varchar(1), " . //(Ativo / Cancelada)
                        "  DataCanc TimeStamp, " .
                        " constraint pk_TabPgtoCRP primary key (CODPGTOCRP) " .
                        ")",
                        $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    
    function createTabMF() {
        $ACodVersao = 1;
        $ACodUpdate = 27;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->createTabPgtoCRP())
                    $this->ExecDDLinDB("create table TabMF " .
                        "( CodMF Integer not null, " .
                        "  RP Varchar(1), " . //(Receber / Pagar)
                        "  DataMF TimeStamp, " .
                        "  NumDoc VarChar(255), " .
                        "  Parcela Integer, " . //(Receber / Pagar)
                        "  CodPC Integer, " . //(Receber / Pagar)
                        "  Valor Float, " .
                        "  Status Varchar(1), " . //(Ativo / Cancelada)
                        "  DataCanc TimeStamp, " .
                        "  CodPgtoCRP Integer, " .
                        " constraint pk_TabMF primary key (CODMF) " .
                        ")",
                        $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function alterTabEmpresaSchema() {
        $ACodVersao = 1;
        $ACodUpdate = 28;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->createTabMF())
                    $this->ExecDDLinDB("alter table TabEmpresa " .
                        "  add SchemaName VarChar(255) ",
                        $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function alterTabEmpresaEhClienteFornec() {
        $ACodVersao = 1;
        $ACodUpdate = 29;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->alterTabEmpresaSchema())
                    $this->ExecDDLinDB("alter table TabEmpresa " .
                        "  add EhCliente VarChar(1), " .
                        "  add EhFornec VarChar(1) ",
                        $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function createTabPessoa () {
        $ACodVersao = 1;
        $ACodUpdate = 30;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->alterTabEmpresaEhClienteFornec())
                    $this->ExecDDLinDB("Create table TabPessoa " .
                        "(" .
                        "  CodPessoa integer not null," .
                        "  Nome VarChar(255)," .
                        
                        "  TipoPessoa VarChar(1)," .
                        "  RazaoSocial VarChar(255)," .
                        "  RG VarChar(40)," .
                        "  CPF VarChar(40)," .
                        "  Cnpj VarChar(40)," .
                        "  InscricaoEstadual VarChar(40)," .
                        
                        "  Endereco VarChar(255)," .
                        "  Numero Integer," .
                        "  Complemento VarChar(255)," .
                        "  Bairro VarChar(255)," .
                        "  CodCidade Integer," .
                        "  CEP VarChar(15)," .
                        "  Telefone VarChar(40)," .
                        "  Fax VarChar(40)," .
                        "  site VarChar(1024)," .
                        
                        "  EhCliente VarChar(1)," .
                        "  EhFornec VarChar(1)," .
                        "  constraint pk_Pessoa primary key(CodPessoa)" .
                        ")", $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function alterTabCRPCodPessoa() {
        $ACodVersao = 1;
        $ACodUpdate = 31;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->createTabPessoa())
                    $this->ExecDDLinDB("alter table TabCRP " .
                        "  add CodPessoa Integer ",
                        $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function alterTabMFCodPessoa() {
        $ACodVersao = 1;
        $ACodUpdate = 32;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->alterTabCRPCodPessoa())
                    $this->ExecDDLinDB("alter table TabMF " .
                        "  add CodPessoa Integer ",
                        $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function alterTabEmpresaSchemaActive() {
        $ACodVersao = 1;
        $ACodUpdate = 33;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->alterTabMFCodPessoa())
                    $this->ExecDDLinDB("alter table TabEmpresa " .
                        "  add SchemaNameActive VarChar(255) ",
                        $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function alterTabEmpresaCodProduto() {
        $ACodVersao = 1;
        $ACodUpdate = 34;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->alterTabEmpresaSchemaActive())
                    $this->ExecDDLinDB("alter table TabEmpresa " .
                        "  add CodProduto VarChar(2), " .
                        "  add ModuloFazenda VarChar(1), " .
                        "  add ModuloAgenda VarChar(1), " .
                        "  add ModuloFinanceiro VarChar(1) ",
                        $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function createTabRecursoAg () {
        $ACodVersao = 1;
        $ACodUpdate = 35;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->alterTabEmpresaCodProduto())
                    $this->ExecDDLinDB("Create table TabRecursoAg " .
                        "(" .
                        "  CodRecursoAg integer not null," .
                        "  DescRecursoAg VarChar(255)," .
                        "  CodFuncionario Integer," .
                        "  HoraInicioAgenda time," .
                        "  HoraFimAgenda time," .
                        "  DiasAmostragem integer," .
                        "  constraint pk_RecursoAg primary key(CodRecursoAg)" .
                        ")", $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function createTabAgenda () {
        $ACodVersao = 1;
        $ACodUpdate = 36;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->createTabRecursoAg())
                    $this->ExecDDLinDB("Create table TabAgenda " .
                        "(" .
                        "  CodAgenda integer not null," .
                        "  CodRecursoAg integer not null," .
                        "  DataHora timestamp," .
                        "  DescAgenda varchar(255)," .
                        "  constraint pk_Agenda primary key(CodAgenda)" .
                        ")", $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function insertTabRecursoAg () {
        $ACodVersao = 1;
        $ACodUpdate = 37;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->createTabAgenda())
                    $this->ExecDDLinDB("insert into TabRecursoAg " .
                        "           (CodRecursoAg, DescRecursoAg, CodFuncionario, HoraInicioAgenda, HoraFimAgenda, DiasAmostragem) " .
                        "    Values (1, 'Geral', 1, '08:00:00', '23:00:00', 5)",
                        $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function alterTabRecursoAgIntervalo() {
        $ACodVersao = 1;
        $ACodUpdate = 38;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->insertTabRecursoAg())
                    $this->ExecDDLinDB("alter table TabRecursoAg " .
                        "  add Intervalo time ",
                        $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function updateTabRecursoAgIntervalo() {
        $ACodVersao = 1;
        $ACodUpdate = 39;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->alterTabRecursoAgIntervalo())
                    $this->ExecDDLinDB("Update TabRecursoAg set Intervalo = '00:30:00'",
                        $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function alterTabAgendaDataHora() {
        $ACodVersao = 1;
        $ACodUpdate = 40;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->updateTabRecursoAgIntervalo())
                    $this->ExecDDLinDB("Alter table TabAgenda " .
                        " drop DataHora, " .
                        " add Data Date, " .
                        " add Hora Time",
                        $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function alterTabFuncCodClienteCob() {
    	$ACodVersao = 1;
    	$ACodUpdate = 41;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->alterTabAgendaDataHora())
    					$this->ExecDDLinDB("Alter table tabfunc " .
    							" add CodClienteCobranca integer ",
    							$ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function alterTabFuncEmpresa() {
    	$ACodVersao = 1;
    	$ACodUpdate = 42;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->alterTabFuncCodClienteCob())
    					$this->ExecDDLinDB("Alter table tabfunc " .
    							" add codempresa integer, ".
    							" add ehadministrador varchar(1) ",
    							$ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function CreateTabUHs() {
    	$ACodVersao = 1;
    	$ACodUpdate = 43;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->alterTabFuncEmpresa())
    					$this->ExecDDLinDB("create table tabuhs".
                                           "( ".
                                           "  codemp integer," . 
    							           "  coduh integer," . 
    							           "  descricao varchar(255)," . 
    							           "  ehaluguel varchar(1)," . 
    							           "  valoraluguel numeric(15,2)," . 
    							           "  ehcond varchar(1)," . 
    							           "  valorcond numeric(15,2)," . 
    							           "  numpessoasuh numeric(15,2)," . 
    							           "  constraint pk_uhs primary key (coduh)" . 
    							           ") ",
    							         $ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function CreateTabDespFixas() {
    	$ACodVersao = 1;
    	$ACodUpdate = 44;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->CreateTabUHs())
    					$this->ExecDDLinDB("create table TabDespFixas".
    							"( ".
    							"  codemp integer," .
    							"  coddespesa integer," .
    							"  descricao varchar(255)," .
    							"  valorPadrao numeric(15,2)," .
    							"  ehluz varchar(1)," .
    							"  TipoRateioluz varchar(1)," .
    							"  ehGaz varchar(1)," .
    							"  TipoRateioGaz varchar(1)," .
    							"  ehAgua varchar(1)," .
    							"  TipoRateioAgua varchar(1)," .
    							"  constraint pk_despfixas primary key (coddespesa)" .
    							") ",
    							$ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function CreateTabPeriodoApuracao() {
    	$ACodVersao = 1;
    	$ACodUpdate = 45;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->CreateTabDespFixas())
    					$this->ExecDDLinDB("create table TabPeriodoApuracao".
    							"( ".
    							"  codemp integer," .
    							"  CodPeriodo integer," .
    							"  descricao varchar(255)," .
    							"  DataInicio date," .
    							"  DataFim date," .
    							"  QtdeConsumoLuz numeric(15,6)," .
    							"  ValorTotalLuz numeric(15,2)," .
    							"  ValorUnLuz numeric(15,6)," .
    							"  ValorAdBandAmarela numeric(15,2)," .
    							"  ValorAdBandVermelha numeric(15,2)," .
    							"  ValorCosip numeric(15,2)," .
    							"  QtdeConsumoAgua numeric(15,6)," .
    							"  ValorTotalAgua numeric(15,2)," .
    							"  ValorRateioGas numeric(15,2)," .
    							"  constraint pk_periodoapuracao primary key (codPeriodo)" .
    							") ",
    							$ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function CreateTabLctoGas() {
    	$ACodVersao = 1;
    	$ACodUpdate = 46;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->CreateTabPeriodoApuracao())
    					$this->ExecDDLinDB("create table TabLctoGas".
    							"( ".
    							"  codemp integer," .
    							"  CodLctoGas integer," .
    							"  CodPeriodo integer," .
    							"  DataLeitura date," .
    							"  CodUH integer," .
    							"  ValorLeitura numeric(15,4)," .
    							"  ValorUltimaLeitura numeric(15,4)," .
    							"  constraint pk_lctogas primary key (CodLctoGas)" .
    							") ",
    							$ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function CreateTabLctoLuz() {
    	$ACodVersao = 1;
    	$ACodUpdate = 46;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->CreateTabLctoGas())
    					$this->ExecDDLinDB("create table TabLctoLuz".
    							"( ".
    							"  codemp integer," .
    							"  CodLctoLuz integer," .
    							"  CodPeriodo integer," .
    							"  DataLeitura date," .
    							"  CodUH integer," .
    							"  ValorLeitura numeric(15,4)," .
    							"  ValorUltimaLeitura numeric(15,4)," .
    							"  constraint pk_lctoluz primary key (CodLctoLuz)" .
    							") ",
    							$ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function CreateTabLctoAgua() {
    	$ACodVersao = 1;
    	$ACodUpdate = 46;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->CreateTabLctoLuz())
    					$this->ExecDDLinDB("create table TabLctoAgua".
    							"( ".
    							"  codemp integer," .
    							"  CodLctoAgua integer," .
    							"  CodPeriodo integer," .
    							"  DataLeitura date," .
    							"  CodUH integer," .
    							"  ValorLeitura numeric(15,4)," .
    							"  ValorUltimaLeitura numeric(15,4)," .
    							"  constraint pk_lctoagua primary key (CodLctoAgua)" .
    							") ",
    							$ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function CreateTabDespesasUH() {
    	$ACodVersao = 1;
    	$ACodUpdate = 47;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->CreateTabLctoAgua())
    					$this->ExecDDLinDB("create table TabDespesasUH".
    							"( ".
    							"  codemp integer," .
    							"  CodDespesaUH integer," .
    							"  CodPeriodo integer," .
    							"  DataLcto date," .
    							"  DataDespesa date," .
    							"  CodUH integer," .
    							"  DescricaoDespesa Varchar(255)," .
    							"  Valor numeric(15,2)," .
    							"  constraint pk_despesasuh primary key (CodDespesaUH)" .
    							") ",
    							$ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function CreateTabExecuting() {
    	$ACodVersao = 1;
    	$ACodUpdate = 48;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->CreateTabDespesasUH())
    					$this->ExecDDLinDB("create table tabexecuting " .
                                           "  (codexec integer not null, " .
                                           "     state integer not null, " .
                                           "      guid varchar(80), " .
                                           "   primary key (codexec)) ",
    							$ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    function InitTabExecuting() {
    	$ACodVersao = 1;
    	$ACodUpdate = 49;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->CreateTabExecuting())
    					$this->ExecDDLinDB("insert into tabexecuting values (1, 0, '') ",
    							$ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function AlterTabLctoLuzMedidor() {
    	$ACodVersao = 1;
    	$ACodUpdate = 50;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->InitTabExecuting())
    					$this->ExecDDLinDB("alter table TabLctoLuz".
    							" add codmedidor integer",
    							$ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function CreateTabSolicitaContato() {
    	$ACodVersao = 1;
    	$ACodUpdate = 51;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->AlterTabLctoLuzMedidor())
    					$this->ExecDDLinDB("create table tabsolicitacontato ".
    							" ( codsolicitacontato integer, ".
    							"  nome varchar(255), ".
    							"  email varchar(255), ".
    							"  ddd varchar(4), ".
    							"  fone varchar(40), ".
    							"  obs varchar(255)," .
    							"  constraint pk_solicitacontato primary key (codsolicitacontato)". 
    							" )",
    							$ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function AlterTabSolicitaContatoData() {
    	$ACodVersao = 1;
    	$ACodUpdate = 51;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->CreateTabSolicitaContato())
    					$this->ExecDDLinDB("alter table tabsolicitacontato".
    							" add datahora timestamp",
    							$ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function AlterTabUHsUsuario() {
    	$ACodVersao = 1;
    	$ACodUpdate = 52;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->AlterTabSolicitaContatoData())
    					$this->ExecDDLinDB("alter table tabuhs".
    							" add senha varchar(20) ",
    							$ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function CreateTabAreaComum() {
    	$ACodVersao = 1;
    	$ACodUpdate = 53;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->AlterTabUHsUsuario())
    					$this->ExecDDLinDB("create table tabareacomum ".
    							" ( codac integer, ".
    							"  descricao varchar(255), ".
    							"  obsaoreservar varchar(255)," .
    							"  codemp integer," .
    							"  constraint pk_areacomum primary key (codac)".
    							" )",
    							$ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function CreateTabACPeriodos() {
    	$ACodVersao = 1;
    	$ACodUpdate = 54;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->CreateTabAreaComum())
    					$this->ExecDDLinDB("create table tabacperiodos ".
    							" ( codacperiodo integer, ".
    							"  descricao varchar(255), ".
    							"  horaini time," .
    							"  horafim time," .
    							"  valorreserva numeric(15,2)," .
    							"  constraint pk_acperiodos primary key (codacperiodo)".
    							" )",
    							$ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function CreateTabReservasAC() {
    	$ACodVersao = 1;
    	$ACodUpdate = 55;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->CreateTabACPeriodos())
    					$this->ExecDDLinDB("create table tabreservasac ".
    							" ( codreservaac integer, ".
    							"  usuario varchar(40), ".
    							"  codac integer, ".
    							"  data date," .
    							"  codperiodoac integer, ".
    							"  valorreserva numeric(15,2)," .
    							"  constraint pk_reservasac primary key (codreservaac)".
    							" )",
    							$ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function AlterTabUHsDataInicio() {
    	$ACodVersao = 1;
    	$ACodUpdate = 56;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->CreateTabReservasAC())
    					$this->ExecDDLinDB("alter table tabuhs".
    							" add datainicio date ",
    							$ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function CreateTabRelPeriodoApuracao() {
    	$ACodVersao = 1;
    	$ACodUpdate = 57;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->AlterTabUHsDataInicio())
    					$this->ExecDDLinDB("create table tabrelperiodoapuracao " .
										   "( " .
											"  codigo integer NOT NULL AUTO_INCREMENT , " .
											"  codemp integer, " .
											"  codperiodo integer, " .
											"  coduh integer, " .
											"  descricao varchar(255), " .
											"  valor numeric (15,2), " .
											"  tiporegistro varchar(2), " .
											"  constraint pk_relperiodoapuracao primary key (codigo) " .
											")",
    							$ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function AlterTabACPeriodosCodAC() {
    	$ACodVersao = 1;
    	$ACodUpdate = 58;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->CreateTabRelPeriodoApuracao())
    					$this->ExecDDLinDB("alter table tabacperiodos".
    							" add codac integer ",
    							$ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function AlterTabReservasACAcertaCodACPeriodo() {
    	$ACodVersao = 1;
    	$ACodUpdate = 59;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->AlterTabACPeriodosCodAC())
    					$this->ExecDDLinDB("alter table tabreservasac".
    							" drop codperiodoac, ".
    							" add codacperiodo integer ",
    							$ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function AlterTabUHsContato() {
    	$ACodVersao = 1;
    	$ACodUpdate = 60;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->AlterTabReservasACAcertaCodACPeriodo())
    					$this->ExecDDLinDB("alter table tabuhs".
    							" add nomecontato varchar(255), " . 
    							" add emailcontato varchar(255), " .
    							" add fonecontato varchar(40) ",
    							$ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function AlterTabEmpConDB() {
    	$ACodVersao = 1;
    	$ACodUpdate = 61;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->AlterTabUHsContato())
    					$this->ExecDDLinDB("alter table tabempresa".
    							" add servidor_db varchar(255), " .
    							" add nome_db varchar(255), " .
    							" add usuario_db varchar(255), " .
    							" add senha_db varchar(255) ",
    							$ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function AlterTabEmpSistVarejo() {
    	$ACodVersao = 1;
    	$ACodUpdate = 62;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->AlterTabEmpConDB())
    					$this->ExecDDLinDB("alter table tabempresa".
    							" add ehsistemavarejo varchar(1) ",
    							$ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function dropTables(){
        $this->ExecDDLinDB("drop table TabVersao",0,0);
        $this->ExecDDLinDB("drop table TabFunc",0,0);
        $this->ExecDDLinDB("drop table Tabtipoanimais",0,0);
        $this->FLastMessageError = "";
    }
    
    function executaTrocaVersao() {
    	return $this->AlterTabEmpSistVarejo();
    }
    
    function setToSchema($_ASchemaName){
        $this->FLastMessage = "";
        //$ASql =  " SET search_path TO \"" . _ASchemaName.toLowerCase() . "\"";
        $ASql =  " use '". strtolower($_ASchemaName) ."'";
        try {
            $stmt = $this->FCon->prepare($ASql);
            $stmt->execute();
        }
        catch (Exception $e) {
            $this->FLastMessage = $e.getMessage();
        }
        return $this->getLastMessage();
    }
    
    function updateDBSchema($_ASchemaName){
        $AResult = "";
        $this->setToSchema($_ASchemaName);
        try{
            $this->setLastDBVersion();
            
            //    dropTables();
            if ($this->executaTrocaVersao())
                $AResult = "";
            else
                $AResult = "[{\"retorno\":0,\"mensagem\":" . $this->FLastMessageError . "}]";
        }
        finally{
            $this->setToSchema("public");
        }
        return $AResult;
    }
    
    function updateDB(){
        $this->FLastMessage = $this->updateDBSchema("id8202109_wp_e6d799528f216a95b17e3a886e298411");
/*      
        $FLastMessage = "";
        $ASchemas = "";
        $ASql =  " select schema_name " .
                 "   from information_schema.schemata " .
                 "  where (schema_name like 'passos_%') " .
                 "     or (shema_name = '' " .
                 "  order by schema_name";
        try {
            $AQuery = $this->FCon->prepare($ASql);
            $AQuery->execute();
            while ($row = $AQuery->fetch(PDO::FETCH_ASSOC)) {
                foreach( $row as $field => $value )
                {
                    $AFieldName = $field;
                    $AFieldValue = $value;
                    
                    $AExec = $this->updateDBSchema($AFieldValue);
                    if ($AExec != ""){
                        $this->FLastMessage = "[{\"retorno\":0,\"mensagem\":" . $this->FLastMessageError . "---" . $AFieldValue . "}]";
                        break;
                    }
                    else
                        $ASchemas .= ":" . $AFieldValue;
                }
                
            }
        }
        catch (Exception $e) {
            $this->FLastMessage = $e.getMessage();
        }
        */
        
        if ($this->FLastMessage == ""){
            $ObjRet = new MensagemRetorno();
            $ObjRet->retorno = 1;
            $ObjRet->mensagem = " - Versao Atual: " . $this->FLastCodVersao .
            " - Update Atual: " . $this->FLastCodUpdate .
            " - Versao Atualizada: " . $this->FLastCodVersaoUpdated .
            " - Update Atualizado: " . $this->FLastCodUpdateUpdated;
            $this->FLastMessage = $this->getJSONFromObj($ObjRet);
        }
        return $this->getLastMessage();
    }
}
