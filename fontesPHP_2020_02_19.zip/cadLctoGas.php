<?php

class cadLctoGas extends cadBase {
	

	function getTabela(){
		return "TabLctoGas";
	}
	
	function getCampoChave(){
		return "CodLctoGas";
	}
	
		
	function getCons() {
		$this->FOrderBy = "order by CodPeriodo, CodUH";
		$this->FSqlInitial = "Select * from tabLctoGas";
		$this->addFieldDef("CodEmp", "C�d. Empresa", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("CodLctoGas", "C�d. Per�odo", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("CodPeriodo", "Descri��o", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("DataLeitura", "Data ini", constCads::FIELD_DATE, "", "");
		$this->addFieldDef("CodUH", "Data fim", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("ValorLeitura", "Qtde consumo luz", constCads::FIELD_FLOAT, "", "");
		$this->addFieldDef("ValorUltimaLeitura", "Valor luz", constCads::FIELD_FLOAT, "", "");
		return parent::getCons();
	}
	
	function keyExists($_ACod) {
		$AResult = false;
		try {
			$AQuery = $this->OpenSQLToResultSet(strtolower("Select Count(*) as NumRec from TabLctoGas where CodLctoGas = ") . $_ACod);
			if ( $dados = $AQuery->fetch() ){
				$AResult = ($dados["NumRec"] > 0);
			}
			else
				$AResult = false;
		}
		catch (Exception $e) {
			$AResult = false;
		}
		return $AResult;
	}
	
	function getPost(){
		$ACodEmp = $this->getParameterInt( "CodEmp");
		$ACodLctoGas = $this->getParameterInt( "CodLctoGas");
		$ACodPeriodo = $this->getParameterInt( "CodPeriodo");
		
		$ADataLeitura = $this->getParameterFloat( "DataLeitura");
		$ACodUH = $this->getParameterInt( "CodUH");
		
		$AValorLeitura = $this->getParameterFloat( "ValorLeitura");
		$AValorUltimaLeitura = $this->getParameterFloat( "ValorUltimaLeitura");
		
		$ASql = strtolower("Update TabLctoGas set CodPeriodo = '") . $ACodPeriodo . "', " .
				" DataLeitura = '" . $ADataLeitura . "', " .
				" CodUH = " . $ACodUH. ", " .
				" ValorLeitura = " . $AValorLeitura . ", " .
				" ValorUltimaLeitura = " . $AValorUltimaLeitura . ", " .
				" CodEmp = " . $ACodEmp .
				" where CodLctoGas = " . $ACodLctoGas;
		
		if ($this->ExecSQL($ASql))
			return "[{\"retorno\":1}]";
			else
				return "[{\"retorno\":0," .
				"\"mensagem\":\"" . $this->getLastMessage() . "\"}]";
	}
	
	
	function getInsert(){
		$ACodEmp = $this->getParameterInt( "CodEmp");
		$ACodPeriodo = $this->getParameterInt( "CodPeriodo");
		
		$ADataLeitura = $this->getParameterFloat( "DataLeitura");
		$ACodUH = $this->getParameterInt( "CodUH");
		
		$AValorLeitura = $this->getParameterFloat( "ValorLeitura");
		$AValorUltimaLeitura = $this->getParameterFloat( "ValorUltimaLeitura");
		
		
		$ASql = strtolower("Insert into TabLctoGas (CodLctoGas, CodEmp, CodPeriodo, DataLeitura, CodUH, ValorLeitura, ValorUltimaLeitura) " .
				"Values (" .
				"(Select Coalesce(Max(tlg.CodLctoGas), 0) from TabLctoGas tlg)+1, ") .
				"  " . $ACodEmp . "," .
				" " . $ACodPeriodo . "," .
				" '" . $ADataLeitura . "', " .
				" " . $ACodUH . ", " .
				" " . $AValorLeitura . ", " .
				" " . $AValorUltimaLeitura . " " .
				")";
		
		$ObjRet = new MensagemRetorno();
		if ($this->ExecSQL($ASql)) {
			$ObjRet->retorno = 1;
			$ObjRet->mensagem = "";
		}
		else {
			$ObjRet->retorno = 0;
			$ObjRet->mensagem = $this->getLastMessage();
		}
		return $this->getJSONFromObj($ObjRet);
	}
}
