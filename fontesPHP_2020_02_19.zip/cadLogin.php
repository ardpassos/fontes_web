<?php
//http://localhost/demo/cad.php?-2=passos_teste&cad=-1&act=c&sys=c&codemp=0&username=ale&password=ale
// Exemplo de empresa configurada para acessar outra base � o codemp=4
//http://localhost/demo/cad.php?-2=passos_teste&cad=-1&act=c&sys=c&codemp=4&username=admin&password=admin
include_once ("recordFields.php");
include_once("cadBase.php");

class cadLogin extends cadBase {
   
	//este login � na nova base de dados configurada no cadastro de empresas da base de dados base
	function EfetuaLoginEmpresa($_ARec, $AUserName, $APassword){
		$AFiltro = " where apelidofunc = '" . $AUserName . "' " .
				"   and senha = '" . $APassword . "'";
		$ASql = "Select codfuncionario, nome, apelidofunc, senha " .
				"  from tabfuncionarios ";
		$ASql = strtolower($ASql) . $AFiltro;
		$AQuery = $this->OpenSQLToResultSet($ASql);
		try {
			$this->clearRecords();
			while ($row = $AQuery->fetch(PDO::FETCH_ASSOC)) {
				$_ARec['username'] = $row['apelidofunc'];
				$_ARec['password'] = $row['senha'];
				$_ARec['senha'] = $row['senha'];
				$row['codempresa'] =$_SESSION['codemp'];
				$row['ehadministrador'] = 'n';
				$row['ehsistemavarejo'] =$_SESSION['ehsistemavarejo'];
				//array_push($row, {"ehsistemavarejo" => $_SESSION['ehsistemavarejo']});
				//print_r($row);
				parent::AddRecord($row);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}	
		
	}
	
	function clearSession(){
		if (isset($_SESSION)){
			session_reset();
			session_destroy();
			session_start();
		}
	}
	function setSession($_ARec, $ACodEmp, $AUserName, $APassword){
		if ($_ARec != null) {
			if (!isset($_SESSION))
				session_start();
				$_SESSION['codemp'] = $ACodEmp;
				$_SESSION['usuario'] = $AUserName;
				$_SESSION['senha'] = $APassword;
				$_SESSION['servidor_db'] = $_ARec["servidor_db"];
				$_SESSION['nome_db'] = $_ARec["nome_db"];
				$_SESSION['usuario_db'] = $_ARec["usuario_db"];
				$_SESSION['senha_db'] = $_ARec["senha_db"];
				$_SESSION['ehsistemavarejo'] = $_ARec["ehsistemavarejo"];

				if ($_ARec["nome_db"] != "")
				{
					$this->FConObj = new ConDB();
					$this->FConObj->startDB();
					$this->FCon = $this->FConObj->getCon();
				}
		}
	}    
	
	function AddRecord($_ARec){
		if (!isset($_SESSION))
			session_start();
		$_SESSION['codusersistcobranca'] = $_ARec["codclientecobranca"];
		
		parent::AddRecord($_ARec);
    }
    
    function getConsTabFunc($AUserName, $APassword){
    	$AFiltro = " where tf.UserName = '" . $AUserName . "' " .
      				"   and tf.Password = '" . $APassword . "'";
    	
    	$ASql = "Select tf.CodFunc, " .
		      	"  tf.NomeFunc, " .
		      	"  tf.UserName, " .
		      	"  tf.Password, " .
		      	"  Coalesce(CodClienteCobranca, -1) as CodClienteCobranca, " .
		      	"  (Select Max(tv.CodVersao) " .
		      	"     from TabVersao tv " .
		      	"  ) as CodVersao, " .
		      	"  (Select Max(tv.codUpdate) " .
		      	"     from TabVersao tv " .
		      	"    where tv.CodVersao = (Select Max(tv1.CodVersao) " .
		      	"                            from TabVersao tv1 " .
		      	"                         ) " .
		      	"  ) as CodUpdate, " .
		      	"  tf.codempresa, te.nomefantasia as descempresa, " .
		      	"  te.servidor_db, " .
		      	"  te.nome_db, " .
		      	"  te.usuario_db, " .
		      	"  te.senha_db, " .
		      	"  te.ehsistemavarejo, " .
		      	"  'n' as ehusuariouh, " .
		      	"  'n' as ehcond, " .
		      	"  tf.ehadministrador " .
		    	"  from tabfunc tf ".
		    	"  left join tabempresa te ".
		    	"         on te.codempresa = tf.codempresa ";
    	$ASql = strtolower($ASql) . $AFiltro;
    	
    	$this->OpenSQLCons($ASql);
    	return $this->getJSONRecords();
    }
    
    function getConsTabUHs($ACodEmp, $AUserName, $APassword){
    	
   	
    	$AFiltro = " where tuh.codemp = " . $ACodEmp . 
			    	"   and tuh.descricao = '" . $AUserName . "' " .
			      	"   and tuh.senha = '" . $APassword . "'";
    	
    	$ASql = "Select tuh.CodUH as CodFunc, " .
		      	"  tuh.descricao as NomeFunc, " .
		      	"  tuh.descricao as UserName, " .
		      	"  tuh.senha as Password, " .
		      	"  0 as CodClienteCobranca, " .
		      	"  (Select Max(tv.CodVersao) " .
		      	"    from TabVersao tv " .
		      	"  ) as CodVersao, " .
		      	"  (Select Max(tv.codUpdate) " .
		      	"     from TabVersao tv " .
		      	"    where tv.CodVersao = (Select Max(tv1.CodVersao) " .
		      	"                            from TabVersao tv1 " .
		      	"                         ) " .
		      	"  ) as CodUpdate, " .
		      	"  tuh.codemp as codempresa, te.nomefantasia as descempresa, " .
		      	"  te.servidor_db, " .
		      	"  te.nome_db, " .
		      	"  te.usuario_db, " .
		      	"  te.senha_db, " .
		      	"  te.ehsistemavarejo, " .
		      	"  's' as ehusuariouh, " .
		      	"  tuh.ehcond, " .
		      	"  'n' as ehadministrador " .
		    	"  from tabuhs tuh ".
		    	"  left join tabempresa te ".
		    	"         on te.codempresa = tuh.codemp ";
    	$ASql = strtolower($ASql) . $AFiltro;
    	
    	$this->OpenSQLCons($ASql);
    	return $this->getJSONRecords();
    }
    
    function getLoginFromEmpresa($ACodEmp, $AUserName, $APassword){
    	$AReturn = false;
      	$ASql = "Select * " .
      			"  from tabempresa te ".
      			" where te.codempresa = ". $ACodEmp;
    	$AQuery = $this->OpenSQLToResultSet($ASql);
    	
    	try {
    		$this->clearRecords();
    		while ($row = $AQuery->fetch(PDO::FETCH_ASSOC)) {
    			if ($row['nome_db'] != '')
    			{
    				$AReturn = true;
    				
    				$this->setSession($row, $ACodEmp, $AUserName, $APassword);
    				$this->EfetuaLoginEmpresa($row, $AUserName, $APassword);
    			}
    		}
    	} catch (Exception $e) {
    		echo $e->getMessage();
    	}
    	return $AReturn;
    }
    
    function getCons() {
        //$ASchemaName = $_GET[constCads::SCHEMA_NAME];
    	//$AUserName = $_POST["username"];
    	//$APassword = $_POST["password"];    	
    	$ACodEmp = $_GET["codemp"];
    	$AUserName = $_GET["username"];
    	$APassword = $_GET["password"];
    	$this->clearSession();    	
    	
    	if ((strcmp($AUserName, "") == 0) && $this->ehProducao()){
    		$AUserName = "admin";
    		$APassword = "admin";
    	}
    	if ($ACodEmp == 0)
    	  return $this->getConsTabFunc($AUserName, $APassword);
    	else {
    		if ($this->getLoginFromEmpresa($ACodEmp, $AUserName, $APassword))
    			return $this->getJSONRecords();
    		else
    			return $this->getConsTabUHs($ACodEmp, $AUserName, $APassword);
    	}
    }
}
