import { GeralServiceComponent } from './../geral-service/geral-service.component';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpParams, HttpClient } from '@angular/common/http';
import { Component, OnInit, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-form-base',
  template: '<div></div>'
})
export class FormBaseComponent implements OnInit {

  public urlServer: string = "/demo/cad.php?-2=passos_teste&-3=4";//&cad=-1&act=c
  public cadID: number = -1;
  FiltrosCons: any = [];
  FiltrosConsLookup: any = [];
  records: any = [];
  activeRecord: any;
  cadInsUpd = "";
  cadAutoPost = false;
  salvando_registro = false;
  excluindo_registro = false;
  codigoExcluindo: String = "-1";
  actionRec = {"filtro":"0", "rec": ""};
  descCons: any[] = [];

  constructor(public http: HttpClient, public router: Router, public GS: GeralServiceComponent, public route: ActivatedRoute) {
  }

  ngOnInit() {
    this.inicializaCad();
    this.GS.execEventEmitter.subscribe(actionRecGS => {
      this.actionRec = actionRecGS;
      this.execActionRec();
    });
  }

  inicializaCad() {
  }

  execActionRec(){
    
  }

  getURLSistema(){
    return "&sys=v";
  }

  getURLServerBase(){
    return this.urlServer + this.getURLSistema();
  }
  getURLServer() {
    return this.getURLServerBase() + "&cad=" + this.cadID;
  }

  getFiltrosCons(_ALkp: boolean) {
    let AResult: String = "";
    let AFiltrosCons = [];
    if (_ALkp)
      AFiltrosCons = this.FiltrosConsLookup;
    else
      AFiltrosCons = this.FiltrosCons;
    for (let filtro of AFiltrosCons) {
      if (!filtro.filtrourl)
        AResult += filtro.nomecampo + "|" + filtro.comp + "|" + filtro.valor + "|[";
      else
        AResult += "&" + filtro.nomecampo + "=" + filtro.valor;
    }
    return AResult;
  }

  getURLServerCons() {
    return this.getURLServer() + "&act=c&filtro=" + this.getFiltrosCons(false);
  }
  
  afterRecebeDados(){
    
  }

  recebedados(_ADados: any[]) {
    this.records = _ADados;
    this.afterRecebeDados();
  }

  ExecCons() {
    params: HttpParams;
    let params = new HttpParams();
    //params = params.append('username', userName);
    this.http.post<any[]>(this.getURLServerCons(), { params }).
      subscribe(data => this.recebedados(data));
  }  

  getAct() {
    return "&act=" + this.cadInsUpd;
  }

  AfterPostCad(){
  }
  getValueFromEditableComp(_AValue: String) {
    if (_AValue === undefined)
      return "";
    else
      return _AValue;
  }
  getURLServerPostAuto(){
    let AResult = "";
    for (var i = 0; i < this.descCons.length; i++) {
      AResult += "&" + this.descCons[i].nomecampo + "=" + this.getValueFromEditableComp(this.activeRecord[this.descCons[i].nomecampo]);
    }
    return this.getURLServer() + this.getAct() + AResult;
  }  
  getURLServerPost() {
    return this.getURLServer() + this.getAct();
  }
  recebedadosPost(_ADados: any[]) {
    this.activeRecord = _ADados["retorno"];
    this.cadInsUpd = "i";
    this.AfterPostCad();
    this.salvando_registro = false;
  }
  ExecPost() {
    this.salvando_registro = true;
    params: HttpParams;
    let params = new HttpParams();
    //params = params.append('username', userName);
    let AURL = "";
    if (this.cadAutoPost)
      AURL = this.getURLServerPostAuto();
    else
      AURL = this.getURLServerPost();

    this.http.post<any[]>(AURL, { params }).
      subscribe(data => this.recebedadosPost(data));
  }

  getFieldKey(){
    return this.descCons[0].nomecampo;
  }
  AfterDelCad(){
    this.ExecCons();
  }
  recebedadosDel(_ADados: any[]) {
    this.excluindo_registro = false;
    this.AfterDelCad();
  }  
  getURLServerDel() {
    this.codigoExcluindo =  this.getValueFromEditableComp(this.activeRecord[this.getFieldKey()]);
    return this.getURLServer() + this.getAct() + "&" + this.getFieldKey() + "=" + 
          this.codigoExcluindo;
  }
  ExecDel() {
    params: HttpParams;
    let params = new HttpParams();
    let AURL = this.getURLServerDel();
    this.http.post<any[]>(AURL, { params }).
      subscribe(data => this.recebedadosDel(data));
  }
  excluirregistro(_ARec) {
    this.excluindo_registro = true;
    this.cadInsUpd = "d";
    this.activeRecord = _ARec;
    this.ExecDel();
  }

  AfterInsert(){

  }
  novoRec() {
    this.cadInsUpd = "i";
    this.activeRecord = [];
    this.AfterInsert();
  }

  insertDescCons(_ANomeCampo: string, _ADescCampo: string, _AMostrarNaCons: boolean,
    _AType: string, _ADescTabCad: string = "Geral", _AMostrarCad: boolean = true,
    _AEhBoolean = false, _AEhObrigatorio = false) {
    let ASize = "s4";

    let AInputType = _AType;
    if (_AType == "float") { 
      AInputType = "number";
    }
    else if (_AType == "img") { 
      AInputType = "file";
    }

    let ARec = {
      nomecampo: _ANomeCampo.toLowerCase(),
      desccampo: _ADescCampo,
      mostrarcons: _AMostrarNaCons,
      inputtype: AInputType,
      size: ASize,
      descTabCad: _ADescTabCad,
      mostrarCad: _AMostrarCad,
      type: _AType,
      ehboolean: _AEhBoolean ,
      ehlookup: false,
      ehimg: _AType==="img",
      readonly: false,
      LookupNameValues: null, // {"desc": "Descrição", "valor": "1"}
      ehObrigatorio: _AEhObrigatorio
    };

    this.descCons.push(ARec);
  }

}
