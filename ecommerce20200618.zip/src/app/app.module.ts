import { InjectScript } from './produto/inject.script';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { MenuSuperiorComponent } from './menu-superior/menu-superior.component';
import { AreaGeralComponent } from './area-geral/area-geral.component';
import { MenuLateralComponent } from './menu-lateral/menu-lateral.component';
import { FormBaseComponent } from './form-base/form-base.component';
import { HttpClientModule } from '@angular/common/http';
import { LoginUsuarioComponent } from './login-usuario/login-usuario.component';
import { CarrinhoComprasComponent } from './carrinho-compras/carrinho-compras.component';
import { AppRoutingModule } from './app-routing.module';
import { SobreComponent } from './sobre/sobre.component';
import { PrincipalComponent } from './principal/principal.component';
import { GeralServiceComponent } from './geral-service/geral-service.component';
import { VerProdutoComponent } from './area-geral/ver-produto/ver-produto.component';
import { ProdutoComponent } from './produto/produto.component';
import { UsuariovEndComponent } from './usuariov-end/usuariov-end.component';

@NgModule({
  declarations: [
    AppComponent,
    MenuSuperiorComponent,
    AreaGeralComponent,
    MenuLateralComponent,
    FormBaseComponent,
    LoginUsuarioComponent,
    CarrinhoComprasComponent,
    SobreComponent,
    PrincipalComponent,
    GeralServiceComponent,
    VerProdutoComponent,
    ProdutoComponent,
    InjectScript,
    UsuariovEndComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    AppRoutingModule
  ],
  exports: [RouterModule],
  providers: [GeralServiceComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
