import { HttpParams } from '@angular/common/http';
import { FormBaseComponent } from './../form-base/form-base.component';
import { Component, OnInit, Output, Input, EventEmitter } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-carrinho-compras',
  templateUrl: './carrinho-compras.component.html',
  styleUrls: ['./carrinho-compras.component.css']
})
export class CarrinhoComprasComponent extends FormBaseComponent implements OnInit {

  recordsresumo = [];
  msgPedidoRealizado = "";
  msgSemItens = "";
  codEndereco = "-1";

  inicializaCad() {
    super.inicializaCad();
    this.cadID = 26;
    this.refrerhDados();
  }
 
  refrerhDados(){
    if (this.GS.usuarioLogado.codusuario > 0){
      this.ExecCons();
      this.execConsResumo();
    }
  }
  
  selecionaCodEnd($_ACodEnd){
    this.codEndereco = $_ACodEnd;
    console.log("endereço: " + this.codEndereco);
  }

  execActionRec(){
    if (this.GS.actionRec.filtro == "6"){
      this.refrerhDados();
    }
  }

  getURLServerCons() {
    return this.getURLServer() + "&act=c&codusuario=" + this.GS.usuarioLogado.codusuario;
  }
  
  getURLImg(_ARec){
    return this.getURLServerBase() + "&cad=23&act=gi&codimg=" + _ARec.codimg;
  } 

  setMyStylesDivCor(_AItemGrade) {
    let styles = {
      'background-color': _AItemGrade.refhexa,
      'font-weight': 'bold'
    };
    return styles;
  }
  
  //tirar do carrinho
  recebedadosTirar(_ADados: any) {
    this.salvando_registro = false;
    if (_ADados[0].retorno != null) {
      if (_ADados[0].retorno > 0){
        this.activeRecord["qtde"] = 0;
        this.activeRecord["msgexcluido"] = "Excluído do carrinho!";
        
        let ARec = {"filtro":"6.1", "rec": ""};
        this.GS.execute(ARec); // atualiza qtde do menu soperior 
      }
    }
  }
  getURLServerTirarCarr() {
    return this.urlServer + this.getURLSistema() + "&cad=26";
  }
  getURLServerTirarAct(){
    let AURL = this.getURLServerTirarCarr() + this.getAct();
    AURL = AURL + 
            "&codusuario=" + this.activeRecord["codusuario"] +
            "&coditemgrade=" + this.activeRecord["coditemgrade"];
    return AURL;
  }

  ExecTirar() {
    params: HttpParams;
    let params = new HttpParams();
    let AURL = "";
    AURL = this.getURLServerTirarAct();
    this.http.post<any[]>(AURL, { params }).
      subscribe(data => this.recebedadosTirar(data));
  }
  
  tirarDoCarrinho(_ARec){
    this.cadInsUpd = "dc";
    this.activeRecord = _ARec;
    this.ExecTirar();
  }  

//Resumo do carrinho
  recebedadosConsR(_ADados: any) {
    this.recordsresumo = _ADados;

    if (this.recordsresumo.length > 0){
      if (this.recordsresumo[0].qtde == 0){
        this.msgSemItens = "Nenhum item encontrado no seu carrinho!";
      }
      else {
        this.msgSemItens = "";
      }
    }
    else {
      this.msgSemItens = "";
    }
  }
  getURLServerConsR() {
    return this.urlServer + this.getURLSistema() + "&cad=26";
  }
  getURLServerActConsR(){
    let AURL = this.getURLServerConsR() + this.getAct();
    AURL = AURL + "&codusuario=" + this.GS.usuarioLogado['codusuario'];
    return AURL;
  }

  ExecConsR() {
    params: HttpParams;
    let params = new HttpParams();
    let AURL = "";
    AURL = this.getURLServerActConsR();
    this.http.post<any[]>(AURL, { params }).
      subscribe(data => this.recebedadosConsR(data));
  }

  execConsResumo(){
    this.cadInsUpd = "cr";
    this.ExecConsR();
  }  
//Fim do Resumo do carrinho

//Gerar pedido
  recebedadosGerarPedido(_ADados: any) {
    if (_ADados[0].retorno == 1){
      let ARec = {"filtro":"6.1", "rec": ""};
      this.GS.execute(ARec); // atualiza qtde do menu soperior 
      this.refrerhDados();
      this.msgPedidoRealizado = "Pedido realizado com sucesso!"; //Você pode vizualisá-lo em Meus pedidos!
    }
  }
  getURLServerGerarPedido() {
    return this.urlServer + this.getURLSistema() + "&cad=26";
  }
  getURLServerActGerarPedido(){
    let AURL = this.getURLServerGerarPedido() + this.getAct();
    AURL = AURL + "&codusuario=" + this.GS.usuarioLogado['codusuario'] + 
                  "&codend=" + this.codEndereco;
    return AURL;
  }

  ExecGerarPedido() {
    params: HttpParams;
    let params = new HttpParams();
    let AURL = "";
    AURL = this.getURLServerActGerarPedido();
    this.http.post<any[]>(AURL, { params }).
      subscribe(data => this.recebedadosGerarPedido(data));
  }

  GerarPedido(){
    if (this.codEndereco == "-1"){
      alert("Favor selecionar um endereço para entrega!");
    }
    else
    {
      this.cadInsUpd = "gp";
      this.ExecGerarPedido();
    }
  }  
// Fim Gerar pedido

// Resumo valor total
  getResumoValorTotal(){
    if (this.recordsresumo.length > 0){
      return this.recordsresumo[0].valortotal;
    }
    else {
      return 0;
    }
  }
  getResumoQtde(){
    if (this.recordsresumo.length > 0){
      return this.recordsresumo[0].qtde;
    }
    else {
      return 0;
    }
  }

  onExitQtde(_ARec){
    if (_ARec['qtdeestoque'] < _ARec['qtde']) {
      _ARec['qtde'] = _ARec['qtdeestoque'];
    }
    else if (_ARec['qtde'] < 1) {
      _ARec['qtde'] = 1;
    }
  }

  execVerProduto(_ARec){
    this.router.navigateByUrl('/produto/' + _ARec['codinsumo']);
  }
}
