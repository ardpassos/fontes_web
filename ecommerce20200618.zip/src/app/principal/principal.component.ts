import { Component, OnInit } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-principal',
  templateUrl: './principal.component.html',
  styleUrls: ['./principal.component.css']
})
export class PrincipalComponent implements OnInit {
  ehconsulta = true;
  ehlogin = false;
  ehcarrinhocompras = false;
  usuarioLogado: any = [];
  filtroClassificacao: any = null;
  filtroCategoria: any = null;
  //nomeBehaviorSubjectPai = new BehaviorSubject<any>([]);
  

  ngOnInit() {
  }

  getDescFiltroClassificacao(){
    return " | " + this.filtroClassificacao.desc;
  }
  getDescFiltroCategoria(){
    return " | " + this.filtroCategoria.categoria;
  }

  getFiltrarClassificacao(){
    return (this.filtroClassificacao != null);
  }
  getFiltrarCategoria(){
    return (this.filtroCategoria != null);
  }
  callbackAddFiltro(_ARec){
    if (_ARec.filtro === "1") {
      this.filtroClassificacao = _ARec.rec;
    }
    else if (_ARec.filtro === "2"){
      this.filtroCategoria = _ARec.rec;
    }
    else if (_ARec.filtro === "4"){
      this.desabilitatodos();
      this.ehlogin = true;
    }
    else if (_ARec.filtro === "5"){
      this.desabilitatodos();
      this.ehconsulta = true;
    }
    else if (_ARec.filtro === "6"){
      this.desabilitatodos();
      this.ehconsulta = true;
      this.usuarioLogado = _ARec;
    }
    else if (_ARec.filtro === "7"){
      this.desabilitatodos();
      this.ehcarrinhocompras = true;
    }
  }

  desabilitatodos(){
    this.ehconsulta = false;
    this.ehlogin = false;
    this.ehcarrinhocompras = false;
  }

}
