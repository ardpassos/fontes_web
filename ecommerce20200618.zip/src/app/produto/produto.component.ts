import { InjectScript } from './inject.script';
import { HttpParams } from '@angular/common/http';
import { FormBaseComponent } from './../form-base/form-base.component';
import { Component, OnInit, Injectable } from '@angular/core';
import { ActivatedRoute, Routes } from '@angular/router';

@Component({
  selector: 'app-produto',
  templateUrl: './produto.component.html',
  styleUrls: ['./produto.component.css']
})

export class ProdutoComponent extends FormBaseComponent implements OnInit {

  recProduto = [];
  CodProduto = 0;
  CodImg = -1;

  ngOnInit() {
    this.cadID = 23;

    this.route.params.subscribe( parametros => {
      if (parametros['produto']) {
        this.CodProduto = parametros['produto'];
        this.atualizaProduto();
      }
    });
    super.ngOnInit(); // registra o evento execActionRec para o contato com outros componentes
  }

  atualizaScript(){
      let inject = new InjectScript();
      inject.LoadScript('assets/js/zoomsl.js');
      inject.LoadScript('assets/js/script.js');
  }

  setMyStylesDivCor(_AItemGrade) {
    let styles = {
      'background-color': _AItemGrade.refhexa,
      'font-weight': 'bold'
    };
    return styles;
  }

  setImgAtiva(_AImg){
    this.CodImg = _AImg.codimg;
  }
  getURLImg(){
    let AUrl = this.getURLServer() + "&act=gi&codimg=-1";
    if (this.recProduto['imgs'] != null) {
      if (this.CodImg > -1) 
        AUrl = this.getURLServer() + "&act=gi&codimg=" + this.CodImg;
      else
        AUrl = this.getURLServer() + "&act=gi&codimg=" + this.recProduto['imgs'][0].codimg;
    }
    return AUrl;
  }
  getURLImgByRec(_AImg){
    let AUrl = this.getURLServer() + "&act=gi&codimg=" + _AImg.codimg;
    return AUrl;
  }

  //atualização do insumo
  recebedadosInsumo(_ADados) {
    let retorno = _ADados;
    this.recProduto = retorno[0];
    this.atualizaScript();
    console.log(this.recProduto);
  }  
  getURLServerProduto() {
    let AParams = this.route.params;

    return this.getURLServerBase() + "&cad=23&codinsumo=" + this.CodProduto;
  }
  getURLServerCons() {
    return this.getURLServerProduto() + this.getAct();
  }
  atualizaProdutoAtual() {
    this.cadInsUpd = "c";
    let AURL = this.getURLServerCons();
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosInsumo(data));
  }    
  atualizaProduto(){
    this.atualizaProdutoAtual();
  }

  
  //add carrinho
  recebedadosPost(_ADados: any) {
    this.salvando_registro = false;
    console.log(_ADados);
    console.log(_ADados[0].retorno);
    if (_ADados[0].retorno != null) {
      if (_ADados[0].retorno > 0){
        this.recProduto["msgadicionadocar"] = "Adicionado ao carrinho!";
        
        let ARec = {"filtro":"6.1", "rec": ""};
        this.GS.execute(ARec);
      }
    }
  }
  getURLServerInsCarr() {
    return this.urlServer + this.getURLSistema() + "&cad=26";
  }
  getURLServerPost(){
    let AURL = this.getURLServerInsCarr() + this.getAct();
    AURL = AURL + 
            "&codusuario=" + this.GS.usuarioLogado["codusuario"] +
            "&coditemgrade=" + this.activeRecord["coditem"] +
            "&qtde=" + this.activeRecord["qtdeadd"];
    return AURL;
  }
  campoEmBranco(_ACampo){
    return (this.activeRecord[_ACampo] == "") || (this.activeRecord[_ACampo] == null);
  }
  addCarrinho(_ARec){
    //this.msgerro = "";
    if ((this.GS.usuarioLogado["codusuario"] == null) || (this.GS.usuarioLogado["codusuario"] < 1)) {
      _ARec["msgerro"] = "Favor efetuar login para adicionar itens ao carrinho!"
    }
    else {
      this.cadInsUpd = "ac";

      _ARec.grade.forEach(itemgrade => {
        if (itemgrade.qtdeadd > 0){
          this.activeRecord = itemgrade;
          this.ExecPost();
        }
      });
    }  
  }  
  
}

