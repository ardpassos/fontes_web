import { OnInit, Component } from '@angular/core';

@Component({
    selector: 'app-inject-script',
    template: '<div></div>'
  })

export class InjectScript implements OnInit {

    ngOnInit(){

    }

    LoadScript(url: string) {
        const body = <HTMLDivElement>document.body;
        const script = document.createElement('script');
        script.innerHTML = '';
        script.src = url;
        script.async = false;
        script.defer = true;
        body.appendChild(script);
    }
  }