import { FormBaseComponent } from './../form-base/form-base.component';
import { Component, OnInit, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-usuariov-end',
  templateUrl: './usuariov-end.component.html',
  styleUrls: ['./usuariov-end.component.css']
})
export class UsuariovEndComponent extends FormBaseComponent implements OnInit {

  InsNovoEnd = false;
  codEndEntrega: String = "-1";
  @Output() callbackSelecionaCodEnd = new EventEmitter();

  ngOnInit() {
    this.cadID = 34;
    this.cadAutoPost = true;

    this.insertDescCons("codend", "Cód. Endereço", true, "number");
    this.insertDescCons("cep", "Cep", true, "text", "", true, false, true);
    this.insertDescCons("cidade", "Cidade", true, "text", "", true, false, true);
    this.insertDescCons("uf", "UF", false, "text", "", true, false, true);
    this.insertDescCons("rua", "Rua", false, "text", "", true, false, true);
    this.insertDescCons("numero", "Número", false, "number", "", true, false, true);
    this.insertDescCons("complemento", "Complemento", false, "text");
    this.insertDescCons("bairro", "Bairro", false, "text", "", true, false, true);
    
    super.ngOnInit(); 
    this.ExecCons();
  }

  afterRecebeDados(){
    if (this.records.length > 0){
      this.setCodEndEntrega(this.records[0].codend);
    }
    else
      this.setCodEndEntrega("-1");
  }

  getEndSelecionado(_ARec){
    let ARet = (this.codEndEntrega == _ARec.codend); 
    return ARet;
  }
  getExcluindo(_ARec){
    let ARet = this.excluindo_registro && (this.codigoExcluindo == _ARec.codend); 
    return ARet;
  }
  setNovoEnd(){
    this.InsNovoEnd = !this.InsNovoEnd;
    this.novoRec();
  }
  cancelarCadastro(){
    this.InsNovoEnd = false;
  }

  setCodEndEntrega(_ACodEnd){
    this.codEndEntrega = _ACodEnd;
    this.callbackSelecionaCodEnd.emit(this.codEndEntrega);
  }

  AfterPostCad(){
    this.InsNovoEnd = false;
    this.ExecCons();
  }

  getCamposSemPreencher(){
    let AResult = "";
    for (var i = 0; i < this.descCons.length; i++) {
      if (this.descCons[i].ehObrigatorio && (this.getValueFromEditableComp(this.activeRecord[this.descCons[i].nomecampo]) == ""))
        AResult += ", " + this.descCons[i].desccampo;
    }
    return AResult;
  }  

  salvarRegistro(){
    let ACamposBranco = this.getCamposSemPreencher();
    if (ACamposBranco != ""){
      alert("Os seguintes campos devem ser preenchidos: " + ACamposBranco);
    }
    else
      this.ExecPost();
  }
}
