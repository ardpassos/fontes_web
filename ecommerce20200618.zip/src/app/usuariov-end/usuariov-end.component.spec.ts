import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UsuariovEndComponent } from './usuariov-end.component';

describe('UsuariovEndComponent', () => {
  let component: UsuariovEndComponent;
  let fixture: ComponentFixture<UsuariovEndComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UsuariovEndComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UsuariovEndComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
