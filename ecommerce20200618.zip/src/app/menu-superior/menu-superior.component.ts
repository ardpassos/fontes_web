import { FormBaseComponent } from './../form-base/form-base.component';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { BehaviorSubject, Subscription } from 'rxjs';

@Component({
  selector: 'app-menu-superior',
  templateUrl: './menu-superior.component.html',
  styleUrls: ['./menu-superior.component.css']
})
export class MenuSuperiorComponent extends FormBaseComponent implements OnInit {

  public textFilter = "";
  nomeBehaviorSubjectSubscription: Subscription;
  usuarioLogado: any = [];  
  recBehaviorAtual = {"filtro":"0", "rec": ""};
  submenuAtivo = "";
  categPromoHomem = [];
  categPromoMulher = [];
  categHomem = [];
  categMulher = [];

  ngOnInit() {
    super.ngOnInit();
/*    this.nomeBehaviorSubjectSubscription = this.nomeBehaviorSubject.subscribe(valor => {
      this.refreshMenuSuperior(valor);
    });*/
    this.recBehaviorAtual = {"filtro":"0", "rec": ""};
    this.loadSessionLogado();
    this.atualizaCategHomem();
    this.atualizaCategMulher();
    this.atualizaCategPromoHomem();
    this.atualizaCategPromoMulher();
  }

  selectSubMenuAtivo(_ASubMenu){
    this.submenuAtivo = _ASubMenu;
  }

  execActionRec(){
    this.refreshMenuSuperior(this.actionRec);
  }

  getNomeFromStr(_ANome){
    let ANome = new String(_ANome);
    let APos = ANome.indexOf(" ");
    if (APos > -1) {
      ANome = ANome.substring(0, APos);
    }
    return ANome;
  }

  getQtdeCarrinho(){
    return this.usuarioLogado["qtdecarrinho"];
  }

  recebedadosLogado(_ADados) {
    let retorno = _ADados;
    if (this.recBehaviorAtual.filtro == "6.1"){ //atualização dos dados do usuário logado com qtde no carrinho
      this.usuarioLogado = retorno[0];
      this.GS.usuarioLogado = retorno[0];
      this.recBehaviorAtual.filtro = "0";
    }
    else if (this.recBehaviorAtual.filtro == "0"){
      if ((retorno != null)){
        let ARec = {"filtro":"6", "rec": retorno[0]};
        this.usuarioLogado = retorno[0];
        this.GS.usuarioLogado = retorno[0];
        this.GS.execute(ARec);
      }
      if (this.cadInsUpd == "eslg"){
        this.loginUsuario();
      }
    }
  }  
  getURLServerLoginUsuario() {
    return this.getURLServer() + this.getAct();
  }
  getSessionLogado() {
    this.cadInsUpd = "slg";
    let AURL = this.getURLServerLoginUsuario();
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosLogado(data));
  }    
  getExitSessionLogado() {
    this.cadInsUpd = "eslg";
    let AURL = this.getURLServerLoginUsuario();
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosLogado(data));
  }    
  loadSessionLogado(){
    this.cadID = 25;
    this.getSessionLogado();
  }

  refreshMenuSuperior(_ARec){
    this.recBehaviorAtual = _ARec;
    if (_ARec.filtro === "6") {
      this.usuarioLogado = _ARec.rec;
    }
    else if (_ARec.filtro === "6.1") {
      this.loadSessionLogado();
    }
  }

  setFiltroText(){
    this.GS.msg = this.textFilter;
    let ARec = {"filtro":"3", "rec": this.textFilter};
    this.GS.execute(ARec);
    
    //this.callbackAddFiltro.emit(ARec); // este método somente atualiza o app-component
    //this.nomeBehaviorSubject.next(ARec); // este método é que faz dispara o evento para o area-geral...
  }


  setFiltroMenuSup(_APromo, _AGenero, _ACodCateg){
    let ARecFiltro = {"promocao": _APromo, "genero": _AGenero, "codcategoria": _ACodCateg};
    console.log(ARecFiltro);
    this.GS.filtrosMenuSup = ARecFiltro;

    let ARec = {"filtro":"3.1", "rec": ARecFiltro};
    console.log(this.router.url);
    if (this.router.url == "/home")
      this.GS.execute(ARec);
    else
      this.paginaPrincipal(); // se não estiver na tela, irá entrar pegando os filtros do GS
    }

  loginUsuario(){
    this.router.navigate(['/login']);
  }
  paginaPrincipal(){
    this.router.navigate(['/home']);
  }
  setCarrinhoCompras(){
    this.router.navigate(['/carrinho']);
  }

  logoutUsuario(){
    this.recBehaviorAtual = {"filtro":"0", "rec": ""};
    this.getExitSessionLogado();
  }

  //url com cad 24 = menufiltros
  getURLServerFiltros() {
    return this.getURLServerBase() + "&cad=24";
  }

  //get Categorias Promoção Homem
  recebedadosPromoHomem(_ADados: any[]) {
    this.categPromoHomem = _ADados;
  }  
  getURLAtualizaPromoHomem() {
    return this.getURLServerFiltros() + "&act=gcph";
  }
  atualizaCategPromoHomem(){
    let AURL = this.getURLAtualizaPromoHomem();
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosPromoHomem(data));
  }

  //get Categorias Promoção Mulher
  recebedadosPromoMulher(_ADados: any[]) {
    this.categPromoMulher = _ADados;
  }  
  getURLAtualizaPromoMulher() {
    return this.getURLServerFiltros() + "&act=gcpm";
  }
  atualizaCategPromoMulher(){
    let AURL = this.getURLAtualizaPromoMulher();
    console.log(AURL);
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosPromoMulher(data));
  }

  //get Categorias Homem
  recebedadosHomem(_ADados: any[]) {
    this.categHomem = _ADados;
  }  
  getURLAtualizaHomem() {
    return this.getURLServerFiltros() + "&act=gch";
  }
  atualizaCategHomem(){
    let AURL = this.getURLAtualizaHomem();
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosHomem(data));
  }

  //get Categorias Mulher
  recebedadosMulher(_ADados: any[]) {
    this.categMulher = _ADados;
  }  
  getURLAtualizaMulher() {
    return this.getURLServerFiltros() + "&act=gcm";
  }
  atualizaCategMulher(){
    let AURL = this.getURLAtualizaMulher();
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosMulher(data));
  }

}
