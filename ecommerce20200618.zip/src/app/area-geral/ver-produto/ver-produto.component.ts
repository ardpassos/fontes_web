import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-ver-produto',
  templateUrl: './ver-produto.component.html',
  styleUrls: ['./ver-produto.component.css']
})
export class VerProdutoComponent extends FormBaseComponent implements OnInit {
  
  @Input() codInsumo: number = -1;
  @Input() recProduto = [];
  @Input() usuarioLogado = [];
  @Input() popup = false;
  @Output() callbackButton = new EventEmitter();

  ngOnInit() {
    this.cadID = 23;
    super.ngOnInit(); // registra o evento execActionRec para o contato com outros componentes
    if (this.recProduto == [])
      this.atualizaProduto();
  }
  
  getNameCarousel(_ARec){
    let ARet = _ARec.codinsumo;
    if (this.popup){
      ARet = ARet + "pop";
    }
    return ARet;
  }
  getURLImg(_ARec){
    return this.getURLServer() + "&act=gi&codimg=" + _ARec.codimg;
  }

  execVerProduto(_ARec){
    let actionRec = {"filtro":"v", "rec": _ARec};
    this.callbackButton.emit(actionRec);
    //document.getElementById('pop').style.display='block';
  }  

  //atualização do insumo
  recebedadosInsumo(_ADados) {
    let retorno = _ADados;
    this.recProduto = retorno[0];
  }  
  getURLServerProduto() {
    return this.getURLServerBase() + "&cad=23&codinsumo=" + this.codInsumo;
  }
  getURLServerCons() {
    return this.getURLServerProduto() + this.getAct();
  }
  atualizaProdutoAtual() {
    this.cadInsUpd = "c";
    let AURL = this.getURLServerCons();
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosInsumo(data));
  }    
  atualizaProduto(){
    this.atualizaProdutoAtual();
  }
  //fim da atualização do insumo
  
  //add carrinho
  recebedadosPost(_ADados: any) {
    this.salvando_registro = false;
    if (_ADados[0].retorno != null) {
      if (_ADados[0].retorno > 0){
        this.recProduto["msgadicionadocar"] = "Adicionado ao carrinho!";
        
        let ARec = {"filtro":"6.1", "rec": ""};
        this.GS.execute(ARec);
      }
    }
  }
  getURLServerInsCarr() {
    return this.urlServer + this.getURLSistema() + "&cad=26";
  }
  getURLServerPost(){
    let AURL = this.getURLServerInsCarr() + this.getAct();
    AURL = AURL + 
            "&codusuario=" + this.usuarioLogado["codusuario"] +
            "&coditemgrade=" + this.activeRecord["coditem"] +
            "&qtde=" + this.activeRecord["qtdeadd"];
    return AURL;
  }
  campoEmBranco(_ACampo){
    return (this.activeRecord[_ACampo] == "") || (this.activeRecord[_ACampo] == null);
  }
  addCarrinho(_ARec){
    //this.msgerro = "";
    if ((this.usuarioLogado["codusuario"] == null) || (this.usuarioLogado["codusuario"] < 1)) {
      _ARec["msgerro"] = "Favor efetuar login para adicionar itens ao carrinho!"
    }
    else {
      this.cadInsUpd = "ac";

      _ARec.grade.forEach(itemgrade => {
        if (itemgrade.qtdeadd > 0){
          this.activeRecord = itemgrade;
          this.ExecPost();
        }
      });
    }  
  }

  clickMostrarGrade(rec){
    if (rec["mostrargrade"] == "S")
      rec["mostrargrade"] = "N";
    else
      rec["mostrargrade"] = "S";
  }
  setMyStylesDivCor(_AItemGrade) {
    let styles = {
      'background-color': _AItemGrade.refhexa,
      'font-weight': 'bold'
    };
    return styles;
  }

  onExitQtde(_ARec){
    if (_ARec['qtdeestoque'] < _ARec['qtdeadd']) {
      _ARec['qtdeadd'] = _ARec['qtdeestoque'];
    }
    else if (_ARec['qtdeadd'] < 0) {
      _ARec['qtdeadd'] = 0;
    }
  }

  getHrefCarousel(_ARec){
    //    this.router.navigate(["#carouselExampleIndicators" + _ARec.codinsumo]);
        return "#carouselExampleIndicators" + _ARec.codinsumo;
  }

}
