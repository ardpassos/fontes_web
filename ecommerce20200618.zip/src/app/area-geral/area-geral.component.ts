import { FormBaseComponent } from '../form-base/form-base.component';
import { Component, OnInit, Input } from '@angular/core';
import { BehaviorSubject, Subscription } from 'rxjs';

@Component({
  selector: 'app-area-geral',
  templateUrl: './area-geral.component.html',
  styleUrls: ['./area-geral.component.css']
})
export class AreaGeralComponent extends FormBaseComponent implements OnInit {
  
  usuarioLogado: any = [];
  filtroText = "";
  filtrosMenuSup = {"promocao": '', "genero": '', "codcategoria": ''};
  msgerro = "";
  mostrarProdutoAtual = false;
  actionRec = {"filtro":"0", "rec": null};

  ngOnInit() {
    super.ngOnInit(); // registra o evento execActionRec para o contato com outros componentes
    this.ExecCons();
  }

  ocultarVerProduto(){
    this.mostrarProdutoAtual = false;
  }

  execCallback(_AactionRec){
    this.actionRec = _AactionRec;
    if (this.actionRec.filtro == "v"){
      this.execVerProduto(this.actionRec.rec);
    }
  }

  execVerProduto(_ARec){
    
    //this.activeRecord = _ARec;
    //this.mostrarProdutoAtual = true;
    ///asdfasfasdfafffffffffsssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss
    this.router.navigateByUrl('/produto/' + _ARec['codinsumo']);
  }

  execActionRec(){
    let ARec = this.actionRec;   
    if (ARec.filtro === "3"){
      this.filtroText = ARec.rec;
    }
    else if (ARec.filtro === "3.1"){
      this.GS.filtrosMenuSup = ARec.rec;
    }
    else if (ARec.filtro === "6"){
      this.usuarioLogado = ARec.rec;
    }
    else if (ARec.filtro === "6.1"){
      this.loadSessionLogado();
      return; // não atualizar
    }
    this.ExecCons();
  }

  inicializaCad() {
    super.inicializaCad();
  }

//loadsession

  recebedadosLogado(_ADados) {
    let retorno = _ADados;
    this.usuarioLogado = retorno[0];
    this.GS.usuarioLogado = retorno[0];
  }  
  getURLServerSession() {
    return this.getURLServerBase() + "&cad=25";
  }
  getURLServerLoginUsuario() {
    return this.getURLServerSession() + this.getAct();
  }
  getSessionLogado() {
    this.cadInsUpd = "slg";
    let AURL = this.getURLServerLoginUsuario();
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosLogado(data));
  }    
  loadSessionLogado(){
    this.getSessionLogado();
  }

//fim loadsession

  getURLServerCons(){
    let AUrl = super.getURLServerCons();
    if (!(this.GS.filtroClassificacao === null)) {
      if (this.GS.filtroClassificacao.codigo === "1")
        AUrl = AUrl + "&ordem=va";
      else if (this.GS.filtroClassificacao.codigo === "2")
        AUrl = AUrl + "&ordem=vd";
    }
    if (this.GS.filtroCategoria != null) {
      AUrl = AUrl + "&codcategoria=" + this.GS.filtroCategoria.codcategoria;
    }
    if (this.GS.filtroSubCategoria != null) {
      AUrl = AUrl + "&codsubcategoria=" + this.GS.filtroSubCategoria.codsubcategoria;
    }
    if ((this.filtroText != null) && (this.filtroText != "")) {
      AUrl = AUrl + "&filtrotext=" + this.filtroText;
    }
    if ((this.GS.filtrosMenuSup.codcategoria != "")) {
      AUrl = AUrl + "&codcategoria=" + this.GS.filtrosMenuSup.codcategoria;
    }
    if ((this.GS.filtrosMenuSup.genero != "")) {
      AUrl = AUrl + "&genero=" + this.GS.filtrosMenuSup.genero;
    }
    if ((this.GS.filtrosMenuSup.promocao != "")) {
      AUrl = AUrl + "&promocao=" + this.GS.filtrosMenuSup.promocao;
    }
    this.GS.filtrosMenuSup = {"promocao": '', "genero": '', "codcategoria": ''};
    return AUrl;
  }

  afterRecebeDados(){
     this.loadSessionLogado(); 
  }

  ExecCons(){
    this.cadID = 23;
    super.ExecCons();
  }

  getURLImg(_ARec){
    return this.getURLServer() + "&act=gi&codimg=" + _ARec.codimg;
  }
  
//add carrinho
  recebedadosPost(_ADados: any) {
    this.salvando_registro = false;
    if (_ADados[0].retorno != null) {
      if (_ADados[0].retorno > 0){
        this.activeRecord["msgadicionadocar"] = "Adicionado ao carrinho!";
        
        let ARec = {"filtro":"6.1", "rec": ""};
        this.GS.execute(ARec);
      }
    }
  }
  getURLServerInsCarr() {
    return this.urlServer + this.getURLSistema() + "&cad=26";
  }
  getURLServerPost(){
    let AURL = this.getURLServerInsCarr() + this.getAct();
    AURL = AURL + 
            "&codusuario=" + this.usuarioLogado["codusuario"] +
            "&coditemgrade=" + this.activeRecord["coditem"] +
            "&qtde=" + this.activeRecord["qtdeadd"];
    return AURL;
  }
  campoEmBranco(_ACampo){
    return (this.activeRecord[_ACampo] == "") || (this.activeRecord[_ACampo] == null);
  }
  addCarrinho(_ARec){
    //this.msgerro = "";
    if ((this.usuarioLogado["codusuario"] == null) || (this.usuarioLogado["codusuario"] < 1)) {
      _ARec["msgerro"] = "Favor efetuar login para adicionar itens ao carrinho!"
    }
    else {
      this.cadInsUpd = "ac";

      _ARec.grade.forEach(itemgrade => {
        if (itemgrade.qtdeadd > 0){
          this.activeRecord = itemgrade;
          this.ExecPost();
        }
      });
    }  
  }

  clickMostrarGrade(rec){
    if (rec["mostrargrade"] == "S")
      rec["mostrargrade"] = "N";
    else
      rec["mostrargrade"] = "S";
  }
  setMyStylesDivCor(_AItemGrade) {
    let styles = {
      'background-color': _AItemGrade.refhexa,
      'font-weight': 'bold'
    };
    return styles;
  }

  onExitQtde(_ARec){
    if (_ARec['qtdeestoque'] < _ARec['qtdeadd']) {
      _ARec['qtdeadd'] = _ARec['qtdeestoque'];
    }
    else if (_ARec['qtdeadd'] < 1) {
      _ARec['qtdeadd'] = 1;
    }
  }

  getHrefCarousel(_ARec){
//    this.router.navigate(["#carouselExampleIndicators" + _ARec.codinsumo]);
    return "#carouselExampleIndicators" + _ARec.codinsumo;
  }

}
//-2=passos_teste&-3=4&sys=v&cad=26&act=ac&codusuario=1&codproduto=1&qtde=1
//-2=passos_teste&-3=4&sys=v&cad=26&act=ac&codusuario=1&codproduto=1&qtde=1