import { ProdutoComponent } from './produto/produto.component';
import { CarrinhoComprasComponent } from './carrinho-compras/carrinho-compras.component';
import { LoginUsuarioComponent } from './login-usuario/login-usuario.component';
import { PrincipalComponent } from './principal/principal.component';
import { SobreComponent } from './sobre/sobre.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  { path: '', component: PrincipalComponent }, 
  { path: 'sobre', component: SobreComponent },
  { path: 'login', component: LoginUsuarioComponent },
  { path: 'carrinho', component: CarrinhoComprasComponent },
  { path: 'home', component: PrincipalComponent },
  { path: 'produto/:produto', component: ProdutoComponent }

  /*
Para acessar o link direto no browser, com parâmetros, 
como por exemplo um produto em específico,
é preciso alterar o .htaccess adicionando as seguintes linhas
.htaccess fica na pasta root do site ou na www/dist/ecommerce do wamp
https://angular.io/guide/deployment#routed-apps-must-fallback-to-indexhtml

      # If an existing asset or directory is requested go to it as it is
      RewriteCond %{DOCUMENT_ROOT}%{REQUEST_URI} -f [OR]
      RewriteCond %{DOCUMENT_ROOT}%{REQUEST_URI} -d
      RewriteRule ^ - [L]

      # If the requested resource doesn't exist, use index.html
      RewriteRule ^ /dist/ecommerce/index.html
  */
];

@NgModule({
  declarations: [],
  exports: [RouterModule],
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ]
})
export class AppRoutingModule { }
