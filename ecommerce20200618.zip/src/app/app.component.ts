import { GeralServiceComponent } from './geral-service/geral-service.component';
import { Component, OnInit } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';

//ng build --prod --base-href /dist/ecommerce/

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent  {
  title = 'ecommerce';
  filtroClassificacao: any = null;
  filtroCategoria: any = null;
  nomeBehaviorSubjectPai = new BehaviorSubject<any>([]);

  usuarioLogado: any = [];

  ehconsulta = true;
  ehlogin = false;
  ehcarrinhocompras = false;

  constructor(private router: Router, public GS: GeralServiceComponent) { 

  }

  getDescFiltroClassificacao(){
    return " | " + this.filtroClassificacao.desc;
  }
  getDescFiltroCategoria(){
    return " | " + this.filtroCategoria.categoria;
  }

  getFiltrarClassificacao(){
    return (this.filtroClassificacao != null);
  }
  getFiltrarCategoria(){
    return (this.filtroCategoria != null);
  }

  callbackAddFiltro(_ARec){
   /* if (_ARec.filtro === "1") {
      this.filtroClassificacao = _ARec.rec;
    }
    else if (_ARec.filtro === "2"){
      this.filtroCategoria = _ARec.rec;
    }
    else if (_ARec.filtro === "4"){
      this.desabilitatodos();
      this.ehlogin = true;
    }
    else if (_ARec.filtro === "5"){
      this.desabilitatodos();
      this.ehconsulta = true;
    }
    else if (_ARec.filtro === "6"){
      this.desabilitatodos();
      this.ehconsulta = true;
      this.usuarioLogado = _ARec;
    }
    else if (_ARec.filtro === "7"){
      this.desabilitatodos();
      this.ehcarrinhocompras = true;
    }*/
  }

  desabilitatodos(){
    this.ehconsulta = false;
    this.ehlogin = false;
    this.ehcarrinhocompras = false;
  }
}
