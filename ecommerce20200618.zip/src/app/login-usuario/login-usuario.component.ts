import { HttpParams } from '@angular/common/http';
import { FormBaseComponent } from './../form-base/form-base.component';
import { Component, OnInit, Output, Input, EventEmitter } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-login-usuario',
  templateUrl: './login-usuario.component.html',
  styleUrls: ['./login-usuario.component.css']
})
export class LoginUsuarioComponent extends FormBaseComponent implements OnInit {

  usuariosSite = [];
  usuarioLogado = [];
  emailusuario = "";
  senhausuario = "";

  cadastroUsuario = false;
  loginUsuario = true;

  msgerro = "";
  msgcadastrado = "";
  msgerrologin = "";

  inicializaCad() {
    super.inicializaCad();
    this.cadID = 25;
    this.loadSessionLogado();
  }
  cadastrarUsuario(){
    this.cadastroUsuario = true;
    this.loginUsuario = false;
    this.activeRecord = [];
  }

  limparDadosLogin(){
    this.usuariosSite = [];
    this.usuarioLogado = [];
    this.emailusuario = "";
    this.senhausuario = "";
  
    this.cadastroUsuario = false;
    this.loginUsuario = true;
  
    this.msgerro = "";
    this.msgcadastrado = "";
    this.msgerrologin = "";
    }

  //load sessão logado
  getURLServerLoginSL() {
    return this.getURLServer() + this.getAct();
  }
  getSessionLogado() {
    this.cadInsUpd = "slg";
    let AURL = this.getURLServerLoginSL();
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosLogin(data));
  }    
  loadSessionLogado(){
    this.cadID = 25;
    this.getSessionLogado();
  }

  logoutVendedor(){
    this.cadInsUpd = "eslgv";
    let AURL = this.getURLServerLoginUsuario();
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosLogin(data));
  }
  //fim sessão logado

// login de usuário

  AfterLoginUsuario(){
  }
  recebedadosLogin(_ADados) {
    this.AfterLoginUsuario();
    let retorno = _ADados;
    console.log(this.cadInsUpd);
    if ((retorno.length > 0) && 
        ( (retorno[0].codfuncionario > -1) || (retorno[0].codusuario > 0) )
      ) {
      this.msgerrologin = "";
      let ARec = {"filtro":"6", "rec": retorno[0]};
      this.GS.execute(ARec);

      this.emailusuario = "";
      this.senhausuario = "";

      this.usuarioLogado = retorno[0];
      if (retorno[0].codusuario > 0)
        this.router.navigate(['/home']);
      else if (retorno[0].codfuncionario > -1){
        this.refreshDadosClientes();
      }
    }
    else if (this.cadInsUpd == "eslgv"){
      let ARec = {"filtro":"6", "rec": retorno[0]};
      this.GS.execute(ARec);
      this.limparDadosLogin();
    }
    else if (this.cadInsUpd != "slg"){
      this.msgerrologin = "Login inválido!";
    }
  }  
  getURLServerLoginUsuario() {
    return this.getURLServer() + this.getAct() + "&usuario=" + this.emailusuario +
          "&senha=" + this.senhausuario;
  }
  execLoginUsuario() {
    this.cadInsUpd = "ls";
    let AURL = this.getURLServerLoginUsuario();
    console.log(AURL);
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosLogin(data));
  }    
  
  fazerLoginUsuario(){
    if (this.emailusuario == "") {
      this.msgerrologin = "Usuário não informado!";
    }
    else if (this.emailusuario == "") {
      this.msgerrologin = "Senha não informada!";
    }
    else {
      this.execLoginUsuario();
    }
  }
  //fim da rotina de login

// cadastro de novo usuário
  recebedadosPost(_ADados: any[]) {
    super.recebedadosPost(_ADados);
    this.msgcadastrado = "Cadastro realizado com sucesso!"
    this.cadastroUsuario = false;
    this.loginUsuario = true; 
  }
  getURLServerPost(){
    let AURL = super.getURLServerPost();
    AURL = AURL + 
            "&nomeusuario=" + this.activeRecord["nomeusuario"] +
            "&usuario=" + this.activeRecord["usuario"] +
            "&senha=" + this.activeRecord["senha"] +
            "&celular=" + this.activeRecord["celular"];

    return AURL;
  }
  campoEmBranco(_ACampo){
    return (this.activeRecord[_ACampo] == "") || (this.activeRecord[_ACampo] == null);
  }
  efetivaCadastro(){
    this.msgerro = "";
    this.msgcadastrado = "";
    if (this.activeRecord["senha"] != this.activeRecord["repitasenha"]) {
      this.msgerro = "Senha deve ser igual ao campo de repetir a senha!"
    }
    else if (this.campoEmBranco("nomeusuario") ||
            this.campoEmBranco("usuario") ||
            this.campoEmBranco("senha") ||
            this.campoEmBranco("repitasenha") ||
            this.campoEmBranco("celular")) {
      this.msgerro = "Todos os campos devem ser preenchidos!"
    }
    else {
      this.cadInsUpd = "i";
      this.ExecPost();
    }
  }

  cancelarCadastro(){
    this.cadastroUsuario = false;
    this.loginUsuario = true;     
  }

  // atualizar dados dos clientes do site
  recebedadosConsR(_ADados: any) {
    this.usuariosSite = _ADados;

    console.log(this.usuariosSite);
  }
  getURLServerConsUS() {
    return this.urlServer + this.getURLSistema() + "&cad=25";
  }
  getURLServerUsuariosSite(){
    let AURL = this.getURLServerConsUS() + "&act=lus";
    return AURL;
  }

  refreshDadosClientes() {
    params: HttpParams;
    let params = new HttpParams();
    let AURL = "";
    AURL = this.getURLServerUsuariosSite();
    console.log(AURL);
    this.http.post<any[]>(AURL, { params }).
      subscribe(data => this.recebedadosConsR(data));
  }

  // fim do atualizar dados dos clientes do site

  selecionaUsuario(_AUser){
    //console.log(_AUser);
    this.emailusuario = _AUser.usuario;
    this.senhausuario = _AUser.senha;
  }

}
