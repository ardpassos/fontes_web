import { FormBaseComponent } from '../form-base/form-base.component';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-menu-lateral',
  templateUrl: './menu-lateral.component.html',
  styleUrls: ['./menu-lateral.component.css']
})
export class MenuLateralComponent extends FormBaseComponent implements OnInit {

  subCateg = [];

  mostrarClassificacao = true;
  mostrarCategorias = true;
  mostrarSubCategorias = true;
  filtroClassificacao: any;
  filtroCategoria: any;
  filtroSubCategoria: any;

  campoClassificacao = [{"codigo": "1", "desc": "Menor valor"},
                        {"codigo": "2", "desc": "Maior valor"}];  

  ngOnInit() {
    super.ngOnInit();
    this.atualizaListas();
  }
  inicializaCad() {
    super.inicializaCad();
    this.cadID = 24;
  }

  atualizaListas(){
    this.ExecCons();
    this.atualizaSubCategorias();
  }


  //get subCategorias
  recebedadosSubCateg(_ADados: any[]) {
    this.subCateg = _ADados;
  }  
  getURLAtualizaSubCateg(_ACodCateg) {
    return this.getURLServer() + "&act=gsc&codcategoria=" + _ACodCateg;
  }
  atualizaSubCategorias(){
    let ACodCateg = -1;
    if (this.filtroCategoria != null)
      ACodCateg = this.filtroCategoria.codcategoria;
    let AURL = this.getURLAtualizaSubCateg(ACodCateg);
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosSubCateg(data));
  }

  getNumItensSubCateg(){
    return this.subCateg.length;
  }  

  // fim get subCategorias
  

  clickClassificacao(){
    this.mostrarClassificacao = !this.mostrarClassificacao;
  }
  clickCategorias(){
    this.mostrarCategorias = !this.mostrarCategorias;
  }
  clickSubCategorias(){
    this.mostrarSubCategorias = !this.mostrarSubCategorias;
  }

  classifSelecionada(_AClassif){
    return (this.filtroClassificacao === _AClassif);
  }

  categSelecionada(_ACateg){
    return (this.filtroCategoria === _ACateg);
  }

  subCategSelecionada(_ASubCateg){
    return (this.filtroSubCategoria === _ASubCateg);
  }

  setClassificacao(_AClassif){
    if (this.filtroClassificacao === _AClassif)
      this.filtroClassificacao = null;
    else
      this.filtroClassificacao = _AClassif;

    let ARec = {"filtro":"1", "rec": this.filtroClassificacao};
    this.GS.filtroClassificacao = ARec.rec;
    this.GS.execute(ARec);
  }
  setCategoria(_ACateg){
    if (this.filtroCategoria === _ACateg){
      this.filtroCategoria = null;
      this.filtroSubCategoria = null;
      this.GS.filtroSubCategoria = null;
    }
    else
      this.filtroCategoria = _ACateg;
    let ARec = {"filtro":"2", "rec": this.filtroCategoria};
    this.GS.filtroCategoria = ARec.rec;
    this.GS.execute(ARec);
    this.atualizaSubCategorias();
  }
  setSubCategoria(_ASubCateg){
    if (this.filtroSubCategoria === _ASubCateg)
      this.filtroSubCategoria = null;
    else
      this.filtroSubCategoria = _ASubCateg;
    let ARec = {"filtro":"10", "rec": this.filtroSubCategoria};
    this.GS.filtroSubCategoria = ARec.rec;
    this.GS.execute(ARec);
  }
  getMostrarSubCategoria(){

  }

}
