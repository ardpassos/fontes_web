import { usuarioLogado } from './../../../../econdo/src/app/login/usuariologado';
import { Component, OnInit, Injectable, EventEmitter } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Injectable({
  providedIn: 'root'
}) 
@Component({
  selector: 'app-geral-service',
  template: '<div></div>'
})
export class GeralServiceComponent implements OnInit {

  msg = "";
  actionRec = {"filtro":"0", "rec": ""};
  filtroClassificacao: any = null;
  filtroCategoria: any = null;
  filtroSubCategoria: any = null;
  usuarioLogado = {"codusuario":-1, "usuario": ""};
  filtrosMenuSup = {"promocao": '', "genero": '', "codcategoria": ''};

  execEventEmitter = new EventEmitter();

  constructor() { }

  ngOnInit() {
  }

  execute(_ActionRec){
    this.actionRec =_ActionRec; 

    this.execEventEmitter.emit(this.actionRec);
  }

}
