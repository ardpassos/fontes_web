$(document).ready(function () {
    $(".imgzoom").imagezoomsl({
        zoomrange: [3, 3]
    });
});
