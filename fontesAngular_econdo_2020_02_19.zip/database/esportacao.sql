-- MySQL dump 10.13  Distrib 8.0.13, for Win64 (x86_64)
--
-- Host: localhost    Database: passos_teste
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tabagenda`
--

DROP TABLE IF EXISTS `tabagenda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tabagenda` (
  `codagenda` int(11) NOT NULL,
  `codrecursoag` int(11) NOT NULL,
  `descagenda` varchar(255) DEFAULT NULL,
  `data` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  PRIMARY KEY (`codagenda`)
) 
;

--
-- Dumping data for table `tabagenda`
--

LOCK TABLES `tabagenda` WRITE;
/*!40000 ALTER TABLE `tabagenda` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabagenda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabagendainsem`
--

DROP TABLE IF EXISTS `tabagendainsem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tabagendainsem` (
  `codagendainsem` int(11) NOT NULL,
  `dataprevista` timestamp NULL DEFAULT NULL,
  `datarealizada` timestamp NULL DEFAULT NULL,
  `dataverificacao` timestamp NULL DEFAULT NULL,
  `status` varchar(1) DEFAULT NULL,
  `codfuncveterinario` int(11) DEFAULT NULL,
  `codempresa` int(11) DEFAULT NULL,
  PRIMARY KEY (`codagendainsem`)
) 
;

--
-- Dumping data for table `tabagendainsem`
--

LOCK TABLES `tabagendainsem` WRITE;
/*!40000 ALTER TABLE `tabagendainsem` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabagendainsem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabanimal`
--

DROP TABLE IF EXISTS `tabanimal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tabanimal` (
  `codanimal` int(11) NOT NULL,
  `codempresa` int(11) DEFAULT NULL,
  `nomebatismo` varchar(255) DEFAULT NULL,
  `datanascimento` timestamp NULL DEFAULT NULL,
  `codraca` int(11) DEFAULT NULL,
  `sexo` varchar(1) DEFAULT NULL,
  `codpai` int(11) DEFAULT NULL,
  `codmae` int(11) DEFAULT NULL,
  `numrp` varchar(40) DEFAULT NULL,
  `numrd` varchar(40) DEFAULT NULL,
  `codcor` int(11) DEFAULT NULL,
  `destaque` varchar(1) DEFAULT NULL,
  `ativo` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`codanimal`)
) 
;

--
-- Dumping data for table `tabanimal`
--

LOCK TABLES `tabanimal` WRITE;
/*!40000 ALTER TABLE `tabanimal` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabanimal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabanimalinsem`
--

DROP TABLE IF EXISTS `tabanimalinsem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tabanimalinsem` (
  `codinsem` int(11) NOT NULL,
  `codanimal` int(11) DEFAULT NULL,
  `datainsem` timestamp NULL DEFAULT NULL,
  `dataverificacao` timestamp NULL DEFAULT NULL,
  `status` varchar(1) DEFAULT NULL,
  `codpai` int(11) DEFAULT NULL,
  `codmae` int(11) DEFAULT NULL,
  `prenha` varchar(1) DEFAULT NULL,
  `dataprevnasc` timestamp NULL DEFAULT NULL,
  `datanasc` timestamp NULL DEFAULT NULL,
  `codanimalnasceu` int(11) DEFAULT NULL,
  `codagenda` int(11) DEFAULT NULL,
  PRIMARY KEY (`codinsem`)
) 
;

--
-- Dumping data for table `tabanimalinsem`
--

LOCK TABLES `tabanimalinsem` WRITE;
/*!40000 ALTER TABLE `tabanimalinsem` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabanimalinsem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabcidade`
--

DROP TABLE IF EXISTS `tabcidade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tabcidade` (
  `codcidade` int(11) NOT NULL,
  `cidade` varchar(255) DEFAULT NULL,
  `coduf` int(11) DEFAULT NULL,
  PRIMARY KEY (`codcidade`)
) 
;

--
-- Dumping data for table `tabcidade`
--

LOCK TABLES `tabcidade` WRITE;
/*!40000 ALTER TABLE `tabcidade` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabcidade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabcor`
--

DROP TABLE IF EXISTS `tabcor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tabcor` (
  `codcor` int(11) NOT NULL,
  `cor` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`codcor`)
) 
;

--
-- Dumping data for table `tabcor`
--

LOCK TABLES `tabcor` WRITE;
/*!40000 ALTER TABLE `tabcor` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabcor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabcrp`
--

DROP TABLE IF EXISTS `tabcrp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tabcrp` (
  `codcrp` int(11) NOT NULL,
  `rp` varchar(1) DEFAULT NULL,
  `codpc` int(11) DEFAULT NULL,
  `numdoc` varchar(255) DEFAULT NULL,
  `parcela` int(11) DEFAULT NULL,
  `status` varchar(1) DEFAULT NULL,
  `datalcto` timestamp NULL DEFAULT NULL,
  `datavcto` timestamp NULL DEFAULT NULL,
  `valor` float DEFAULT NULL,
  `valorpendente` float DEFAULT NULL,
  `codpessoa` int(11) DEFAULT NULL,
  PRIMARY KEY (`codcrp`)
) 
;

--
-- Dumping data for table `tabcrp`
--

LOCK TABLES `tabcrp` WRITE;
/*!40000 ALTER TABLE `tabcrp` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabcrp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabdespesasuh`
--

DROP TABLE IF EXISTS `tabdespesasuh`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tabdespesasuh` (
  `codemp` int(11) DEFAULT NULL,
  `coddespesauh` int(11) NOT NULL,
  `codperiodo` int(11) DEFAULT NULL,
  `datalcto` date DEFAULT NULL,
  `datadespesa` date DEFAULT NULL,
  `coduh` int(11) DEFAULT NULL,
  `descricaodespesa` varchar(255) DEFAULT NULL,
  `valor` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`coddespesauh`)
) 
;

--
-- Dumping data for table `tabdespesasuh`
--

LOCK TABLES `tabdespesasuh` WRITE;
/*!40000 ALTER TABLE `tabdespesasuh` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabdespesasuh` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabdespfixas`
--

DROP TABLE IF EXISTS `tabdespfixas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tabdespfixas` (
  `codemp` int(11) DEFAULT NULL,
  `coddespesa` int(11) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `valorpadrao` decimal(15,2) DEFAULT NULL,
  `ehluz` varchar(1) DEFAULT NULL,
  `tiporateioluz` varchar(1) DEFAULT NULL,
  `ehgaz` varchar(1) DEFAULT NULL,
  `tiporateiogaz` varchar(1) DEFAULT NULL,
  `ehagua` varchar(1) DEFAULT NULL,
  `tiporateioagua` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`coddespesa`)
) 
;

--
-- Dumping data for table `tabdespfixas`
--

LOCK TABLES `tabdespfixas` WRITE;
/*!40000 ALTER TABLE `tabdespfixas` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabdespfixas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabempresa`
--

DROP TABLE IF EXISTS `tabempresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tabempresa` (
  `codempresa` int(11) NOT NULL,
  `razaosocial` varchar(255) DEFAULT NULL,
  `nomefantasia` varchar(255) DEFAULT NULL,
  `cnpj` varchar(40) DEFAULT NULL,
  `inscricaoestadual` varchar(40) DEFAULT NULL,
  `endereco` varchar(255) DEFAULT NULL,
  `numero` int(11) DEFAULT NULL,
  `complemento` varchar(255) DEFAULT NULL,
  `bairro` varchar(255) DEFAULT NULL,
  `codcidade` int(11) DEFAULT NULL,
  `cep` varchar(15) DEFAULT NULL,
  `telefone` varchar(40) DEFAULT NULL,
  `fax` varchar(40) DEFAULT NULL,
  `site` varchar(1024) DEFAULT NULL,
  `codfuncresp` int(11) DEFAULT NULL,
  `codgrupoempresa` int(11) DEFAULT NULL,
  `logo` blob,
  `schemaname` varchar(255) DEFAULT NULL,
  `ehcliente` varchar(1) DEFAULT NULL,
  `ehfornec` varchar(1) DEFAULT NULL,
  `schemanameactive` varchar(255) DEFAULT NULL,
  `codproduto` varchar(2) DEFAULT NULL,
  `modulofazenda` varchar(1) DEFAULT NULL,
  `moduloagenda` varchar(1) DEFAULT NULL,
  `modulofinanceiro` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`codempresa`)
) 
;

--
-- Dumping data for table `tabempresa`
--

LOCK TABLES `tabempresa` WRITE;
/*!40000 ALTER TABLE `tabempresa` DISABLE KEYS */;
INSERT INTO `tabempresa` VALUES (1,'Condomínio Ave Maria','Condomínio Ave Maria','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,'Residencial São Bento','Residencial São Bento','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,'Residencial Santa Ágata','Residencial Santa Ágata','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tabempresa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabexecuting`
--

DROP TABLE IF EXISTS `tabexecuting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tabexecuting` (
  `codexec` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `guid` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`codexec`)
) 
;

--
-- Dumping data for table `tabexecuting`
--

LOCK TABLES `tabexecuting` WRITE;
/*!40000 ALTER TABLE `tabexecuting` DISABLE KEYS */;
INSERT INTO `tabexecuting` VALUES (1,0,'');
/*!40000 ALTER TABLE `tabexecuting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabfunc`
--

DROP TABLE IF EXISTS `tabfunc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tabfunc` (
  `codfunc` int(11) NOT NULL,
  `nomefunc` varchar(255) DEFAULT NULL,
  `cpf` varchar(40) DEFAULT NULL,
  `codfuncaoresp` int(11) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `username` varchar(40) DEFAULT NULL,
  `password` varchar(40) DEFAULT NULL,
  `codclientecobranca` int(11) DEFAULT NULL,
  `codempresa` int(11) DEFAULT NULL,
  `ehadministrador` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`codfunc`)
) 
;

--
-- Dumping data for table `tabfunc`
--

LOCK TABLES `tabfunc` WRITE;
/*!40000 ALTER TABLE `tabfunc` DISABLE KEYS */;
INSERT INTO `tabfunc` VALUES (0,'admin',NULL,NULL,NULL,'admin','admin',NULL,1,'s'),(1,'Ale',NULL,NULL,NULL,'ale','ale',NULL,2,'n');
/*!40000 ALTER TABLE `tabfunc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabfuncaofunc`
--

DROP TABLE IF EXISTS `tabfuncaofunc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tabfuncaofunc` (
  `codfuncaofunc` int(11) NOT NULL,
  `funcaofunc` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`codfuncaofunc`)
) 
;

--
-- Dumping data for table `tabfuncaofunc`
--

LOCK TABLES `tabfuncaofunc` WRITE;
/*!40000 ALTER TABLE `tabfuncaofunc` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabfuncaofunc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabgrupoempresa`
--

DROP TABLE IF EXISTS `tabgrupoempresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tabgrupoempresa` (
  `codgrupoempresa` int(11) NOT NULL,
  `grupoempresa` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`codgrupoempresa`)
) 
;

--
-- Dumping data for table `tabgrupoempresa`
--

LOCK TABLES `tabgrupoempresa` WRITE;
/*!40000 ALTER TABLE `tabgrupoempresa` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabgrupoempresa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tablctoagua`
--

DROP TABLE IF EXISTS `tablctoagua`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tablctoagua` (
  `codemp` int(11) DEFAULT NULL,
  `codlctoagua` int(11) NOT NULL,
  `codperiodo` int(11) DEFAULT NULL,
  `dataleitura` date DEFAULT NULL,
  `coduh` int(11) DEFAULT NULL,
  `valorleitura` decimal(15,4) DEFAULT NULL,
  `valorultimaleitura` decimal(15,4) DEFAULT NULL,
  PRIMARY KEY (`codlctoagua`)
) 
;

--
-- Dumping data for table `tablctoagua`
--

LOCK TABLES `tablctoagua` WRITE;
/*!40000 ALTER TABLE `tablctoagua` DISABLE KEYS */;
/*!40000 ALTER TABLE `tablctoagua` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tablctogas`
--

DROP TABLE IF EXISTS `tablctogas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tablctogas` (
  `codemp` int(11) DEFAULT NULL,
  `codlctogas` int(11) NOT NULL,
  `codperiodo` int(11) DEFAULT NULL,
  `dataleitura` date DEFAULT NULL,
  `coduh` int(11) DEFAULT NULL,
  `valorleitura` decimal(15,4) DEFAULT NULL,
  `valorultimaleitura` decimal(15,4) DEFAULT NULL,
  PRIMARY KEY (`codlctogas`)
) 
;

--
-- Dumping data for table `tablctogas`
--

LOCK TABLES `tablctogas` WRITE;
/*!40000 ALTER TABLE `tablctogas` DISABLE KEYS */;
INSERT INTO `tablctogas` VALUES (1,1,1,'2019-07-01',3,145.0310,0.0000),(1,2,1,'2019-07-01',2,74.1240,0.0000),(1,3,1,'2019-07-01',5,78.7210,0.0000),(1,4,1,'2019-07-01',6,46.8000,0.0000),(1,5,1,'2019-07-01',1,76.2590,0.0000),(1,6,1,'2019-07-01',4,180.2780,0.0000),(1,7,3,'2019-09-03',2,76.1220,0.0000),(1,8,3,'2019-09-03',3,147.5720,0.0000),(1,9,3,'2019-09-03',4,188.4450,0.0000),(1,10,3,'2019-09-03',1,77.8010,0.0000),(1,11,3,'2019-09-03',6,47.2180,0.0000),(1,12,3,'2019-09-03',5,79.9860,0.0000),(1,13,4,'2019-08-03',1,76.7870,0.0000),(1,14,4,'2019-08-03',6,47.2180,0.0000),(1,15,4,'2019-08-03',3,146.2700,0.0000),(1,16,4,'2019-08-03',5,79.5480,0.0000),(1,17,4,'2019-08-03',4,183.5330,0.0000),(1,18,4,'2019-08-03',2,75.4980,0.0000);
/*!40000 ALTER TABLE `tablctogas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tablctoluz`
--

DROP TABLE IF EXISTS `tablctoluz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tablctoluz` (
  `codemp` int(11) DEFAULT NULL,
  `codlctoluz` int(11) NOT NULL,
  `codperiodo` int(11) DEFAULT NULL,
  `dataleitura` date DEFAULT NULL,
  `coduh` int(11) DEFAULT NULL,
  `valorleitura` decimal(15,4) DEFAULT NULL,
  `valorultimaleitura` decimal(15,4) DEFAULT NULL,
  `codmedidor` int(11) DEFAULT NULL,
  PRIMARY KEY (`codlctoluz`)
) 
;

--
-- Dumping data for table `tablctoluz`
--

LOCK TABLES `tablctoluz` WRITE;
/*!40000 ALTER TABLE `tablctoluz` DISABLE KEYS */;
INSERT INTO `tablctoluz` VALUES (1,1,1,'2019-07-01',7,1285.8000,0.0000,1),(1,2,1,'2019-07-01',1,1252.4000,0.0000,2),(1,3,1,'2019-07-01',2,2849.7000,0.0000,2),(1,4,1,'2019-07-01',2,1239.9000,0.0000,1),(1,5,1,'2019-07-01',3,863.0000,0.0000,2),(1,6,1,'2019-07-01',1,3789.0000,0.0000,1),(1,7,1,'2019-07-01',5,1183.4000,0.0000,1),(1,8,1,'2019-07-01',4,0.1000,0.0000,2),(1,9,1,'2019-07-01',3,4469.9000,0.0000,1),(1,10,1,'2019-07-01',6,2216.0000,0.0000,1),(1,11,1,'2019-07-01',4,4272.2000,0.0000,1),(1,12,1,'2019-07-01',5,860.0000,0.0000,2),(1,13,1,'2019-07-01',6,2166.2000,0.0000,2),(1,14,3,'2019-09-03',7,1414.8000,0.0000,1),(1,15,3,'2019-09-03',1,4225.0000,0.0000,1),(1,16,3,'2019-09-03',3,4910.1000,0.0000,1),(1,17,3,'2019-09-03',2,3055.1000,0.0000,2),(1,18,3,'2019-09-03',2,1442.9000,0.0000,1),(1,19,3,'2019-09-03',1,1311.7000,0.0000,2),(1,20,3,'2019-09-03',5,1314.8000,0.0000,1),(1,21,3,'2019-09-03',4,28.1000,0.0000,2),(1,22,3,'2019-09-03',5,942.0000,0.0000,2),(1,23,3,'2019-09-03',6,2268.2000,0.0000,1),(1,24,3,'2019-09-03',3,863.0000,0.0000,2),(1,25,3,'2019-09-03',4,4411.1000,0.0000,1),(1,26,3,'2019-09-03',6,2219.2000,0.0000,2),(1,27,4,'2019-08-03',1,4015.6000,0.0000,1),(1,28,4,'2019-08-03',3,4691.9000,0.0000,1),(1,29,4,'2019-08-03',2,3004.8000,0.0000,2),(1,30,4,'2019-08-03',2,1348.1000,0.0000,1),(1,31,4,'2019-08-03',7,1350.4000,0.0000,1),(1,32,4,'2019-08-03',1,1267.8000,0.0000,2),(1,33,4,'2019-08-03',5,902.8000,0.0000,2),(1,34,4,'2019-08-03',4,0.1000,0.0000,2),(1,35,4,'2019-08-03',3,863.0000,0.0000,2),(1,36,4,'2019-08-03',5,1252.4000,0.0000,1),(1,37,4,'2019-08-03',4,4311.3000,0.0000,1),(1,38,4,'2019-08-03',6,2268.2000,0.0000,1),(1,39,4,'2019-08-03',6,2219.2000,0.0000,2);
/*!40000 ALTER TABLE `tablctoluz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabmf`
--

DROP TABLE IF EXISTS `tabmf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tabmf` (
  `codmf` int(11) NOT NULL,
  `rp` varchar(1) DEFAULT NULL,
  `datamf` timestamp NULL DEFAULT NULL,
  `numdoc` varchar(255) DEFAULT NULL,
  `parcela` int(11) DEFAULT NULL,
  `codpc` int(11) DEFAULT NULL,
  `valor` float DEFAULT NULL,
  `status` varchar(1) DEFAULT NULL,
  `datacanc` timestamp NULL DEFAULT NULL,
  `codpgtocrp` int(11) DEFAULT NULL,
  `codpessoa` int(11) DEFAULT NULL,
  PRIMARY KEY (`codmf`)
) 
;

--
-- Dumping data for table `tabmf`
--

LOCK TABLES `tabmf` WRITE;
/*!40000 ALTER TABLE `tabmf` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabmf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabpc`
--

DROP TABLE IF EXISTS `tabpc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tabpc` (
  `codpc` int(11) NOT NULL,
  `pc` varchar(255) DEFAULT NULL,
  `rd` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`codpc`)
) 
;

--
-- Dumping data for table `tabpc`
--

LOCK TABLES `tabpc` WRITE;
/*!40000 ALTER TABLE `tabpc` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabpc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabperiodoapuracao`
--

DROP TABLE IF EXISTS `tabperiodoapuracao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tabperiodoapuracao` (
  `codemp` int(11) DEFAULT NULL,
  `codperiodo` int(11) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `datainicio` date DEFAULT NULL,
  `datafim` date DEFAULT NULL,
  `qtdeconsumoluz` decimal(15,6) DEFAULT NULL,
  `valortotalluz` decimal(15,2) DEFAULT NULL,
  `valorunluz` decimal(15,6) DEFAULT NULL,
  `valoradbandamarela` decimal(15,2) DEFAULT NULL,
  `valoradbandvermelha` decimal(15,2) DEFAULT NULL,
  `valorcosip` decimal(15,2) DEFAULT NULL,
  `qtdeconsumoagua` decimal(15,6) DEFAULT NULL,
  `valortotalagua` decimal(15,2) DEFAULT NULL,
  `valorrateiogas` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`codperiodo`)
) 
;

--
-- Dumping data for table `tabperiodoapuracao`
--

LOCK TABLES `tabperiodoapuracao` WRITE;
/*!40000 ALTER TABLE `tabperiodoapuracao` DISABLE KEYS */;
INSERT INTO `tabperiodoapuracao` VALUES (1,1,'Julho de 2019','2019-07-01','2019-07-31',0.000000,0.00,0.700226,15.25,0.00,21.74,0.000000,359.51,17.87),(0,2,'Setembro de 2019','2019-09-01','2019-09-30',0.000000,0.00,0.000000,0.00,0.00,0.00,0.000000,0.00,0.00),(1,3,'Setembro de 2019','2019-09-01','2019-09-30',0.000000,0.00,0.786455,6.10,53.67,19.03,0.000000,359.51,17.87),(1,4,'Agosto de 2019','2019-08-01','2019-08-31',0.000000,0.00,0.783962,21.97,0.00,18.80,0.000000,359.51,17.87),(1,5,'Outubro de 2019','2019-10-01','2019-10-31',0.000000,0.00,0.000000,0.00,0.00,0.00,0.000000,0.00,0.00);
/*!40000 ALTER TABLE `tabperiodoapuracao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabpessoa`
--

DROP TABLE IF EXISTS `tabpessoa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tabpessoa` (
  `codpessoa` int(11) NOT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `tipopessoa` varchar(1) DEFAULT NULL,
  `razaosocial` varchar(255) DEFAULT NULL,
  `rg` varchar(40) DEFAULT NULL,
  `cpf` varchar(40) DEFAULT NULL,
  `cnpj` varchar(40) DEFAULT NULL,
  `inscricaoestadual` varchar(40) DEFAULT NULL,
  `endereco` varchar(255) DEFAULT NULL,
  `numero` int(11) DEFAULT NULL,
  `complemento` varchar(255) DEFAULT NULL,
  `bairro` varchar(255) DEFAULT NULL,
  `codcidade` int(11) DEFAULT NULL,
  `cep` varchar(15) DEFAULT NULL,
  `telefone` varchar(40) DEFAULT NULL,
  `fax` varchar(40) DEFAULT NULL,
  `site` varchar(1024) DEFAULT NULL,
  `ehcliente` varchar(1) DEFAULT NULL,
  `ehfornec` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`codpessoa`)
) 
;

--
-- Dumping data for table `tabpessoa`
--

LOCK TABLES `tabpessoa` WRITE;
/*!40000 ALTER TABLE `tabpessoa` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabpessoa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabpgtocrp`
--

DROP TABLE IF EXISTS `tabpgtocrp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tabpgtocrp` (
  `codpgtocrp` int(11) NOT NULL,
  `codcrp` int(11) DEFAULT NULL,
  `datapgto` timestamp NULL DEFAULT NULL,
  `valor` float DEFAULT NULL,
  `tipo` varchar(1) DEFAULT NULL,
  `status` varchar(1) DEFAULT NULL,
  `datacanc` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`codpgtocrp`)
) 
;

--
-- Dumping data for table `tabpgtocrp`
--

LOCK TABLES `tabpgtocrp` WRITE;
/*!40000 ALTER TABLE `tabpgtocrp` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabpgtocrp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabraca`
--

DROP TABLE IF EXISTS `tabraca`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tabraca` (
  `codraca` int(11) NOT NULL,
  `raca` varchar(255) DEFAULT NULL,
  `numdiasprenhez` int(11) DEFAULT NULL,
  PRIMARY KEY (`codraca`)
) 
;

--
-- Dumping data for table `tabraca`
--

LOCK TABLES `tabraca` WRITE;
/*!40000 ALTER TABLE `tabraca` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabraca` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabrecursoag`
--

DROP TABLE IF EXISTS `tabrecursoag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tabrecursoag` (
  `codrecursoag` int(11) NOT NULL,
  `descrecursoag` varchar(255) DEFAULT NULL,
  `codfuncionario` int(11) DEFAULT NULL,
  `horainicioagenda` time DEFAULT NULL,
  `horafimagenda` time DEFAULT NULL,
  `diasamostragem` int(11) DEFAULT NULL,
  `intervalo` time DEFAULT NULL,
  PRIMARY KEY (`codrecursoag`)
) 
;

--
-- Dumping data for table `tabrecursoag`
--

LOCK TABLES `tabrecursoag` WRITE;
/*!40000 ALTER TABLE `tabrecursoag` DISABLE KEYS */;
INSERT INTO `tabrecursoag` VALUES (1,'geral',1,'08:00:00','23:00:00',5,'00:30:00');
/*!40000 ALTER TABLE `tabrecursoag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabtipoanimais`
--

DROP TABLE IF EXISTS `tabtipoanimais`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tabtipoanimais` (
  `codtipoanimal` int(11) NOT NULL,
  `tipoanimal` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`codtipoanimal`)
) 
;

--
-- Dumping data for table `tabtipoanimais`
--

LOCK TABLES `tabtipoanimais` WRITE;
/*!40000 ALTER TABLE `tabtipoanimais` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabtipoanimais` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabuf`
--

DROP TABLE IF EXISTS `tabuf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tabuf` (
  `coduf` int(11) NOT NULL,
  `uf` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`coduf`)
) 
;

--
-- Dumping data for table `tabuf`
--

LOCK TABLES `tabuf` WRITE;
/*!40000 ALTER TABLE `tabuf` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabuf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabuhs`
--

DROP TABLE IF EXISTS `tabuhs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tabuhs` (
  `codemp` int(11) NOT NULL,
  `coduh` int(11) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `ehaluguel` varchar(1) DEFAULT NULL,
  `valoraluguel` decimal(15,2) DEFAULT NULL,
  `ehcond` varchar(1) DEFAULT NULL,
  `valorcond` decimal(15,2) DEFAULT NULL,
  `numpessoasuh` decimal(15,2) DEFAULT NULL,
  PRIMARY KEY (`coduh`)
) 
;

--
-- Dumping data for table `tabuhs`
--

LOCK TABLES `tabuhs` WRITE;
/*!40000 ALTER TABLE `tabuhs` DISABLE KEYS */;
INSERT INTO `tabuhs` VALUES (1,1,'101','s',890.00,'n',95.00,2.40),(1,2,'102','s',840.00,'n',95.00,2.00),(1,3,'201','s',890.00,'n',95.00,2.40),(1,4,'202','s',890.00,'n',95.00,3.00),(1,5,'301','s',890.00,'n',95.00,1.50),(1,6,'302','s',900.00,'n',95.00,2.00),(1,7,'0','n',0.00,'s',95.00,0.00),(1,8,'401','n',0.00,'n',95.00,3.50),(1,9,'402','n',0.00,'n',0.00,0.00);
/*!40000 ALTER TABLE `tabuhs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabversao`
--

DROP TABLE IF EXISTS `tabversao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tabversao` (
  `codversao` int(11) NOT NULL,
  `codupdate` int(11) NOT NULL,
  PRIMARY KEY (`codversao`,`codupdate`)
) 
;

--
-- Dumping data for table `tabversao`
--

LOCK TABLES `tabversao` WRITE;
/*!40000 ALTER TABLE `tabversao` DISABLE KEYS */;
INSERT INTO `tabversao` VALUES (1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),(1,8),(1,9),(1,10),(1,11),(1,12),(1,13),(1,14),(1,15),(1,16),(1,17),(1,18),(1,19),(1,20),(1,21),(1,22),(1,23),(1,24),(1,25),(1,26),(1,27),(1,28),(1,29),(1,30),(1,31),(1,32),(1,33),(1,34),(1,35),(1,36),(1,37),(1,38),(1,39),(1,40),(1,41),(1,42),(1,43),(1,44),(1,45),(1,46),(1,47),(1,48),(1,49);
/*!40000 ALTER TABLE `tabversao` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-08  8:59:46
