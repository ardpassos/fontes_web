const proxy = [
    {
      context: '/demo',
      target: 'http://localhost:80/demo',
      pathRewrite: { '^/demo': '' }
    }
  ];
  module.exports = proxy;