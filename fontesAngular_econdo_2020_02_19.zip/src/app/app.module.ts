import { HttpClientModule } from '@angular/common/http';
import { AuthGuard } from './guard/auth-guard';
import { AuthService } from './login/auth.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { UsuariosComponent } from './usuarios/usuarios.component';
import { CadastrosComponent } from './cadastros/cadastros.component';
import { EmpresasComponent } from './cadastros/empresas/empresas.component';
import { UhsComponent } from './cadastros/uhs/uhs.component';
import { DespesasfixasComponent } from './cadastros/despesasfixas/despesasfixas.component';
import { FormBaseComponent } from './form-base/form-base.component';
import { ConsultabaseComponent } from './consultabase/consultabase.component';
import { CadastrobaseComponent } from './cadastrobase/cadastrobase.component';
import { PeriodoapuracaoComponent } from './cadastros/periodoapuracao/periodoapuracao.component';
import { LctogasComponent } from './cadastros/lctogas/lctogas.component';
import { LctoluzComponent } from './cadastros/lctoluz/lctoluz.component';
import { LctoaguaComponent } from './cadastros/lctoagua/lctoagua.component';
import { DespesasuhComponent } from './cadastros/despesasuh/despesasuh.component';
import { PeriodoapuracaolctosComponent } from './cadastros/periodoapuracaolctos/periodoapuracaolctos.component';
import { PeriodoapuracaolctosdespcondComponent } from './cadastros/periodoapuracaolctosdespcond/periodoapuracaolctosdespcond.component';
import { PeriodoapuracaolctosluzComponent } from './cadastros/periodoapuracaolctosluz/periodoapuracaolctosluz.component';
import { PeriodoapuracaolctosaguaComponent } from './cadastros/periodoapuracaolctosagua/periodoapuracaolctosagua.component';
import { PeriodoapuracaolctosgasComponent } from './cadastros/periodoapuracaolctosgas/periodoapuracaolctosgas.component';
import { PeriodoapuracaorelComponent } from './cadastros/periodoapuracaorel/periodoapuracaorel.component';
import { PeriodoapuracaorellctosComponent } from './cadastros/periodoapuracaorellctos/periodoapuracaorellctos.component';
import { SolicitacontatoComponent } from './solicitacontato/solicitacontato.component';
import { AreacomumComponent } from './cadastros/areacomum/areacomum.component';
import { PaineluhComponent } from './paineluh/paineluh.component';
import { PaineluhperiodosapuracaoComponent } from './paineluh/paineluhperiodosapuracao/paineluhperiodosapuracao.component';
import { PaineluhreservasacComponent } from './paineluh/paineluhreservasac/paineluhreservasac.component';
import { DatagridComponent } from './comps/datagrid/datagrid.component';
import { AcperiodosComponent } from './cadastros/areacomum/acperiodos/acperiodos.component';
import { PaineluhreservasacdiaComponent } from './paineluh/paineluhreservasac/paineluhreservasacdia/paineluhreservasacdia.component';
import { CadFuncionariosComponent } from './varejo/cad-funcionarios/cad-funcionarios.component';
import { MenuCadastrosVarejoComponent } from './varejo/menu-cadastros-varejo/menu-cadastros-varejo.component';
import { CadPessoasComponent } from './varejo/cad-pessoas/cad-pessoas.component';
import { LookupComponent } from './comps/lookup/lookup.component';
import { CadUnmedidasComponent } from './varejo/cad-unmedidas/cad-unmedidas.component';
import { CadMarcasComponent } from './varejo/cad-marcas/cad-marcas.component';
import { CadLocalalmoxComponent } from './varejo/cad-localalmox/cad-localalmox.component';
import { CadGruposprodutosComponent } from './varejo/cad-gruposprodutos/cad-gruposprodutos.component';
import { CadProdutosComponent } from './varejo/cad-produtos/cad-produtos.component';
import { MenuEstoqueVarejoComponent } from './varejo/menu-estoque-varejo/menu-estoque-varejo.component';
import { MenuFinanceiroVarejoComponent } from './varejo/menu-financeiro-varejo/menu-financeiro-varejo.component';

@NgModule({ 
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    UsuariosComponent,
    CadastrosComponent,
    EmpresasComponent,
    UhsComponent,
    DespesasfixasComponent,
    FormBaseComponent,
    ConsultabaseComponent,
    CadastrobaseComponent,
    PeriodoapuracaoComponent,
    LctogasComponent,
    LctoluzComponent,
    LctoaguaComponent,
    DespesasuhComponent,
    PeriodoapuracaolctosComponent,
    PeriodoapuracaolctosdespcondComponent,
    PeriodoapuracaolctosluzComponent,
    PeriodoapuracaolctosaguaComponent,
    PeriodoapuracaolctosgasComponent,
    PeriodoapuracaorelComponent,
    PeriodoapuracaorellctosComponent,
    SolicitacontatoComponent,
    AreacomumComponent,
    PaineluhComponent,
    PaineluhperiodosapuracaoComponent,
    PaineluhreservasacComponent,
    DatagridComponent,
    AcperiodosComponent,
    PaineluhreservasacdiaComponent,
    CadFuncionariosComponent,
    MenuCadastrosVarejoComponent,
    CadPessoasComponent,
    LookupComponent,
    CadUnmedidasComponent,
    CadMarcasComponent,
    CadLocalalmoxComponent,
    CadGruposprodutosComponent,
    CadProdutosComponent,
    MenuEstoqueVarejoComponent,
    MenuFinanceiroVarejoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [AuthService, AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
