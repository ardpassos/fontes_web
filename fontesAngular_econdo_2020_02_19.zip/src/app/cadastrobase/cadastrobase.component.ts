import { Component, OnInit, HostBinding, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-cadastrobase',
  templateUrl: './cadastrobase.component.html',
  styleUrls: ['./cadastrobase.component.css']
})
export class CadastrobaseComponent implements OnInit {

  @HostBinding('class.desc-Cons')
  @Input() descCons: any[];
  @Input() descTabsCad: any[];
  @HostBinding('class.activeRecord')
  @Input() activeRecord: any[];
  @Output() callbackPost = new EventEmitter();
  @Output() callbackCancel = new EventEmitter();
  tabSelected = "Geral";

  campoBoolean = [{"desc": "Sim", "valor": "s"},
                  {"desc": "Não", "valor": "n"}];

  constructor() { }

  ngOnInit() {
    this.selectionaTabCad("Geral");
  }

  getEhBoolean(_ABool){
    return _ABool;
  }

  getEhLookup(_ABool){
    return _ABool;
  }

  salvarRegistro() {
    this.callbackPost.emit();
  }
  cancelarEdicao() {
    this.callbackCancel.emit();
  }

  selectionaTabCad(_ADivName: string) {
    this.tabSelected = _ADivName;
  /*  for(var i=0; i<this.descTabsCad.length; i++){
      if (document.getElementById(this.descTabsCad[i].descTabCad) != null){
        document.getElementById(this.descTabsCad[i].descTabCad).style.display = "none";
      }
    }
    if (document.getElementById(_ADivName) != null){
      document.getElementById(_ADivName).style.display = "block";
    }*/
  }

}
