import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadastrobaseComponent } from './cadastrobase.component';

describe('CadastrobaseComponent', () => {
  let component: CadastrobaseComponent;
  let fixture: ComponentFixture<CadastrobaseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadastrobaseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadastrobaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
