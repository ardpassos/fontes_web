import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-cadastros-varejo',
  templateUrl: './menu-cadastros-varejo.component.html',
  styleUrls: ['./menu-cadastros-varejo.component.css']
})
export class MenuCadastrosVarejoComponent extends FormBaseComponent implements OnInit {


  ngOnInit() {
  }

}
