import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cad-produtos',
  templateUrl: './cad-produtos.component.html',
  styleUrls: ['./cad-produtos.component.css']
})
export class CadProdutosComponent extends FormBaseComponent implements OnInit {
    ngOnInit() {
      this.ExecCons();
    }
    inicializaCad() {
      super.inicializaCad();
      this.DescricaoSuperiorTela = "Produtos";
      this.cadID = 8;
      this.recno = 0;
      this.insertDescCons("codinsumo", "Cód. Produto", true, "number");
      this.insertDescCons("insumo", "Produto", true, "text");
      this.insertDescCons("obs", "Obs", false, "text");
      this.insertDescCons("status", "Status", false, "text");
      this.insertDescCons("codgrupo", "Cód. Grupo", false, "text", "Especificação");
      this.insertDescCons("codlocalalm", "Cód. local almoxarifado", false, "text", "Especificação");
      this.insertDescCons("codunmedida", "Cód. unidade de medida", false, "text", "Especificação");
      this.insertDescCons("qtdemin", "Qtde mínima", false, "number", "Qtdes");
      this.insertDescCons("qtdemax", "Qtde máxima", false, "number", "Qtdes");
      this.insertDescCons("numoriginal", "Número original", false, "text", "Numerações");
      this.insertDescCons("ncm", "NCM", false, "text", "Numerações");
      this.insertDescCons("codbarras", "Código de barras", false, "text", "Numerações");
    }
    getURLServerPost() {
      return super.getURLServerPost() +
        "&codinsumo=" + this.getValueFromEditableComp(this.activeRecord.codinsumo) +
        "&insumo=" + this.getValueFromEditableComp(this.activeRecord.insumo) +
        "&obs=" + this.getValueFromEditableComp(this.activeRecord.obs) +
        "&codgrupo=" + this.getValueFromEditableComp(this.activeRecord.codgrupo) +
        "&codlocalalm=" + this.getValueFromEditableComp(this.activeRecord.codlocalalm) +
        "&codunmedida=" + this.getValueFromEditableComp(this.activeRecord.codunmedida) +
        "&qtdemin=" + this.getValueFromEditableComp(this.activeRecord.qtdemin) +
        "&qtdemax=" + this.getValueFromEditableComp(this.activeRecord.qtdemax) +
        "&status=" + this.getValueFromEditableComp(this.activeRecord.status) +
        "&numoriginal=" + this.getValueFromEditableComp(this.activeRecord.numoriginal) +
        "&ncm=" + this.getValueFromEditableComp(this.activeRecord.ncm) +
        "&codbarras=" + this.getValueFromEditableComp(this.activeRecord.codbarras);
    }
  }