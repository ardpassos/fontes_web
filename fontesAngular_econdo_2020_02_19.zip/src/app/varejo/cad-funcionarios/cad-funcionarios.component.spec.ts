import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadFuncionariosComponent } from './cad-funcionarios.component';

describe('CadFuncionariosComponent', () => {
  let component: CadFuncionariosComponent;
  let fixture: ComponentFixture<CadFuncionariosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadFuncionariosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadFuncionariosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
