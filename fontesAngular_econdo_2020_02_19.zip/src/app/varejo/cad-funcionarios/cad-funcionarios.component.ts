import { HttpClient } from '@angular/common/http';
import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cad-funcionarios',
  templateUrl: './cad-funcionarios.component.html',
  styleUrls: ['./cad-funcionarios.component.css']
})

export class CadFuncionariosComponent extends FormBaseComponent implements OnInit {

    ngOnInit() {
      this.ExecCons();
    }
  
    inicializaCad() {
      super.inicializaCad();
      this.DescricaoSuperiorTela = "Funcionários";
      this.cadID = 1;
      this.recno = 0;
      this.insertDescCons("CodFuncionario", "Cód. Func.", true, "number");
      this.insertDescCons("Nome", "Nome", true, "text");
      this.insertDescCons("ApelidoFunc", "Usuário", true, "text", "Acesso");
      this.insertDescCons("Senha", "Senha", true, "text", "Acesso");
      this.insertDescCons("datanasc", "Data Nasc.", true, "date", "Dados");
      this.insertDescCons("CPF", "CPF", false, "text", "Dados");
      this.insertDescCons("Email", "Email", false, "text", "Dados");
      this.insertDescCons("DataAdmissao", "Data Admissão", false, "date", "Registro");
      this.insertDescCons("DataDemissao", "Data Demissão", false, "date", "Registro");
      this.insertDescCons("CodEmpresa", "Cód. Emprpesa", false, "number", "", false, false);
    } 
    
    getURLServerPost() {
      return super.getURLServerPost() +
        "&codfuncionario=" + this.getValueFromEditableComp(this.activeRecord.codfuncionario) +
        "&nome=" + this.getValueFromEditableComp(this.activeRecord.nome) +
        "&apelidofunc=" + this.getValueFromEditableComp(this.activeRecord.apelidofunc) +
        "&senha=" + this.getValueFromEditableComp(this.activeRecord.senha) +
        "&datanasc=" + this.getValueFromEditableComp(this.activeRecord.datanasc) +
        "&cpf=" + this.getValueFromEditableComp(this.activeRecord.cpf) +
        "&email=" + this.getValueFromEditableComp(this.activeRecord.email) +
        "&dataadmissao=" + this.getValueFromEditableComp(this.activeRecord.dataadmissao) +
        "&datademissao=" + this.getValueFromEditableComp(this.activeRecord.datademissao) +
        "&codempresa=" + this.getValueFromEditableComp(this.activeRecord.codempresa);
    }
  
  }
  
