import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-financeiro-varejo',
  templateUrl: './menu-financeiro-varejo.component.html',
  styleUrls: ['./menu-financeiro-varejo.component.css']
})
export class MenuFinanceiroVarejoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
