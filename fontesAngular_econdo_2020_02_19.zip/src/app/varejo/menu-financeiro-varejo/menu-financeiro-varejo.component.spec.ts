import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MenuFinanceiroVarejoComponent } from './menu-financeiro-varejo.component';

describe('MenuFinanceiroVarejoComponent', () => {
  let component: MenuFinanceiroVarejoComponent;
  let fixture: ComponentFixture<MenuFinanceiroVarejoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MenuFinanceiroVarejoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuFinanceiroVarejoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
