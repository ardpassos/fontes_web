import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadLocalalmoxComponent } from './cad-localalmox.component';

describe('CadLocalalmoxComponent', () => {
  let component: CadLocalalmoxComponent;
  let fixture: ComponentFixture<CadLocalalmoxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadLocalalmoxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadLocalalmoxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
