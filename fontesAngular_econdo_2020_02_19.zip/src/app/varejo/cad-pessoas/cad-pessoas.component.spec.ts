import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadPessoasComponent } from './cad-pessoas.component';

describe('CadPessoasComponent', () => {
  let component: CadPessoasComponent;
  let fixture: ComponentFixture<CadPessoasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadPessoasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadPessoasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
