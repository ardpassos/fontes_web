import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cad-pessoas',
  templateUrl: './cad-pessoas.component.html',
  styleUrls: ['./cad-pessoas.component.css']
})
export class CadPessoasComponent extends FormBaseComponent implements OnInit {

    ngOnInit() {
      this.ExecCons();
    }
  
    inicializaCad() {
      super.inicializaCad();
      this.DescricaoSuperiorTela = "Clientes/Fornecedores";
      this.cadID = 2;
      this.recno = 0;
      this.insertDescCons("codpessoa", "Cód. Pessoa", true, "number");
      this.insertDescCons("Nome", "Nome", true, "text");
      this.insertDescCons("nomefantasia", "Nome Fantasia", true, "text");
      this.insertDescCons("cliente", "É Cliente?", true, "text", "Tipo pessoa", true, true);
      this.insertDescCons("fornecedor", "É Fornecedor?", true, "text", "Tipo pessoa", true, true);
      this.insertDescCons("pessoafisica", "É pessoa física?", false, "text", "Tipo pessoa", true, true);
      this.insertDescCons("cpfcnpj", "CPF/CNPJ", false, "text", "Tipo pessoa");
      this.insertDescCons("endereco", "Endereço", false, "text", "Endereço");
      this.insertDescCons("complemento", "Complemento", false, "text", "Endereço");
      this.insertDescCons("bairro", "Bairro", false, "text", "Endereço");
      this.insertDescCons("cep", "CEP", false, "text", "Endereço");
      this.insertDescCons("codcidade", "Cód. Cidade", false, "text", "Endereço");
      this.insertDescCons("fonecomercial", "Fone Comercial", false, "text", "Contato");
      this.insertDescCons("email", "Email", false, "text", "Contato");
      this.insertDescCons("www", "Site", false, "text", "Contato");
      this.insertDescCons("fonecelular", "Celular", false, "text", "Contato");
      this.insertDescCons("datanasc", "Data Nasc.", false, "date", "Pessoa Física");
      this.insertDescCons("rg", "RG", false, "text", "Pessoa Física");
      this.insertDescCons("inscmun", "Inscrição municipal", false, "text", "Pessoa Jurídica");
      this.insertDescCons("inscrestadual", "Inscrição estadual", false, "text", "Pessoa Jurídica");
      this.insertDescCons("seriecert", "Série Certificado", false, "text", "Pessoa Jurídica");
      this.setLookups();      
  } 

  recebedadoslkp(_ADados: any[]) {
    this.setLookupNameValues("codcidade", _ADados);
  }

  setLookups(){
    this.ExecConsLookup(3);
  }
    
  getURLServerPost() {
    return super.getURLServerPost() +
      "&codpessoa=" + this.getValueFromEditableComp(this.activeRecord.codpessoa) +
      "&nome=" + this.getValueFromEditableComp(this.activeRecord.nome) +
      "&nomefantasia=" + this.getValueFromEditableComp(this.activeRecord.nomefantasia) +
      "&cliente=" + this.getValueFromEditableComp(this.activeRecord.cliente) +
      "&fornecedor=" + this.getValueFromEditableComp(this.activeRecord.fornecedor) +
      "&pessoafisica=" + this.getValueFromEditableComp(this.activeRecord.pessoafisica) +
      "&cpfcnpj=" + this.getValueFromEditableComp(this.activeRecord.cpfcnpj) +
      "&endereco=" + this.getValueFromEditableComp(this.activeRecord.endereco) +
      "&complemento=" + this.getValueFromEditableComp(this.activeRecord.complemento) +
      "&bairro=" + this.getValueFromEditableComp(this.activeRecord.bairro) +
      "&cep=" + this.getValueFromEditableComp(this.activeRecord.cep) +
      "&codcidade=" + this.getValueFromEditableComp(this.activeRecord.codcidade) +
      "&fonecomercial=" + this.getValueFromEditableComp(this.activeRecord.fonecomercial) +
      "&email=" + this.getValueFromEditableComp(this.activeRecord.email) +
      "&www=" + this.getValueFromEditableComp(this.activeRecord.www) +
      "&fonecelular=" + this.getValueFromEditableComp(this.activeRecord.fonecelular) +
      "&datanasc=" + this.getValueFromEditableComp(this.activeRecord.datanasc) +
      "&rg=" + this.getValueFromEditableComp(this.activeRecord.rg) +
      "&inscmun=" + this.getValueFromEditableComp(this.activeRecord.inscmun) +
      "&inscrestadual=" + this.getValueFromEditableComp(this.activeRecord.inscrestadual) +
      "&seriecert=" + this.getValueFromEditableComp(this.activeRecord.seriecert);
    }
  }
  

