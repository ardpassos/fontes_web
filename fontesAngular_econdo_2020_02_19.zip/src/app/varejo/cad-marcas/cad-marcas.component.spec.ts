import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadMarcasComponent } from './cad-marcas.component';

describe('CadMarcasComponent', () => {
  let component: CadMarcasComponent;
  let fixture: ComponentFixture<CadMarcasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadMarcasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadMarcasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
