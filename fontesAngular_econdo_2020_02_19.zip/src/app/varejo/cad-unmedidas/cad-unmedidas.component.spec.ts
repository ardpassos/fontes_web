import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadUnmedidasComponent } from './cad-unmedidas.component';

describe('CadUnmedidasComponent', () => {
  let component: CadUnmedidasComponent;
  let fixture: ComponentFixture<CadUnmedidasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadUnmedidasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadUnmedidasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
