import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-estoque-varejo',
  templateUrl: './menu-estoque-varejo.component.html',
  styleUrls: ['./menu-estoque-varejo.component.css']
})
export class MenuEstoqueVarejoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
