import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MenuEstoqueVarejoComponent } from './menu-estoque-varejo.component';

describe('MenuEstoqueVarejoComponent', () => {
  let component: MenuEstoqueVarejoComponent;
  let fixture: ComponentFixture<MenuEstoqueVarejoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MenuEstoqueVarejoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuEstoqueVarejoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
