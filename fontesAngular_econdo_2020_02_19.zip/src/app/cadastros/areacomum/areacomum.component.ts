import { AuthService } from './../../login/auth.service';
import { HttpClient } from '@angular/common/http';
import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-areacomum',
  templateUrl: './areacomum.component.html',
  styleUrls: ['./areacomum.component.css']
})
export class AreacomumComponent extends FormBaseComponent implements OnInit  {
  
  public ehACPeriodos = false;
  public descACPeriodos = "";

  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "Áreas Comuns";
    this.cadID = 21;
    this.recno = 0;
    this.insertDescCons("codac", "Cód. Área", true, "number", "Geral", false);
    this.insertDescCons("codemp", "Cód. Empresa", true, "number", "Geral", false);
    this.insertDescCons("descricao", "Área Comum", true, "text");
    this.insertDescCons("obsaoreservar", "Obs ao reservar", true, "text");

    this.insertButtonRec("Delete", "Excluir", "clear");
    this.insertButtonRec("acperiodos", "Períodos", "add");
  }

  getURLServerPost() {
    return super.getURLServerPost() +
      "&codemp=" + this.activeRecord.codemp +
      "&codac=" + this.activeRecord.codac +
      "&descricao=" + this.activeRecord.descricao +
      "&obsaoreservar=" + this.activeRecord.obsaoreservar;
  }

  setDescLctos(){
    this.descACPeriodos = "Períodos da área comum: " + this.activeRecord.descricao;
  }

  disableConsAndCad(){ 
    super.disableConsAndCad();
    this.ehACPeriodos = false;
  }

  buttonevent(_ARet: any){
    this.activeRecord = _ARet.record;
    if (_ARet.btnText === "clear"){
      this.excluirregistro();
      this.ExecCons();
    } 
    else if (_ARet.btnText === "add") {
      this.setDescLctos();
      this.disableConsAndCad();
      this.ehACPeriodos = true;
    }    
  }
  
  AfterInsert(){
    this.activeRecord.codemp = this.authService.codempresa;
  }

  ngOnInit() {
    this.insertFiltroCons("codemp", "=", this.authService.codempresa.toString());
    this.ExecCons();
  }

  AfterPostEnableDisableScreen(){
    this.ehconsulta = true;
    this.ehcadastro = false;
  }
  
  voltarConsultaPrinc(){
    this.disableConsAndCad();
    this.AfterPostEnableDisableScreen();
  }  

}
