import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AcperiodosComponent } from './acperiodos.component';

describe('AcperiodosComponent', () => {
  let component: AcperiodosComponent;
  let fixture: ComponentFixture<AcperiodosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AcperiodosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AcperiodosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
