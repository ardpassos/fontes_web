import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AreacomumComponent } from './areacomum.component';

describe('AreacomumComponent', () => {
  let component: AreacomumComponent;
  let fixture: ComponentFixture<AreacomumComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AreacomumComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AreacomumComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
