import { HttpClient } from '@angular/common/http';
import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-periodoapuracaorel',
  templateUrl: './periodoapuracaorel.component.html',
  styleUrls: ['./periodoapuracaorel.component.css']
})
export class PeriodoapuracaorelComponent extends FormBaseComponent implements OnInit {
  @Input() recordmaster: any;

  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "";
    this.cadID = 1060;
    this.recno = 0;
    this.insertDescCons("coduh", "Cód. UH", true, "number");
    this.insertDescCons("codemp", "Cód. Empresa", true, "number");
    this.insertDescCons("descricao", "UH", true, "text");
    this.insertDescCons("numpessoasuh", "Pessoas", false, "number");
    this.insertDescCons("ehaluguel", "É Aluguel?", false, "text", "Aluguel");
    this.insertDescCons("valoraluguel", "V. Aluguel", false, "number", "Aluguel");
    this.insertDescCons("ehcond", "É Cond?", false, "text", "Condomínio");
    this.insertDescCons("valorcond", "V. Condomínio", false, "number", "Condomínio");
  }
  
  ngOnInit() {
    this.insertFiltroCons("conspart", "=", "1061", false, true);
    this.insertFiltroCons("codemp", "=", this.recordmaster.codemp, false, true);
    this.insertFiltroCons("codperiodo", "=", this.recordmaster.codperiodo, false, true);
    this.ExecCons();
  }

}
