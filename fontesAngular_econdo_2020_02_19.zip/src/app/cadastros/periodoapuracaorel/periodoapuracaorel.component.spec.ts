import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PeriodoapuracaorelComponent } from './periodoapuracaorel.component';

describe('PeriodoapuracaorelComponent', () => {
  let component: PeriodoapuracaorelComponent;
  let fixture: ComponentFixture<PeriodoapuracaorelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PeriodoapuracaorelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PeriodoapuracaorelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
