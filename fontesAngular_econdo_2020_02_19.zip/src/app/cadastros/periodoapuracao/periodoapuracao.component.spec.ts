import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PeriodoapuracaoComponent } from './periodoapuracao.component';

describe('PeriodoapuracaoComponent', () => {
  let component: PeriodoapuracaoComponent;
  let fixture: ComponentFixture<PeriodoapuracaoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PeriodoapuracaoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PeriodoapuracaoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
