import { environment } from './../../../../../hello-world/src/environments/environment.prod';
import { element } from 'protractor';
import { AuthService } from './../../login/auth.service';
import { HttpClient, HttpParams } from '@angular/common/http';
import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import * as es6printJS from "print-js";

@Component({
  selector: 'app-periodoapuracao',
  templateUrl: './periodoapuracao.component.html',
  styleUrls: ['./periodoapuracao.component.css']
})
export class PeriodoapuracaoComponent extends FormBaseComponent implements OnInit {

  public descLctos: string = "";
  public ehLctos: boolean = false;
  public ehListagem: boolean = false;
  public titleDespCond: string = "Despesas do Condomínio";
  uhs: any = [];
  HTMLInteiro: HTMLElement;
  HTMLHead: HTMLElement;
  HTMLPrint: HTMLElement;
//  generator: Generator; 
  gen: any;
  style: any;

  afterPrint(){
    this.gen.document.close();
    this.gen.close();
  }

  printListagem() {
    this.gen = window.open("", "name", '');
    this.HTMLInteiro = document.getElementById('body') as HTMLElement;
    this.HTMLHead = document.getElementById('head') as HTMLElement;
    this.HTMLPrint = document.getElementById('listagem') as HTMLElement;

    this.gen.document.write('<html>');
    this.gen.document.write(this.HTMLHead.innerHTML);
    this.gen.document.write('<body onload="window.print();window.close();">');  
    this.gen.document.write(this.HTMLPrint.innerHTML);
    this.gen.document.write('</body></html>');
    window.onafterprint = this.afterPrint;
    //this.gen.print();
    this.gen.document.close();
    //this.gen.close();
  }

  recebedadoslkp(_ADados: any[]) {
    this.uhs = _ADados;
  }
  
  getLookupUHs(){
    this.insertFiltroCons("codemp", "=", this.activeRecord.codemp, true);
    this.cadIDLookup = 8;
    this.ExecConsLookup();
  }

  ngOnInit() {
    this.insertFiltroCons("codemp", "=", this.authService.codempresa.toString());
    this.ExecCons();    
  }

  AfterInsert(){
    this.activeRecord.codemp = this.authService.codempresa;
  }

  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "Períodos de apuração";
    this.cadID = 10;
    this.recno = 0;
    this.insertDescCons("Codperiodo", "Cód. Período", true, "number", "Geral", false);
    this.insertDescCons("codemp", "Cód. Empresa", true, "number", "Geral", false);
    this.insertDescCons("descricao", "Descrição", true, "text");
    this.insertDescCons("datainicio", "Data Início", true, "date");
    this.insertDescCons("datafim", "Data Fim", true, "date");
    this.insertDescCons("QtdeConsumoLuz", "Qtde Consumo Luz", false, "number", "Luz");
    this.insertDescCons("ValorTotalLuz", "Valor Total da Luz", false, "number", "Luz");
    this.insertDescCons("ValorUnLuz", "Valor Un. da Luz", false, "number", "Luz");
    this.insertDescCons("ValorAdBandAmarela", "Valor Adicional Band. Amarela", false, "number", "Luz");
    this.insertDescCons("ValorAdBandVermelha", "Valor Adicional Band. Vermelha", false, "number", "Luz");
    this.insertDescCons("ValorCosip", "Valor COSIP", false, "number", "Luz");

    this.insertDescCons("QtdeConsumoAgua", "Qtde Consumo Água", false, "number", "Água");
    this.insertDescCons("ValorTotalAgua", "Valor Total Água", false, "number", "Água");
    
    this.insertDescCons("ValorRateioGas", "Valor Rateio Gás", false, "number", "Gás");

    this.insertButtonRec("Lctos", "Leituras", "add");
    this.insertButtonRec("Delete", "Excluir", "clear");
    this.insertButtonRec("Gerar", "Gerar", "publish");
    this.insertButtonRec("Listagem", "Relatório", "description");
    this.insertButtonRec("Email", "Email", "contact_mail");
  }  
  
  getURLServerPost() {
    return super.getURLServerPost() +
      "&codemp=" + this.getValueFromEditableComp(this.activeRecord.codemp) +
      "&codperiodo=" + this.getValueFromEditableComp(this.activeRecord.codperiodo) +
      "&descricao=" + this.getValueFromEditableComp(this.activeRecord.descricao) +
      "&datainicio=" + this.getValueFromEditableComp(this.activeRecord.datainicio) +
      "&datafim=" + this.getValueFromEditableComp(this.activeRecord.datafim) +
      "&qtdeconsumoluz=" + this.getValueFromEditableComp(this.activeRecord.qtdeconsumoluz) +
      "&valortotalluz=" + this.getValueFromEditableComp(this.activeRecord.valortotalluz) +
      "&valorunluz=" + this.getValueFromEditableComp(this.activeRecord.valorunluz) +
      "&valoradbandamarela=" + this.getValueFromEditableComp(this.activeRecord.valoradbandamarela) +
      "&valoradbandvermelha=" + this.getValueFromEditableComp(this.activeRecord.valoradbandvermelha) +
      "&valorcosip=" + this.getValueFromEditableComp(this.activeRecord.valorcosip) +
      "&qtdeconsumoagua=" + this.getValueFromEditableComp(this.activeRecord.qtdeconsumoagua) +
      "&valortotalagua=" + this.getValueFromEditableComp(this.activeRecord.valortotalagua) +
      "&valorrateiogas=" + this.getValueFromEditableComp(this.activeRecord.valorrateiogas);
  }    

  setDescLctos(){
    this.descLctos = this.activeRecord.descricao + " - de " + 
                     this.activeRecord.datainicio + " até " +
                     this.activeRecord.datafim;
  }

  disableConsAndCad(){ 
    super.disableConsAndCad();
    this.ehLctos = false;
    this.ehListagem = false;
  }

  getURLGeraListagemPA(){
    let AURLGLPA = this.urlServer + "&cad=" + 1060 +
                                    "&codemp=" + this.activeRecord.codemp +
                                    "&codperiodo=" + this.activeRecord.codperiodo +
                                    "&conspart=1062";
    return AURLGLPA + "&act=c&filtro=" + this.getFiltrosCons(false);
  }  

  recebedadosGLPA(_ADados: any[]){
    let retorno = _ADados;
    if (retorno[0].valor == 1)
      alert("Listagem gerada com sucesso!");
    else
      alert("Erro ao gerar período! ");
  }

  gerarListagemPeriodoApuracao(){
    if (confirm("Deseja gerar listagem para este período?") === true){
      this.http.post<any[]>(this.getURLGeraListagemPA(), { }).
        subscribe(data => this.recebedadosGLPA(data));    
    }
  }

  getURLEmailCondominos(){
    let AURLGLPA = this.urlServer + "&cad=" + 1060 +
                                    "&codemp=" + this.activeRecord.codemp +
                                    "&codperiodo=" + this.activeRecord.codperiodo +
                                    "&conspart=1064";
    return AURLGLPA + "&act=c&filtro=" + this.getFiltrosCons(false);
  }
  recebedadosEmailCondominos(_ADados: any[]){
    let retorno = _ADados;
    if (retorno[0].valor == 1)
      alert("Emails enviados com sucesso!");
    else
      alert("Erro ao enviar emails! ");
  }  
  enviarEmailFechamentoPeriodo(){
    if (confirm("Deseja enviar email para todos os condôminos avisando que o demonstrativo está pronto?") === true){
      this.http.post<any[]>(this.getURLEmailCondominos(), { }).
        subscribe(data => this.recebedadosEmailCondominos(data));    
    }
  }

  buttonevent(_ARet: any){
    this.activeRecord = _ARet.record;
    if (_ARet.btnText === "add") {
      this.setDescLctos();
      this.disableConsAndCad();
      this.getLookupUHs();
      this.ehLctos = true;
    }
    else if (_ARet.btnText === "clear"){
      this.excluirregistro();
      this.ExecCons();
    } 
    else if (_ARet.btnText === "publish"){
      this.gerarListagemPeriodoApuracao();
    } 
    else if (_ARet.btnText === "description") {
      this.setDescLctos();
      this.disableConsAndCad();
      this.ehListagem = true;
    }
    else if (_ARet.btnText === "contact_mail") {
      this.enviarEmailFechamentoPeriodo();
    }
  }

  voltarConsultaPrinc(){
    this.disableConsAndCad();
    this.AfterPostEnableDisableScreen();
  }
}
