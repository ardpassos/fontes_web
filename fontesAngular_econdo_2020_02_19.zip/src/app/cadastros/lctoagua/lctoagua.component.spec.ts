import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LctoaguaComponent } from './lctoagua.component';

describe('LctoaguaComponent', () => {
  let component: LctoaguaComponent;
  let fixture: ComponentFixture<LctoaguaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LctoaguaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LctoaguaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
