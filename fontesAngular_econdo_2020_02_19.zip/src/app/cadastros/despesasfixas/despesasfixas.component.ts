import { AuthService } from './../../login/auth.service';
import { HttpClient } from '@angular/common/http';
import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-despesasfixas',
  templateUrl: './despesasfixas.component.html',
  styleUrls: ['./despesasfixas.component.css']
})
export class DespesasfixasComponent extends FormBaseComponent implements OnInit {


  ngOnInit() {
    this.insertFiltroCons("codemp", "=", this.authService.codempresa.toString());
    this.ExecCons();    
  }

  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "Despesas fixas";
    this.cadID = 9;
    this.recno = 0;
    this.insertDescCons("coddespesa", "Cód. Despesa", true, "number", "Geral", false);
    this.insertDescCons("codemp", "Cód. Empresa", true, "number", "Geral", false);
    this.insertDescCons("descricao", "Descrição", true, "text");
    this.insertDescCons("ValorPadrao", "Valor Padrão", true, "number");
    this.insertDescCons("EhLuz", "É Luz?", false, "text", "Luz");
    this.insertDescCons("TipoRateioLuz", "Rateio luz", false, "text", "Luz");
    this.insertDescCons("EhGas", "É Gás?", false, "text", "Gás");
    this.insertDescCons("TipoRateioGas", "Rateio Gás", false, "text", "Gás");
    this.insertDescCons("EhAgua", "É Água?", false, "text", "Água");
    this.insertDescCons("TipoRateioAgua", "Rateio Água", false, "text", "Água");
  }  

  getURLServerPost() {
    return super.getURLServerPost() +
      "&codemp=" + this.activeRecord.codemp +
      "&coddespesa=" + this.activeRecord.coddespesa +
      "&descricao=" + this.activeRecord.descricao +
      "&valorpadrao=" + this.activeRecord.valorpadrao +
      "&ehluz=" + this.activeRecord.ehluz +
      "&tiporateioluz=" + this.activeRecord.tiporateioluz +
      "&ehgas=" + this.activeRecord.ehgas +
      "&tiporateiogas=" + this.activeRecord.tiporateiogas +
      "&ehagua=" + this.activeRecord.ehagua +
      "&tiporateioagua=" + this.activeRecord.tiporateioagua;
  }  

  AfterInsert(){
    this.activeRecord.codemp = this.authService.codempresa;
  }

}
