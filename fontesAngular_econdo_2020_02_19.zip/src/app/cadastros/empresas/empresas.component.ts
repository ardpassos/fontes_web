import { HttpClient } from '@angular/common/http';
import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-empresas',
  templateUrl: './empresas.component.html',
  styleUrls: ['./empresas.component.css']
})
export class EmpresasComponent extends FormBaseComponent implements OnInit {

  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "Empresas";
    this.cadID = 7;
    this.recno = 0;
    this.insertDescCons("codempresa", "Cód. Empresa", true, "number");
    this.insertDescCons("razaosocial", "Razão Social", true, "text");
    this.insertDescCons("nomefantasia", "Nome Fantasia", true, "text");
    this.insertDescCons("cnpj", "CNPJ", false, "text");
    this.insertDescCons("ehsistemavarejo", "Sistema de Varejo", false, "text", "Geral", true, true);
    this.insertDescCons("servidor_db", "Servidor DB", false, "text", "Banco de dados");
    this.insertDescCons("nome_db", "Nome do DB", false, "text", "Banco de dados");
    this.insertDescCons("usuario_db", "Usuário DB", false, "text", "Banco de dados");
    this.insertDescCons("senha_db", "Senha DB", false, "text", "Banco de dados");
  }

  getURLServerPost() {
    return super.getURLServerPost() +
      "&codempresa=" + this.getValueFromEditableComp(this.activeRecord.codempresa) +
      "&razaosocial=" + this.getValueFromEditableComp(this.activeRecord.razaosocial) +
      "&nomefantasia=" + this.getValueFromEditableComp(this.activeRecord.nomefantasia) +
      "&cnpj=" + this.getValueFromEditableComp(this.activeRecord.cnpj) +
      "&ehsistemavarejo=" + this.getValueFromEditableComp(this.activeRecord.ehsistemavarejo) +
      "&servidor_db=" + this.getValueFromEditableComp(this.activeRecord.servidor_db) +
      "&nome_db=" + this.getValueFromEditableComp(this.activeRecord.nome_db) +
      "&usuario_db=" + this.getValueFromEditableComp(this.activeRecord.usuario_db) +
      "&senha_db=" + this.getValueFromEditableComp(this.activeRecord.senha_db);
  }
  ngOnInit() {
    this.ExecCons();
  }

}
