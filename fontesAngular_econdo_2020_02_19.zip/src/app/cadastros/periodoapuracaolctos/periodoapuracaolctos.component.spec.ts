import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PeriodoapuracaolctosComponent } from './periodoapuracaolctos.component';

describe('PeriodoapuracaolctosComponent', () => {
  let component: PeriodoapuracaolctosComponent;
  let fixture: ComponentFixture<PeriodoapuracaolctosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PeriodoapuracaolctosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PeriodoapuracaolctosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
