import { HttpClient } from '@angular/common/http';
import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { delay } from 'rxjs/operators';

@Component({
  selector: 'app-periodoapuracaolctos',
  templateUrl: './periodoapuracaolctos.component.html',
  styleUrls: ['./periodoapuracaolctos.component.css']
})
export class PeriodoapuracaolctosComponent extends FormBaseComponent implements OnInit {

  //  @Input() descCons: any[];
  //  @Input() descConsGrid: any[];
  @Input() recordmaster: any;
  //  @Input() buttonsRecord: any[];
  recordsToPost: any = [];
  recordsToPostActions: any = [];
  canRefreshCons: boolean = true;

  ngOnInit() {
  }

  buttonEvent(rec: []) {
  }

  editarRegistro(rec: []) {
  }

  novoRegistro() {
    this.activeRecord = {};
    this.AfterInsert();
    this.records.push(this.activeRecord);
    //this.descTabsCad.push({});
  }

  AfterPostCad() {
    if (this.canRefreshCons)
      this.ExecCons();
  }

  AfterPostEnableDisableScreen() {
  }

  addRecordToPost(rec, _Act) {
    if (this.recordsToPost.indexOf(rec) == -1) {
      this.recordsToPost.push(rec);
      this.recordsToPostActions.push(_Act);
    }
  }

  getKeyValueActiveRecord(){
    return 0;
  }

  salvarRegistroByRec(rec) {
    this.activeRecord = rec;

    if (this.getKeyValueActiveRecord() > 0)
      this.cadInsUpd = 'p';
    else
      this.cadInsUpd = 'i';
    this.salvarregistro();
  }

  sleep(ms = 0) {
    return new Promise(r => setTimeout(r, ms));
  }

  salvarTodosRec() {
    this.canRefreshCons = false;
    try {
      let x = this.recordsToPost.length;
      let y = 0;
//      console.log(this.recordsToPost);
      for (let rec of this.recordsToPost) {

        y += 1;
        if (x === y)
          this.canRefreshCons = true;
//          console.log(rec);
        if (this.recordsToPostActions[y-1] == "d")
          this.excluirRegistroByRec(rec);
        else
          this.salvarRegistroByRec(rec);
          
      }
    }
    finally {
      this.canRefreshCons = true;
      this.recordsToPost = [];
      this.recordsToPostActions = [];
    }
  }

  excluirSalvandoRegistroByRec(rec) {
    this.addRecordToPost(rec, "d");
    this.salvarTodosRec();
  }

  getDisabledRec(_ARec) {
    return true;
  }

  getSelected(_ACodField){
  }

  changeCampo(_AEvent, rec) {
    _AEvent.target.style.backgroundColor = 'LightGoldenRodYellow';
    this.addRecordToPost(rec, "p");
  }

  ExitLine(_ARec) {
  }

}
