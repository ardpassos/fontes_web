import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PeriodoapuracaorellctosComponent } from './periodoapuracaorellctos.component';

describe('PeriodoapuracaorellctosComponent', () => {
  let component: PeriodoapuracaorellctosComponent;
  let fixture: ComponentFixture<PeriodoapuracaorellctosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PeriodoapuracaorellctosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PeriodoapuracaorellctosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
