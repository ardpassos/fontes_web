import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PeriodoapuracaolctosaguaComponent } from './periodoapuracaolctosagua.component';

describe('PeriodoapuracaolctosaguaComponent', () => {
  let component: PeriodoapuracaolctosaguaComponent;
  let fixture: ComponentFixture<PeriodoapuracaolctosaguaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PeriodoapuracaolctosaguaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PeriodoapuracaolctosaguaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
