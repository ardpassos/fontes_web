import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PeriodoapuracaolctosgasComponent } from './periodoapuracaolctosgas.component';

describe('PeriodoapuracaolctosgasComponent', () => {
  let component: PeriodoapuracaolctosgasComponent;
  let fixture: ComponentFixture<PeriodoapuracaolctosgasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PeriodoapuracaolctosgasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PeriodoapuracaolctosgasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
