import { PeriodoapuracaolctosComponent } from '../periodoapuracaolctos/periodoapuracaolctos.component';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-periodoapuracaolctosgas',
  templateUrl: './periodoapuracaolctosgas.component.html',
  styleUrls: ['./periodoapuracaolctosgas.component.css']
})
export class PeriodoapuracaolctosgasComponent extends PeriodoapuracaolctosComponent implements OnInit {

  @Input() uhs: any = [];

  getShowSelectField(_AFieldName: string){
    return _AFieldName === "coduh";
  }
  
  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "Lançamentos das leituras - gás";
    this.cadID = 11;
    this.recno = 0;
    this.insertDescCons("CodLctoGas", "Cód. Lcto Gás", false, "number");
    this.insertDescCons("codemp", "Cód. Empresa", false, "number");
    this.insertDescCons("CodPeriodo", "Cód. Período", false, "number");
    this.insertDescCons("DataLeitura", "Data Leitura", true, "date");
    this.insertDescCons("CodUH", "Cód. UH", true, "number");
    this.insertDescCons("ValorLeitura", "Valor Leitura", true, "number");
    this.insertDescCons("ValorUltimaLeitura", "Valor Última Leitura", false, "number");
  }  
  
  getURLServerPost() {
    return super.getURLServerPost() +
      "&codlctogas=" + this.getValueFromEditableComp(this.activeRecord.codlctogas) +
      "&codemp=" + this.getValueFromEditableComp(this.recordmaster.codemp) +
      "&codperiodo=" + this.getValueFromEditableComp(this.recordmaster.codperiodo) +
      "&dataleitura=" + this.getValueFromEditableComp(this.activeRecord.dataleitura) +
      "&coduh=" + this.getValueFromEditableComp(this.activeRecord.coduh) +
      "&valorleitura=" + this.getValueFromEditableComp(this.activeRecord.valorleitura) +
      "&valorultimaleitura=" + this.getValueFromEditableComp(this.activeRecord.valorultimaleitura);
  }

  getKeyValueActiveRecord(){
    return this.activeRecord.codlctogas;
  }

  AfterInsert(){
    this.activeRecord.dataleitura = this.getDataAtual();
  }

  ngOnInit() {
    this.insertFiltroCons("codemp", "=", this.recordmaster.codemp);
    this.insertFiltroCons("codperiodo", "=", this.recordmaster.codperiodo);
    this.ExecCons();
  }  
}
