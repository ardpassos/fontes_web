import { AuthService } from './../../login/auth.service';
import { HttpClient } from '@angular/common/http';
import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uhs',
  templateUrl: './uhs.component.html',
  styleUrls: ['./uhs.component.css']
})
export class UhsComponent extends FormBaseComponent implements OnInit {
 

  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "Unidades habitacionais - UHs";
    this.cadID = 8;
    this.recno = 0;
    this.insertDescCons("coduh", "Cód. UH", true, "number", "Geral", false);
    this.insertDescCons("codemp", "Cód. Empresa", true, "number", "Geral", false);
    this.insertDescCons("descricao", "UH", true, "text");
    this.insertDescCons("numpessoasuh", "Pessoas", false, "number");
    this.insertDescCons("senha", "Senha", false, "text");
    this.insertDescCons("datainicio", "Data Início", false, "date");
    this.insertDescCons("ehaluguel", "É Aluguel?", false, "text", "Aluguel", true, true);
    this.insertDescCons("valoraluguel", "V. Aluguel", false, "number", "Aluguel");
    this.insertDescCons("ehcond", "É Cond?", false, "text", "Condomínio", true, true);
    this.insertDescCons("valorcond", "V. Condomínio", false, "number", "Condomínio");
    this.insertDescCons("nomecontato", "Nome contato", false, "text", "Contato");
    this.insertDescCons("emailcontato", "Email contato", false, "text", "Contato");
    this.insertDescCons("fonecontato", "Fone contato", false, "text", "Contato");

    this.insertButtonRec("Delete", "Excluir", "clear");
    this.insertButtonRec("Email", "Email", "contact_mail");
  }

  getURLServerPost() {
    return super.getURLServerPost() +
      "&codemp=" + this.activeRecord.codemp +
      "&coduh=" + this.getARValueFromName("coduh") +
      "&descricao=" + this.getARValueFromName("descricao") +
      "&ehaluguel=" + this.getARValueFromName("ehaluguel")+
      "&valoraluguel=" + this.getARValueFromName("valoraluguel") +
      "&ehcond=" + this.getARValueFromName("ehcond") +
      "&valorcond=" + this.getARValueFromName("valorcond") +
      "&senha=" + this.getARValueFromName("senha") +
      "&datainicio=" + this.getARValueFromName("datainicio") +
      "&numpessoasuh=" + this.getARValueFromName("numpessoasuh") +
      "&nomecontato=" + this.getARValueFromName("nomecontato") +
      "&emailcontato=" + this.getARValueFromName("emailcontato") +
      "&fonecontato=" + this.getARValueFromName("fonecontato");
  }

  getURLEmailUsuarioSenhaUH(){
    let AURL = this.urlServer + "&cad=" + 8 +
                                "&coduh=" + this.activeRecord.coduh;
    return AURL + "&act=8001&filtro=" + this.getFiltrosCons(false);
  }
  recebedadosEmailUsuarioSenhaUH(_ADados: any[]){
    let retorno = _ADados;
    if (retorno[0].retorno == 1)
      alert("Email enviado com sucesso!");
    else
      alert("Erro ao enviar email! ");
  }    
  enviarEmailUsuarioSenhaUH(_ARec){
    if (confirm("Deseja enviar email para esta UH informando seu usuário e senha?") === true){
      this.http.post<any[]>(this.getURLEmailUsuarioSenhaUH(), { }).
        subscribe(data => this.recebedadosEmailUsuarioSenhaUH(data));    
    }
  }

  buttonevent(_ARet: any){
    this.activeRecord = _ARet.record;
    if (_ARet.btnText === "clear"){
      this.excluirregistro();
      this.ExecCons();
    } 
    else if (_ARet.btnText === "contact_mail") {
      this.enviarEmailUsuarioSenhaUH(this.activeRecord);
    }
  }
  
  AfterInsert(){
    this.activeRecord.codemp = this.authService.codempresa;
  }

  ngOnInit() {
    this.insertFiltroCons("codemp", "=", this.authService.codempresa.toString());
    this.ExecCons();
  }
}
