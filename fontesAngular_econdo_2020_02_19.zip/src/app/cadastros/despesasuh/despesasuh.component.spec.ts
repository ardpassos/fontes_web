import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DespesasuhComponent } from './despesasuh.component';

describe('DespesasuhComponent', () => {
  let component: DespesasuhComponent;
  let fixture: ComponentFixture<DespesasuhComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DespesasuhComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DespesasuhComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
