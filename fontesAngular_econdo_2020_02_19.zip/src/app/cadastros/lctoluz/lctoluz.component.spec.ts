import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LctoluzComponent } from './lctoluz.component';

describe('LctoluzComponent', () => {
  let component: LctoluzComponent;
  let fixture: ComponentFixture<LctoluzComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LctoluzComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LctoluzComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
