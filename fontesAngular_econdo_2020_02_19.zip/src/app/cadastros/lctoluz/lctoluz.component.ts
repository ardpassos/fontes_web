import { HttpClient } from '@angular/common/http';
import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lctoluz',
  templateUrl: './lctoluz.component.html',
  styleUrls: ['./lctoluz.component.css']
})
export class LctoluzComponent extends FormBaseComponent implements OnInit {

  ngOnInit() {

  }

  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "Lançamentos das leituras - luz";
    this.cadID = 12;
    this.recno = 0;
    this.insertDescCons("CodLctoLuz", "Cód. Lcto Luz", true, "number");
    this.insertDescCons("codemp", "Cód. Empresa", true, "number");
    this.insertDescCons("CodPeriodo", "Cód. Período", true, "number");
    this.insertDescCons("DataLeitura", "Data Leitura", false, "date");
    this.insertDescCons("CodUH", "Cód. UH", false, "number");
    this.insertDescCons("ValorLeitura", "Valor Leitura", false, "number");
    this.insertDescCons("ValorUltimaLeitura", "Valor Última Leitura", false, "number");
  }  
}
