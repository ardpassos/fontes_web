import { AuthService } from './login/auth.service';
import { Component } from '@angular/core';
import { usuarioLogado } from './login/usuariologado';
import { Router } from '@angular/router';

//ng build --prod --base-href /dist/econdo/

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'econdo';
  logado: boolean = false;

  usuariologado: usuarioLogado = null;
  usuarioAdministrador: boolean = false;

  constructor(private router:Router, public authService: AuthService){

  }  

  ngOnInit(){
    this.authService.mostrarMenuEmitter.subscribe(logado => {
      this.logado = logado;
      this.usuariologado = this.authService.usuarioRetorno[0];
      this.usuarioAdministrador = this.authService.ehadministrador;
      this.redirectAfterLogin();
    });
  }

  redirectAfterLogin(){
    if (this.authService.logado) {
      this.authService.msgloginerror = "";
      if (this.authService.logadocond)
        this.router.navigate(["/cadastros"]);
      else if (this.authService.logadouh)
        this.router.navigate(["/paineluh"]);
      else
        this.router.navigate(["/cadastros"]);
    }
    else {
      this.authService.msgloginerror = "Usuário inválido!";
      this.router.navigate(["/login"]);
    }
  }
}
