import { AuthService } from './../login/auth.service';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-form-base',
  template: '<div></div>'
})
export class FormBaseComponent implements OnInit {

  public urlServer: string = "/demo/cad.php?-2=passos_teste";//&cad=-1&act=c
  public cadID: number = -1;
  public cadIDLookup: number = -1;
  public DescricaoSuperiorTela: String = "Cadastro...";
  public cadInsUpd: string = "p";
  ehconsulta = true;
  ehcadastro = false;
  records: any = [];
  buttonsRecord: any = [];
  activeRecord: any;
  FiltrosCons: any = [];
  FiltrosConsLookup: any = [];
  recno: number = -1;
  ARec: any;
  descConsGrid: any[] = [];
  descCons: any[] = [];
  descTabsCad: any[] = [];
  ASize: string;

  formulario: FormGroup;

  constructor(public http: HttpClient, public authService: AuthService) {
    this.inicializaCad();
  }

  inicializaCad() {

  }

  ngOnInit() {
  }

  getARValueFromName(_AName) {
    let AValue = this.activeRecord[_AName];
    if ((AValue === undefined) || (AValue === null))
      AValue = "";
    else
      AValue = AValue;
    return AValue;
  }
  getValueFromEditableComp(_AValue: String) {
    if (_AValue === undefined)
      return "";
    else
      return _AValue;
  }

  insertInDescCad(_ADesc: string) {
    for (var i = 0; i < this.descTabsCad.length; i++) {
      if (this.descTabsCad[i].descTabCad == _ADesc) {
        return;
      }
    }
    this.descTabsCad.push({ descTabCad: _ADesc });
  }

  setLookupNameValues(_ANomeCampo: String, _ALookupNameValues:any){
    for (let desc of this.descCons){
      if (desc.nomecampo == _ANomeCampo){
        desc.ehlookup = true;
        desc.LookupNameValues = _ALookupNameValues;
        desc.size = "s8";
      } 
    }
  }

  insertDescCons(_ANomeCampo: string, _ADescCampo: string, _AMostrarNaCons: boolean,
    _AInputType: string, _ADescTabCad: string = "Geral", _AMostrarCad: boolean = true,
    _AEhBoolean = false) {
    this.insertInDescCad(_ADescTabCad);
    this.ASize = "s4";
    if ((_AInputType == "number") || (_AInputType == "time") || (_AInputType == "date"))
      this.ASize = "s2";

    this.ARec = {
      nomecampo: _ANomeCampo.toLowerCase(),
      desccampo: _ADescCampo,
      mostrarcons: _AMostrarNaCons,
      inputtype: _AInputType,
      size: this.ASize,
      descTabCad: _ADescTabCad,
      mostrarCad: _AMostrarCad,
      ehboolean: _AEhBoolean ,
      ehlookup: false,
      LookupNameValues: null // {"desc": "Descrição", "valor": "1"}
    };

    this.descCons.push(this.ARec);
    if (_AMostrarNaCons)
      this.descConsGrid.push(this.ARec);
  }

  insertFiltroCons(_ANomeCampo: string, _AComp: string, _AValor: String, _ALkp: boolean=false, _AFiltroURL: boolean=false) {
    this.ARec = {
      nomecampo: _ANomeCampo.toLowerCase(),
      comp: _AComp,
      valor: _AValor,
      filtrourl: _AFiltroURL
    };

    if (_ALkp)
      this.FiltrosConsLookup.push(this.ARec);
    else
      this.FiltrosCons.push(this.ARec);
  }  

  insertButtonRec(_ANomeBut: string, _ADescBut: string, _ATipo) {
    this.buttonsRecord.push({
      nomebut: _ANomeBut.toLowerCase(),
      descbut: _ADescBut,
      tipo: _ATipo
    });
  }

  getURLSistema(){
    if (this.authService.ehsistemavarejo)
      return "&sys=v";
    else
      return "&sys=c";
  }

  getURLServer() {
    return this.urlServer + this.getURLSistema() + "&cad=" + this.cadID;
  }
  getURLServerLookup() {
    return this.urlServer + this.getURLSistema() + "&cad=" + this.cadIDLookup;
  }

  getURLServerCons() {
    return this.getURLServer() + "&act=c&filtro=" + this.getFiltrosCons(false);
  }

  getURLServerConsLookup() {
    return this.getURLServerLookup() + "&act=l&filtro=" + this.getFiltrosCons(true);
  }

  getActPost() {
    return "&act=" + this.cadInsUpd;
  }

  getURLServerPost() {
    return this.getURLServer() + this.getActPost();
  }

  getFiltrosCons(_ALkp: boolean) {
    let AResult: String = "";
    let AFiltrosCons = [];
    if (_ALkp)
      AFiltrosCons = this.FiltrosConsLookup;
    else
      AFiltrosCons = this.FiltrosCons;
    for (let filtro of AFiltrosCons) {
      if (!filtro.filtrourl)
        AResult += filtro.nomecampo + "|" + filtro.comp + "|" + filtro.valor + "|[";
      else
        AResult += "&" + filtro.nomecampo + "=" + filtro.valor;
    }
    return AResult;
  }

//GetLookupData
  recebedadoslkp(_ADados: any[]) {
  }

  ExecConsLookup(_ACadIdLkp = -1){
    if (_ACadIdLkp > -1)
      this.cadIDLookup = _ACadIdLkp;
    params: HttpParams;
    let params = new HttpParams();

    this.http.post<any[]>(this.getURLServerConsLookup(), { params }).
      subscribe(data => this.recebedadoslkp(data));
  }


  recebedados(_ADados: any[]) {
    this.records = _ADados;
  }

  AfterPostCad(){
    this.ExecCons();
  }

  recebedadosPost(_ADados: any[]) {
    this.AfterPostCad();
  }

  ExecCons() {
    params: HttpParams;
    let params = new HttpParams();
    //params = params.append('username', userName);
    //console.log(params.get('password'));
    this.http.post<any[]>(this.getURLServerCons(), { params }).
      subscribe(data => this.recebedados(data));
  }

  ExecPost() {
    params: HttpParams;
    let params = new HttpParams();
    //params = params.append('username', userName);
    //console.log(this.getURLServerPost());
    this.http.post<any[]>(this.getURLServerPost(), { params }).
      subscribe(data => this.recebedadosPost(data));
  }

  ExecDel() {
    params: HttpParams;
    let params = new HttpParams();
    this.http.post<any[]>(this.getURLServerPost(), { params }).
      subscribe(data => this.recebedadosPost(data));
  }
  
  disableConsAndCad(){
    this.ehconsulta = false;
    this.ehcadastro = false;
  }

  novoRec(rec: any) {
    this.cadInsUpd = "i";
    this.activeRecord = rec;
    this.AfterInsert();
    //this.recno = index;
    this.ehconsulta = false;
    this.ehcadastro = true;
  }
  editarRecAtual(rec: any) {
    this.cadInsUpd = "p";
    this.activeRecord = rec;
    //this.recno = index;
    this.ehconsulta = false;
    this.ehcadastro = true;
  }

  editarregistro(rec: any) {
    if (rec.length == 0)
      this.novoRec(rec);
    else
    this.editarRecAtual(rec);
  }

  buttonevent(rec: any) {    
  }

  AfterInsert(){

  }

  AfterPostEnableDisableScreen(){
    this.ehconsulta = true;
    this.ehcadastro = false;
  }

  salvarregistro() {
    this.ExecPost();
    this.AfterPostEnableDisableScreen();
  }

  excluirRegistroByRec(rec) {
    this.activeRecord = rec;
    this.excluirregistro();
  }
  
  excluirregistro() {
    this.cadInsUpd = "d";
    this.ExecDel();
    this.AfterPostEnableDisableScreen();
  }

  cancelarEdicao() {
    this.AfterPostEnableDisableScreen();
    this.ExecCons();
  }


  public getDataAtual(_AFormat: string = "") {
    const date = new Date();
    const ano = date.getFullYear();
    const mes = date.getMonth()+1;
    const dia = date.getDate();
    let mesValor = ((mes < 10) ? '0' : '').concat(mes.toString())
    let diaValor = ((dia < 10) ? '0' : '').concat(dia.toString())

    if (_AFormat === "ddmmyyyy")
      return diaValor.toString().concat('/').concat(mesValor).concat('/').concat(ano.toString());
    else
      return ano.toString().concat('-').concat(mesValor).concat('-').concat(diaValor);
}  
}
