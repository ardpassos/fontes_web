
export class Usuario  {
    codemp: string;
    nome: string;
    senha: string;
}