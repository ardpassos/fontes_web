import { HttpClient, HttpParams } from '@angular/common/http';
import { Usuario } from './usuario';
import { Injectable, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { usuarioLogado } from './usuariologado';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private urlLogin: string = "/demo/cad.php?-2=passos_teste&cad=-1&act=c"; //&username=ale&password=ale
  public logado: boolean = false;
  public logadoadm: boolean = false;
  public logadocond: boolean = false;
  public logadouh: boolean = false;
  public ehsistemavarejo: boolean = false;
  public msgloginerror: string = "";
  public codempresa: number = 0;
  public ehadministrador: boolean = false;
  public usuarioRetorno: usuarioLogado[] = [];
  mostrarMenuEmitter = new EventEmitter<boolean>();

  constructor(private router:Router, private http: HttpClient) { }

  getUsuario(codemp: string, userName: string, password: string): Observable<usuarioLogado[]> {
    //console.log(this.http.get<usuarioLogado[]>(this.urlLogin));
    //return this.http.get<usuarioLogado[]>(this.urlLogin);
    params: HttpParams;
    let params = new HttpParams();
    params = params.append('codemp', codemp);
    params = params.append('username', userName);
    params = params.append('password', password);
    //console.log(params.get('password'));

    return this.http.post<usuarioLogado[]>(this.urlLogin + "&sys=c" + "&codemp=" + codemp + "&username=" + userName + "&password=" + password, 
      {params});
  }

  validaLogin(usuario: Usuario, data: usuarioLogado[]){
    this.usuarioRetorno = data;
    if ((this.usuarioRetorno.length > 0) && 
        (this.usuarioRetorno[0].username != "") &&
        (this.usuarioRetorno[0].password != "")) {
          this.logado = true;
          this.codempresa = this.usuarioRetorno[0].codempresa;
          this.ehadministrador = (this.usuarioRetorno[0].ehadministrador=="s");
          this.logadoadm = this.usuarioRetorno[0].ehadministrador=="s";
          this.logadocond = this.usuarioRetorno[0].ehcond=="s";
          this.logadouh = this.usuarioRetorno[0].ehusuariouh=="s";
          this.ehsistemavarejo = this.usuarioRetorno[0].ehsistemavarejo=="s"; 
          console.log(this.usuarioRetorno[0]);
          this.mostrarMenuEmitter.emit(this.logado);
       //   this.router.navigate(["/home"]);
        } 
        else {
          this.logado = false;
          this.logadoadm = false;
          this.logadocond = false;
          this.logadouh = false;
          this.ehsistemavarejo = false;
          this.mostrarMenuEmitter.emit(this.logado);
     //     this.router.navigate(["/login"]);
        }    
  }

  fazerLogin(usuario: Usuario){
    this.logado = false;
    this.getUsuario(usuario.codemp, usuario.nome, usuario.senha).subscribe(data =>  this.validaLogin(usuario, data));  
  }

  usuarioAutenticado(){
    return this.logado;
  }

}
