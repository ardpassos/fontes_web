
import { Component, OnInit } from '@angular/core';
import { AuthService } from './auth.service';
import { Usuario } from './usuario';

//ng build --prod --base-href /dist/econdo/

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public usuario: Usuario = new Usuario();
  constructor(public authService: AuthService) { }

  ngOnInit() {
    this.usuario.codemp = "";
    this.usuario.nome = "";
    this.usuario.senha = "";
  }

  getCodEmpresa(){
    return this.authService.codempresa;
  }

  getEhAdministrador(){
    return this.authService.ehadministrador;
  }

  fazerLogin(){
    this.authService.fazerLogin(this.usuario);
  }
  clickLabel(_AId){
    document.getElementById(_AId).focus();
  }
}
