export interface usuarioLogado{
    codfunc: number;
    nomefunc: string;
    username: string;
    password: string;
    codlientecobranca: number;
    codversao: number;
    codupdate: number;
    codempresa: number;
    descempresa: string;
    ehusuariouh: string;
    ehcond: string;
    ehadministrador: string;
    ehsistemavarejo: string;
}