import { MenuFinanceiroVarejoComponent } from './varejo/menu-financeiro-varejo/menu-financeiro-varejo.component';
import { MenuEstoqueVarejoComponent } from './varejo/menu-estoque-varejo/menu-estoque-varejo.component';
import { CadProdutosComponent } from './varejo/cad-produtos/cad-produtos.component';
import { CadGruposprodutosComponent } from './varejo/cad-gruposprodutos/cad-gruposprodutos.component';
import { CadMarcasComponent } from './varejo/cad-marcas/cad-marcas.component';
import { CadLocalalmoxComponent } from './varejo/cad-localalmox/cad-localalmox.component';
import { CadUnmedidasComponent } from './varejo/cad-unmedidas/cad-unmedidas.component';
import { CadPessoasComponent } from './varejo/cad-pessoas/cad-pessoas.component';
import { CadFuncionariosComponent } from './varejo/cad-funcionarios/cad-funcionarios.component';
import { MenuCadastrosVarejoComponent } from './varejo/menu-cadastros-varejo/menu-cadastros-varejo.component';
import { PaineluhComponent } from './paineluh/paineluh.component';
import { DespesasuhComponent } from './cadastros/despesasuh/despesasuh.component';
import { LctoaguaComponent } from './cadastros/lctoagua/lctoagua.component';
import { LctogasComponent } from './cadastros/lctogas/lctogas.component';
import { LctoluzComponent } from './cadastros/lctoluz/lctoluz.component';
import { PeriodoapuracaoComponent } from './cadastros/periodoapuracao/periodoapuracao.component';
import { PeriodoapuracaolctosComponent } from './cadastros/periodoapuracaolctos/periodoapuracaolctos.component';
import { DespesasfixasComponent } from './cadastros/despesasfixas/despesasfixas.component';
import { UhsComponent } from './cadastros/uhs/uhs.component';
import { EmpresasComponent } from './cadastros/empresas/empresas.component';
import { CadastrosComponent } from './cadastros/cadastros.component';
import { AuthGuard } from './guard/auth-guard';
import { UsuariosComponent } from './usuarios/usuarios.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SolicitacontatoComponent } from './solicitacontato/solicitacontato.component';
import { AreacomumComponent } from './cadastros/areacomum/areacomum.component';

const routes: Routes = [
  {path: '', component: HomeComponent},
  {path: 'home', component: HomeComponent},
  {path: 'login', component: LoginComponent},
  {path: 'solicitacontato', component: SolicitacontatoComponent},
  {path: 'usuarios', component: UsuariosComponent, canActivate: [AuthGuard]},
  {path: 'paineluh', component: PaineluhComponent, canActivate: [AuthGuard]},
  {path: 'cadastros', component: CadastrosComponent, canActivate: [AuthGuard]},
  {path: 'cadastros/empresas', component: EmpresasComponent, canActivate: [AuthGuard]},
  {path: 'cadastros/uhs', component: UhsComponent, canActivate: [AuthGuard]},
  {path: 'cadastros/areacomum', component: AreacomumComponent, canActivate: [AuthGuard]},
  {path: 'cadastros/despesasfixas', component: DespesasfixasComponent, canActivate: [AuthGuard]},
  {path: 'cadastros/periodoapuracao', component: PeriodoapuracaoComponent, canActivate: [AuthGuard]},
  {path: 'cadastros/periodoapuracaolctos', component: PeriodoapuracaolctosComponent, canActivate: [AuthGuard]},
  {path: 'cadastros/lctoluz', component: LctoluzComponent, canActivate: [AuthGuard]},
  {path: 'cadastros/lctogas', component: LctogasComponent, canActivate: [AuthGuard]},
  {path: 'cadastros/lctoagua', component: LctoaguaComponent, canActivate: [AuthGuard]},
  {path: 'cadastros/despesasuh', component: DespesasuhComponent, canActivate: [AuthGuard]},
  // sistema de varejo
  {path: 'varejo/menu-cadastros-varejo', component: MenuCadastrosVarejoComponent, canActivate: [AuthGuard]},
  {path: 'varejo/menu-estoque-varejo', component: MenuEstoqueVarejoComponent, canActivate: [AuthGuard]},
  {path: 'varejo/menu-financeiro-varejo', component: MenuFinanceiroVarejoComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-funcionarios', component: CadFuncionariosComponent, canActivate: [AuthGuard]},
  {path: 'varejo/clientes-fornecedores', component: CadPessoasComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-unmedidas', component: CadUnmedidasComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-localalmox', component: CadLocalalmoxComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-marcas', component: CadMarcasComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-gruposprodutos', component: CadGruposprodutosComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-produtos', component: CadProdutosComponent, canActivate: [AuthGuard]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
