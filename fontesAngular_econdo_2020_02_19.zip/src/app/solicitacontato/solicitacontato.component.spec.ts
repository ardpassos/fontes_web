import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SolicitacontatoComponent } from './solicitacontato.component';

describe('SolicitacontatoComponent', () => {
  let component: SolicitacontatoComponent;
  let fixture: ComponentFixture<SolicitacontatoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SolicitacontatoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SolicitacontatoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
