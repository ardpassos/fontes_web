import { HttpClient } from '@angular/common/http';
import { FormBaseComponent } from './../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-solicitacontato',
  templateUrl: './solicitacontato.component.html',
  styleUrls: ['./solicitacontato.component.css']
})
export class SolicitacontatoComponent extends FormBaseComponent implements OnInit {

  nome = "";
  email = "";
  ddd = "";
  fone = "";
  obs = "";
  enviado = false;

  ngOnInit() {
  }

  clickLabel(_AId){
    document.getElementById(_AId).focus();
  }
  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "CONTATO";
    this.cadID = 20;
    this.recno = 0;
  }

  getURLServerPost() {
    return super.getURLServerPost() +
      "&nome=" + this.nome +
      "&email=" + this.email +
      "&ddd=" + this.ddd +
      "&fone=" + this.fone +
      "&obs=" + this.obs;
  }

  AfterPostCad(){
    this.nome = "";
    this.email = "";
    this.ddd = "";
    this.fone = "";
    this.obs = "";    
    this.enviado = true;
  }
  
  enviarSolicitacao(){
    this.cadInsUpd = "i";
    this.ExecPost();
  }

}
