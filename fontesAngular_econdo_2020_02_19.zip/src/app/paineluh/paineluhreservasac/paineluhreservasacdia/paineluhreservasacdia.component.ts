import { AuthService } from './../../../login/auth.service';
import { HttpClient, HttpParams } from '@angular/common/http';
import { FormBaseComponent } from './../../../form-base/form-base.component';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import * as moment from 'moment';

@Component({
  selector: 'app-paineluhreservasacdia',
  templateUrl: './paineluhreservasacdia.component.html',
  styleUrls: ['./paineluhreservasacdia.component.css']
})
export class PaineluhreservasacdiaComponent extends FormBaseComponent implements OnInit{

  @Input() dia: String;
  @Input() recordmaster: any;
  recordsReservasAC: any=[];
  recordPosting: any;
  public descDia: String = "";
  public diaSelecionado = moment();
  diasSemana = ["Domingo", "Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado"];

  inicializaCad() {
    super.inicializaCad();
    this.cadID = 23;
    this.recno = 0;

    this.insertDescCons("codreservaac", "Cód. Reserva AC", false, "number");
    this.insertDescCons("usuario", "Usuário", false, "text");
    this.insertDescCons("codac", "Cód. AC", true, "number");
    this.insertDescCons("data", "Data", true, "date");
    this.insertDescCons("codacperiodo", "CodACPeriodo", true, "number");
    this.insertDescCons("valorreserva", "Valor da reserva", false, "number");
  }
  
  getURLServerPost() {
    return super.getURLServerPost() +
      "&codreservaac=" + this.activeRecord.codreservaac +
      "&usuario=" + this.activeRecord.usuario +
      "&codac=" + this.activeRecord.codac +
      "&data=" + this.activeRecord.data +
      "&codacperiodo=" + this.activeRecord.codacperiodo +
      "&valorreserva=" + this.activeRecord.valorreserva;
  }

  recebedadosPost(_ADados: any[]) {
    let ACodRetorno: number = _ADados[0].retorno;
    
    if (ACodRetorno == 1){
      this.refreshTelaDiaSelecionado();
      if (this.cadInsUpd == "d")
        alert("Reserva cancelada com sucesso!");
      else
        alert("Reserva efetuada com sucesso!");
    }
    else {
      if (this.cadInsUpd == "d")
        alert("Não foi possível cancelar a reserva: " + _ADados[0].mensagem);
      else  
        alert("Não foi possível efetuar a reserva: " + _ADados[0].mensagem);
    }
  }
  
  getTimeFormatado(_ATime: String){
    return _ATime.substring(0, 5);
  }
  
  periodoLivre(_ARec){
    return _ARec.status == "l";
  }
  reservadoParaMim(_ARec){
    return _ARec.usuario_r == this.authService.usuarioRetorno[0].username;
  }

  reservar(_ARec){
    if (confirm("Confirma a reserva para: \n - Dia: " + this.descDia + "\n - " + _ARec.descricao)) {
      this.novoRec([]);
      this.activeRecord.codreservaac = 0;
      this.activeRecord.usuario = this.authService.usuarioRetorno[0].username;
      this.activeRecord.codac = _ARec.codac;
      this.activeRecord.data = this.diaSelecionado.format("YYYY-MM-DD");
      this.activeRecord.codacperiodo = _ARec.codacperiodo;
      this.activeRecord.valorreserva = _ARec.valorreserva;
      this.ExecPost();
    }
  }

  cancelarReserva(_ARec){
    if (confirm("Deseja calcelar a reserva: \n - Dia: " + this.descDia + "\n - " + _ARec.descricao)) {
      this.novoRec([]);
      this.activeRecord.codreservaac = 0;
      this.activeRecord.usuario = this.authService.usuarioRetorno[0].username;
      this.activeRecord.codac = _ARec.codac;
      this.activeRecord.data = this.diaSelecionado.format("YYYY-MM-DD");
      this.activeRecord.codacperiodo = _ARec.codacperiodo;
      this.activeRecord.valorreserva = _ARec.valorreserva;
      this.excluirregistro();
    }
  }

  recebedadosReservasAC(_ADados: any[]) {
    this.recordsReservasAC = _ADados;
    this.ExecCons();
  }

  getURLServerCons() {
    return this.getURLServer() + "&act=c&constype=2301&filtro=" + this.getFiltrosCons(false);
  }
  
  getURLServerConsAC() {
    return this.getURLServer() + "&act=c" + 
                                  "&constype=2302" +
                                  "&codac=" + this.recordmaster.codac +
                                  "&data=" + this.dia +
                                  "&filtro=" + this.getFiltrosCons(false);
  }

  refreshPeriodosAC(){
    this.http.post<any[]>(this.getURLServerConsAC(),{}).
        subscribe(data => this.recebedadosReservasAC(data));
  }

  getDiaSemana(){
    return this.diasSemana[this.diaSelecionado.day()];
  }

  setDadosDiaSelecionado(){
    let ADay = this.diaSelecionado.get('date');
    let AMonth = this.diaSelecionado.get('month')+1;
    let ADia = ADay + "/" +
                AMonth + "/" + 
                this.diaSelecionado.get('year');
    this.descDia = ADia + " - " + this.getDiaSemana();
  }

  refreshTelaDiaSelecionado(){
    this.DescricaoSuperiorTela = this.recordmaster.descricao;
    this.diaSelecionado = moment(this.dia.toString(), "YYYY-MM-DD");
    this.setDadosDiaSelecionado();

    this.refreshPeriodosAC();
  }

  ngOnInit() {
    this.refreshTelaDiaSelecionado();
  }

}
