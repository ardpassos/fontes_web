import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaineluhreservasacdiaComponent } from './paineluhreservasacdia.component';

describe('PaineluhreservasacdiaComponent', () => {
  let component: PaineluhreservasacdiaComponent;
  let fixture: ComponentFixture<PaineluhreservasacdiaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaineluhreservasacdiaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaineluhreservasacdiaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
