import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaineluhreservasacComponent } from './paineluhreservasac.component';

describe('PaineluhreservasacComponent', () => {
  let component: PaineluhreservasacComponent;
  let fixture: ComponentFixture<PaineluhreservasacComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaineluhreservasacComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaineluhreservasacComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
