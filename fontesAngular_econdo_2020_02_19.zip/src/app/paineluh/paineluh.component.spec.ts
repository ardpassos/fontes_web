import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaineluhComponent } from './paineluh.component';

describe('PaineluhComponent', () => {
  let component: PaineluhComponent;
  let fixture: ComponentFixture<PaineluhComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaineluhComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaineluhComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
