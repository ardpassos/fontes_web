import { usuarioLogado } from './../../login/usuariologado';
import { AuthService } from './../../login/auth.service';
import { HttpClient } from '@angular/common/http';
import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-paineluhperiodosapuracao',
  templateUrl: './paineluhperiodosapuracao.component.html',
  styleUrls: ['./paineluhperiodosapuracao.component.css']
})
export class PaineluhperiodosapuracaoComponent extends FormBaseComponent implements OnInit {

  public mostrarPeriosos = true;
  public mostrarRelPeriodo = false;
  public recordmaster: any;

  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "Demonstrativos mensais";
    this.cadID = 1070;
    this.recno = 0;
    this.insertDescCons("codemp", "Cód. Empresa", false, "number");
    this.insertDescCons("codperiodo", "Cód. Período", false, "number");
    this.insertDescCons("coduh", "Cód. UH", false, "number");
    this.insertDescCons("descuh", "UH", false, "number");
    this.insertDescCons("descricao", "Período", true, "text");
    this.insertDescCons("valor", "Total", true, "number");
  }
  
  ngOnInit() {
    this.insertFiltroCons("conspart", "=", "1070", false, true);
    this.insertFiltroCons("codemp", "=", this.authService.usuarioRetorno[0].codempresa.toString(), false, true);
    this.insertFiltroCons("coduh", "=", this.authService.usuarioRetorno[0].username, false, true);
    this.ExecCons();
  }

  buttonEvent(rec: any) {
    this.activeRecord = rec;
    this.recordmaster = {codemp: rec.codemp,
                         codperiodo: rec.codperiodo,
                         coduh: rec.coduh,
                         descuh: rec.descuh
                        };
    this.mostrarPeriosos = false;
    this.mostrarRelPeriodo = true;    
  }

  voltarListagemPrinc(){
    this.mostrarPeriosos = true;
    this.mostrarRelPeriodo = false;    
  }

}
