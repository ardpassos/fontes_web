import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaineluhperiodosapuracaoComponent } from './paineluhperiodosapuracao.component';

describe('PaineluhperiodosapuracaoComponent', () => {
  let component: PaineluhperiodosapuracaoComponent;
  let fixture: ComponentFixture<PaineluhperiodosapuracaoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaineluhperiodosapuracaoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaineluhperiodosapuracaoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
