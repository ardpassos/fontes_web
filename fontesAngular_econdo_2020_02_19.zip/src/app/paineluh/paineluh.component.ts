import { AuthService } from './../login/auth.service';
import { HttpClient } from '@angular/common/http';
import { FormBaseComponent } from './../form-base/form-base.component';
import { Component, OnInit } from '@angular/core'; 

@Component({
  selector: 'app-paineluh',
  templateUrl: './paineluh.component.html',
  styleUrls: ['./paineluh.component.css']
})
export class PaineluhComponent  extends FormBaseComponent implements OnInit {

  public descEmpresa = "";

  inicializaCad() {
    super.inicializaCad();
  }

  ngOnInit() {
    this.descEmpresa = this.authService.usuarioRetorno[0].descempresa;
    this.DescricaoSuperiorTela = "Painel da UH - " + this.authService.usuarioRetorno[0].username;
  }

}
