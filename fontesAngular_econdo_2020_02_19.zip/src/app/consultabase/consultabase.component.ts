import { Component, OnInit, HostBinding, Input, Output, EventEmitter } from '@angular/core';
import * as moment from 'moment';

@Component({
  selector: 'app-consultabase',
  templateUrl: './consultabase.component.html',
  styleUrls: ['./consultabase.component.css']
})
export class ConsultabaseComponent implements OnInit {

  @HostBinding('class.desc-Cons') 
  @Input() descCons: any[];
  @Input() descConsGrid: any[];
  @HostBinding('class.records') 
  @Input() records: any[];
  @Input() buttonsRecord: any[];
  @Output() callbackEditar = new EventEmitter();
  @Output() callbackButton = new EventEmitter();
  
  constructor() { }

  ngOnInit() {
  }

  buttonEventExcluir(_ABtn, rec: []) {
    if (confirm("Deseja excluir?"))
      this.buttonEvent(_ABtn, rec);
  }

  buttonEvent(_ABtn, rec: []) {
    this.callbackButton.emit({btnText: _ABtn.target.outerText, record: rec});
  }  

  editarRegistro(rec: []) {
    this.callbackEditar.emit(rec);
  }  

  novoRegistro() {
    this.callbackEditar.emit([]);
  }  

  getFormattedValue(desc, _AValue){
    let AValue = _AValue;
    if (desc.inputtype == "date")
    {
      AValue = moment(_AValue).format("DD/MM/YYYY");
    }
    else  
      AValue = _AValue;
    return AValue;
  }
}
