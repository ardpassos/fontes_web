
$(document).ready(function () {
  $('#modal_alert').modal(); 
  $('select').formSelect();
  $('ul.tabs').tabs({
    swipeable: true,
    responsiveThreshold: 1920
  });
  $('.dropdown-trigger').dropdown();
  $('.sidenav').sidenav().on('click tap', 'li a', () => {
    $('.sidenav').sidenav('close');
  });  
  $('.collapsible').collapsible();
})


