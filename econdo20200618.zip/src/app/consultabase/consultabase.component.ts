import { Component, OnInit, HostBinding, Input, Output, EventEmitter } from '@angular/core';
import * as moment from 'moment';
import { CurrencyPipe } from '@angular/common';

@Component({
  selector: 'app-consultabase',
  templateUrl: './consultabase.component.html',
  styleUrls: ['./consultabase.component.css']
})
export class ConsultabaseComponent implements OnInit {

  @HostBinding('class.desc-Cons') 
  @Input() FiltrosCons: any[]; 
  @Input() descCons: any[]; 
  @Input() descConsGrid: any[];
  @HostBinding('class.records') 
  @Input() records: any[];
  @Input() buttonsRecord: any[];
  @Output() callbackEditar = new EventEmitter();
  @Output() callbackButton = new EventEmitter();
  mostrarFiltros = false;
  constructor() { }

  ngOnInit() {
  }

  buttonEventExcluir(_ABtn, rec: []) {
    if (confirm("Deseja excluir?"))
      this.buttonEvent(_ABtn, rec);
  }

  chamaCallBackButton(_ARet: any){
    if ((_ARet.btnText === "new_rec") || (_ARet.btnText === "edit_rec")){
      this.callbackEditar.emit(_ARet.record);
    }
    else {
      this.callbackButton.emit(_ARet);
    }
  }

  buttonEvent(_ABtn, rec: []) {
    this.chamaCallBackButton({btnText: _ABtn.target.outerText, record: rec});
  }  

  buttonEventFiltros(_ARet: any) {
    if (_ARet.btnText === "refresh") {
      this.refreshConsulta();
    }    
    else{
      this.chamaCallBackButton(_ARet);
    }
  }  

  selecionaRegistro(_ARec){
    this.chamaCallBackButton({btnText: "return_lkp", record: _ARec});
  }

  editarRegistro(rec: []) {
    this.chamaCallBackButton({btnText: "edit_rec", record: rec});
  }  

  novoRegistro() {
    this.chamaCallBackButton({btnText: "new_rec", record: []});
  }  

  filtrarConsulta() {
    this.mostrarFiltros = !this.mostrarFiltros;
  }

  refreshConsulta() {
    this.mostrarFiltros = false;
    this.chamaCallBackButton({btnText: "refresh", record: {} });
  }

  getFormattedValue(desc, _AValue){
    let AValue = _AValue;
    if (desc.inputtype == "date")
    {
      AValue = moment(_AValue).format("DD/MM/YYYY");
    }
    else if (desc.ehlookup) {
      for (let namevalue of desc.LookupNameValues){
        if (namevalue.codigo.match(_AValue) != null ){
          AValue = namevalue.descricao;
          break;
        } 
      }
    }
    else if (desc.type == "float")
    {
      AValue = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(AValue);
      // Outra forma é usar o currenciPipe;
    }
    else  
      AValue = _AValue;
    return AValue;
  }
}
