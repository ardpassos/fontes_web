import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsultabaseComponent } from './consultabase.component';

describe('ConsultabaseComponent', () => {
  let component: ConsultabaseComponent;
  let fixture: ComponentFixture<ConsultabaseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsultabaseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsultabaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
