import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-consultabase-filtros',
  templateUrl: './consultabase-filtros.component.html',
  styleUrls: ['./consultabase-filtros.component.css']
})
export class ConsultabaseFiltrosComponent implements OnInit {
  
  @Input() FiltrosCons: any[];
  @Input() descCons: any[];
  @Output() callbackButton = new EventEmitter();
  
  campoBoolean = [{"desc": "Sim", "valor": "s"},
  {"desc": "Não", "valor": "n"}];  
  camparacao = [{"desc": "Igual", "valor": "="},
                {"desc": "Maior que", "valor": ">"},
                {"desc": "Maior igual que", "valor": ">="},
                {"desc": "Menor que", "valor": "<"},
                {"desc": "Menor igual que", "valor": "<="},
                {"desc": "Contendo", "valor": "like"}
              ];  
/*form-base/insertFiltroCons
    this.ARec = {
      nomecampo: _ANomeCampo.toLowerCase(),
      comp: _AComp,
      valor: _AValor,
      desc: this.getDescFromdescCons(_ANomeCampo),
      filtrourl: _AFiltroURL
    };
*/  
  constructor() { }

  ngOnInit() {
  }

  addFiltro(){
    let ARec = {
      nomecampo: "",
      comp: "=",
      valor: "",
      desc: {},
      filtrourl: ""
    };
    this.FiltrosCons.push(ARec);
  }
  excluirFiltro(_AFiltro){
    let i = this.FiltrosCons.indexOf(_AFiltro);
    this.FiltrosCons.splice(i, 1);
  }

  getDescFromFieldName(_ANomeCampo){
    let ARet = {};
    for (let desc of this.descCons){
      if (desc.nomecampo === _ANomeCampo) {
        ARet = desc;
        break;
      } 
    }
    return ARet;
  }

  setDescFromCampo(_AFiltro){
    _AFiltro.desc = this.getDescFromFieldName(_AFiltro.nomecampo);
    if (_AFiltro.desc.type === "text")
      _AFiltro.comp = "like";
    else
      _AFiltro.comp = "=";
  }

  chamaCallBackButton(_ARet: any){
    this.callbackButton.emit(_ARet);
  }

  refreshConsulta() {
    this.chamaCallBackButton({btnText: "refresh", record: {} });
  }  

}
