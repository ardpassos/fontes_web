import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsultabaseFiltrosComponent } from './consultabase-filtros.component';

describe('ConsultabaseFiltrosComponent', () => {
  let component: ConsultabaseFiltrosComponent;
  let fixture: ComponentFixture<ConsultabaseFiltrosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsultabaseFiltrosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsultabaseFiltrosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
