import { PaineluhreservasacdiaComponent } from './paineluhreservasacdia/paineluhreservasacdia.component';
import { AuthService } from './../../login/auth.service';
import { HttpClient } from '@angular/common/http';
import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit, ViewChild } from '@angular/core';
import * as moment from 'moment';

@Component({
  selector: 'app-paineluhreservasac',
  templateUrl: './paineluhreservasac.component.html',
  styleUrls: ['./paineluhreservasac.component.css']
})
export class PaineluhreservasacComponent extends FormBaseComponent implements OnInit{

  public editarDia=false;
  public diaSelecionado;

  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "Reservas de áreas comuns";
    this.cadID = 21;
    this.recno = 0; 
    this.insertDescCons("codemp", "Cód. Empresa", true, "number");
    this.insertDescCons("codac", "Cód. AC", true, "number");
    this.insertDescCons("descricao", "Área comum", true, "number");
    this.insertDescCons("obsaoreservar", "Obs ao reservar", true, "number");
  }  

  ngOnInit() {
    this.insertFiltroCons("codemp", "=", this.authService.codempresa.toString());
    this.ExecCons();
  }

  fecharEdicaoDia(){
    this.editarDia = false;
  }

  selecionaDia(_ADia, rec){
    this.activeRecord = rec;
    this.editarDia = false;
    this.diaSelecionado = _ADia;
    this.editarDia = true;
  }

}
