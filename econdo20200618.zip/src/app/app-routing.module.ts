import { CadConfigVarejoComponent } from './varejo/cad-config-varejo/cad-config-varejo.component';
import { CadCrdComponent } from './varejo/cad-crd/cad-crd.component';
import { CadInventarioComponent } from './varejo/cad-inventario/cad-inventario.component';
import { CadSubCategoriaComponent } from './varejo/cad-sub-categoria/cad-sub-categoria.component';
import { CadCoresComponent } from './varejo/cad-cores/cad-cores.component';
import { CadContasPagarLctosComponent } from './varejo/cad-contas-pagar/cad-contas-pagar-lctos/cad-contas-pagar-lctos.component';
import { CadContasReceberLctosComponent } from './varejo/cad-contas-receber/cad-contas-receber-lctos/cad-contas-receber-lctos.component';
import { CadMovFinancComponent } from './varejo/cad-mov-financ/cad-mov-financ.component';
import { CadContasPagarComponent } from './varejo/cad-contas-pagar/cad-contas-pagar.component';
import { CadContasReceberComponent } from './varejo/cad-contas-receber/cad-contas-receber.component';
import { CadSaidaNfItensComponent } from './varejo/cad-saida-nf/cad-saida-nf-itens/cad-saida-nf-itens.component';
import { CadSaidaNFComponent } from './varejo/cad-saida-nf/cad-saida-nf.component';
import { CadProdutoImgsComponent } from './varejo/cad-produtos/cad-produto-imgs/cad-produto-imgs.component';
import { CadItensNfEntradaComponent } from './varejo/cad-entrada-nf/cad-itens-nf-entrada/cad-itens-nf-entrada.component';
import { CadDetalheComponent } from './cadastrobase/cad-detalhe/cad-detalhe.component';
import { CadEntradaNFComponent } from './varejo/cad-entrada-nf/cad-entrada-nf.component';
import { CadCategoriasComponent } from './varejo/cad-categorias/cad-categorias.component';
import { CadFaixasEtariasComponent } from './varejo/cad-faixas-etarias/cad-faixas-etarias.component';
import { MenuFinanceiroVarejoComponent } from './varejo/menu-financeiro-varejo/menu-financeiro-varejo.component';
import { MenuEstoqueVarejoComponent } from './varejo/menu-estoque-varejo/menu-estoque-varejo.component';
import { CadProdutosComponent } from './varejo/cad-produtos/cad-produtos.component';
import { CadGruposprodutosComponent } from './varejo/cad-gruposprodutos/cad-gruposprodutos.component';
import { CadMarcasComponent } from './varejo/cad-marcas/cad-marcas.component';
import { CadLocalalmoxComponent } from './varejo/cad-localalmox/cad-localalmox.component';
import { CadUnmedidasComponent } from './varejo/cad-unmedidas/cad-unmedidas.component';
import { CadPessoasComponent } from './varejo/cad-pessoas/cad-pessoas.component';
import { CadFuncionariosComponent } from './varejo/cad-funcionarios/cad-funcionarios.component';
import { MenuCadastrosVarejoComponent } from './varejo/menu-cadastros-varejo/menu-cadastros-varejo.component';
import { PaineluhComponent } from './paineluh/paineluh.component';
import { DespesasuhComponent } from './cadastros/despesasuh/despesasuh.component';
import { LctoaguaComponent } from './cadastros/lctoagua/lctoagua.component';
import { LctogasComponent } from './cadastros/lctogas/lctogas.component';
import { LctoluzComponent } from './cadastros/lctoluz/lctoluz.component';
import { PeriodoapuracaoComponent } from './cadastros/periodoapuracao/periodoapuracao.component';
import { PeriodoapuracaolctosComponent } from './cadastros/periodoapuracaolctos/periodoapuracaolctos.component';
import { DespesasfixasComponent } from './cadastros/despesasfixas/despesasfixas.component';
import { UhsComponent } from './cadastros/uhs/uhs.component';
import { EmpresasComponent } from './cadastros/empresas/empresas.component';
import { CadastrosComponent } from './cadastros/cadastros.component';
import { AuthGuard } from './guard/auth-guard';
import { UsuariosComponent } from './usuarios/usuarios.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SolicitacontatoComponent } from './solicitacontato/solicitacontato.component';
import { AreacomumComponent } from './cadastros/areacomum/areacomum.component';
import { MenuEstoqueCadastrosVarejoComponent } from './varejo/menu-estoque-varejo/menu-estoque-cadastros-varejo/menu-estoque-cadastros-varejo.component';

const routes: Routes = [
  {path: '', component: HomeComponent},
  {path: 'home', component: HomeComponent},
  {path: 'login', component: LoginComponent},
  {path: 'solicitacontato', component: SolicitacontatoComponent},
  {path: 'usuarios', component: UsuariosComponent, canActivate: [AuthGuard]},
  {path: 'paineluh', component: PaineluhComponent, canActivate: [AuthGuard]},
  {path: 'cadastros', component: CadastrosComponent, canActivate: [AuthGuard]},
  {path: 'cadastros/empresas', component: EmpresasComponent, canActivate: [AuthGuard]},
  {path: 'cadastros/uhs', component: UhsComponent, canActivate: [AuthGuard]},
  {path: 'cadastros/areacomum', component: AreacomumComponent, canActivate: [AuthGuard]},
  {path: 'cadastros/despesasfixas', component: DespesasfixasComponent, canActivate: [AuthGuard]},
  {path: 'cadastros/periodoapuracao', component: PeriodoapuracaoComponent, canActivate: [AuthGuard]},
  {path: 'cadastros/periodoapuracaolctos', component: PeriodoapuracaolctosComponent, canActivate: [AuthGuard]},
  {path: 'cadastros/lctoluz', component: LctoluzComponent, canActivate: [AuthGuard]},
  {path: 'cadastros/lctogas', component: LctogasComponent, canActivate: [AuthGuard]},
  {path: 'cadastros/lctoagua', component: LctoaguaComponent, canActivate: [AuthGuard]},
  {path: 'cadastros/despesasuh', component: DespesasuhComponent, canActivate: [AuthGuard]},
  // sistema de varejo
  {path: 'cadastrobase/cad-detalhe', component: CadDetalheComponent, canActivate: [AuthGuard]},
  {path: 'varejo/menu-cadastros-varejo', component: MenuCadastrosVarejoComponent, canActivate: [AuthGuard]},
  {path: 'varejo/menu-estoque-varejo', component: MenuEstoqueVarejoComponent, canActivate: [AuthGuard]},
  {path: 'varejo/menu-estoque-cadastros-varejo', component: MenuEstoqueCadastrosVarejoComponent, canActivate: [AuthGuard]},
  {path: 'varejo/menu-financeiro-varejo', component: MenuFinanceiroVarejoComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-funcionarios', component: CadFuncionariosComponent, canActivate: [AuthGuard]},
  {path: 'varejo/clientes-fornecedores', component: CadPessoasComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-unmedidas', component: CadUnmedidasComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-cores', component: CadCoresComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-localalmox', component: CadLocalalmoxComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-marcas', component: CadMarcasComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-gruposprodutos', component: CadGruposprodutosComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-categorias', component: CadCategoriasComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-sub-categorias', component: CadSubCategoriaComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-faixasetarias', component: CadFaixasEtariasComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-produtos', component: CadProdutosComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-produtos/cad-produto-imgs', component: CadProdutoImgsComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-inventario', component: CadInventarioComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-entrada-nf', component: CadEntradaNFComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-entrada-nf/cad-itens-entrada-nf', component: CadItensNfEntradaComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-saida-nf/:tn', component: CadSaidaNFComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-saida-nf/cad-saida-nf-itens', component: CadSaidaNfItensComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-contas-receber', component: CadContasReceberComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-contas-receber-lctos', component: CadContasReceberLctosComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-contas-pagar', component: CadContasPagarComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-contas-pagar-lctos', component: CadContasPagarLctosComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-mov-financ', component: CadMovFinancComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-crd', component: CadCrdComponent, canActivate: [AuthGuard]},
  {path: 'varejo/cad-config-varejo', component: CadConfigVarejoComponent, canActivate: [AuthGuard]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
