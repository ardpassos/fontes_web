import { usuarioLogado } from './../../login/usuariologado';
import { Usuario } from './../../login/usuario';
import { AuthService } from './../../login/auth.service';
import { HttpClient } from '@angular/common/http';
import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import * as moment from 'moment';

@Component({
  selector: 'app-datagrid',
  templateUrl: './datagrid.component.html',
  styleUrls: ['./datagrid.component.css']
})
export class DatagridComponent extends FormBaseComponent implements OnInit {

  @Input() recordmaster: any;
  @Output() callbackSelecionaDia = new EventEmitter();
  public weeks = new Array();
  public daysArr;
  public date_atual = moment();
  public date = moment();
  public mes_atual;
  public desc_mes_ano_atual;
  public dia_atual;
  recordsACPeriodos: any[];
  recordsReservas: any[];

  ngOnInit() {
    this.cadID = 23;
    this.refreshACPeriodos();
  }

  recebedadosACPeriodos(_ADados: any[]) {
    this.recordsACPeriodos = _ADados;
    this.refreshReservas();
  }

  refreshACPeriodos(){
    let AURL = this.getURLServer();
    AURL = AURL + "&act=c" + 
                  "&constype=2302" +
                  "&codemp=" + this.authService.codempresa +
                  "&codac=" + this.recordmaster.codac +
                  "&data=1900-01-01" +
                  "&filtro=" + this.getFiltrosCons(false);
    this.http.post<any[]>(AURL, {}).
        subscribe(data => this.recebedadosACPeriodos(data));    
  }

  recebedadosReservas(_ADados: any[]) {
    this.recordsReservas = _ADados;
    this.createCalendar(this.date);
  }

  refreshReservas(){
    let ALastDay = moment(this.date).endOf('M');

    let AURL = this.getURLServer();
    AURL = AURL + "&act=c" + 
                  "&constype=2303" +
                  "&codemp=" + this.authService.codempresa +
                  "&codac=" + this.recordmaster.codac +
                  "&dataini=" + this.getDateISO(1) +
                  "&datafim=" + this.getDateISO(ALastDay.date()) +
                  "&filtro=" + this.getFiltrosCons(false);
    this.http.post<any[]>(AURL, {}).
        subscribe(data => this.recebedadosReservas(data));    
  }

  prior_month() {
    this.date.add(-1, "month");
    this.refreshReservas();
  }

  next_month() {
    this.date.add(1, "month");
    this.refreshReservas();
  }

  getStatusDiaPeriodo(_ADay, _ARecper){
    for (let rec of _ADay.reserva){
      if (rec.codacperiodo == _ARecper.codacperiodo)
        if (this.authService.usuarioRetorno[0].username == rec.usuario_r)
          return "rm";
        else
          return "r";
    }
    return "l";
  }

  getTimeFormatado(_ATime: String){
    return _ATime.substring(0, 5);
  }

  ehdiaAtual(_ADia) {
    if (_ADia == null)
      _ADia = 0;
    let AReturn = (
      (this.date.get('year') == this.date_atual.get('year')) &&
      (this.date.get('month') == this.date_atual.get('month')) &&
      (_ADia == this.date.date())
    );
    return AReturn;
  }

  ehdiaPosterior(_ADia) {
    if (_ADia == null)
      _ADia = 0;
    let AReturn = (
      (this.date.get('year') > this.date_atual.get('year')) ||

      ((this.date.get('year') == this.date_atual.get('year')) &&
        (this.date.get('month') > this.date_atual.get('month'))
      ) ||

      ((this.date.get('year') == this.date_atual.get('year')) &&
        (this.date.get('month') == this.date_atual.get('month')) &&
        (_ADia > this.date.date())
      )
    );
    return AReturn;
  }

  setDescMes(_AMes) {
    if (_AMes == 1)
      this.mes_atual = "Janeiro";
    else if (_AMes == 2)
      this.mes_atual = "Fevereiro";
    else if (_AMes == 3)
      this.mes_atual = "Março";
    else if (_AMes == 4)
      this.mes_atual = "Abril";
    else if (_AMes == 5)
      this.mes_atual = "Maio";
    else if (_AMes == 6)
      this.mes_atual = "Junho";
    else if (_AMes == 7)
      this.mes_atual = "Julho";
    else if (_AMes == 8)
      this.mes_atual = "Agosto";
    else if (_AMes == 9)
      this.mes_atual = "Setembro";
    else if (_AMes == 10)
      this.mes_atual = "Outubro";
    else if (_AMes == 11)
      this.mes_atual = "Novembro";
    else
      this.mes_atual = "Dezembro";
    this.desc_mes_ano_atual = this.mes_atual + ' / ' + this.date.get('year');
  }

  clear_data() {
    this.weeks = [];
  }

  getReservasByDay(_ADay){
    let AReturn = [];
    for (let rec of this.recordsReservas){
      let ADT = moment(rec.data_r);
      if (ADT.date() == _ADay){
        AReturn.push(rec);
      }
    }
    return AReturn;
  }

  createCalendar(dateMoment) {
    this.clear_data();

    let aDateTemp = moment(dateMoment);
    let firstDay = aDateTemp.startOf('M');
    let daysNull = firstDay.day();

    let lastDay = aDateTemp.endOf('M');

    this.dia_atual = dateMoment.date();
    let mes = dateMoment.get('month') + 1;
    this.setDescMes(mes);

    let i = 0;
    let ADays = new Array(7);
    for (let x = 1; x <= lastDay.date(); x++) {
      if (daysNull > 0) {
        for (let y = 0; y < daysNull; y++) {
          ADays[i] = {dia: null, reserva: []};
          i += 1;
        }
        daysNull = 0;
      }
      let AReservas = this.getReservasByDay(x);
      ADays[i] = {dia: x, reserva: AReservas};
      i += 1;
      if (i > 6) {
        i = 0;
        this.weeks.push(ADays);
        ADays = new Array(7);
      }
    }
    if ((i > 0) && (i < 7)) {
      this.weeks.push(ADays);
    }
  }

  getDateISO(_ADia){
    let AMonth = this.date.get('month')+1;
    let ADia = this.date.get('year') + "-" + AMonth + "-" + _ADia;
    return ADia;
  }

  seleciona_dia(_ADia){
    let ADia = this.getDateISO(_ADia);
    this.callbackSelecionaDia.emit(ADia);
  }

}
