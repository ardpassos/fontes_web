import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ResumoVarejoComponent } from './resumo-varejo.component';

describe('ResumoVarejoComponent', () => {
  let component: ResumoVarejoComponent;
  let fixture: ComponentFixture<ResumoVarejoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ResumoVarejoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ResumoVarejoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
