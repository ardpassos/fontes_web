import { FormBaseComponent } from './../../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resumo-estoque',
  templateUrl: './resumo-estoque.component.html',
  styleUrls: ['./resumo-estoque.component.css']
})
export class ResumoEstoqueComponent extends FormBaseComponent implements OnInit {

  pedidos = [];
  itenspedido = [];
  codPedidoMostrando = -1;
  valorTotalPedidos: number = 0;

  ngOnInit() { 
    this.cadID = 27;
    this.atualizaDados();
  }

  //rotina para atualizar pedidos
  recebedadosPedidos(_ADados: any[]) {
    this.pedidos = _ADados;
    
    this.valorTotalPedidos = 0;
    this.pedidos.forEach(ARec => {
      this.valorTotalPedidos = this.valorTotalPedidos + parseFloat(ARec.valornf);
     });
  }  
  getURLAtualizaPedidos() {
    return this.getURLServer() + "&act=cp";
  }
  atualizaPedidos(){
    let AURL = this.getURLAtualizaPedidos();
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosPedidos(data));
  }

  getNomeUsuarioPedido(_ANome){
    let ANome = new String(_ANome);
    let APos = ANome.indexOf(" ");
    if (APos > -1) {
      ANome = ANome.substring(0, APos);
    }
    return ANome;
  }  
  getNumPedidos(){
    return this.pedidos.length;
  }  
  //fim da rotina de atualizar pedidos


//rotina para atualizar itens do pedido
  recebedadosItensPedidos(_ADados: any[]) {
    this.itenspedido = _ADados;
  }  
  getURLAtualizaItensPedidos(_ACodNF) {
    return this.getURLServer() + "&act=cip&codnf=" + _ACodNF;
  }
  atualizaItensPedidos(_APedido){
    if (this.codPedidoMostrando == _APedido['codnf']) {
      this.codPedidoMostrando = -1;
    }
    else {
      this.codPedidoMostrando = _APedido['codnf'];
    }
    let AURL = this.getURLAtualizaItensPedidos(this.codPedidoMostrando);
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosItensPedidos(data));
  }

  getMostrarDetalhesPedido(_ACodNF){
    let AResult = (this.itenspedido.length>0);
    if (AResult){
      AResult = (_ACodNF == this.itenspedido[0].codnf);
    }
    return AResult;
  }
  getNumItensPedidos(){
    return this.pedidos.length;
  }  
//fim da rotina de atualizar itens do pedido  

  atualizaDados(){
    this.atualizaPedidos();
  }

}
