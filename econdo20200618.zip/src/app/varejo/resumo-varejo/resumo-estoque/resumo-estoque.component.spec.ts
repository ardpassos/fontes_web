import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ResumoEstoqueComponent } from './resumo-estoque.component';

describe('ResumoEstoqueComponent', () => {
  let component: ResumoEstoqueComponent;
  let fixture: ComponentFixture<ResumoEstoqueComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ResumoEstoqueComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ResumoEstoqueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
