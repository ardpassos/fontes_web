import { FormBaseComponent } from './../../form-base/form-base.component';
import { AuthService } from './../../login/auth.service';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resumo-varejo',
  templateUrl: './resumo-varejo.component.html',
  styleUrls: ['./resumo-varejo.component.css']
})
export class ResumoVarejoComponent extends FormBaseComponent implements OnInit {

  pedidos = [];
  itenspedido = [];
  codPedidoMostrando = -1;
  valorTotalPedidos: number = 0;

  crhoje = [];
  itenscr = [];
  crHojeDataMostrando = null;
  valorTotalCR: number = 0;

  cphoje = [];
  itenscp = [];
  cpHojeDataMostrando = null;
  valorTotalCP: number = 0;

  ngOnInit() { 
    this.cadID = 27;
    this.atualizaDados();
  }

  //rotina para atualizar pedidos
  recebedadosPedidos(_ADados: any[]) {
    this.pedidos = _ADados;
    
    this.valorTotalPedidos = 0;
    this.pedidos.forEach(ARec => {
      this.valorTotalPedidos = this.valorTotalPedidos + parseFloat(ARec.valornf);
     });
  }  
  getURLAtualizaPedidos() {
    return this.getURLServer() + "&act=cp";
  }
  atualizaPedidos(){
    let AURL = this.getURLAtualizaPedidos();
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosPedidos(data));
  }

  getNomeUsuarioPedido(_ANome){
    let ANome = new String(_ANome);
    let APos = ANome.indexOf(" ");
    if (APos > -1) {
      ANome = ANome.substring(0, APos);
    }
    return ANome;
  }  
  getNumPedidos(){
    return this.pedidos.length;
  }  
  //fim da rotina de atualizar pedidos


//rotina para atualizar itens do pedido
  recebedadosItensPedidos(_ADados: any[]) {
    this.itenspedido = _ADados;
  }  
  getURLAtualizaItensPedidos(_ACodNF) {
    return this.getURLServer() + "&act=cip&codnf=" + _ACodNF;
  }
  atualizaItensPedidos(_APedido){
    if (this.codPedidoMostrando == _APedido['codnf']) {
      this.codPedidoMostrando = -1;
    }
    else {
      this.codPedidoMostrando = _APedido['codnf'];
    }
    let AURL = this.getURLAtualizaItensPedidos(this.codPedidoMostrando);
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosItensPedidos(data));
  }

  getMostrarDetalhesPedido(_ACodNF){
    let AResult = (this.itenspedido.length>0);
    if (AResult){
      AResult = (_ACodNF == this.itenspedido[0].codnf);
    }
    return AResult;
  }
  getNumItensPedidos(){
    return this.pedidos.length;
  }  
//fim da rotina de atualizar itens do pedido  



  //rotina para atualizar CRHoje
  recebedadosCRHoje(_ADados: any[]) {
    this.crhoje = _ADados;

    this.valorTotalCR = 0;
    this.crhoje.forEach(ARec => {
      this.valorTotalCR = this.valorTotalCR + parseFloat(ARec.valordia);
     });
  }  
  getURLAtualizaCRHoje() {
    return this.getURLServer() + "&act=crh";
  }
  atualizaCRHoje(){
    let AURL = this.getURLAtualizaCRHoje();
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosCRHoje(data));
  }

  getNumCRHoje(){
    return this.crhoje.length;
  }  
  //fim da rotina de atualizar CRHoje

//rotina para atualizar itens do CRHoje
  recebedadosItensCRHoje(_ADados: any[]) {
    this.itenscr = _ADados;
  }  
  getURLAtualizaItensCRHoje(_AData) {
    return this.getURLServer() + "&act=crd&data=" + _AData;
  }
  atualizaItensCRHoje(_ACRHoje){
    if (this.crHojeDataMostrando == _ACRHoje['datavcto']) {
      this.crHojeDataMostrando = null;
    }
    else {
      this.crHojeDataMostrando = _ACRHoje['datavcto'];
    }
    let AURL = this.getURLAtualizaItensCRHoje(this.crHojeDataMostrando);
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosItensCRHoje(data));
  }

  getMostrarDetalhesCRHoje(_AData){
    let AResult = (this.itenscr.length>0);
    if (AResult){
      AResult = (_AData == this.itenscr[0].datavcto);
    }
    return AResult;
  }
  getNomeClienteCR(_ANome){
    let ANome = new String(_ANome);
    let APos = ANome.indexOf(" ");
    if (APos > -1) {
      ANome = ANome.substring(0, APos);
    }
    return ANome;
  }  
  getNumItensCRHoje(){
    return this.itenscr.length;
  }  
//fim da rotina de atualizar itens do CRHoje  


//rotina para atualizar CPHoje
  recebedadosCPHoje(_ADados: any[]) {
    this.cphoje = _ADados;
    
    this.valorTotalCP = 0;
    this.cphoje.forEach(ARec => {
      this.valorTotalCP = this.valorTotalCP + parseFloat(ARec.valordia);
    });
  }  
  getURLAtualizaCPHoje() {
    return this.getURLServer() + "&act=cph";
  }
  atualizaCPHoje(){
    let AURL = this.getURLAtualizaCPHoje();
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosCPHoje(data));
  }

  getNumCPHoje(){
    return this.cphoje.length;
  }  
  //fim da rotina de atualizar CPHoje

  //rotina para atualizar itens do CPHoje
  recebedadosItensCPHoje(_ADados: any[]) {
    this.itenscp = _ADados;
  }  
  getURLAtualizaItensCPHoje(_AData) {
    return this.getURLServer() + "&act=cpd&data=" + _AData;
  }
  atualizaItensCPHoje(_ACPHoje){
    if (this.cpHojeDataMostrando == _ACPHoje['datavcto']) {
      this.cpHojeDataMostrando = null;
    }
    else {
      this.cpHojeDataMostrando = _ACPHoje['datavcto'];
    }
    let AURL = this.getURLAtualizaItensCPHoje(this.cpHojeDataMostrando);
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosItensCPHoje(data));
  }

  getMostrarDetalhesCPHoje(_AData){
    let AResult = (this.itenscp.length>0);
    if (AResult){
      AResult = (_AData == this.itenscp[0].datavcto);
      }
    return AResult;
  }
  getNomeFornecCP(_ANome){
    let ANome = new String(_ANome);
    let APos = ANome.indexOf(" ");
    if (APos > -1) {
      ANome = ANome.substring(0, APos);
    }
    return ANome;
  }  
  getNumItensCPHoje(){
    return this.itenscp.length;
  }  
//fim da rotina de atualizar itens do CPHoje 

  atualizaDados(){
    this.atualizaPedidos();
    this.atualizaCRHoje();
    this.atualizaCPHoje();
  }

}
