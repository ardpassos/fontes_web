import { FormBaseComponent } from './../../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resumo-financeiro',
  templateUrl: './resumo-financeiro.component.html',
  styleUrls: ['./resumo-financeiro.component.css']
})
export class ResumoFinanceiroComponent extends FormBaseComponent implements OnInit {

  crhoje = [];
  itenscr = [];
  crHojeDataMostrando = null;
  valorTotalCR: number = 0;

  cphoje = [];
  itenscp = [];
  cpHojeDataMostrando = null;
  valorTotalCP: number = 0;

  ngOnInit() { 
    this.cadID = 27;
    this.atualizaDados();
  }

  //rotina para atualizar CRHoje
  recebedadosCRHoje(_ADados: any[]) {
    this.crhoje = _ADados;

    this.valorTotalCR = 0;
    this.crhoje.forEach(ARec => {
      this.valorTotalCR = this.valorTotalCR + parseFloat(ARec.valordia);
     });
  }  
  getURLAtualizaCRHoje() {
    return this.getURLServer() + "&act=crh";
  }
  atualizaCRHoje(){
    let AURL = this.getURLAtualizaCRHoje();
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosCRHoje(data));
  }

  getNumCRHoje(){
    return this.crhoje.length;
  }  
  //fim da rotina de atualizar CRHoje

//rotina para atualizar itens do CRHoje
  recebedadosItensCRHoje(_ADados: any[]) {
    this.itenscr = _ADados;
  }  
  getURLAtualizaItensCRHoje(_AData) {
    return this.getURLServer() + "&act=crd&data=" + _AData;
  }
  atualizaItensCRHoje(_ACRHoje){
    if (this.crHojeDataMostrando == _ACRHoje['datavcto']) {
      this.crHojeDataMostrando = null;
    }
    else {
      this.crHojeDataMostrando = _ACRHoje['datavcto'];
    }
    let AURL = this.getURLAtualizaItensCRHoje(this.crHojeDataMostrando);
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosItensCRHoje(data));
  }

  getMostrarDetalhesCRHoje(_AData){
    let AResult = (this.itenscr.length>0);
    if (AResult){
      AResult = (_AData == this.itenscr[0].datavcto);
    }
    return AResult;
  }
  getNomeClienteCR(_ANome){
    let ANome = new String(_ANome);
    let APos = ANome.indexOf(" ");
    if (APos > -1) {
      ANome = ANome.substring(0, APos);
    }
    return ANome;
  }  
  getNumItensCRHoje(){
    return this.itenscr.length;
  }  
//fim da rotina de atualizar itens do CRHoje  


//rotina para atualizar CPHoje
  recebedadosCPHoje(_ADados: any[]) {
    this.cphoje = _ADados;
    
    this.valorTotalCP = 0;
    this.cphoje.forEach(ARec => {
      this.valorTotalCP = this.valorTotalCP + parseFloat(ARec.valordia);
    });
  }  
  getURLAtualizaCPHoje() {
    return this.getURLServer() + "&act=cph";
  }
  atualizaCPHoje(){
    let AURL = this.getURLAtualizaCPHoje();
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosCPHoje(data));
  }

  getNumCPHoje(){
    return this.cphoje.length;
  }  
  //fim da rotina de atualizar CPHoje

  //rotina para atualizar itens do CPHoje
  recebedadosItensCPHoje(_ADados: any[]) {
    this.itenscp = _ADados;
  }  
  getURLAtualizaItensCPHoje(_AData) {
    return this.getURLServer() + "&act=cpd&data=" + _AData;
  }
  atualizaItensCPHoje(_ACPHoje){
    if (this.cpHojeDataMostrando == _ACPHoje['datavcto']) {
      this.cpHojeDataMostrando = null;
    }
    else {
      this.cpHojeDataMostrando = _ACPHoje['datavcto'];
    }
    let AURL = this.getURLAtualizaItensCPHoje(this.cpHojeDataMostrando);
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosItensCPHoje(data));
  }

  getMostrarDetalhesCPHoje(_AData){
    let AResult = (this.itenscp.length>0);
    if (AResult){
      AResult = (_AData == this.itenscp[0].datavcto);
      }
    return AResult;
  }
  getNomeFornecCP(_ANome){
    let ANome = new String(_ANome);
    let APos = ANome.indexOf(" ");
    if (APos > -1) {
      ANome = ANome.substring(0, APos);
    }
    return ANome;
  }  
  getNumItensCPHoje(){
    return this.itenscp.length;
  }  
//fim da rotina de atualizar itens do CPHoje 

  atualizaDados(){
    this.atualizaCRHoje();
    this.atualizaCPHoje();
  }

}
