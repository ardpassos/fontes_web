import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cad-contas-receber',
  templateUrl: './cad-contas-receber.component.html',
  styleUrls: ['./cad-contas-receber.component.css']
})

export class CadContasReceberComponent extends FormBaseComponent implements OnInit {

  public descLctos: string = "";
  public ehLctos: boolean = false;

  ngOnInit() {
    this.insertFiltroCons("status", "in", " 'A', 'I' ");
    this.insertFiltroCons("datavcto", "<=", this.getDataAtual(""));
    this.ExecCons();  
  }
  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "Contas a receber";
    this.cadID = 17;
    this.recno = 0;
    this.cadAutoPost = true;
    this.insertDescCons("codcontareceber", "Código", true, "number", "Geral", false);
    this.insertDescCons("numdoc", "Núm doc.", true, "text");
    this.insertDescCons("codpessoaconta", "Cód. cliente", false, "text");
    this.insertDescCons("codcrd", "Cód. CRD", false, "text");
    this.insertDescCons("datavcto", "Data vcto", true, "date");
    this.insertDescCons("valor", "Valor", true, "float");
    this.insertDescCons("obs", "Obs", true, "text");
    this.insertDescCons("lancmanual", "Lanc. manual?", false, "float", "Geral", false, true);
    this.insertDescCons("status", "Status", true, "text", "Geral", false);
    this.insertDescCons("datahoralcto", "Data hora lcto", false, "date", "Geral", false);
    
    this.insertButtonRec("Lctos", "Receber", "add");
    this.setLookups(); 
  }

  recebedadoslkp(_ADados: any[]) {
    this.setLookupNameValues(this.cadIDLookup_CampoRetorno, _ADados);
    if ((this.cadIDLookup === 2) && (this.cadIDLookup_CampoRetorno.match("codpessoaconta") != null)){
      this.ExecConsLookup(17, "ls", "status");
    }
    else if (this.cadIDLookup === 17){
      this.ExecConsLookup(32, "gc", "codcrd");
    }
  }

  setLookups(){
    this.ExecConsLookup(2, "lc", "codpessoaconta");
  }

  setDescLctos(){
    this.descLctos = "Detalhamento de recebimentos: " + this.activeRecord.numdoc + 
                      " / Cliente: " + this.activeRecord.codpessoaconta;
  }
  
  AfterInsert(){
    this.activeRecord.status = "A";
  }  
  
  disableConsAndCad(){ 
    super.disableConsAndCad();
    this.ehLctos = false;
  }

  buttonevent(_ARet: any){
    this.activeRecord = _ARet.record;
    if (_ARet.btnText === "add") {
      this.setDescLctos();
      this.disableConsAndCad();
      this.ehLctos = true;
    }
    else{
      super.buttonevent(_ARet);
    } 
  }

  ExecPost(){
    if (this.activeRecord["status"] != "A") 
      alert("Este registro só poderá ser alterado se ele estiver com o status de 'Aberto'! ");
    else
      super.ExecPost();
  }

  editarRecAtual(rec: any) {
    if (rec["status"] === "B"){
      alert("Esta registro está com status de 'Baixado' e suas alterações não poderão ser efetivadas! Para alterar, favor estornar o recebimento!");
    }
    super.editarRecAtual(rec);
  }

  voltarConsultaPrinc(){
    this.disableConsAndCad();
    this.AfterPostEnableDisableScreen();
  }
  
}
