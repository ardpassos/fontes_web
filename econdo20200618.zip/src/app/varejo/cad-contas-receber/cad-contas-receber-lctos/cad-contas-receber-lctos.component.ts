import { CadDetalheComponent } from './../../../cadastrobase/cad-detalhe/cad-detalhe.component';
import { Component, OnInit, Input } from '@angular/core';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-cad-contas-receber-lctos',
  templateUrl: './cad-contas-receber-lctos.component.html',
  styleUrls: ['./cad-contas-receber-lctos.component.css']
})

export class CadContasReceberLctosComponent extends CadDetalheComponent implements OnInit {

  @Input() uhs: any = [];

  getShowSelectField(_AFieldName: string){
    return _AFieldName === "codlcto";
  }
  
  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "Recebimentos - Contas a receber";
    this.cadID = 19;
    this.recno = 0;
    this.cadAutoPost = true;
    this.insertDescCons("codlcto", "Cód. lcto", false, "number");
    this.insertDescCons("codcontareceber", "Cód. conta receber", false, "number");
    this.insertDescCons("tipolcto", "Status", true, "text", "", false);
    this.insertDescCons("datalcto", "Data", true, "date");
    this.insertDescCons("valor", "Valor", true, "float");
    this.setLookups();
  }  
  
  recebedadoslkp(_ADados: any[]) {
    this.setLookupNameValues(this.cadIDLookup_CampoRetorno, _ADados, true);
  }

  setLookups(){
    this.ExecConsLookup(19, "ls", "tipolcto");
  }

  getKeyValueActiveRecord(){
    return this.activeRecord.codlcto;
  }

  AfterInsert(){
    this.activeRecord.codcontareceber = this.recordmaster.codcontareceber;
    this.activeRecord.tipolcto = "I";
    this.activeRecord.datalcto = this.getDataAtual();
    this.activeRecord.valor = this.recordmaster.valor;
  }

  ngOnInit() {
    this.insertFiltroCons("codcontareceber", "=", this.recordmaster.codcontareceber);
    this.ExecCons();
  }  
//início da rotina de começar baixa

  recebedadosComecarBaixaConta(_ADados: any[]) {
    let retorno = _ADados;
    if (retorno[0].retorno === 1){
      this.recordmaster["status"] = "I";
      this.ExecCons();
    }
    else{
      alert("A baixa não pode ser efetuada! " + retorno[0].mensagem);
    }
  }  
  getURLServerComecarBaixaConta() {
    return this.getURLServer() + this.getAct() + "&codcontareceber=" + this.recordmaster["codcontareceber"];
  }
  ExecComecarBaixaConta() {
    let AURL = this.getURLServerComecarBaixaConta();
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosComecarBaixaConta(data));
  }   
  comecarBaixa(){
    if (this.recordmaster["status"] === "A") {
      if (confirm("Este procedimento começará uma ocorrência de baixa para o documento " + this.recordmaster["numdoc"] + ". Continuar?") === true){
        this.cadInsUpd = "cb";
        this.ExecComecarBaixaConta();
      }
    }
    else if (this.recordmaster["status"] === "B")
      alert("Esta conta está baixada! ");
  }
//fim da rotina de começar baixa

  
//rotina para baixar conta
  recebedadosBaixaConta(_ADados: any[]) {
    let retorno = _ADados;
    if (retorno[0].retorno === 1){
      this.ExecCons();
      this.recordmaster["status"] = "B";
      alert("Conta baixada com sucesso!");
    }
    else
      alert("Erro ao baixar conta! ");
  }  
  getURLServerBaixaConta() {
    return this.getURLServerPostAuto();
    /*return this.getURLServer() + this.getAct() + "&" + this.getFieldKey() + "=" + 
            this.getValueFromEditableComp(this.activeRecord[this.getFieldKey()]) +
            "&codcontareceber=" + this.activeRecord["codcontareceber"] ;*/
  }
  ExecBaixaConta() {
    let AURL = this.getURLServerBaixaConta();
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosBaixaConta(data));
  }    
  baixarConta(rec){
    this.activeRecord = rec;
    if (this.activeRecord["tipolcto"] == "I") {
      if (confirm("Deseja baixar o documento " + this.recordmaster["numdoc"] + "?") === true){
        this.cadInsUpd = "eb";
        this.ExecBaixaConta();
      }
    }
    else if (this.recordmaster["statusnf"] === "E")
      alert("Esta baixa está estornada! ");
  }
//fim da rotina de baixar conta

//início da rotina de estorno da baixa
  recebedadosEstornoConta(_ADados: any[]) {
    let retorno = _ADados;
    if (retorno[0].retorno === 1){
      this.ExecCons();
      this.recordmaster["status"] = "A";
      alert("Estorno realizado com sucesso!");
    }
    else
      alert("Erro ao estornar baixa! ");
  }  
  getURLServerEstornoConta() {
    return this.getURLServer() + this.getAct() + "&" + this.getFieldKey() + "=" + 
            this.getValueFromEditableComp(this.activeRecord[this.getFieldKey()]) +
            "&codcontareceber=" + this.activeRecord["codcontareceber"];
  }
  ExecEstornoConta() {
    let AURL = this.getURLServerEstornoConta();
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosEstornoConta(data));
  }    
  estornarBaixa(rec){
    this.activeRecord = rec;
    if (this.activeRecord["tipolcto"] == "B") {
      if (confirm("Deseja estornar a baixa atual?") === true){
        this.cadInsUpd = "ee";
        this.ExecEstornoConta();
      }
    }
    else if (this.recordmaster["status"] === "I")
      alert("Esta baixa está iniciada! Para estorná-la é necessário antes finalizá-la!");
    else if (this.recordmaster["status"] === "E")
      alert("Esta baixa já está estornada!");
  }
//fim da rotina de estorno da baixa


  contaAberta(){
    return (this.recordmaster["status"] === "A");
  }
  baixaInicializada(){
    return (this.recordmaster["status"] === "I");
  }
  contaBaixada(){
    return (this.recordmaster["status"] === "B");
  }

}

