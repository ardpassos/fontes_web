import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadContasReceberLctosComponent } from './cad-contas-receber-lctos.component';

describe('CadContasReceberLctosComponent', () => {
  let component: CadContasReceberLctosComponent;
  let fixture: ComponentFixture<CadContasReceberLctosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadContasReceberLctosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadContasReceberLctosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
