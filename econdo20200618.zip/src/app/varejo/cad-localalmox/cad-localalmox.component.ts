import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cad-localalmox',
  templateUrl: './cad-localalmox.component.html',
  styleUrls: ['./cad-localalmox.component.css']
})
export class CadLocalalmoxComponent extends FormBaseComponent implements OnInit {
    ngOnInit() {
      this.ExecCons();
    }
    inicializaCad() {
      super.inicializaCad();
      this.DescricaoSuperiorTela = "Locais do almoxarifado";
      this.cadID = 6;
      this.recno = 0;
      this.insertDescCons("codlocalalm", "Cód. Grupo", true, "number");
      this.insertDescCons("localalm", "Local", true, "text");
    }
    getURLServerPost() {
      return super.getURLServerPost() +
        "&codlocalalm=" + this.getValueFromEditableComp(this.activeRecord.codlocalalm) +
        "&localalm=" + this.getValueFromEditableComp(this.activeRecord.localalm);
    }
  }
  