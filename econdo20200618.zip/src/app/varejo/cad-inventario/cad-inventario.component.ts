import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cad-inventario',
  templateUrl: './cad-inventario.component.html',
  styleUrls: ['./cad-inventario.component.css']
})
export class CadInventarioComponent extends FormBaseComponent implements OnInit {

  ngOnInit() {
    this.ExecCons();
  }


  inicializaCad() {
    //      super.inicializaCad(); não adicionar botão de excluir
    this.DescricaoSuperiorTela = "Inventário de produtos";
    this.cadID = 31;
    this.recno = 0;
    this.cadAutoPost = false;
    this.insertDescCons("coditem", "Cód. Item", false, "number");
    this.insertDescCons("codbarras", "Cód. barras", true, "text");
    this.insertDescCons("codinsumo", "Cód. Produto", true, "number");
    this.insertDescCons("insumo", "Produto", true, "text");
    this.insertDescCons("tamanho", "Tamanho", true, "text");
    this.insertDescCons("cor", "Cor", true, "text");
    this.insertDescCons("refhexa", "Referência", true, "text");
    this.insertDescCons("qtdeestoque", "Qtde Estoque", true, "number");
    this.insertDescCons("statusalt", "Qtde Estoque", true, "number");
  }

  getStyleColor(_ARec){
    let myStyles = {
      backgroundColor: _ARec.refhexa,
    };
    return  myStyles;
  }

  printPage(){
    window.print();
  }
  AfterPostCad() {
    //não atualizar consulta
  }
  setStatusAlt(_AChave, _ADesc){
    this.records.forEach(rec => {
      if (rec.coditem == _AChave){
        rec.statusalt = _ADesc;
        return;
      }
    });
  }
  recebedadosPost(_ADados: any[]) {
    super.recebedadosPost(_ADados);
    console.log(_ADados);
    if (_ADados["retorno"] == 1){
      this.setStatusAlt(_ADados["chave"], "Alterado");
    }
    else {
      this.setStatusAlt(_ADados["chave"], _ADados["mensagem"]);
    }
  }

  getURLServerPost() {
    return super.getURLServerPost() +
      "&coditem=" + this.getValueFromEditableComp(this.activeRecord.coditem) +
      "&qtdeestoque=" + this.getValueFromEditableComp(this.activeRecord.qtdeestoque);
  }
  changeCampo($event, rec) {
    this.activeRecord = rec;
    this.cadInsUpd = "p";
    this.ExecPost();
  }

}
