import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadInventarioComponent } from './cad-inventario.component';

describe('CadInventarioComponent', () => {
  let component: CadInventarioComponent;
  let fixture: ComponentFixture<CadInventarioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadInventarioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadInventarioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
