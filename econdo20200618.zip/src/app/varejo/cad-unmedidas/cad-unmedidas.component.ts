import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cad-unmedidas',
  templateUrl: './cad-unmedidas.component.html',
  styleUrls: ['./cad-unmedidas.component.css']
})
export class CadUnmedidasComponent extends FormBaseComponent implements OnInit {
    ngOnInit() {
      this.ExecCons();
    }
    inicializaCad() {
      super.inicializaCad();
      this.DescricaoSuperiorTela = "Unidades de medida";
      this.cadID = 4;
      this.recno = 0;
      this.insertDescCons("codunmedida", "Cód. Un. Medida", true, "number");
      this.insertDescCons("unmedida", "Unidade de medida", true, "text");
    }
    getURLServerPost() {
      return super.getURLServerPost() +
        "&codunmedida=" + this.getValueFromEditableComp(this.activeRecord.codunmedida) +
        "&unmedida=" + this.getValueFromEditableComp(this.activeRecord.unmedida);
    }
  }