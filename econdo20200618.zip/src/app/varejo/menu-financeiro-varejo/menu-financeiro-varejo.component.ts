import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-financeiro-varejo',
  templateUrl: './menu-financeiro-varejo.component.html',
  styleUrls: ['./menu-financeiro-varejo.component.css']
})
export class MenuFinanceiroVarejoComponent extends FormBaseComponent implements OnInit {

  mostrarMenu = false;

  async delay(ms: number) {
    await new Promise(resolve => setTimeout(()=>resolve(), ms)).then(()=>
    {
      this.mostrarMenu = true; 
    });
  }

  ngOnInit() {
    this.delay(200);
  }
}