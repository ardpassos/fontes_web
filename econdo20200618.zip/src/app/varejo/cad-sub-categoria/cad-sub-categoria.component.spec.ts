import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadSubCategoriaComponent } from './cad-sub-categoria.component';

describe('CadSubCategoriaComponent', () => {
  let component: CadSubCategoriaComponent;
  let fixture: ComponentFixture<CadSubCategoriaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadSubCategoriaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadSubCategoriaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
