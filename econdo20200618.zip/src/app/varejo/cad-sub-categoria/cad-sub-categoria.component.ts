import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cad-sub-categoria',
  templateUrl: './cad-sub-categoria.component.html',
  styleUrls: ['./cad-sub-categoria.component.css']
})
export class CadSubCategoriaComponent extends FormBaseComponent implements OnInit {
  ngOnInit() {
    this.ExecCons();
  }
  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "Sub categorias";
    this.cadID = 30;
    this.recno = 0;
    this.cadAutoPost = true;
    this.insertDescCons("codsubcategoria", "Cód. sub categoria", true, "number");
    this.insertDescCons("subcategoria", "Sub categoria", true, "text");
  }
}

