import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cad-faixas-etarias',
  templateUrl: './cad-faixas-etarias.component.html',
  styleUrls: ['./cad-faixas-etarias.component.css']
})
export class CadFaixasEtariasComponent extends FormBaseComponent implements OnInit {
    ngOnInit() {
      this.ExecCons();
    }
    inicializaCad() {
      super.inicializaCad();
      this.DescricaoSuperiorTela = "Faixas Etárias";
      this.cadID = 10;
      this.recno = 0;
      this.insertDescCons("codfaixaetaria", "Cód. faixa etária", true, "number");
      this.insertDescCons("faixaetaria", "Faixa etária", true, "text");
    }
    getURLServerPost() {
      return super.getURLServerPost() +
        "&codfaixaetaria=" + this.getValueFromEditableComp(this.activeRecord.codfaixaetaria) +
        "&faixaetaria=" + this.getValueFromEditableComp(this.activeRecord.faixaetaria);
    }
  }