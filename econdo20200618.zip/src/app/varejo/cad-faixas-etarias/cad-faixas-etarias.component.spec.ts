import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadFaixasEtariasComponent } from './cad-faixas-etarias.component';

describe('CadFaixasEtariasComponent', () => {
  let component: CadFaixasEtariasComponent;
  let fixture: ComponentFixture<CadFaixasEtariasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadFaixasEtariasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadFaixasEtariasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
