import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MenuCadastrosVarejoComponent } from './menu-cadastros-varejo.component';

describe('MenuCadastrosVarejoComponent', () => {
  let component: MenuCadastrosVarejoComponent;
  let fixture: ComponentFixture<MenuCadastrosVarejoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MenuCadastrosVarejoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuCadastrosVarejoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
