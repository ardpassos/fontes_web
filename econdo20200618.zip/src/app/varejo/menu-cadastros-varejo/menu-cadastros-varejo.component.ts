import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-cadastros-varejo',
  templateUrl: './menu-cadastros-varejo.component.html',
  styleUrls: ['./menu-cadastros-varejo.component.css']
})
export class MenuCadastrosVarejoComponent extends FormBaseComponent implements OnInit {

  mostrarMenu = false;

  async delay(ms: number) {
    await new Promise(resolve => setTimeout(()=>resolve(), ms)).then(()=>
    {
      this.mostrarMenu = true; 
    });
  }

  ngOnInit() {
    this.delay(200);
  }
}
