import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadCrdComponent } from './cad-crd.component';

describe('CadCrdComponent', () => {
  let component: CadCrdComponent;
  let fixture: ComponentFixture<CadCrdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadCrdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadCrdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
