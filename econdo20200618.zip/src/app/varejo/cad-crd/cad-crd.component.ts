import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cad-crd',
  templateUrl: './cad-crd.component.html',
  styleUrls: ['./cad-crd.component.css']
})
export class CadCrdComponent extends FormBaseComponent implements OnInit {
  ngOnInit() {
    this.ExecCons();
  }
  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "Centro de receitas e despesas";
    this.cadID = 32;
    this.recno = 0;
    this.cadAutoPost = true;
    this.insertDescCons("codcrd", "Cód. CRD", true, "number", "Geral", false);
    this.insertDescCons("crd", "CRD", true, "text");
    this.insertDescCons("debcred", "Débito/Crédito", true, "text");

    this.setLookups();
  }

  recebedadoslkp(_ADados: any[]) {
    if (this.cadIDLookup === 32) {
      this.setLookupNameValues("debcred", _ADados);
    }
  }

  setLookups(){
    this.ExecConsLookup(32, "gdc");
  }  
}

