import { CadDetalheComponent } from './../../../cadastrobase/cad-detalhe/cad-detalhe.component';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-cad-itens-pedidos',
  templateUrl: './cad-itens-pedidos.component.html',
  styleUrls: ['./cad-itens-pedidos.component.css']
})
export class CadItensPedidosComponent  extends CadDetalheComponent implements OnInit {

  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "Itens do pedido";
    this.cadID = 14;
    this.recno = 0;
    this.cadAutoPost = true;
    this.insertDescCons("codlcto", "Cód. lcto", false, "number");
    this.insertDescCons("codnf", "Cód. nf", false, "number");
    this.insertDescCons("coditemgrade", "Cód. produto", true, "number");
    this.insertDescCons("valorunit", "Valor unitário", true, "number");
    this.insertDescCons("qtde", "Qtde", true, "number");
    this.insertDescCons("valortotal", "Valor total", true, "number");
    this.setLookups();
  }  

  recebedados(_ADados: any[]){
    super.recebedados(_ADados);
    console.log(this.records);
  }
  
  recebedadoslkp(_ADados: any[]) {
    if (this.cadIDLookup === 28) {
      this.setLookupNameValues("coditemgrade", _ADados);
    }
  }

  setLookups(){
    this.ExecConsLookup(28);
  }

  getKeyValueActiveRecord(){
    return this.activeRecord.codlcto;
  }

  AfterInsert(){
    this.activeRecord.codnf = this.recordmaster.codnf;
  }

  ngOnInit() {
    this.insertFiltroCons("codnf", "=", this.recordmaster.codnf);
    this.ExecCons();
  }  

  getStyleColor(_ARec){
    let myStyles = {
      backgroundColor: _ARec.refhexa,
    };
    return  myStyles;
  }  

}