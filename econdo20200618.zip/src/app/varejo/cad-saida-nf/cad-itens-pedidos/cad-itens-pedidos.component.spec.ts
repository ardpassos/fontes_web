import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadItensPedidosComponent } from './cad-itens-pedidos.component';

describe('CadItensPedidosComponent', () => {
  let component: CadItensPedidosComponent;
  let fixture: ComponentFixture<CadItensPedidosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadItensPedidosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadItensPedidosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
