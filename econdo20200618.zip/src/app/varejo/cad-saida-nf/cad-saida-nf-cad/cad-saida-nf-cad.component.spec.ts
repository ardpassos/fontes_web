import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadSaidaNfCadComponent } from './cad-saida-nf-cad.component';

describe('CadSaidaNfCadComponent', () => {
  let component: CadSaidaNfCadComponent;
  let fixture: ComponentFixture<CadSaidaNfCadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadSaidaNfCadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadSaidaNfCadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
