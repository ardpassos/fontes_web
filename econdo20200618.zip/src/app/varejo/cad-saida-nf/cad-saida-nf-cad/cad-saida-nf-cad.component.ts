import { CadastrobaseComponent } from './../../../cadastrobase/cadastrobase.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cad-saida-nf-cad',
  templateUrl: './cad-saida-nf-cad.component.html',
  styleUrls: ['./cad-saida-nf-cad.component.css']
})

export class CadSaidaNfCadComponent extends CadastrobaseComponent implements OnInit {

  ngOnInit() {
    super.ngOnInit();
  }

}
