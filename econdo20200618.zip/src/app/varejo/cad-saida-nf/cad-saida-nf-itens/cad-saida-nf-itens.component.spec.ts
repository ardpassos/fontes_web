import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadSaidaNfItensComponent } from './cad-saida-nf-itens.component';

describe('CadSaidaNfItensComponent', () => {
  let component: CadSaidaNfItensComponent;
  let fixture: ComponentFixture<CadSaidaNfItensComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadSaidaNfItensComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadSaidaNfItensComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
