import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadSaidaNFComponent } from './cad-saida-nf.component';

describe('CadSaidaNFComponent', () => {
  let component: CadSaidaNFComponent;
  let fixture: ComponentFixture<CadSaidaNFComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadSaidaNFComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadSaidaNFComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
