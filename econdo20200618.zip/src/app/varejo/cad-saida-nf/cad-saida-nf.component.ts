import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cad-saida-nf',
  templateUrl: './cad-saida-nf.component.html',
  styleUrls: ['./cad-saida-nf.component.css']
})

export class CadSaidaNFComponent extends FormBaseComponent implements OnInit {

  public descLctos: string = "";
  public ehLctos: boolean = false;
  public ehpedidos: boolean = false;
  public ehcondicional: boolean = false;
  public ehnota: boolean = false;
  codNFSelecionado = "-1";

  ngOnInit() {
    this.route.params.subscribe( parametros => {
      if (parametros['tn']) {
        this.ehpedidos = (parametros['tn'] == "p");
        this.ehcondicional = (parametros['tn'] == "c");
        this.ehnota = (parametros['tn'] == "n");
      }
    });
    if (this.ehpedidos){
      this.insertFiltroCons("tiponf", "=", "p")
      this.DescricaoSuperiorTela = "Pedidos em aberto";
    }
    else if (this.ehcondicional){
      this.insertFiltroCons("tiponf", "=", "c")
      this.DescricaoSuperiorTela = "Pedidos em condicional";
    }
    else if (this.ehnota){
      this.insertFiltroCons("tiponf", "=", "n")
      this.DescricaoSuperiorTela = "Pedidos em condicional";
    }

    this.ExecCons();
  }
  
  inicializaCad() {
    super.inicializaCad();
    this.cadID = 12; 
    this.recno = 0;
    this.cadAutoPost = true;
    this.insertDescCons("codnf", "Cód. NF", false, "number", "Geral", false);
    this.insertDescCons("codcliente", "Cliente", false, "number");
    this.insertDescCons("tiponf", "Tipo NF", true, "text");
    this.insertDescCons("numnf", "Número NF", true, "text");
    this.insertDescCons("serienf", "Série NF", true, "text");
    this.insertDescCons("dataemissao", "Data emissão", false, "date", "Datas");
    this.insertDescCons("datasaida", "Data saída", false, "date", "Datas");
    this.insertDescCons("valornf", "Valor NF", true, "float", "Financeiro");
    this.insertDescCons("tipopgto", "Tipo Pgto", false, "text", "Financeiro", false); // será mostrado manualmente no html
    this.insertDescCons("valorentrada", "Valor de entrada", false, "float", "Financeiro", false); // será mostrado manualmente no html
    this.insertDescCons("numparcelas", "Núm. de parcelas", false, "number", "Financeiro", false); // será mostrado manualmente no html

    this.insertDescCons("statusnf", "Status NF", true, "text", "Financeiro", false);
    this.insertDescCons("tiponf", "Tipo NF", false, "text", "Financeiro", false);
    this.insertDescCons("valoritens", "Valor itens", true, "float", "Financeiro", false);
    this.insertDescCons("valorfinanc", "Valor financ.", true, "float", "Financeiro", false);

    this.insertButtonRec("Lctos", "Itens", "add");
    this.insertButtonRec("Finalizar", "Finalizar", "call_missed_outgoing");
    this.insertButtonRec("Reabrir", "Reabrir", "call_missed");
    this.setLookups(); 
  }

  recebedadoslkp(_ADados: any[]) {
    if ((this.cadIDLookup === 12) && (this.cadIDLookup_CampoRetorno.match("statusnf") != null)){
      this.setLookupNameValues(this.cadIDLookup_CampoRetorno, _ADados);
      this.ExecConsLookup(12, "lpg", "tipopgto");
    }
    else if ((this.cadIDLookup === 12) && (this.cadIDLookup_CampoRetorno.match("tipopgto") != null)){
      this.setLookupNameValues(this.cadIDLookup_CampoRetorno, _ADados);
      this.ExecConsLookup(2, "lc", "codcliente");
    }
    else if ((this.cadIDLookup === 2) && (this.cadIDLookup_CampoRetorno.match("codcliente") != null)){
      this.setLookupNameValues("codcliente", _ADados);
      this.ExecConsLookup(12, "ltnf", "tiponf");
    }
    else if ((this.cadIDLookup === 12) && (this.cadIDLookup_CampoRetorno.match("tiponf") != null)){
      this.setLookupNameValues(this.cadIDLookup_CampoRetorno, _ADados);
    }
  }

  setLookups(){
    this.ExecConsLookup(12, "lst", "statusnf");
  }

  setDescLctos(){
    this.descLctos = "Itens da nota fiscal: " + this.activeRecord.numnf + 
                      " / Série: " + this.activeRecord.serienf;
  }
  
  AfterInsert(){
    this.activeRecord.statusnf = "A";
  }  
  
  disableConsAndCad(){ 
    super.disableConsAndCad();
    this.ehLctos = false;
  }

  buttonevent(_ARet: any){
    this.activeRecord = _ARet.record;
    if (_ARet.btnText === "add") {
      this.setDescLctos();
      this.disableConsAndCad();
//        this.getLookupUHs();
      this.ehLctos = true;
    }
    else if (_ARet.btnText === "clear"){
      this.excluirregistro();
      this.ExecCons();
    } 
    else if (_ARet.btnText === "call_missed_outgoing"){
      this.finalizarNF();
    } 
    else if (_ARet.btnText === "call_missed"){
      this.reabrirNF();
    } 
    else {
      super.buttonevent(_ARet);
    }
  }
  
//rotina para finalizar NF
  AfterFinalizaNF(){
    this.ExecCons();
  }
  recebedadosFinaliza(_ADados: any[]) {
    this.AfterFinalizaNF();
    let retorno = _ADados;
    console.log(retorno);
    if (retorno[0].retorno == 1)
      alert("Nota fiscal finalizada!");
    else
      alert("Erro ao finalizar nota fiscal! ");
  }  
  getURLServerFinalizaNF() {
    return this.getURLServer() + this.getAct() + "&" + this.getFieldKey() + "=" + 
            this.getValueFromEditableComp(this.activeRecord[this.getFieldKey()]);
  }
  ExecFinalizarNF() {
    let AURL = this.getURLServerFinalizaNF();
    console.log(AURL);
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosFinaliza(data));
  }    
  finalizarNF(){
    if (this.activeRecord["statusnf"] === "A") {
      if (confirm("Deseja finalizar a nota fiscal " + this.activeRecord["numnf"] + "?") === true){
        this.cadInsUpd = "fnf";
        this.ExecFinalizarNF();
      }
    }
    else if (this.activeRecord["statusnf"] === "F")
      alert("Esta nota fiscal já se encontra finalizada! ");
    else if (this.activeRecord["statusnf"] === "C")
      alert("Esta nota fiscal se encontra cancelada! ");
  }
//fim da rotina de finalização de NF

//rotina para reabrir NF
  AfterReabrirNF(){
    this.ExecCons();
  }
  recebedadosReabrir(_ADados: any[]) {
    this.AfterReabrirNF();
    let retorno = _ADados;
    if (retorno[0].retorno == 1)
      alert("Nota fiscal reaberta!");
    else
      alert("Erro ao reabrir nota fiscal! ");
  }  
  getURLServerReabrirNF() {
    return this.getURLServer() + this.getAct() + "&" + this.getFieldKey() + "=" + 
          this.getValueFromEditableComp(this.activeRecord[this.getFieldKey()]);
  }
  ExecReabrirNF() {
    let AURL = this.getURLServerReabrirNF();
    console.log(AURL);
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosReabrir(data));
  }    
  reabrirNF(){
    if (this.activeRecord["statusnf"] === "F") {
      if (confirm("Deseja reabrir a nota fiscal " + this.activeRecord["numnf"] + "?") === true){
        this.cadInsUpd = "rnf";
        this.ExecReabrirNF();
      }
    }
    else if (this.activeRecord["statusnf"] === "A")
      alert("Esta nota fiscal já se encontra aberta! ");
    else if (this.activeRecord["statusnf"] === "C")
      alert("Esta nota fiscal se encontra cancelada! ");
  }
  //fim da rotina de reabrir de NF

  ExecPost(){
    if ((this.activeRecord["tiponf"] == "n") && (this.activeRecord["statusnf"] != "A") )
      alert("Esta nota fiscal só poderá ser alterada se ela estiver ABERTA! ");
    else
      super.ExecPost();
  }

  editarRecAtual(rec: any) {
    if (rec["statusnf"] === "F"){
      alert("Esta nota fiscal está fechada e suas alteração não poderão ser efetivadas! Para alterar, favor reabrir a nota fiscal!");
    }
    else if (rec["statusnf"] === "C"){
      alert("Esta nota fiscal está cancelada e suas alteração não poderão ser efetivadas!");
    }
    super.editarRecAtual(rec);
  }

  gerarCondicional(_ARec){
    this.activeRecord = _ARec;
    this.cadInsUpd = "gc";
    this.salvarregistro();
  }

  voltarConsultaPrinc(){
    this.disableConsAndCad();
    this.AfterPostEnableDisableScreen();
  }

  ExecCons(){
    super.ExecCons();
  }

  setNFSelecionada(_ARec){
    if (this.codNFSelecionado == _ARec.codnf)
      this.codNFSelecionado = "-1";
    else
      this.codNFSelecionado = _ARec.codnf;
  }
}
