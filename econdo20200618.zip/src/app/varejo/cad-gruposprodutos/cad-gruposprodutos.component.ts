
import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-cad-gruposprodutos',
  templateUrl: './cad-gruposprodutos.component.html',
  styleUrls: ['./cad-gruposprodutos.component.css']
})
export class CadGruposprodutosComponent extends FormBaseComponent implements OnInit {
  ngOnInit() {
    this.ExecCons();
  }
  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "Grupos de Produtos";
    this.cadID = 7;
    this.recno = 0;
    this.insertDescCons("codgrupo", "Cód. Grupo", true, "number");
    this.insertDescCons("grupo", "Grupo", true, "text");
  }
  getURLServerPost() {
    return super.getURLServerPost() +
      "&codgrupo=" + this.getValueFromEditableComp(this.activeRecord.codgrupo) +
      "&grupo=" + this.getValueFromEditableComp(this.activeRecord.grupo);
  }
}
