import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadGruposprodutosComponent } from './cad-gruposprodutos.component';

describe('CadGruposprodutosComponent', () => {
  let component: CadGruposprodutosComponent;
  let fixture: ComponentFixture<CadGruposprodutosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadGruposprodutosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadGruposprodutosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
