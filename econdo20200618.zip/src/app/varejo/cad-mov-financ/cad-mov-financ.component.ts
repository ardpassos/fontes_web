import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cad-mov-financ',
  templateUrl: './cad-mov-financ.component.html',
  styleUrls: ['./cad-mov-financ.component.css']
})

export class CadMovFinancComponent extends FormBaseComponent implements OnInit {
  
  ngOnInit() {
    this.insertFiltroCons("datahoralcto", ">=", this.getDataAtual("", 1));
    this.ExecCons();
  }

  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "Movimentações financeiras";
    this.cadID = 16;
    this.cadAutoPost = true;
    this.recno = 0;
    this.insertDescCons("codmovfinanc", "Código", true, "number", "Geral", false);
    this.insertDescCons("entsai", "Entrada/Saída", true, "text", "Geral", true);
    this.insertDescCons("numdoc", "Núm. doc.", true, "text");
    this.insertDescCons("codcliente", "Cód cliente", false, "number");
    this.insertDescCons("codfornecedor", "Cód fornec.", false, "number");
    this.insertDescCons("codcrdcredito", "Cód. CRD", false, "number");
    this.insertDescCons("codcrddebito", "Cód. CRD", false, "number");
    this.insertDescCons("dataaprop", "Data aprop.", true, "date");
    this.insertDescCons("valor", "Valor", true, "float");
    this.insertDescCons("obs", "Obs", false, "text");
    this.insertDescCons("datahoralcto", "Data hora lcto", false, "date", "", false);
    this.insertDescCons("lancmanual", "Lanc. manual", false, "text", "", false, true);
    this.setLookupNameValues("codpessoaconta", [{"codigo": "0", "descricao": "carregando..."}]);
    this.setLookups();
  }

  onChangeSelecteds(_ADados){
    if (_ADados.campo.match("entsai") != 0){
      this.setLookupCliFor();
    }
  }
  SetMostrarCadInDesc(_ANomeCampo, _AMostrarCad){
    for (let desc of this.descCons){
      if (desc.nomecampo.match(_ANomeCampo) != null ){
        desc.mostrarCad = _AMostrarCad;
        break;
      } 
    }
  }
  setLookupCliFor(){
    if (this.activeRecord.entsai === "E"){
      this.SetMostrarCadInDesc("codcliente", true);
      this.SetMostrarCadInDesc("codfornecedor", false);

      this.SetMostrarCadInDesc("codcrdcredito", true);
      this.SetMostrarCadInDesc("codcrddebito", false);
    }
    else {
      this.SetMostrarCadInDesc("codcliente", false);
      this.SetMostrarCadInDesc("codfornecedor", true);

      this.SetMostrarCadInDesc("codcrdcredito", false);
      this.SetMostrarCadInDesc("codcrddebito", true);
    }
  }

  recebedadoslkp(_ADados: any[]) {
    this.setLookupNameValues(this.cadIDLookup_CampoRetorno, _ADados);
    if ((this.cadIDLookup === 16) && (this.cadIDLookup_CampoRetorno.match("entsai") != null)){
      this.ExecConsLookup(2, "lc", "codcliente");
    }
    else if ((this.cadIDLookup === 2) && (this.cadIDLookup_CampoRetorno.match("codcliente") != null)){
      this.ExecConsLookup(2, "lf", "codfornecedor");
    }
    else if (this.cadIDLookup === 2){
      this.ExecConsLookup(32, "gc", "codcrdcredito");
    }  
    else if ((this.cadIDLookup === 32) && (this.cadIDLookup_CampoRetorno.match("codcrdcredito") != null)){
      this.ExecConsLookup(32, "gd", "codcrddebito");
    }
  }

  setLookups(){
    this.ExecConsLookup(16, "les", "entsai");
  }

  AfterInsert(){
    this.activeRecord.lancmanual = "S";
    this.activeRecord.datahoralcto = this.getDataAtual();
    this.activeRecord.dataaprop = this.getDataAtual();
  }
  afterEdit(){
    this.setLookupCliFor();
  }
}
