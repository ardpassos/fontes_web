import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadMovFinancComponent } from './cad-mov-financ.component';

describe('CadMovFinancComponent', () => {
  let component: CadMovFinancComponent;
  let fixture: ComponentFixture<CadMovFinancComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadMovFinancComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadMovFinancComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
