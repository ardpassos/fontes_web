import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadProdutoImgsComponent } from './cad-produto-imgs.component';

describe('CadProdutoImgsComponent', () => {
  let component: CadProdutoImgsComponent;
  let fixture: ComponentFixture<CadProdutoImgsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadProdutoImgsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadProdutoImgsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
