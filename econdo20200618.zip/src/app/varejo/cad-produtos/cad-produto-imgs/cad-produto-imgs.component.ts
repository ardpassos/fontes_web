import { HttpParams, HttpEventType } from '@angular/common/http';
import { CadDetalheComponent } from './../../../cadastrobase/cad-detalhe/cad-detalhe.component';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-cad-produto-imgs',
  templateUrl: './cad-produto-imgs.component.html',
  styleUrls: ['./cad-produto-imgs.component.css']
})
export class CadProdutoImgsComponent extends CadDetalheComponent implements OnInit {

    public descEnvio = "";

    getShowSelectField(_AFieldName: string){
      return _AFieldName === "codproduto";
    }
    
    inicializaCad() {
      super.inicializaCad();
      this.DescricaoSuperiorTela = "Imagens do produto";
      this.cadID = 15;
      this.recno = 0;
      this.cadAutoPost = true;
      this.insertDescCons("codimg", "Cód. img", false, "number");
      this.insertDescCons("codproduto", "Cód. produto", false, "number");
      this.insertDescCons("img", "Imagem", true, "img");
      this.insertDescCons("selectedfile", "selectedfile", false, "img", "", false);
    }  
    
    getKeyValueActiveRecord(){
      return this.activeRecord.codimg;
    }
  
    AfterInsert(){
      this.activeRecord.codproduto = this.recordmaster.codinsumo;
    }
  
    changeCampo(_AEvent) {

      let AFiles =  <File>_AEvent.target.files;
      let ALen = _AEvent.target.files.length;
      
      for (var i = 0; i < ALen; i++) {
        this.novoRegistro();
        //this.activeRecord = rec;
        
        this.activeRecord.selectedfile = AFiles[i];
        this.descEnvio = "";
        this.addRecordToPost(this.activeRecord, "p");
      }
      this.salvarTodosRec();
    }

    ExecPost() {
      params: HttpParams;
      let params = new HttpParams();

      const fd = new FormData();
      //fd.append('codimg', <string>this.getValueFromEditableComp(this.activeRecord.codimg));
      fd.append('codproduto', <string>this.getValueFromEditableComp(this.activeRecord.codproduto));
      fd.append('img', this.activeRecord.selectedfile, this.activeRecord.selectedfile.name);

      console.log(this.activeRecord.selectedfile.name);
      
      let AURL = this.getURLServerPost();
      this.http.post(AURL, fd, {reportProgress: true, observe: "events"}).
        subscribe(event => {
          if (event.type === HttpEventType.UploadProgress){
            this.descEnvio = 'Enviando ' + Math.round((event.loaded/event.total)*100) + '%';
          }
          else if (event.type === HttpEventType.Response){
            this.descEnvio = "Imagem cadastrada com sucesso";
            this.AfterPostCad();
          }
        });
    }

    getImgByRec(rec){
      this.cadIDLookup = 15;
      this.cadIDLookup_Act = "get_img";
      return this.getURLServerConsLookup() + "&codimg=" + rec["codimg"];
    }

    ngOnInit() {
      this.insertFiltroCons("codproduto", "=", this.recordmaster.codinsumo);
      this.ExecCons();
    }  
  }
  
