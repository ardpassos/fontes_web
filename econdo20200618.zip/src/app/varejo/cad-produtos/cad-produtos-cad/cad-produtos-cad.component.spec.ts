import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadProdutosCadComponent } from './cad-produtos-cad.component';

describe('CadProdutosCadComponent', () => {
  let component: CadProdutosCadComponent;
  let fixture: ComponentFixture<CadProdutosCadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadProdutosCadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadProdutosCadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
