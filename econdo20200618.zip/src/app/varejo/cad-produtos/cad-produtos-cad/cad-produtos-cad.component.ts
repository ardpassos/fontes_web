import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cad-produtos-cad',
  templateUrl: './cad-produtos-cad.component.html',
  styleUrls: ['./cad-produtos-cad.component.css']
})
export class CadProdutosCadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
