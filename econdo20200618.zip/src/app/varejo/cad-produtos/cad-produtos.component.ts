import { CadFaixasEtariasComponent } from './../cad-faixas-etarias/cad-faixas-etarias.component';
import { CadSubCategoriaComponent } from './../cad-sub-categoria/cad-sub-categoria.component';
import { CadCategoriasComponent } from './../cad-categorias/cad-categorias.component';
import { CadMarcasComponent } from './../cad-marcas/cad-marcas.component';
import { CadUnmedidasComponent } from './../cad-unmedidas/cad-unmedidas.component';
import { CadLocalalmoxComponent } from './../cad-localalmox/cad-localalmox.component';
import { CadGruposprodutosComponent } from './../cad-gruposprodutos/cad-gruposprodutos.component';
import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cad-produtos',
  templateUrl: './cad-produtos.component.html',
  styleUrls: ['./cad-produtos.component.css']
})
export class CadProdutosComponent extends FormBaseComponent implements OnInit {
  
  public descLctos: string = "";
  public ehLctos: boolean = false;
  public ehGrade: boolean = false;

  ngOnInit() {
    super.ngOnInit();
      this.ExecCons();
  }

  inicializaCad() {
      super.inicializaCad();
      this.DescricaoSuperiorTela = "Produtos";
      this.cadID = 8;
      this.recno = 0;
      this.cadAutoPost = true;
      this.insertDescCons("codinsumo", "Cód. Produto", false, "number", "Geral", false);
      this.insertDescCons("insumo", "Produto", true, "text");
      this.insertDescCons("obs", "Obs", false, "text");
      this.insertDescCons("status", "Status", false, "text");
      this.insertDescCons("codgrupo", "Cód. Grupo", false, "text", "Especificação");
      this.insertDescCons("codlocalalm", "Cód. local almoxarifado", false, "text", "Especificação");
      this.insertDescCons("codunmedida", "Cód. unidade de medida", false, "text", "Especificação");
      this.insertDescCons("codmarca", "Cód. marca", false, "text", "Classificação");
      this.insertDescCons("codcategoria", "Cód. categoria", false, "text", "Classificação");
      this.insertDescCons("codsubcategoria", "Cód. sub categoria", false, "text", "Classificação");
      this.insertDescCons("codfaixaetaria", "Cód. faixa etária", false, "text", "Classificação");
      this.insertDescCons("genero", "Gênero", false, "text", "Classificação");
      this.insertButtonRec("Delete", "Excluir", "clear");
      this.insertButtonRec("Imgs", "Imagens", "add");
      this.insertButtonRec("Grade", "Grade", "apps");
      this.insertCampoLookup("codgrupo", "app-cad-gruposprodutos", CadGruposprodutosComponent);
      this.insertCampoLookup("codlocalalm", "app-cad-localalmox", CadLocalalmoxComponent);
      this.insertCampoLookup("codunmedida", "app-cad-unmedidas", CadUnmedidasComponent);
      this.insertCampoLookup("codmarca", "app-cad-marcas", CadMarcasComponent);
      this.insertCampoLookup("codcategoria", "app-cad-categorias", CadCategoriasComponent);
      this.insertCampoLookup("codsubcategoria", "app-cad-sub-categoria", CadSubCategoriaComponent);
      this.insertCampoLookup("codfaixaetaria", "app-cad-faixas-etarias", CadFaixasEtariasComponent);

      this.setLookups();
    }

    recebedadoslkp(_ADados: any[]) {
      this.setLookupNameValues(this.cadIDLookup_CampoRetorno, _ADados);
      if (this.LookupsCarregados)
        return;
      if (this.cadIDLookup === 30){
        this.ExecConsLookup(10, "l", "codfaixaetaria");
      }
      else if (this.cadIDLookup === 10){
        this.ExecConsLookup(9, "l", "codcategoria");
      }
      else if (this.cadIDLookup === 9){
        this.ExecConsLookup(8, "lst", "status");
      }
      else if ((this.cadIDLookup === 8) && (this.cadIDLookup_CampoRetorno.match("status") != null)){
        this.ExecConsLookup(8, "lgn", "genero");
      }
      else if ((this.cadIDLookup === 8) && (this.cadIDLookup_CampoRetorno.match("genero") != null)){
        this.ExecConsLookup(7, "l", "codgrupo");
      }
      else if (this.cadIDLookup === 7){
        this.ExecConsLookup(6, "l", "codlocalalm");
      }
      else if (this.cadIDLookup === 6) {
        this.ExecConsLookup(5, "l", "codmarca");
      }
      else if (this.cadIDLookup === 5) {
        this.ExecConsLookup(4, "l", "codunmedida");
      }
      else if (this.cadIDLookup === 4){
        this.LookupsCarregados = true;
      }
    }
    setLookups(){
      this.ExecConsLookup(30, "l", "codsubcategoria");
    }

    setDescLctos(){
      this.descLctos = "Imagens do produto: " + this.activeRecord.insumo;
    } 

    ExecPost() {
      this.manterNaAbaAtual = true;
      super.ExecPost();
    }


    buttonevent(_ARet: any){
      this.activeRecord = _ARet.record;
      if (_ARet.btnText === "add") {
        this.setDescLctos();
        this.disableConsAndCad();
//        this.getLookupUHs();
        this.ehLctos = true;
      }
      else if (_ARet.btnText === "apps") {
        this.setDescLctos();
        this.disableConsAndCad();
//        this.getLookupUHs();
        this.ehGrade = true;
      }
      else {
        super.buttonevent(_ARet);
      }
    }    
  
    disableConsAndCad(){ 
      super.disableConsAndCad();
      this.ehLctos = false;
      this.ehGrade = false;
    }

    AfterPostEnableDisableScreen(){
    }

    voltarConsultaPrinc(){
      this.disableConsAndCad();
      this.AfterPostEnableDisableScreen();
      this.ehconsulta = true;
      this.ehcadastro = false;
    }
   
    getMostrarImgs(){
      let AComp = ((this.activeRecord != null) && (this.activeRecord.codinsumo != null));
      if (AComp)
        AComp = (this.ehcadastro && this.activeRecord.codinsumo > 0);
      return (AComp ||
              (this.ehLctos));
    }

    getMostrarGrade(){
      let AComp = ((this.activeRecord != null) && (this.activeRecord.codinsumo != null));
      if (AComp)
        AComp = (this.ehcadastro && this.activeRecord.codinsumo > 0);
      return (AComp ||
              (this.ehGrade));
    }

  }