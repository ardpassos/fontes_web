import { CadDetalheComponent } from './../../../cadastrobase/cad-detalhe/cad-detalhe.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cad-produtos-grade',
  templateUrl: './cad-produtos-grade.component.html',
  styleUrls: ['./cad-produtos-grade.component.css']
})
export class CadProdutosGradeComponent extends CadDetalheComponent implements OnInit {

  getShowSelectField(_AFieldName: string){
    return _AFieldName === "coditem";
  }
  
  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "Grade do produto";
    this.cadID = 28;
    this.recno = 0;
    this.cadAutoPost = true;
    this.insertDescCons("coditem", "Cód. item", false, "number");
    this.insertDescCons("codinsumo", "Cód. insumo", false, "number");
    this.insertDescCons("codlocalalm", "Cód. local", true, "number");
    this.insertDescCons("codcor", "Cor", true, "number");
    this.insertDescCons("tamanho", "Tamanho", true, "text");
    this.insertDescCons("valorde", "Valor de", true, "number");
    this.insertDescCons("valorvenda", "Valor venda", true, "number");
    this.insertDescCons("mostrarvalorsite", "Mostrar valor no site", true, "text", "", true, true);
    this.insertDescCons("itemempromocao", "Em promoção", true, "text", "", true, true);
    this.insertDescCons("qtdemin", "Qtde mín.", true, "number");
    this.insertDescCons("qtdemax", "Qtde máx.", true, "number");
    this.insertDescCons("codbarras", "Cód. barras", true, "text");

    this.setLookups();
  } 
  
  recebedadoslkp(_ADados: any[]) {
    if (this.cadIDLookup === 6) {
      this.setLookupNameValues("codlocalalm", _ADados);
      this.ExecConsLookup(29);
    }
    else if (this.cadIDLookup === 29) {
      this.setLookupNameValues("codcor", _ADados);
    }
  }

  setLookups(){
    this.ExecConsLookup(6);
  }

  getKeyValueActiveRecord(){
    return this.activeRecord.coditem;
  }

  AfterInsert(){
    this.activeRecord.codinsumo = this.recordmaster.codinsumo;
  }

  ngOnInit() {
    this.insertFiltroCons("codinsumo", "=", this.recordmaster.codinsumo);
    console.log("codinsumo=" + this.recordmaster.codinsumo);
    this.ExecCons();
  }  

}
