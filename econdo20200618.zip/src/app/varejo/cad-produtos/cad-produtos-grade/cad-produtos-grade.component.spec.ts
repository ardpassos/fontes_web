import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadProdutosGradeComponent } from './cad-produtos-grade.component';

describe('CadProdutosGradeComponent', () => {
  let component: CadProdutosGradeComponent;
  let fixture: ComponentFixture<CadProdutosGradeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadProdutosGradeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadProdutosGradeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
