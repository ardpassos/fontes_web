import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadContasPagarComponent } from './cad-contas-pagar.component';

describe('CadContasPagarComponent', () => {
  let component: CadContasPagarComponent;
  let fixture: ComponentFixture<CadContasPagarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadContasPagarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadContasPagarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
