import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cad-contas-pagar',
  templateUrl: './cad-contas-pagar.component.html',
  styleUrls: ['./cad-contas-pagar.component.css']
})

export class CadContasPagarComponent extends FormBaseComponent implements OnInit {

  public descLctos: string = "";
  public ehLctos: boolean = false;

  ngOnInit() {
    this.insertFiltroCons("status", "in", " 'A', 'I' ");
//    this.insertFiltroCons("datavcto", "<=", this.getDataAtual(""));
    this.ExecCons();  
  }
  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "Contas a pagar";
    this.cadID = 18;
    this.recno = 0;
    this.cadAutoPost = true;
    this.insertDescCons("codcontapagar", "Código", true, "number", "Geral", false);
    this.insertDescCons("numdoc", "Núm doc.", true, "text");
    this.insertDescCons("codpessoaconta", "Cód. fornecedor", false, "text");
    this.insertDescCons("codcrd", "Cód. CRD", false, "number");
    this.insertDescCons("datavcto", "Data vcto", true, "date");
    this.insertDescCons("valor", "Valor", true, "float");
    this.insertDescCons("obs", "Obs", true, "text");
    this.insertDescCons("lancmanual", "Lanc. manual?", false, "float", "Geral", false, true);
    this.insertDescCons("status", "Status", true, "text", "Geral", false);
    this.insertDescCons("datahoralcto", "Data hora lcto", false, "date", "Geral", false);
    
    this.insertButtonRec("Lctos", "Pagar", "add");
    this.setLookups(); 
  }

  recebedadoslkp(_ADados: any[]) {
    this.setLookupNameValues(this.cadIDLookup_CampoRetorno, _ADados);
    if ((this.cadIDLookup === 2) && (this.cadIDLookup_CampoRetorno.match("codpessoaconta") != null)){
      this.ExecConsLookup(18, "ls", "status");
    }
    else if (this.cadIDLookup === 18){
      this.ExecConsLookup(32, "gd", "codcrd");
    }
  }

  setLookups(){
    this.ExecConsLookup(2, "lf", "codpessoaconta");
  }

  setDescLctos(){
    this.descLctos = "Detalhamento de recebimentos: " + this.activeRecord.numdoc + 
                      " / Cliente: " + this.activeRecord.codpessoaconta;
  }
  
  AfterInsert(){
    this.activeRecord.status = "A";
  }  
  
  disableConsAndCad(){ 
    super.disableConsAndCad();
    this.ehLctos = false;
  }

  buttonevent(_ARet: any){
    this.activeRecord = _ARet.record;
    if (_ARet.btnText === "add") {
      this.setDescLctos();
      this.disableConsAndCad();
      this.ehLctos = true;
    }
    else {
      super.buttonevent(_ARet);
    }
  }

  ExecPost(){
    if (this.activeRecord["status"] != "A") 
      alert("Este registro só poderá ser alterado se ele estiver com o status de 'Aberto'! ");
    else
      super.ExecPost();
  }

  editarRecAtual(rec: any) {
    if (rec["status"] === "B"){
      alert("Esta registro está com status de 'Baixado' e suas alterações não poderão ser efetivadas! Para alterar, favor estornar o recebimento!");
    }
    super.editarRecAtual(rec);
  }

  voltarConsultaPrinc(){
    this.disableConsAndCad();
    this.AfterPostEnableDisableScreen();
  }
  
}

