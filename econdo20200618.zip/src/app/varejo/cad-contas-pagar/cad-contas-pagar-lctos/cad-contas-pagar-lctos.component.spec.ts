import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadContasPagarLctosComponent } from './cad-contas-pagar-lctos.component';

describe('CadContasPagarLctosComponent', () => {
  let component: CadContasPagarLctosComponent;
  let fixture: ComponentFixture<CadContasPagarLctosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadContasPagarLctosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadContasPagarLctosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
