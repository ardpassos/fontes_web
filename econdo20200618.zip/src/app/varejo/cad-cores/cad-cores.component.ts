import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cad-cores',
  templateUrl: './cad-cores.component.html',
  styleUrls: ['./cad-cores.component.css']
})
export class CadCoresComponent  extends FormBaseComponent implements OnInit {

  ngOnInit() {
    this.ExecCons();
  }
  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "Cores";
    this.cadID = 29;
    this.recno = 0;
    this.cadAutoPost = false;
    this.insertDescCons("codcor", "Cód. Cor", true, "number");
    this.insertDescCons("Cor", "Cor", true, "text");
    this.insertDescCons("refhexa", "Referência", true, "color");
  }

  getURLServerPost() {
    let ACor = this.getValueFromEditableComp(this.activeRecord.refhexa);
    ACor = ACor.replace("#", "");
    console.log(ACor);
    return super.getURLServerPost() +
      "&codcor=" + this.getValueFromEditableComp(this.activeRecord.codcor) +
      "&cor=" + this.getValueFromEditableComp(this.activeRecord.cor) +
      "&refhexa=" + ACor;
  }  
}
