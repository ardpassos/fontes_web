import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadCoresComponent } from './cad-cores.component';

describe('CadCoresComponent', () => {
  let component: CadCoresComponent;
  let fixture: ComponentFixture<CadCoresComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadCoresComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadCoresComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
