import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cad-marcas',
  templateUrl: './cad-marcas.component.html',
  styleUrls: ['./cad-marcas.component.css']
})
export class CadMarcasComponent extends FormBaseComponent implements OnInit {
  ngOnInit() {
    this.ExecCons();
  }
  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "Marcas";
    this.cadID = 5;
    this.recno = 0;
    this.insertDescCons("codmarca", "Cód. Marca", true, "number");
    this.insertDescCons("marca", "Marca", true, "text");
  }
  getURLServerPost() {
    return super.getURLServerPost() +
      "&codmarca=" + this.getValueFromEditableComp(this.activeRecord.codmarca) +
      "&marca=" + this.getValueFromEditableComp(this.activeRecord.marca);
  }
}
