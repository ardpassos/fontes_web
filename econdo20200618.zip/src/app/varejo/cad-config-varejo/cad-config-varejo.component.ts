import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cad-config-varejo',
  templateUrl: './cad-config-varejo.component.html',
  styleUrls: ['./cad-config-varejo.component.css']
})
export class CadConfigVarejoComponent extends FormBaseComponent implements OnInit {
  ngOnInit() {
    this.ExecCons();
  }
  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "Configuração geral";
    this.cadID = 33;
    this.recno = 0;
    this.cadAutoPost = true;
    this.insertDescCons("codconfig", "Cód. config", true, "number");
    this.insertDescCons("codcrdvendas", "Cód. CRD compras", true, "number", "Financeiro");
    this.insertDescCons("codcrdcompras", "Cód. CRD compras", true, "number", "Financeiro");
    this.setLookups(); 
  }
  
  recebedadoslkp(_ADados: any[]) {
    this.setLookupNameValues(this.cadIDLookup_CampoRetorno, _ADados);
    if ((this.cadIDLookup === 32)  && (this.cadIDLookup_CampoRetorno.match("codcrdcompras") != null)) {
      this.ExecConsLookup(32, "gc", "codcrdvendas");
    }
  }

  setLookups(){
    this.ExecConsLookup(32, "gd", "codcrdcompras");
  }  
}
