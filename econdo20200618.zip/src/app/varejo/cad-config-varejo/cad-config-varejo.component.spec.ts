import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadConfigVarejoComponent } from './cad-config-varejo.component';

describe('CadConfigVarejoComponent', () => {
  let component: CadConfigVarejoComponent;
  let fixture: ComponentFixture<CadConfigVarejoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadConfigVarejoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadConfigVarejoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
