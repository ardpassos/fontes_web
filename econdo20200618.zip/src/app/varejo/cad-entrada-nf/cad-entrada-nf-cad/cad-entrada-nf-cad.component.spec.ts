import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadEntradaNfCadComponent } from './cad-entrada-nf-cad.component';

describe('CadEntradaNfCadComponent', () => {
  let component: CadEntradaNfCadComponent;
  let fixture: ComponentFixture<CadEntradaNfCadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadEntradaNfCadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadEntradaNfCadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
