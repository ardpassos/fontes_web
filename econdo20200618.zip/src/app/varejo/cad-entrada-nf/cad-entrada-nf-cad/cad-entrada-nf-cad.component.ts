import { CadastrobaseComponent } from './../../../cadastrobase/cadastrobase.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cad-entrada-nf-cad',
  templateUrl: './cad-entrada-nf-cad.component.html',
  styleUrls: ['./cad-entrada-nf-cad.component.css']
})
export class CadEntradaNfCadComponent extends CadastrobaseComponent implements OnInit {

  ngOnInit() {
    super.ngOnInit();
  }

}
