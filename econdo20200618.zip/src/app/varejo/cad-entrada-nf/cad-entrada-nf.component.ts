import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';
import { exists } from 'fs';

@Component({
  selector: 'app-cad-entrada-nf',
  templateUrl: './cad-entrada-nf.component.html',
  styleUrls: ['./cad-entrada-nf.component.css']
})
export class CadEntradaNFComponent extends FormBaseComponent implements OnInit {

  public descLctos: string = "";
  public ehLctos: boolean = false;

  ngOnInit() {
    this.ExecCons();
  }
  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "Entrada de Nota Fiscal";
    this.cadID = 11;
    this.recno = 0;
    this.cadAutoPost = true;
    this.insertDescCons("codnf", "Cód. NF", false, "number", "Geral", false);
    this.insertDescCons("codfornecedor", "Fornecedor", false, "number");
    this.insertDescCons("numnf", "Número NF", true, "text");
    this.insertDescCons("serienf", "Série NF", true, "text");
    this.insertDescCons("dataemissao", "Data emissão", false, "date", "Datas");
    this.insertDescCons("dataentrada", "Data entrada", false, "date", "Datas");
    this.insertDescCons("valornf", "Valor NF", true, "float", "Financeiro");
    this.insertDescCons("tipopgto", "Tipo Pgto", false, "text", "Financeiro", false); // será mostrado manualmente no html
    this.insertDescCons("valorentrada", "Valor de entrada", false, "float", "Financeiro", false); // será mostrado manualmente no html
    this.insertDescCons("numparcelas", "Núm. de parcelas", false, "number", "Financeiro", false); // será mostrado manualmente no html

    this.insertDescCons("statusnf", "Status NF", true, "text", "Financeiro", false);
    this.insertDescCons("tiponf", "Tipo NF", false, "text", "Financeiro", false);
    this.insertDescCons("valorItens", "Valor itens", true, "float", "Financeiro", false);
    this.insertDescCons("valorfinanc", "Val. financ.", true, "float", "Financeiro", false);

    this.insertButtonRec("Lctos", "Itens", "add");
    this.insertButtonRec("Finalizar", "Finalizar", "call_missed_outgoing");
    this.insertButtonRec("Reabrir", "Reabrir", "call_missed");
    this.setLookups();
  }

  recebedadoslkp(_ADados: any[]) {
    if ((this.cadIDLookup === 11) && (this.cadIDLookup_CampoRetorno.match("statusnf") != null)){
      this.setLookupNameValues(this.cadIDLookup_CampoRetorno, _ADados);
      this.ExecConsLookup(11, "lpg", "tipopgto");
    }
    else if ((this.cadIDLookup === 11) && (this.cadIDLookup_CampoRetorno.match("tipopgto") != null)){
      this.setLookupNameValues(this.cadIDLookup_CampoRetorno, _ADados);
      this.ExecConsLookup(2, "lf", "codfornecedor");
    }
    else if ((this.cadIDLookup === 2) && (this.cadIDLookup_CampoRetorno.match("codfornecedor") != null)){
      this.setLookupNameValues("codfornecedor", _ADados);
    }
  }

  setLookups(){
    this.ExecConsLookup(11, "lst", "statusnf");
  }

  setDescLctos(){
    this.descLctos = "Itens da nota fiscal: " + this.activeRecord.numnf + 
                      " / Série: " + this.activeRecord.serienf;
  }
  
  AfterInsert(){
    this.activeRecord.statusnf = "A";
  }  
  
  disableConsAndCad(){ 
    super.disableConsAndCad();
    this.ehLctos = false;
  }

  buttonevent(_ARet: any){
    if (_ARet.record != null)
      this.activeRecord = _ARet.record;
    console.log(_ARet);
    if (_ARet.btnText === "add") {
      this.setDescLctos();
      this.disableConsAndCad();
//        this.getLookupUHs();
      this.ehLctos = true;
    }
    else if (_ARet.btnText === "call_missed_outgoing"){
      this.finalizarNF();
    } 
    else if (_ARet.btnText === "call_missed"){
      this.reabrirNF();
    }  
    else {
      super.buttonevent(_ARet);
    }
  }

//rotina para finalizar NF
  AfterFinalizaNF(){
    this.ExecCons();
  }
  recebedadosFinaliza(_ADados: any[]) {
    this.AfterFinalizaNF();
    let retorno = _ADados;
    if (retorno[0].retorno == 1)
      alert("Nota fiscal finalizada!");
    else
      alert("Erro ao finalizar nota fiscal! ");
  }  
  getURLServerFinalizaNF() {
    return this.getURLServer() + this.getAct() + "&" + this.getFieldKey() + "=" + 
            this.getValueFromEditableComp(this.activeRecord[this.getFieldKey()]);
  }
  ExecFinalizarNF() {
    let AURL = this.getURLServerFinalizaNF();
    console.log(AURL);
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosFinaliza(data));
  }    
  finalizarNF(){
    if (this.activeRecord["statusnf"] === "A") {
      let AV1 = parseFloat(this.activeRecord["valornf"]).toFixed(2);
      let AV2 = parseFloat(this.activeRecord["valorfinanc"]).toFixed(2);
      if (AV1 !== AV2)
        if (confirm("Valor da nota fiscal é diferente do valor informado para o financeiro! Deseja continuar mesmo assim?") === false)
          return;

      AV2 = parseFloat(this.activeRecord["valoritens"]).toFixed(2);
      if (AV1 !== AV2)
        if (confirm("Valor da nota fiscal é diferente do valor dos ítens da nota! Deseja continuar mesmo assim?") === false)
          return;
    
      if (confirm("Deseja finalizar a nota fiscal " + this.activeRecord["numnf"] + "?") === true){
        this.cadInsUpd = "fnf";
        this.ExecFinalizarNF();
      }
    }
    else if (this.activeRecord["statusnf"] === "F")
      alert("Esta nota fiscal já se encontra finalizada! ");
    else if (this.activeRecord["statusnf"] === "C")
      alert("Esta nota fiscal se encontra cancelada! ");
  }
  //fim da rotina de finalização de NF

  //rotina para reabrir NF
  AfterReabrirNF(){
    this.ExecCons();
  }
  recebedadosReabrir(_ADados: any[]) {
    this.AfterReabrirNF();
    let retorno = _ADados;
    if (retorno[0].retorno == 1)
      alert("Nota fiscal reaberta!");
    else
      alert("Erro ao reabrir nota fiscal! ");
  }  
  getURLServerReabrirNF() {
    return this.getURLServer() + this.getAct() + "&" + this.getFieldKey() + "=" + 
          this.getValueFromEditableComp(this.activeRecord[this.getFieldKey()]);
  }
  ExecReabrirNF() {
    let AURL = this.getURLServerReabrirNF();
    console.log(AURL);
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosReabrir(data));
  }    
  reabrirNF(){
    if (this.activeRecord["statusnf"] === "F") {
      if (confirm("Deseja reabrir a nota fiscal " + this.activeRecord["numnf"] + "?") === true){
        this.cadInsUpd = "rnf";
        this.ExecReabrirNF();
      }
    }
    else if (this.activeRecord["statusnf"] === "A")
      alert("Esta nota fiscal já se encontra aberta! ");
    else if (this.activeRecord["statusnf"] === "C")
      alert("Esta nota fiscal se encontra cancelada! ");
  }
  //fim da rotina de reabrir de NF

  ExecPost(){
    if (this.activeRecord["statusnf"] != "A") 
      alert("Esta nota fiscal só poderá ser alterada se ela estiver ABERTA! ");
    else
      super.ExecPost();
  }

  editarRecAtual(rec: any) {
    if (rec["statusnf"] === "F"){
      alert("Esta nota fiscal está fechada e suas alteração não poderão ser efetivadas! Para alterar, favor reabrir a nota fiscal!");
    }
    else if (rec["statusnf"] === "C"){
      alert("Esta nota fiscal está cancelada e suas alteração não poderão ser efetivadas!");
    }
    super.editarRecAtual(rec);
  }

  voltarConsultaPrinc(){
    this.disableConsAndCad();
    this.AfterPostEnableDisableScreen();
  }
  
}
