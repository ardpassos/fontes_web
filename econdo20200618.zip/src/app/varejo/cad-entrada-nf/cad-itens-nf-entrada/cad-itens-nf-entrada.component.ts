import { CadDetalheComponent } from './../../../cadastrobase/cad-detalhe/cad-detalhe.component';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-cad-itens-nf-entrada',
  templateUrl: './cad-itens-nf-entrada.component.html',
  styleUrls: ['./cad-itens-nf-entrada.component.css']
})
export class CadItensNfEntradaComponent extends CadDetalheComponent implements OnInit {

    @Input() uhs: any = [];
  
    getShowSelectField(_AFieldName: string){
      return _AFieldName === "codnf";
    }
    
    inicializaCad() {
      super.inicializaCad();
      this.DescricaoSuperiorTela = "Itens - Entrada de NF";
      this.cadID = 13;
      this.recno = 0;
      this.cadAutoPost = true;
      this.insertDescCons("codlcto", "Cód. lcto", false, "number");
      this.insertDescCons("codnf", "Cód. nf", false, "number");
      this.insertDescCons("coditemgrade", "Cód. produto", true, "number");
      this.insertDescCons("valorunit", "Valor unitário", true, "number");
      this.insertDescCons("qtde", "Qtde", true, "number");
      this.insertDescCons("valortotal", "Valor total", true, "number");
      this.setLookups();
    }  
    
    recebedadoslkp(_ADados: any[]) {
      if (this.cadIDLookup === 28) {
        this.setLookupNameValues("coditemgrade", _ADados);
      }
    }
  
    setLookups(){
      this.ExecConsLookup(28);
    }

    getKeyValueActiveRecord(){
      return this.activeRecord.codlcto;
    }
  
    AfterInsert(){
      this.activeRecord.codnf = this.recordmaster.codnf;
    }
  
    ngOnInit() {
      this.insertFiltroCons("codnf", "=", this.recordmaster.codnf);
      this.ExecCons();
    }  
  }
  