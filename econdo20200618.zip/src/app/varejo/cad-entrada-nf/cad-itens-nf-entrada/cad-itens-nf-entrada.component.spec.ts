import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadItensNfEntradaComponent } from './cad-itens-nf-entrada.component';

describe('CadItensNfEntradaComponent', () => {
  let component: CadItensNfEntradaComponent;
  let fixture: ComponentFixture<CadItensNfEntradaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadItensNfEntradaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadItensNfEntradaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
