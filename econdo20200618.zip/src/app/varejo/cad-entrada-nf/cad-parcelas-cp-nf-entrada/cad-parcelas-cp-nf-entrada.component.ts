import { CadDetalheComponent } from './../../../cadastrobase/cad-detalhe/cad-detalhe.component';
import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-cad-parcelas-cp-nf-entrada',
  templateUrl: './cad-parcelas-cp-nf-entrada.component.html',
  styleUrls: ['./cad-parcelas-cp-nf-entrada.component.css']
})

export class CadParcelasCpNfEntradaComponent extends CadDetalheComponent implements OnInit {

  @Input() uhs: any = [];
  @Output() callbackButton = new EventEmitter();

  getShowSelectField(_AFieldName: string){
    return _AFieldName === "codlcto";
  }
  
  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "Parcelas para o contas a pagar";
    this.cadID = 21;
    this.recno = 0;
    this.cadAutoPost = true;
    this.insertDescCons("codlcto", "Cód. lcto", false, "number");
    this.insertDescCons("codnf", "Cód. nf", false, "number");
    this.insertDescCons("datavcto", "Qtde", true, "date");
    this.insertDescCons("valor", "Valor", true, "float");
  }  
  
  getKeyValueActiveRecord(){
    return this.activeRecord.codlcto;
  }

  AfterInsert(){
    this.activeRecord.codnf = this.recordmaster.codnf;
  }

  ngOnInit() {
    this.refreshCons();
  }  

  refreshCons(){
    this.limpaFiltros();
    this.insertFiltroCons("codnf", "=", this.recordmaster.codnf);
    this.ExecCons();
  }

  ExecPostMaster(){
    this.callbackButton.emit({btnText: "post_stay_rec", record: null});
  }

  //rotina para gerar parcelas
  AfterGerarParcelasNF(){
    this.refreshCons();
    this.ExecCons();
  }
  recebedadosGerarParcela(_ADados: any[]) {
    this.AfterGerarParcelasNF();
//    let retorno = _ADados;
  }  
  getURLServerGerarParcelasNF() {
    return this.getURLServer() + this.getAct() + "&codnf=" + this.recordmaster.codnf +
            "&valornf=" + this.recordmaster.valornf +
            "&numparcelas=" + this.recordmaster.numparcelas +
            "&valorentrada=" + this.recordmaster.valorentrada;
  }
  ExecGerarParcelasNF() {
    let AURL = this.getURLServerGerarParcelasNF();
    console.log(AURL);
    this.http.post<any[]>(AURL, {}).
      subscribe(data => this.recebedadosGerarParcela(data));
  }    
  gerarParcelasNF(){
    console.log(this.recordmaster.codnf);
    if (this.recordmaster.codnf == undefined) {
      if (confirm("É necessário salvar esta nota antes de gerar parcelas para o financeiro. Deseja salvar?") === true){
        this.ExecPostMaster();
      }
    }
    else if (this.recordmaster.statusnf === "A") {
      if (confirm("Deseja gerar/regerar as condições de parcelas para o financeiro?") === true){
        this.cadInsUpd = "gp";
        this.ExecGerarParcelasNF();
      }
    }
    else if (this.recordmaster.statusnf === "F")
      alert("Esta nota fiscal está fechada! ");
    else if (this.recordmaster.statusnf === "C")
      alert("Esta nota fiscal está cancelada! ");
  }
  //fim da rotina de gerar parcelas


}
