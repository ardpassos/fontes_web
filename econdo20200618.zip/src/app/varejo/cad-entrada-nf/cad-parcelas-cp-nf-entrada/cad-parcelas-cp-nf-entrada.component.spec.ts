import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadParcelasCpNfEntradaComponent } from './cad-parcelas-cp-nf-entrada.component';

describe('CadParcelasCpNfEntradaComponent', () => {
  let component: CadParcelasCpNfEntradaComponent;
  let fixture: ComponentFixture<CadParcelasCpNfEntradaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadParcelasCpNfEntradaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadParcelasCpNfEntradaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
