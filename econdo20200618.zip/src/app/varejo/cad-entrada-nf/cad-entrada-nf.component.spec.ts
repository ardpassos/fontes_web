import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadEntradaNFComponent } from './cad-entrada-nf.component';

describe('CadEntradaNFComponent', () => {
  let component: CadEntradaNFComponent;
  let fixture: ComponentFixture<CadEntradaNFComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadEntradaNFComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadEntradaNFComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
