import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cad-categorias',
  templateUrl: './cad-categorias.component.html',
  styleUrls: ['./cad-categorias.component.css']
})
export class CadCategoriasComponent extends FormBaseComponent implements OnInit {
    ngOnInit() {
      this.ExecCons();
    }
    inicializaCad() {
      super.inicializaCad();
      this.DescricaoSuperiorTela = "Categorias";
      this.cadID = 9;
      this.recno = 0;
      this.insertDescCons("codcategoria", "Cód. Categoria", true, "number");
      this.insertDescCons("Categoria", "Categoria", true, "text");
    }
    getURLServerPost() {
      return super.getURLServerPost() +
        "&codcategoria=" + this.getValueFromEditableComp(this.activeRecord.codcategoria) +
        "&categoria=" + this.getValueFromEditableComp(this.activeRecord.categoria);
    }
  }
