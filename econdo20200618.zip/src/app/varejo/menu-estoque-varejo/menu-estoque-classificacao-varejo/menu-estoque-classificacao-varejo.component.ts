import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-estoque-classificacao-varejo',
  templateUrl: './menu-estoque-classificacao-varejo.component.html',
  styleUrls: ['./menu-estoque-classificacao-varejo.component.css']
})
export class MenuEstoqueClassificacaoVarejoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
