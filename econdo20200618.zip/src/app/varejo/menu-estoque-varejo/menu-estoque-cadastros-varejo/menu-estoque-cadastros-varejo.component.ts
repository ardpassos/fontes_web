import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-estoque-cadastros-varejo',
  templateUrl: './menu-estoque-cadastros-varejo.component.html',
  styleUrls: ['./menu-estoque-cadastros-varejo.component.css']
})
export class MenuEstoqueCadastrosVarejoComponent implements OnInit {
  mostrarMenu = false;
  constructor() { }

  async delay(ms: number) {
    await new Promise(resolve => setTimeout(()=>resolve(), ms)).then(()=>
    {
      this.mostrarMenu = true; 
    });
  }

  ngOnInit() {
    this.delay(200);
  }

}
