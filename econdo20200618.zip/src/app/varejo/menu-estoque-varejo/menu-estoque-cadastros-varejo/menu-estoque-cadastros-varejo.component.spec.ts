import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MenuEstoqueCadastrosVarejoComponent } from './menu-estoque-cadastros-varejo.component';

describe('MenuEstoqueCadastrosVarejoComponent', () => {
  let component: MenuEstoqueCadastrosVarejoComponent;
  let fixture: ComponentFixture<MenuEstoqueCadastrosVarejoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MenuEstoqueCadastrosVarejoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuEstoqueCadastrosVarejoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
