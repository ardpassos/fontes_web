import { GeralServiceComponent } from './geral-service/geral-service.component';
import { HttpClientModule } from '@angular/common/http';
import { AuthGuard } from './guard/auth-guard';
import { AuthService } from './login/auth.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { UsuariosComponent } from './usuarios/usuarios.component';
import { CadastrosComponent } from './cadastros/cadastros.component';
import { EmpresasComponent } from './cadastros/empresas/empresas.component';
import { UhsComponent } from './cadastros/uhs/uhs.component';
import { DespesasfixasComponent } from './cadastros/despesasfixas/despesasfixas.component';
import { FormBaseComponent } from './form-base/form-base.component';
import { ConsultabaseComponent } from './consultabase/consultabase.component';
import { CadastrobaseComponent } from './cadastrobase/cadastrobase.component';
import { PeriodoapuracaoComponent } from './cadastros/periodoapuracao/periodoapuracao.component';
import { LctogasComponent } from './cadastros/lctogas/lctogas.component';
import { LctoluzComponent } from './cadastros/lctoluz/lctoluz.component';
import { LctoaguaComponent } from './cadastros/lctoagua/lctoagua.component';
import { DespesasuhComponent } from './cadastros/despesasuh/despesasuh.component';
import { PeriodoapuracaolctosComponent } from './cadastros/periodoapuracaolctos/periodoapuracaolctos.component';
import { PeriodoapuracaolctosdespcondComponent } from './cadastros/periodoapuracaolctosdespcond/periodoapuracaolctosdespcond.component';
import { PeriodoapuracaolctosluzComponent } from './cadastros/periodoapuracaolctosluz/periodoapuracaolctosluz.component';
import { PeriodoapuracaolctosaguaComponent } from './cadastros/periodoapuracaolctosagua/periodoapuracaolctosagua.component';
import { PeriodoapuracaolctosgasComponent } from './cadastros/periodoapuracaolctosgas/periodoapuracaolctosgas.component';
import { PeriodoapuracaorelComponent } from './cadastros/periodoapuracaorel/periodoapuracaorel.component';
import { PeriodoapuracaorellctosComponent } from './cadastros/periodoapuracaorellctos/periodoapuracaorellctos.component';
import { SolicitacontatoComponent } from './solicitacontato/solicitacontato.component';
import { AreacomumComponent } from './cadastros/areacomum/areacomum.component';
import { PaineluhComponent } from './paineluh/paineluh.component';
import { PaineluhperiodosapuracaoComponent } from './paineluh/paineluhperiodosapuracao/paineluhperiodosapuracao.component';
import { PaineluhreservasacComponent } from './paineluh/paineluhreservasac/paineluhreservasac.component';
import { DatagridComponent } from './comps/datagrid/datagrid.component';
import { AcperiodosComponent } from './cadastros/areacomum/acperiodos/acperiodos.component';
import { PaineluhreservasacdiaComponent } from './paineluh/paineluhreservasac/paineluhreservasacdia/paineluhreservasacdia.component';
import { CadFuncionariosComponent } from './varejo/cad-funcionarios/cad-funcionarios.component';
import { MenuCadastrosVarejoComponent } from './varejo/menu-cadastros-varejo/menu-cadastros-varejo.component';
import { CadPessoasComponent } from './varejo/cad-pessoas/cad-pessoas.component';
import { LookupComponent } from './comps/lookup/lookup.component';
import { CadUnmedidasComponent } from './varejo/cad-unmedidas/cad-unmedidas.component';
import { CadMarcasComponent } from './varejo/cad-marcas/cad-marcas.component';
import { CadLocalalmoxComponent } from './varejo/cad-localalmox/cad-localalmox.component';
import { CadGruposprodutosComponent } from './varejo/cad-gruposprodutos/cad-gruposprodutos.component';
import { CadProdutosComponent } from './varejo/cad-produtos/cad-produtos.component';
import { MenuEstoqueVarejoComponent } from './varejo/menu-estoque-varejo/menu-estoque-varejo.component';
import { MenuFinanceiroVarejoComponent } from './varejo/menu-financeiro-varejo/menu-financeiro-varejo.component';
import { CadCategoriasComponent } from './varejo/cad-categorias/cad-categorias.component';
import { CadFaixasEtariasComponent } from './varejo/cad-faixas-etarias/cad-faixas-etarias.component';
import { CadEntradaNFComponent } from './varejo/cad-entrada-nf/cad-entrada-nf.component';
import { CadSaidaNFComponent } from './varejo/cad-saida-nf/cad-saida-nf.component';
import { CadDetalheComponent } from './cadastrobase/cad-detalhe/cad-detalhe.component';
import { CadItensNfEntradaComponent } from './varejo/cad-entrada-nf/cad-itens-nf-entrada/cad-itens-nf-entrada.component';
import { CadProdutoImgsComponent } from './varejo/cad-produtos/cad-produto-imgs/cad-produto-imgs.component';
import { CadSaidaNfItensComponent } from './varejo/cad-saida-nf/cad-saida-nf-itens/cad-saida-nf-itens.component';
import { MenuEstoqueCadastrosVarejoComponent } from './varejo/menu-estoque-varejo/menu-estoque-cadastros-varejo/menu-estoque-cadastros-varejo.component';
import { MenuEstoqueClassificacaoVarejoComponent } from './varejo/menu-estoque-varejo/menu-estoque-classificacao-varejo/menu-estoque-classificacao-varejo.component';
import { CadMovFinancComponent } from './varejo/cad-mov-financ/cad-mov-financ.component';
import { CadContasReceberComponent } from './varejo/cad-contas-receber/cad-contas-receber.component';
import { CadContasPagarComponent } from './varejo/cad-contas-pagar/cad-contas-pagar.component';
import { CadContasReceberLctosComponent } from './varejo/cad-contas-receber/cad-contas-receber-lctos/cad-contas-receber-lctos.component';
import { ConsultabaseFiltrosComponent } from './consultabase/consultabase-filtros/consultabase-filtros.component';
import { CadContasPagarLctosComponent } from './varejo/cad-contas-pagar/cad-contas-pagar-lctos/cad-contas-pagar-lctos.component';
import { CadParcelasCpNfEntradaComponent } from './varejo/cad-entrada-nf/cad-parcelas-cp-nf-entrada/cad-parcelas-cp-nf-entrada.component';
import { CadEntradaNfCadComponent } from './varejo/cad-entrada-nf/cad-entrada-nf-cad/cad-entrada-nf-cad.component';
import { CadSaidaNfCadComponent } from './varejo/cad-saida-nf/cad-saida-nf-cad/cad-saida-nf-cad.component';
import { CadParcelasCrSaidaNfComponent } from './varejo/cad-saida-nf/cad-parcelas-cr-saida-nf/cad-parcelas-cr-saida-nf.component';
import { ResumoVarejoComponent } from './varejo/resumo-varejo/resumo-varejo.component';
import { CadProdutosGradeComponent } from './varejo/cad-produtos/cad-produtos-grade/cad-produtos-grade.component';
import { CadCoresComponent } from './varejo/cad-cores/cad-cores.component';
import { CadSubCategoriaComponent } from './varejo/cad-sub-categoria/cad-sub-categoria.component';
import { CadInventarioComponent } from './varejo/cad-inventario/cad-inventario.component';
import { CadCrdComponent } from './varejo/cad-crd/cad-crd.component';
import { CadConfigVarejoComponent } from './varejo/cad-config-varejo/cad-config-varejo.component';
import { CadItensPedidosComponent } from './varejo/cad-saida-nf/cad-itens-pedidos/cad-itens-pedidos.component';
import { ResumoFinanceiroComponent } from './varejo/resumo-varejo/resumo-financeiro/resumo-financeiro.component';
import { ResumoEstoqueComponent } from './varejo/resumo-varejo/resumo-estoque/resumo-estoque.component';
import { CadProdutosCadComponent } from './varejo/cad-produtos/cad-produtos-cad/cad-produtos-cad.component';

@NgModule({ 
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    UsuariosComponent,
    CadastrosComponent,
    EmpresasComponent,
    UhsComponent,
    DespesasfixasComponent,
    FormBaseComponent,
    ConsultabaseComponent,
    CadastrobaseComponent,
    PeriodoapuracaoComponent,
    LctogasComponent,
    LctoluzComponent,
    LctoaguaComponent,
    DespesasuhComponent,
    PeriodoapuracaolctosComponent,
    PeriodoapuracaolctosdespcondComponent,
    PeriodoapuracaolctosluzComponent,
    PeriodoapuracaolctosaguaComponent,
    PeriodoapuracaolctosgasComponent,
    PeriodoapuracaorelComponent,
    PeriodoapuracaorellctosComponent,
    SolicitacontatoComponent,
    AreacomumComponent,
    PaineluhComponent,
    PaineluhperiodosapuracaoComponent,
    PaineluhreservasacComponent,
    DatagridComponent,
    AcperiodosComponent,
    PaineluhreservasacdiaComponent,
    CadFuncionariosComponent,
    MenuCadastrosVarejoComponent,
    CadPessoasComponent,
    LookupComponent,
    CadUnmedidasComponent,
    CadMarcasComponent,
    CadLocalalmoxComponent,
    CadGruposprodutosComponent,
    CadProdutosComponent,
    MenuEstoqueVarejoComponent,
    MenuFinanceiroVarejoComponent,
    CadCategoriasComponent,
    CadFaixasEtariasComponent,
    CadEntradaNFComponent,
    CadSaidaNFComponent,
    CadDetalheComponent,
    CadItensNfEntradaComponent,
    CadProdutoImgsComponent,
    CadSaidaNfItensComponent,
    MenuEstoqueCadastrosVarejoComponent,
    MenuEstoqueClassificacaoVarejoComponent,
    CadMovFinancComponent,
    CadContasReceberComponent,
    CadContasPagarComponent,
    CadContasReceberLctosComponent,
    ConsultabaseFiltrosComponent,
    CadContasPagarLctosComponent,
    CadParcelasCpNfEntradaComponent,
    CadEntradaNfCadComponent,
    CadSaidaNfCadComponent,
    CadParcelasCrSaidaNfComponent,
    ResumoVarejoComponent,
    CadProdutosGradeComponent,
    CadCoresComponent,
    CadSubCategoriaComponent,
    CadInventarioComponent,
    CadCrdComponent,
    CadConfigVarejoComponent,
    CadItensPedidosComponent,
    ResumoFinanceiroComponent,
    ResumoEstoqueComponent,
    CadProdutosCadComponent,
    GeralServiceComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [AuthService, AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
