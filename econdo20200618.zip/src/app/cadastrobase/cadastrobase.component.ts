import { GeralServiceComponent } from './../geral-service/geral-service.component';
import { Component, OnInit, HostBinding, Input, Output, EventEmitter, ElementRef, ChangeDetectorRef, Injector, ReflectiveInjector, Injectable } from '@angular/core';
import * as moment from 'moment';

@Component({
  selector: 'app-cadastrobase',
  templateUrl: './cadastrobase.component.html',
  styleUrls: ['./cadastrobase.component.css']
})
export class CadastrobaseComponent implements OnInit {

  @HostBinding('class.desc-Cons')
  @Input() descCons: any[];
  @Input() descTabsCad: any[];
  @HostBinding('class.activeRecord')
  @Input() activeRecord: any[];
  @Output() callbackPost = new EventEmitter();
  @Output() callbackCancel = new EventEmitter();
  @Output() callbackSelectChanged = new EventEmitter();
  @Output() callbackButton = new EventEmitter();
  tabSelected = "Geral";
  CadLookup = null;
  DescLookupAtivo = null;
  actionGS = {"filtro":"0", "rec": null};
  myInjector: Injector;
 
  campoBoolean = [{"desc": "Sim", "valor": "s"},
                  {"desc": "Não", "valor": "n"}];  

  constructor(public GS: GeralServiceComponent) { }

  ngOnInit() {
    this.selectionaTabCad("Geral");
    this.GS.execEventEmitter.subscribe(actionRecGS => {
      this.actionGS = actionRecGS;
      this.execActionGS();
    });    
  }

  execActionGS(){
    if (this.actionGS.filtro == "1"){ // retorno do lookup
      if (this.DescLookupAtivo != null){
        if (this.actionGS.rec.codlookup > -1) {
          let AVal = this.getFormattedValue(this.DescLookupAtivo, this.actionGS.rec.codlookup);
          if (AVal == this.actionGS.rec.codlookup) {
            this.DescLookupAtivo.LookupNameValues.push({"codigo": this.actionGS.rec.codlookup, "descricao": this.actionGS.rec.desclookup});
          }
          this.activeRecord[this.DescLookupAtivo.nomecampo] = this.actionGS.rec.codlookup;
        }
        this.showHideLookup(this.DescLookupAtivo);
      }
    }
  }

  onSelectChanged(desc, _AEvent){
    //alert(desc.nomecampo + ":" + _AEvent.target.value);
    if (desc.nomecampo != null)
      this.callbackSelectChanged.emit({"campo": desc.nomecampo, "valor": _AEvent.target.value});
    else
      this.callbackSelectChanged.emit({"campo": desc, "valor": _AEvent.target.value});
  }

  getCampoEhLookup(_ADesc){
    return (_ADesc.lookupappname != null);    
  }

  showHideLookup(_ADesc){
    _ADesc.showinglkp = !_ADesc.showinglkp;
    if (!_ADesc.showinglkp) {
      this.CadLookup = null;
      this.DescLookupAtivo = null;
    }
    else if (_ADesc.showinglkp){
      this.DescLookupAtivo = _ADesc;
      this.GS.openingLookup = true;

      this.CadLookup = _ADesc.CadLookup;
    }
  }

  callbackLookup(_ARet){
  }

  getMostrarCampoNestaTab(desc){
    let AResult = (this.tabSelected=="Geral" && 
                    desc.mostrarCad) ||
                    (desc.descTabCad==this.tabSelected && 
                      desc.mostrarCad)  ;
/*    let AResult = (this.tabSelected=="Geral" && 
                    desc.mostrarCad) ||
                  (descTab.descTabCad==this.tabSelected && 
                    descTab.descTabCad == desc.descTabCad && 
                    desc.mostrarCad);*/
    return AResult;
  }

  getRecFieldsCad(){
    let ARecs = [];
    this.descCons.forEach(rec => {
      if (this.getMostrarCampoNestaTab(rec))
        ARecs.push(rec);
    });
    return ARecs;
  }

  getLookupNameValues(_AFieldName){
    let ARet = {};
    for (let desc of this.descCons){
      if (desc.nomecampo === _AFieldName){
        ARet = desc.LookupNameValues;
        break;
      } 
    }
    return ARet;
  }

  getFormattedValue(desc, _AValue){
    let AValue = _AValue;
    if (desc.inputtype == "date")
    {
      AValue = moment(_AValue).format("DD/MM/YYYY");
    }
    else if (desc.ehlookup) {
      for (let namevalue of desc.LookupNameValues){
        if (namevalue.codigo == _AValue){
          AValue = namevalue.descricao;
          break;
        } 
      }
    }
    else if (desc.type == "float")
    {
      AValue = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(AValue);
      // Outra forma é usar o currenciPipe;
    }
    else  
      AValue = _AValue;
    return AValue; 
  }

  getEhCampoColor(_ADesc){
    return _ADesc.type == "color";
  }
  getEhBoolean(_ABool){
    return _ABool;
  }

  getEhLookup(_ABool){
    return _ABool;
  }

  chamaCallBackButton(_ARet: any){
    if (_ARet.btnText === "post_rec"){
      this.callbackPost.emit();
    }
    else {
      this.callbackButton.emit(_ARet);
    }
  }

  buttonEvent(_ABtn, rec: []) {
    this.chamaCallBackButton({btnText: _ABtn.target.outerText, record: rec});
  }  

  atualizarLookupByDesc(_ADesc) {
    this.chamaCallBackButton({btnText: "update_lookup", record: _ADesc});
  }
  salvarRegistroMesmaAba() {
    this.chamaCallBackButton({btnText: "post_stay_rec", record: []});
  }
  salvarRegistro() {
    this.chamaCallBackButton({btnText: "post_rec", record: []});
  }
  cancelarEdicao() {
    this.callbackCancel.emit();
  }

  selectionaTabCad(_ADivName: string) {
    this.tabSelected = _ADivName;
  /*  for(var i=0; i<this.descTabsCad.length; i++){
      if (document.getElementById(this.descTabsCad[i].descTabCad) != null){
        document.getElementById(this.descTabsCad[i].descTabCad).style.display = "none";
      }
    }
    if (document.getElementById(_ADivName) != null){
      document.getElementById(_ADivName).style.display = "block";
    }*/
  }

}
