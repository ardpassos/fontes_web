import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CadDetalheComponent } from './cad-detalhe.component';

describe('CadDetalheComponent', () => {
  let component: CadDetalheComponent;
  let fixture: ComponentFixture<CadDetalheComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CadDetalheComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CadDetalheComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
