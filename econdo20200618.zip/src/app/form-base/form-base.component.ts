import { GeralServiceComponent } from './../geral-service/geral-service.component';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from './../login/auth.service';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Component, OnInit, Input, Output, EventEmitter, Injectable } from '@angular/core';
import { FormGroup } from '@angular/forms';
import * as moment from 'moment';

@Component({
  selector: 'app-form-base',
  template: '<div></div>'
})
export class FormBaseComponent implements OnInit {

  public urlServer: string = "/demo/cad.php?-2=passos_teste";//&cad=-1&act=c
  public cadID: number = -1;
  public cadIDLookup: number = -1;
  public LookupsCarregados: boolean = false;
  public cadIDLookup_Act: String = "l";
  public cadIDLookup_CampoRetorno: String = "";
  public DescricaoSuperiorTela: String = "Cadastro...";
  public cadInsUpd: string = "p";
  public cadAutoPost = false;
  manterNaAbaAtual = false;
  salvando_registro = false;
  codigoSalvando = "-1";
  excluindo_registro = false;
  codigoExcluindo = "-1";
  ehconsulta = true;
  ehcadastro = false;
  ehLookup = false;
  records: any = [];
  buttonsRecord: any = [];
  activeRecord: any;
  FiltrosCons: any = [];
  FiltrosConsLookup: any = [];
  recno: number = -1;
  ARec: any; 
  descConsGrid: any[] = [];
  descCons: any[] = [];
  descTabsCad: any[] = [];
  ASize: string;
  actionGS = {"filtro":"0", "rec": ""};

  formulario: FormGroup;

  constructor(public http: HttpClient, 
              public authService: AuthService, 
              public route: ActivatedRoute, 
              private router: Router, 
              public GS: GeralServiceComponent) {
    this.ehLookup = GS.openingLookup;
    GS.openingLookup = false;
    this.inicializaCad();
  }

  inicializaCad() { 
    this.insertButtonRec("Delete", "Excluir", "clear");
  }

  ngOnInit() {

  }

  getARValueFromName(_AName) {
    let AValue = this.activeRecord[_AName];
    if ((AValue === undefined) || (AValue === null))
      AValue = "";
    else
      AValue = AValue;
    return AValue;
  }
  getValueFromEditableComp(_AValue: String) {
    if (_AValue === undefined)
      return "";
    else
      return _AValue;
  }

  insertInDescCad(_ADesc: string) {
    for (var i = 0; i < this.descTabsCad.length; i++) {
      if (this.descTabsCad[i].descTabCad == _ADesc) {
        return;
      }
    }
    this.descTabsCad.push({ descTabCad: _ADesc });
  }

  setLookupNameValues(_ANomeCampo: String, _ALookupNameValues:any, _AReadOnly = false){
    for (let desc of this.descCons){
      if (desc.nomecampo == _ANomeCampo){
        desc.readonly = _AReadOnly;
        desc.ehlookup = true;
        desc.LookupNameValues = _ALookupNameValues;
        desc.CadIDLookup = this.cadIDLookup;
        desc.CadIDLookupAct = this.cadIDLookup_Act;
        desc.size = "s8";
      } 
    }
  }

  insertDescCons(_ANomeCampo: string, _ADescCampo: string, _AMostrarNaCons: boolean,
    _AType: string, _ADescTabCad: string = "Geral", _AMostrarCad: boolean = true,
    _AEhBoolean = false) {
    this.insertInDescCad(_ADescTabCad);
    this.ASize = "s4";
    if ((_AType == "number") || (_AType == "float") || (_AType == "time") || (_AType == "date"))
      this.ASize = "s2";

    let AInputType = _AType;
    if (_AType == "float") { 
      AInputType = "number";
    }
    else if (_AType == "img") { 
      AInputType = "file";
    }

    this.ARec = {
      nomecampo: _ANomeCampo.toLowerCase(),
      desccampo: _ADescCampo,
      mostrarcons: _AMostrarNaCons,
      inputtype: AInputType,
      size: this.ASize,
      descTabCad: _ADescTabCad,
      mostrarCad: _AMostrarCad,
      type: _AType,
      ehboolean: _AEhBoolean ,
      ehlookup: false,
      ehimg: _AType==="img",
      readonly: false,
      LookupNameValues: null, // {"desc": "Descrição", "valor": "1"}
      lookupappname: null,
      showinglkp: false,
      lookuphtml: "",
      CadLookup: null
    };

    this.descCons.push(this.ARec);
    if (_AMostrarNaCons)
      this.descConsGrid.push(this.ARec);
  }

  getDescFromdescCons(_ANomeCampo){
    let ARet = {};
    for (let desc of this.descCons){
      if (desc.nomecampo.match(_ANomeCampo) != null ){
        ARet = desc;
        break;
      } 
    }
    return ARet;
  }

  insertFiltroCons(_ANomeCampo: string, _AComp: string, _AValor: String, _ALkp: boolean=false, _AFiltroURL: boolean=false) {
    this.ARec = {
      nomecampo: _ANomeCampo.toLowerCase(),
      comp: _AComp,
      valor: _AValor,
      desc: this.getDescFromdescCons(_ANomeCampo),
      filtrourl: _AFiltroURL
    };

    if (_ALkp)
      this.FiltrosConsLookup.push(this.ARec);
    else
      this.FiltrosCons.push(this.ARec);
  }  

  limpaFiltros(){
    this.FiltrosConsLookup = [];
    this.FiltrosCons = [];
  }

  podeInserirBut(_ANomeBut: string, _ADescBut: string){
    let AResult = true;

    for (let but of this.buttonsRecord){
      if ((but.descbut === _ADescBut) ){
        AResult = false;
        break;
      } 
    }

    return AResult;
  }

  insertButtonRec(_ANomeBut: string, _ADescBut: string, _ATipo) {
    if (this.podeInserirBut(_ANomeBut, _ADescBut)){
      this.buttonsRecord.push({
        nomebut: _ANomeBut.toLowerCase(),
        descbut: _ADescBut,
        tipo: _ATipo
      });
    }
  }

  insertCampoLookup(_ANomeCampo: string, _AAppName: string, _ACadObj) {

    for (let campo of this.descCons){
      if (campo.nomecampo == _ANomeCampo){
        campo.lookupappname = _AAppName;
        campo.CadLookup = _ACadObj;
        break;
      }       
    }

  }


  getURLSistema(){
    if (this.authService.ehsistemavarejo)
      return "&sys=v";
    else
      return "&sys=c";
  }

  getURLServer() {
    return this.urlServer + this.getURLSistema() + "&cad=" + this.cadID;
  }
  getURLServerLookup() {
    return this.urlServer + this.getURLSistema() + "&cad=" + this.cadIDLookup;
  }

  getURLServerCons() {
    return this.getURLServer() + "&act=c&filtro=" + this.getFiltrosCons(false);
  }

  getURLServerConsLookupAct() {
    return "&act=" + this.cadIDLookup_Act;
  }

  getURLServerConsLookup() {
    return this.getURLServerLookup() + this.getURLServerConsLookupAct() + "&filtro=" + this.getFiltrosCons(true);
  }

  getAct() {
    return "&act=" + this.cadInsUpd;
  }

  getURLServerPost() {
    return this.getURLServer() + this.getAct();
  }

  getFieldKey(){
    return this.descCons[0].nomecampo;
  }
  getFieldDescLookup(){
    return this.descCons[1].nomecampo;
  }

  getURLServerDel() {
    return this.getURLServer() + this.getAct() + "&" + this.getFieldKey() + "=" + 
           this.getValueFromEditableComp(this.activeRecord[this.getFieldKey()]);
  }

  getURLServerPostAuto(){
    let AResult = "";
    for (var i = 0; i < this.descCons.length; i++) {
      AResult += "&" + this.descCons[i].nomecampo + "=" + this.getValueFromEditableComp(this.activeRecord[this.descCons[i].nomecampo]);
    }
    return this.getURLServer() + this.getAct() + AResult;
  }

  getFiltrosCons(_ALkp: boolean) {
    let AResult: String = "";
    let AFiltrosCons = [];
    if (_ALkp)
      AFiltrosCons = this.FiltrosConsLookup;
    else
      AFiltrosCons = this.FiltrosCons;
    for (let filtro of AFiltrosCons) {
      if (!filtro.filtrourl)
        AResult += filtro.nomecampo + "|" + filtro.comp + "|" + filtro.valor + "|[";
      else
        AResult += "&" + filtro.nomecampo + "=" + filtro.valor;
    }
    return AResult;
  }

//GetLookupData
  recebedadoslkp(_ADados: any[]) {
  }

  ExecConsLookup(_ACadIdLkp = -1, _AAct = "l", _ACampoRet = ""){
    if (_ACadIdLkp > -1)
      this.cadIDLookup = _ACadIdLkp;
    this.cadIDLookup_Act = _AAct;
    this.cadIDLookup_CampoRetorno = _ACampoRet;
    params: HttpParams;
    let params = new HttpParams();
    this.http.post<any[]>(this.getURLServerConsLookup(), { params }).
      subscribe(data => this.recebedadoslkp(data));
  }

  recebedados(_ADados: any[]) {
    this.records = _ADados;
  }

  AfterPostCad(){
    this.ExecCons();
  }

  recebedadosPost(_ADados: any[]) {
    if (this.manterNaAbaAtual) {
      this.activeRecord[this.getFieldKey()] = _ADados["chave"];
      let ARec = this.activeRecord;
      this.activeRecord = [];
      this.activeRecord = ARec;
      this.manterNaAbaAtual = false;
      this.cadInsUpd = "p";
    }
    else {
      this.AfterPostCad();
    }
    this.salvando_registro = false;
  }
 
  ExecCons() {
    params: HttpParams;
    let params = new HttpParams();
    //params = params.append('username', userName);
    this.http.post<any[]>(this.getURLServerCons(), { params }).
      subscribe(data => this.recebedados(data));
  }

  ExecPost() {
    params: HttpParams;
    let params = new HttpParams();
    //params = params.append('username', userName);
    let AURL = "";
    if (this.cadAutoPost)
      AURL = this.getURLServerPostAuto();
    else
      AURL = this.getURLServerPost();

    this.codigoSalvando = this.activeRecord[this.getFieldKey()];
    this.salvando_registro = true;
    this.http.post<any[]>(AURL, { params }).
      subscribe(data => this.recebedadosPost(data));
  }

  AfterDelCad(){
    this.ExecCons();
  }
  recebedadosDel(_ADados: any[]) {
    this.excluindo_registro = false;
    this.AfterDelCad();
  }  
  ExecDel() {
    params: HttpParams;
    let params = new HttpParams();
    let AURL = this.getURLServerDel();
    this.http.post<any[]>(AURL, { params }).
      subscribe(data => this.recebedadosDel(data));
  }
  
  disableConsAndCad(){
    this.ehconsulta = false;
    this.ehcadastro = false;
  }

  novoRec(rec: any) {
    this.cadInsUpd = "i";
    this.activeRecord = rec;
    this.AfterInsert();
    //this.recno = index;
    this.ehconsulta = false;
    this.ehcadastro = true;
  }
  editarRecAtual(rec: any) {
    this.cadInsUpd = "p";
    this.activeRecord = rec;
    //this.recno = index;
    this.ehconsulta = false;
    this.ehcadastro = true;
  }

  editarregistro(rec: any) {
    if (rec.length == 0)
      this.novoRec(rec);
    else
      this.editarRecAtual(rec);
    this.afterEdit();
  }

  chamaCallBackLookup(_ARet: any){
    let action = {"filtro":"1", "rec": _ARet};
    this.GS.execute(action);
  }

  buttonevent(_ARet: any) {
    if (_ARet.btnText === "refresh") {
      this.ExecCons();
    }    
    else if (_ARet.btnText === "clear"){
      if (_ARet.record != null)
        this.activeRecord = _ARet.record;
      this.excluirregistro();
      this.ExecCons();
    } 
    else if (_ARet.btnText === "post_stay_rec"){
      this.manterNaAbaAtual = true;
      this.ExecPost();
    } 
    else if ((_ARet.btnText === "return_lkp") && (this.ehLookup)) {
      this.chamaCallBackLookup({btnText: "return_lkp", 
                                codlookup: _ARet.record[this.getFieldKey()] ,
                                desclookup: _ARet.record[this.getFieldDescLookup()],
                                record: _ARet.record});
    }
    else if (_ARet.btnText === "update_lookup"){
      this.ExecConsLookup(_ARet.record.CadIDLookup, _ARet.record.CadIDLookupAct, _ARet.record.nomecampo);
    } 
  }

  afterEdit(){

  }

  AfterInsert(){

  }

  voltarTelaConsulta(){
    this.ehconsulta = true;
    this.ehcadastro = false;
  }

  AfterPostEnableDisableScreen(){
    this.voltarTelaConsulta();
  }

  salvarregistro() {
    this.ExecPost();
    this.AfterPostEnableDisableScreen();
  }

  excluirRegistroByRec(rec) {
    this.activeRecord = rec;
    this.excluirregistro();
  }
  
  excluirregistro() {
    this.codigoExcluindo = this.activeRecord[this.getFieldKey()];
    this.excluindo_registro = true;
    this.cadInsUpd = "d";
    this.ExecDel();
    this.voltarTelaConsulta();
  }

  cancelarEdicao() {
    this.voltarTelaConsulta();
    this.ExecCons();
  }

  getExcluindo(_ARec){
    let ARet = this.excluindo_registro && (this.codigoExcluindo == _ARec[this.getFieldKey()]); 
    return ARet;
  }

  getSalvando(_ARec){
    let ARet = this.salvando_registro && (this.codigoSalvando == _ARec[this.getFieldKey()]); 
    return ARet;
  }

  public getDataAtual(_AFormat: string = "", _ADiaFixo = 0) {
    let date = new Date();
    let ano = date.getFullYear();
    let mes = date.getMonth()+1;
    let dia = date.getDate();
    if (_ADiaFixo > 0)
      dia = _ADiaFixo;
    let mesValor = ((mes < 10) ? '0' : '').concat(mes.toString());
    let diaValor = ((dia < 10) ? '0' : '').concat(dia.toString());

    if (_AFormat === "ddmmyyyy")
      return diaValor.toString().concat('/').concat(mesValor).concat('/').concat(ano.toString());
    else
      return ano.toString().concat('-').concat(mesValor).concat('-').concat(diaValor);
  }
  
  getFormattedValue(desc, _AValue){
    let AValue = _AValue;
    if (desc.inputtype == "date")
    {
      AValue = moment(_AValue).format("DD/MM/YYYY");
    }
    else if (desc.ehlookup) {
      for (let namevalue of desc.LookupNameValues){
        if (namevalue.codigo.match(_AValue) != null ){
          AValue = namevalue.descricao;
          break;
        } 
      }
    }
    else if (desc.type == "float")
    {
      AValue = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(AValue);
      // Outra forma é usar o currenciPipe;
    }
    else  
      AValue = _AValue;
    return AValue;
  }

  routerLinkTo(_ARouterLink){
    this.router.navigate([_ARouterLink]);
  }
}
