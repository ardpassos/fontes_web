import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GeralServiceComponent } from './geral-service.component';

describe('GeralServiceComponent', () => {
  let component: GeralServiceComponent;
  let fixture: ComponentFixture<GeralServiceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GeralServiceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GeralServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
