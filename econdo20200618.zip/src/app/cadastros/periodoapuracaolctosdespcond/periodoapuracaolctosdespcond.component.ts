import { PeriodoapuracaolctosComponent } from '../periodoapuracaolctos/periodoapuracaolctos.component';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-periodoapuracaolctosdespcond',
  templateUrl: './periodoapuracaolctosdespcond.component.html',
  styleUrls: ['./periodoapuracaolctosdespcond.component.css']
})
export class PeriodoapuracaolctosdespcondComponent extends PeriodoapuracaolctosComponent implements OnInit {

  @Input() uhs: any = [];

/*  <option value="rec[desc.nomecampo]" selected disabled hidden>{{getUHValue(rec[desc.nomecampo])}}</option>
  getUHValue(_ACodUH) {
    let _AResult = "";
    for (let uh of this.uhs) {
      if (uh.coduh === _ACodUH)
        _AResult = uh.descuh;
    }
    return _AResult;
  }
*/
  getShowSelectField(_AFieldName: string){
    return _AFieldName === "coduh";
  }

  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "Lançamento de Despesas por UH";
    this.cadID = 14;
    this.recno = 0;
    this.insertDescCons("CodDespesauh", "Cód. Despesa", false, "number");
    this.insertDescCons("codemp", "Cód. Empresa", false, "number");
    this.insertDescCons("CodPeriodo", "Cód. Período", false, "number");
    this.insertDescCons("DataLcto", "Data Lcto", false, "date");
    this.insertDescCons("CodUH", "Cód. UH", true, "number");
    this.insertDescCons("DescricaoDespesa", "Descrição", true, "text");
    this.insertDescCons("DataDespesa", "Data Despesa", true, "date");
    this.insertDescCons("Valor", "Valor", true, "number");
  }

  getURLServerPost() {
    return super.getURLServerPost() +
      "&coddespesauh=" + this.activeRecord.coddespesauh +
      "&codemp=" + this.recordmaster.codemp +
      "&codperiodo=" + this.recordmaster.codperiodo +
      "&datalcto=" +
      "&coduh=" + this.activeRecord.coduh +
      "&descricaodespesa=" + this.activeRecord.descricaodespesa +
      "&datadespesa=" + this.activeRecord.datadespesa +
      "&valor=" + this.activeRecord.valor;
  }

  getKeyValueActiveRecord() {
    return this.activeRecord.coddespesauh;
  }

  AfterInsert(){
    this.activeRecord.datadespesa = this.getDataAtual();
  }

  ngOnInit() {
    this.insertFiltroCons("codemp", "=", this.recordmaster.codemp);
    this.insertFiltroCons("codperiodo", "=", this.recordmaster.codperiodo);
    this.ExecCons();
  }
}
