import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PeriodoapuracaolctosdespcondComponent } from './periodoapuracaolctosdespcond.component';

describe('PeriodoapuracaolctosdespcondComponent', () => {
  let component: PeriodoapuracaolctosdespcondComponent;
  let fixture: ComponentFixture<PeriodoapuracaolctosdespcondComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PeriodoapuracaolctosdespcondComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PeriodoapuracaolctosdespcondComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
