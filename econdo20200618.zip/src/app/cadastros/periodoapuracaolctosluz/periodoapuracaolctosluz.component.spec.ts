import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PeriodoapuracaolctosluzComponent } from './periodoapuracaolctosluz.component';

describe('PeriodoapuracaolctosluzComponent', () => {
  let component: PeriodoapuracaolctosluzComponent;
  let fixture: ComponentFixture<PeriodoapuracaolctosluzComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PeriodoapuracaolctosluzComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PeriodoapuracaolctosluzComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
