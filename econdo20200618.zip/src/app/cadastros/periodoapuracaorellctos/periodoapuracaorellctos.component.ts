import { FormBaseComponent } from './../../form-base/form-base.component';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-periodoapuracaorellctos',
  templateUrl: './periodoapuracaorellctos.component.html',
  styleUrls: ['./periodoapuracaorellctos.component.css']
})
export class PeriodoapuracaorellctosComponent extends FormBaseComponent implements OnInit {

  @Input() recordmaster: any;
  @Input() coduh: any;
  dataatual: any;
 
  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "";
    this.cadID = 1060;
    this.recno = 0;
  }
  
  ngOnInit() {
    this.insertFiltroCons("conspart", "=", "1063", false, true);
    this.insertFiltroCons("codemp", "=", this.recordmaster.codemp, false, true);
    this.insertFiltroCons("codperiodo", "=", this.recordmaster.codperiodo, false, true);
    this.insertFiltroCons("coduh", "=", this.coduh, false, true);
    this.dataatual = this.getDataAtual("ddmmyyyy");
    this.ExecCons();
  }

}
