import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UhsComponent } from './uhs.component';

describe('UhsComponent', () => {
  let component: UhsComponent;
  let fixture: ComponentFixture<UhsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UhsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UhsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
