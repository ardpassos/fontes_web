import { HttpClient } from '@angular/common/http';
import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-despesasuh',
  templateUrl: './despesasuh.component.html',
  styleUrls: ['./despesasuh.component.css']
})
export class DespesasuhComponent extends FormBaseComponent implements OnInit {

  ngOnInit() {

  }

  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "Lançamento de Despesas por UH";
    this.cadID = 14;
    this.recno = 0;
    this.insertDescCons("CodDespesa", "Cód. Despesa", true, "number");
    this.insertDescCons("codemp", "Cód. Empresa", true, "number");
    this.insertDescCons("CodPeriodo", "Cód. Período", true, "number");
    this.insertDescCons("DataLcto", "Data Lcto", false, "date");
    this.insertDescCons("CodUH", "Cód. UH", false, "number");
    this.insertDescCons("DescricaoDespesa", "Descrição", false, "text");
    this.insertDescCons("DataDespesa", "Data Despesa", false, "date");
    this.insertDescCons("Valor", "Valor", true, "number");
  }  

}
