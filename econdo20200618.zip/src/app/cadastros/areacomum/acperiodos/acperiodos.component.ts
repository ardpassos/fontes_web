import { PeriodoapuracaolctosComponent } from './../../periodoapuracaolctos/periodoapuracaolctos.component';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-acperiodos',
  templateUrl: './acperiodos.component.html',
  styleUrls: ['./acperiodos.component.css']
})
export class AcperiodosComponent extends PeriodoapuracaolctosComponent implements OnInit {

  getShowSelectField(_AFieldName: string){
  }
  
  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "Perídos que serão possíveis reservar a área comum";
    this.cadID = 22;
    this.recno = 0;
    this.insertDescCons("codacperiodo", "Cód. AC Período", false, "number");
    this.insertDescCons("codac", "Cód. AC", false, "number");
    this.insertDescCons("descricao", "Descrição", true, "text");
    this.insertDescCons("horaini", "Hora inicial", true, "time");
    this.insertDescCons("horafim", "Hora final", true, "time");
    this.insertDescCons("valorreserva", "Valor da reserva", false, "number");
  }  
  
  getURLServerPost() {
    return super.getURLServerPost() +
      "&codacperiodo=" + this.getValueFromEditableComp(this.activeRecord.codacperiodo) +
      "&codac=" + this.getValueFromEditableComp(this.recordmaster.codac) +
      "&descricao=" + this.getValueFromEditableComp(this.activeRecord.descricao) +
      "&horaini=" + this.getValueFromEditableComp(this.activeRecord.horaini) +
      "&horafim=" + this.getValueFromEditableComp(this.activeRecord.horafim) +
      "&valorreserva=" + this.getValueFromEditableComp(this.activeRecord.valorreserva);
  }

  AfterInsert(){
    this.activeRecord.valorreserva = 0;
  }

  getKeyValueActiveRecord(){
    return this.activeRecord.codacperiodo;
  }

  ngOnInit() {
    this.insertFiltroCons("codac", "=", this.recordmaster.codac);
    this.ExecCons();
  }  
}
