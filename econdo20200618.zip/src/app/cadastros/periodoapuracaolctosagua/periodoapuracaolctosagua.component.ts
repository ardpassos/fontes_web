import { PeriodoapuracaolctosComponent } from '../periodoapuracaolctos/periodoapuracaolctos.component';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-periodoapuracaolctosagua',
  templateUrl: './periodoapuracaolctosagua.component.html',
  styleUrls: ['./periodoapuracaolctosagua.component.css']
})
export class PeriodoapuracaolctosaguaComponent extends PeriodoapuracaolctosComponent implements OnInit {

  @Input() uhs: any = [];

  getShowSelectField(_AFieldName: string){
    return _AFieldName === "coduh";
  }
  
  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "Lançamentos das leituras - água";
    this.cadID = 13;
    this.recno = 0;
    this.insertDescCons("CodLctoAgua", "Cód. Lcto Água", false, "number");
    this.insertDescCons("codemp", "Cód. Empresa", false, "number");
    this.insertDescCons("CodPeriodo", "Cód. Período", false, "number");
    this.insertDescCons("DataLeitura", "Data Leitura", true, "date");
    this.insertDescCons("CodUH", "Cód. UH", true, "number");
    this.insertDescCons("ValorLeitura", "Valor Leitura", true, "number");
    this.insertDescCons("ValorUltimaLeitura", "Valor Última Leitura", false, "number");
  }  
  
  getURLServerPost() {
    return super.getURLServerPost() +
      "&codlctoagua=" + this.getValueFromEditableComp(this.activeRecord.codlctoagua) +
      "&codemp=" + this.getValueFromEditableComp(this.recordmaster.codemp) +
      "&codperiodo=" + this.getValueFromEditableComp(this.recordmaster.codperiodo) +
      "&dataleitura=" + this.getValueFromEditableComp(this.activeRecord.dataleitura) +
      "&coduh=" + this.getValueFromEditableComp(this.activeRecord.coduh) +
      "&valorleitura=" + this.getValueFromEditableComp(this.activeRecord.valorleitura) +
      "&valorultimaleitura=" + this.getValueFromEditableComp(this.activeRecord.valorultimaleitura);
  }

  getKeyValueActiveRecord(){
    return this.activeRecord.codlctoagua;
  }

  AfterInsert(){
    this.activeRecord.dataleitura = this.getDataAtual();
  }

  ngOnInit() {
    this.insertFiltroCons("codemp", "=", this.recordmaster.codemp);
    this.insertFiltroCons("codperiodo", "=", this.recordmaster.codperiodo);
    this.ExecCons();
  }  
}
