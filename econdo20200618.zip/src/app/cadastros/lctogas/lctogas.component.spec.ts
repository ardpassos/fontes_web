import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LctogasComponent } from './lctogas.component';

describe('LctogasComponent', () => {
  let component: LctogasComponent;
  let fixture: ComponentFixture<LctogasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LctogasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LctogasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
