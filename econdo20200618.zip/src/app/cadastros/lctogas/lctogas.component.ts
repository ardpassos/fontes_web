import { HttpClient } from '@angular/common/http';
import { FormBaseComponent } from './../../form-base/form-base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lctogas',
  templateUrl: './lctogas.component.html',
  styleUrls: ['./lctogas.component.css']
})
export class LctogasComponent extends FormBaseComponent implements OnInit {

  ngOnInit() {

  }

  inicializaCad() {
    super.inicializaCad();
    this.DescricaoSuperiorTela = "Lançamentos das leituras - gás";
    this.cadID = 11;
    this.recno = 0;
    this.insertDescCons("CodLctoGas", "Cód. Lcto Gás", true, "number");
    this.insertDescCons("codemp", "Cód. Empresa", true, "number");
    this.insertDescCons("CodPeriodo", "Cód. Período", true, "number");
    this.insertDescCons("DataLeitura", "Data Leitura", true, "date");
    this.insertDescCons("CodUH", "Cód. UH", false, "number");
    this.insertDescCons("ValorLeitura", "Valor Leitura", false, "number");
    this.insertDescCons("ValorUltimaLeitura", "Valor Última Leitura", false, "number");
  }  

}
