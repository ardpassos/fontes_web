<?php

class FieldDef {
    public $FieldName;
    public $FieldDesc;
    public $FieldType;
    public $FieldPrefix;
    public $FieldNameReplace;
}
