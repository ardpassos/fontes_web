<?php

class ConDB {
    private $conn;
    private $connEspelho;
    private $FStartDB = false;
    public $FUserConnected = false;
    public $producao = false;
    
    function UpdateDB() {
        
    }
    
    function setUTF8($_ACon){
        try {
        	$stmt = $_ACon->prepare("set names utf8");
            $stmt->execute();
        } catch (PDOException $e) {
            print $e->getMessage();
        }
    }
    
    
    function setSession($_ARec){
    	if ($_ARec != null) {
    		if (!isset($_SESSION)){
    			session_start();
    		}
    		$_SESSION['servidor_db'] = $_ARec["servidor_db"];
    		$_SESSION['nome_db'] = $_ARec["nome_db"];
    		$_SESSION['usuario_db'] = $_ARec["usuario_db"];
    		$_SESSION['senha_db'] = $_ARec["senha_db"];
    		$_SESSION['ehsistemavarejo'] = $_ARec["ehsistemavarejo"];
    		//-2=passos_teste&-3=4&sys=v&cad=23&act=c&filtro=    		echo $_SESSION['nome_db'];
    	}
    }    
    
    function setConSessionByCodEmp($_ACodEmp){
    	$ini = parse_ini_file('configpassos.ini', true);
    	$this->producao = $ini['conexao']['producao'] == 1;
    	
    	$server = $ini['conexao']['servidor'];
    	$db = $ini['conexao']['nomebanco'];
    	$user = $ini['conexao']['usuario']; //"root";
    	$senha = $ini['conexao']['senha']; //"root";
   		$url = "mysql:host=" . $server . ";dbname=" . $db; // "mysql:host=localhost;dbname=passos_teste";
   		try {
   			$GLOBALS["EXEC_CON"] = false;
   			$this->conn = new PDO($url, $user, $senha);
   			$this->conn->setAttribute(PDO::ATTR_AUTOCOMMIT,0);
   			
   			$this->UpdateDB();
   			$this->setUTF8($this->conn);
   			
   			$ASql = "Select te.* " .
     			"  from tabempresa te ".
     			" where te.codempresa = ". $_ACodEmp;
   			$AQuery = $this->conn->prepare( $ASql );
   			$AQuery->execute();
   			if ($row = $AQuery->fetch(PDO::FETCH_ASSOC)){
   				$this->setSession($row);
   			}
   			
   		} catch (Exception $e) {
   			echo $e->getMessage();
   		}
   		$this->FStartDB = true;
    }
    
    // ir� conectar inicialmente com base no configpassos.ini
    // ao efetuar o login via cadLogin.php, ir� configurar o session para os dados de conex�o, caso tenha um servidor com base configurado
    // a partir da�, todas as conex�es ser�o embasadas no session
    function startDB() {
        if (!$this->FStartDB) {
            $ini = parse_ini_file('configpassos.ini', true);
            $this->producao = $ini['conexao']['producao'] == 1;
            
            $server = $ini['conexao']['servidor'];
            $db = $ini['conexao']['nomebanco'];
            $user = $ini['conexao']['usuario']; //"root";
            $senha = $ini['conexao']['senha']; //"root";
            if (!isset($_SESSION))
            	session_start();
           	
            if (!isset($_SESSION['usuario_db'])) {
            	if (isset($_GET["-3"])){ // codempresa
            		$this->setConSessionByCodEmp($_GET["-3"]);
            	}
            }            	
           	
           	if (isset($_SESSION['usuario_db'])) {
           		$server = $_SESSION['servidor_db'];
            	$db = $_SESSION['nome_db']; 
            	$user = $_SESSION['usuario_db']; 
            	$senha = $_SESSION['senha_db']; 
           	}
           	
            $url = "mysql:host=" . $server . ";dbname=" . $db; // "mysql:host=localhost;dbname=passos_teste";
            try {
            	$GLOBALS["EXEC_CON"] = false;
            	$this->conn = new PDO($url, $user, $senha);
                $this->conn->setAttribute(PDO::ATTR_AUTOCOMMIT,0);
                
                $this->UpdateDB();
                $this->setUTF8($this->conn);
                
                //if (!$ARemote)
                  
            } catch (Exception $e) {
                echo $e->getMessage();
            } 
            $this->FStartDB = true;
        }
        return $this->FStartDB;
    }
    
    function startDBEspelho(){
    	$ini = parse_ini_file('configpassos.ini', true);
    	
    	/*            $url = "mysql:host=localhost;dbname=id8202109_wp_e6d799528f216a95b17e3a886e298411";
    	 $user = "id8202109_wp_e6d799528f216a95b17e3a886e298411";
    	 $senha = "171717";
    	 */
    	// print_r($ini);
    	$url = "mysql:host=" . $ini['conexao']['servidor'] . ";dbname=" . $ini['conexao']['nomebanco_pay4me']; // "mysql:host=localhost;dbname=passos_teste";
    	$user = $ini['conexao']['usuario_pay4me']; //"root";
    	$senha = $ini['conexao']['senha_pay4me']; //"root";
    	
    	
    	/*            dbHost = getenv("OPENSHIFT_POSTGRESQL_DB_HOST");
    	 $ARemote = (dbHost != null);
    	 if (ARemote) {
    	 $user = "root";
    	 $senha = "root";
    	 $url = "jdbc:postgresql://" + dbHost + ":" + dbPort + "/hello";
    	 }*/
    	try {
    		$this->connEspelho = new PDO($url, $user, $senha);
    		$this->setUTF8($this->connEspelho);
    		
    	} catch (Exception $e) {
    		echo $e->getMessage();
    	}
    }
    
    
    function getConnected(){
        return $this->FStartDB;
    }
    
    function getCon(){
        return $this->conn;
    }
    
    function getConEspelho(){
    	return $this->connEspelho;
    }
    
    function ProcessToken(ConStm $ACon) {
        $AInd = $ACon->User->indexOf(".");
        if ($AInd > -1) {
            $ACon->PrefixoEmp = substr($ACon->User, AInd + 1);
            $ACon->User = substr($ACon->User, 0, AInd);
        }
    }
    
    function setToSchema($_ASchemaName){
        $ASql =  " SET search_path TO \"" . strtolower($_ASchemaName) . "\"";
        try {
            $stmt = $this->conn->prepare($ASql);
            $stmt->execute();
        } catch (PDOException $e) {
        }
    }
    
    function __construct(){
    }
    
    function StartDBs(){
    	$this->startDB();
    	$this->startDBEspelho();
    }
    
    
}