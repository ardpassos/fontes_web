<?php

class constCads {
    public const MAX_CONNECTIONS = 10;
    
    public const FILTER_SEP = "|";
    public const FIELD_INTEGER = 0;
    public const FIELD_STRING = 1;
    public const FIELD_DATE = 2;
    public const FIELD_FLOAT = 3;
    public const FIELD_TIME = 4;
    public const FIELD_DATE_TIME = 5;
    public const FIELD_BLOB = 6;
    
    public const ACTION = "act";
    public const ACTION_CONS = "c";
    public const ACTION_POST = "p";
    public const ACTION_INSERT = "i";
    public const ACTION_DEL  = "d";
    public const ACTION_LKP  = "l";
    public const ACTION_EST  = "e";
    
    public const REL_BASE_DIR_REMOTE = "/report/";
    public const REL_BASE_DIR_LOCAL  = "D:\\FontesJava\\hello\\src\\main\\webapp\\report\\";
    
    public const SISTEMA = "sys"; //c=Condom�nio ; v=Varejo
    public const SISTEMA_CONDOMINIO = "c"; //c=Condom�nio ; v=Varejo
    public const SISTEMA_VAREJO = "v"; //c=Condom�nio ; v=Varejo
    
    public const SCHEMA_NAME = "-2";
    public const CAD = "cad";
    public const CAD_RECREATE_DB = "100123";
    public const CAD_RECREATE_DB_VAREJO = "V100123";
    public const CAD_UPD_ESTRUTURA_DB = "2000";
    public const CAD_LOGIN = "-1";
    
    //SISTEMA DE CONDOM�NIOS
    public const CAD_FUNC = "1";
    public const CAD_TIPO_ANIMAIS = "2";
    public const CAD_FUNCAO_FUNC = "3";
    public const CAD_UF = "4";
    public const CAD_CIDADE = "5";
    public const CAD_GRUPO_EMPRESA = "6";
    public const CAD_EMPRESA = "7";
    public const CAD_UHS = "8";
    public const CAD_UHS_SEN_EMAIL = "8001";
    public const CAD_DESPFIXAS = "9";
    public const CAD_PERIODOAPURACAO = "10";
    public const CAD_LCTOGAS = "11";
    public const CAD_LCTOLUZ = "12";
    public const CAD_LCTOAGUA = "13";
    public const CAD_DESPESASUH = "14";
    public const ACTION_EMP_CRIASCHEMA = "7ecs";
    public const ACTION_EMP_DROPSCHEMA = "7eds";
    
    public const CAD_RACA = "8";
    public const CAD_COR = "9";
    public const CAD_ANIMAL = "10";
    public const ACTION_CONS_ANIMAL_ATIVO = "caa";
    public const CAD_AGENDA_INSEM = "11";
    public const CAD_ANIMAL_INSEM = "12";
    public const CAD_ANIMAL_INSEM_CONS_CT = "12ct";
    public const CAD_ANIMAL_INSEM_CONS_AD = "12cad";
    public const CAD_ANIMAL_INSEM_CONS_AI = "12cai";
    
    public const CAD_PC = "13";
    public const CAD_CReceber = "14";
    public const CAD_CPagar = "15";
    public const CAD_MF = "16";
    public const CAD_PESSOA = "17";
    public const CAD_RECURSO_AG = "18";
    public const CAD_AGENDA = "19";
    public const ACTION_AGENDA_CONS_PARAMS = "19cp";
    public const ACTION_AGENDA_CONS_LC = "19clc";
    
    public const CAD_SOLICITACONTATO = "20";
    public const CAD_AREACOMUM = "21";
    public const CAD_AC_PERIODOS = "22";
    public const CAD_RESERVAS_AC = "23";
    public const CAD_RESERVAS_AC_CONS_PADRAO = '2301';
    public const CAD_RESERVAS_AC_CONS_AREAS_COMUNS = '2302';
    public const CAD_RESERVAS_AC_CONS_RESERVAS_MES = '2303';
    
    public const ACTION_CRP_PGTO = "crppgto";
    public const CRP_TIPOPGTO_TOTAL = "T";
    public const CRP_TIPOPGTO_PARCIAL = "P";
    
    public const REL_ANIMAL_INSEM_AGENDADOS = "1000";
    public const REL_ANIMAL_INSEM_PARA_CONF = "1001";
    public const REL_ANIMAL_INSEM_PRENHA    = "1002";
    public const REL_SITUACAO_GERAL_FAZENDA = "1003";
    
    public const REL_COBRANCAS_CLIENTE = '1050';
    public const REL_LISTAGEM_PERIODO_APURACAO       = '1060';
    public const REL_LISTAGEM_PERIODO_APURACAO_UHS   = '1061';
    public const REL_LISTAGEM_PERIODO_APURACAO_LCTOS = '1062';
    public const REL_LISTAGEM_PERIODO_APURACAO_LCTOS_GERADOS = '1063';
    public const REL_LISTAGEM_PERIODO_APURACAO_EMAILS_CONDOMINOS = '1064';
    
    public const REL_PAINEL_UH_PERIODOS_APURACAO = '1070';
    
    public const ACTION_GET_COBRANCAS_FROM_CLI = '1050c';
    public const ACTION_GET_COBRANCAS_FROM_CLI_PDF = '1050pdf';
    public const STATUS_COB_ABERTO    = 1;
    public const STATUS_COB_ACORDADO  = 2;
    public const STATUS_COB_CANCELADO = 3;
    public const STATUS_COB_AGRUPADO  = 4;    
    
    public const COD_PRODUTO_FAZENDA = "01";
    public const COD_PRODUTO_SALAO_BELEZA = "02";
    public const COD_PRODUTO_CONSULTORIO = "03";
    
    
    
    //SISTEMA DE VAREJO
    
    public const CADV_FUNCIONARIOS = "1";
    public const CADV_PESSOAS = "2";    
    public const ACTION_PESSOAS_LKP_FORNECEDOR  = "lf";
    public const ACTION_PESSOAS_LKP_CLIENTE  = "lc";
    
    public const CADV_CIDADES = "3";
    public const CADV_UNMEDIDAS = "4";
    public const CADV_MARCAS = "5";
    public const CADV_LOCALALMOX = "6";
    public const CADV_GRUPOSPRODUTOS = "7";
    
    public const CADV_PRODUTOS = "8";
    public const ACTION_PROCUTOS_LKP_STATUS  = "lst";
    public const ACTION_PROCUTOS_LKP_GENERO  = "lgn";
    
    public const CADV_CATEGORIAS = "9";
    public const CADV_FAIXASETARIAS = "10";
    public const CADV_ENTRADANF = "11";
    public const CADV_SAIDANF = "12";    
    public const CADV_ENTRADANF_ITENS = "13";
    public const CADV_SAIDANF_ITENS = "14";
    
    public const ACTION_ENTRADANF_FINALIZANF  = "fnf";
    public const ACTION_ENTRADANF_REABRIRNF  = "rnf";
    public const ACTION_ENTRADANF_LKP_STATUSNF  = "lst";
    public const CADV_ENTRADANF_STATUS_ABERTA = "A";
    public const CADV_ENTRADANF_STATUS_FECHADA = "F";
    public const CADV_ENTRADANF_STATUS_CANCELADA = "C";
    
    public const ACTION_SAIDANF_GERACONDICIONAL  = "gc";
    public const ACTION_SAIDANF_FINALIZANF  = "fnf";
    public const ACTION_SAIDANF_REABRIRNF  = "rnf";
    public const ACTION_SAIDANF_LKP_STATUSNF  = "lst";
    public const ACTION_SAIDANF_LKP_TIPONF  = "ltnf";
    public const CADV_SAIDANF_STATUS_ABERTA = "A";
    public const CADV_SAIDANF_STATUS_FECHADA = "F";
    public const CADV_SAIDANF_STATUS_CANCELADA = "C";
    
    public const CADV_FINANC_STATUS_AVISTA = "V";
    public const CADV_FINANC_STATUS_APRAZO = "P";
    public const CADV_FINANC_STATUS_AVISTA_D = "A Vista";
    public const CADV_FINANC_STATUS_APRAZO_D = "A Prazo";
    
    public const ACTION_FINANC_LKP_TIPOPGTO  = "lpg";
    
    public const CADV_PRODUTOIMGS = "15";
    public const ACTION_PRODUTOIMGS_LKP_GET_IMG  = "get_img";

    public const CADV_MOVFINANC = "16";
    public const ACTION_MOVFINANC_LKP_ENTSAI  = "les";
    public const CADV_CONTASRECEBER = "17";
    public const ACTION_CONTASRECEBER_LIST_STATUS  = "ls";
    public const CADV_CONTASPAGAR = "18";
    public const ACTION_CONTASPAGAR_LIST_STATUS  = "ls";
    
    public const CADV_CONTASRECEBER_LCTOS = "19";
    public const ACTION_CONTASRECEBERLCTOS_LIST_TIPO  = "ls";
    public const ACTION_CONTASRECEBERLCTOS_BAIXA  = "eb"; // efetua baixa
    public const ACTION_CONTASRECEBERLCTOS_ESTORNO_BAIXA  = "ee"; // efetua estorno
    public const ACTION_CONTASRECEBERLCTOS_COMECAR_BAIXA  = "cb"; // efetua baixa
    //tipolcto = I=Iniciou baixa B=Baixado E=Estornado
    
    public const CADV_CONTASPAGAR_LCTOS = "20";
    public const ACTION_CONTASPAGARLCTOS_LIST_TIPO  = "ls";
    public const ACTION_CONTASPAGARLCTOS_BAIXA  = "eb"; // efetua baixa
    public const ACTION_CONTASPAGARLCTOS_ESTORNO_BAIXA  = "ee"; // efetua estorno
    public const ACTION_CONTASPAGARLCTOS_COMECAR_BAIXA  = "cb"; // efetua baixa
    //tipolcto = I=Iniciou baixa B=Baixado E=Estornado

    public const CADV_ENTRADANF_PARCELAS = "21";
    public const ACTION_ENTRADANF_PARCELAS_GERAR  = "gp";
    public const CADV_SAIDANF_PARCELAS = "22";
    public const ACTION_SAIDANF_PARCELAS_GERAR  = "gp";

    public const CADV_CONSPRODUTOS = "23";
    public const ACTION_CONSPRODUTOS_GETIMG  = "gi";
    public const CADV_CONSMENUFILTROS = "24";
    public const ACTION_CONSMENUFILTROS_GETCATEGORIAS  = "gc";
    public const ACTION_CONSMENUFILTROS_GETSUBCATEGORIAS  = "gsc";
    public const ACTION_CONSMENUFILTROS_GETCATEGPROMOCOESHOMEM  = "gcph";
    public const ACTION_CONSMENUFILTROS_GETCATEGPROMOCOESMULHER  = "gcpm";
    public const ACTION_CONSMENUFILTROS_GETCATEGHOMEM  = "gch";
    public const ACTION_CONSMENUFILTROS_GETCATEGMULHER  = "gcm";
    
    public const CADV_CADUSUARIO_VAREJO = "25";
    public const CADV_CADUSUARIO_VAREJO_LOGIN_SITE = "ls";
    public const CADV_CADUSUARIO_VAREJO_SESSION_LOGADO = "slg";
    public const CADV_CADUSUARIO_VAREJO_EXIT_SESSION_LOGADO = "eslg";
    public const CADV_CADUSUARIO_VAREJO_EXIT_SESSION_LOGADO_VENDEDOR = "eslgv";
    public const CADV_CADUSUARIO_VAREJO_USUARIOS_SITE = "lus";
    
    public const CADV_CADITENSCARRINHO = "26";
    public const CADV_CADITENSCARRINHO_DEL_CARRINHO = "dc";
    public const CADV_CADITENSCARRINHO_ADD_CARRINHO = "ac";
    public const CADV_CADITENSCARRINHO_CONS_RESUMO = "cr";
    public const CADV_CADITENSCARRINHO_GERAR_PEDIDO = "gp";

    
    public const CADV_RESUMO_VAREJO = "27";
    public const CADV_RESUMO_VAREJO_PEDIDOS = "cp";
    public const CADV_RESUMO_VAREJO_ITENS_PEDIDOS = "cip";
    public const CADV_RESUMO_VAREJO_CR_ATE_HOJE = "crh";
    public const CADV_RESUMO_VAREJO_CR_DIA = "crd";
    public const CADV_RESUMO_VAREJO_CP_ATE_HOJE = "cph";
    public const CADV_RESUMO_VAREJO_CP_DIA = "cpd";

    public const CADV_PRODUTOS_GRADE = "28";
    public const CADV_CORES = "29";
    public const CADV_SUBCATEGORIA = "30";
    public const CADV_INVENTARIO = "31";
    public const CADV_CRD = "32";
    public const ACTION_CRD_GETDEBCRED = "gdc";
    public const ACTION_CRD_GETDEBITOS = "gd";
    public const ACTION_CRD_GETCREDITOS = "gc";
    public const CADV_CONFIG_VAREJO = "33";
    public const CADV_CADUSUARIOEND_VAREJO = "34";
    
}
