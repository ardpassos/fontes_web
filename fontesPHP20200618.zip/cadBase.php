<?php
//LOCAL consultar
//http://localhost/demo/cad.php?-2=passos_teste&cad=1&act=c&filtro=
//consultar
//u495964352.hostingerapp.com/demo/cad.php?
//https://hotelariapassos.000webhostapp.com/demo/cad.php?-2=id8202109_wp_e6d799528f216a95b17e3a886e298411&cad=1&act=c&filtro=
//inserir
//u495964352.hostingerapp.com/demo/cad.php?-2=id8202109_wp_e6d799528f216a95b17e3a886e298411&cad=1&act=i&codfunc=&nomefunc=AlexPassos&cpf=&codfuncaoresp=&email=&username=passos&password=passos
//https://hotelariapassos.000webhostapp.com/demo/cad.php?-2=id8202109_wp_e6d799528f216a95b17e3a886e298411&cad=1&act=i&codfunc=&nomefunc=AlexPassos&cpf=&codfuncaoresp=&email=&username=passos&password=passos
//deletar
//u495964352.hostingerapp.com/demo/cad.php?
//https://hotelariapassos.000webhostapp.com/demo/cad.php?-2=passos_teste&cad=1&act=d&codfunc=4&nomefunc=AlexPassos&cpf=&codfuncaoresp=&email=&username=passos&password=passos
include("mensagemRetorno.php");

class cadBase {
    
	public $FConObj;
	public $FCon;
    public $FQuery;
    public $FSqlInitial = "";
    public $FOrderBy = "";
    public $FLimitInCons = " limit 50 ";
    public $FWhere = true;
    public $FLastMessage = "";
    public $Records = array();
    public $Fields = array();
    public $FieldsInsPost = array();
    
    function logMe($msg){
      error_log($msg);
    }

    function __construct(ConDB $_ACon) {
    	$this->FConObj = $_ACon;
    	$this->FCon = $this->FConObj->getCon();
    }
    
    function cadBase($_ACon){
        $this->FCon = _ACon;
    }
    
    function getCon(){
        return $this.FCon;
    }
    
    function getMsgReturnLastError($_AErrorCode=0){
    	$ObjRet = new MensagemRetorno();
    	$ObjRet->retorno = $_AErrorCode;
    	$ObjRet->mensagem = $this->getLastMessage();
    	return $this->getJSONMsgRetorno($ObjRet);
    }
    
    function getReturnOk(){
    	$ObjRet = new MensagemRetorno();
    	$ObjRet->setRetornoOK();
    	return $this->getJSONMsgRetorno($ObjRet);
    }
    function getReturnError($_AMsg){
    	$ObjRet = new MensagemRetorno();
    	$ObjRet->setRetornoErro($_AMsg);
    	return $this->getJSONMsgRetorno($ObjRet);
    }
    
    function AddFieldDef($_AFieldName, $_AFieldDesc, $_AFieldType, $_AFieldPrefix, $_AFieldNameReplace){
        $AField = new FieldDef();
        $AField->FieldName = strtolower($_AFieldName);
        $AField->FieldDesc = $_AFieldDesc;
        $AField->FieldType = $_AFieldType;
        $AField->FieldPrefix = strtolower($_AFieldPrefix);
        if ($AField->FieldPrefix != "")
            if (strpos($AField->FieldPrefix, ".") == -1)
                $AField->FieldPrefix += ".";
                $AField->FieldNameReplace = strtolower($_AFieldNameReplace);
                array_push($this->Fields, $AField);
    }
    
    function getFieldNameDefToCons($_AFieldName){
        $AResult = $_AFieldName;
        for ($i = 0; $i<count($this->Fields); $i++){
            
            $AFieldDef = $this->Fields[$i];
            if (strcasecmp($AFieldDef->FieldName, $_AFieldName) == 0){
            	if (strcasecmp($AFieldDef->FieldNameReplace, "") != 0)
          		  $AResult = $AFieldDef->FieldPrefix . "." . $AFieldDef->FieldNameReplace;
                    
                    if ($AFieldDef->FieldType == constCads::FIELD_STRING)
                        $AResult = "lower(" . $AResult . ")";
                        break;
            }
        }
        return $AResult;
    }
    
/* n�o precisa mais desta fun��o, pois o comparador ser� enviado do cliente   
 * function getFieldCompDefToCons($_AFieldName, $_AComp){
        $AResult = $_AComp;
        for ($i = 0; $i<count($this->Fields); $i++){
            $AFieldDef = $this->Fields[$i];
            if (strcasecmp($AFieldDef->FieldName, $_AFieldName) == 0){
                if (($AFieldDef->FieldType == constCads::FIELD_STRING) &&
                		($_AComp != "in") $$	
                		)
                    $AResult = "like";
                break;
            }
        }
        return $AResult;
    } */
    
    function getFieldValueDefToCons($_AFieldName, $_AValue, $_AComp){
        $AResult = $_AValue;
        for ($i = 0; $i<count($this->Fields); $i++){
            $AFieldDef = $this->Fields[$i];
            if (strcasecmp($AFieldDef->FieldName, $_AFieldName) == 0){
            	$this->logMe("Tipo: " . $AFieldDef->FieldType);
            	if ($AFieldDef->FieldType == constCads::FIELD_STRING){
            		if ($_AComp == "like"){
            			$AResult = "'%" . $AResult . "%'";
            		}
            		else if ($_AComp == "in"){
            			if ($_AValue != ""){
            				$AFirstChar = substr($_AValue, 1, 1);
            				if ($AFirstChar == "(") {
            					$AResult = $AResult; // n�o faz nada
            				}
            				else {
            					$AResult = "(" . $AResult . ")";
            				}            					
            			}
            			else {            				
            				$AResult = "'" . $AResult . "'";
            			}
            		}
            		else {
            			$AResult = "'" . $AResult . "'";
            		}
            	}
            	else if (($AFieldDef->FieldType == constCads::FIELD_DATE) ||
                        ($AFieldDef->FieldType == constCads::FIELD_DATE_TIME) ||
            			($AFieldDef->FieldType == constCads::FIELD_TIME)){
            				$AResult = "'" . $AResult . "'";
            	}
                break;
            }
        }
        return $AResult;
    }
    
    function getLastMessage(){
        return str_replace('"', '*', $this->FLastMessage);
    }
    
    function pgToClientStr(String $str){
        if ($str == null){
            return "";
        }
        else {
            return $str;
           /* Charset utf8_charset = Charset.forName("LATIN9");
            ByteBuffer outputBuffer = utf8charset.encode(str);
            byte[] outputData = outputBuffer.array();
            return new String(outputData);*/
        }
    }
    
    
    function getFieldString($_AField) {
        try {
            return pgToClientStr($this->FQuery->getString(_AField));
        }
        catch (Exception $e){
            return "";
        }
    }
    
    function getFieldInt($_AField) {
        try {
            return $this->$this->FQuery->getInt(_AField);
        }
        catch (Exception $e){
            return 0;
        }
    }
    
    function getFieldFloat($_AField) {
        try {
            return $this->FQuery->getFloat(_AField);
        }
        catch (Exception $e){
            return 0;
        }
    }
    
    function getFieldDate($_AField) {
        try {
            if ($this->FQuery->getTimestamp(_AField) == null){
                return "1899-12-30";
            }
            else
                return $this->FQuery->getDate(_AField).toString();
        }
        catch (Exception $e){
            return "1899-12-30";
        }
    }
    
    function getFieldTimeStamp($_AField) {
        try {
            if ($this->FQuery->getTimestamp(_AField) == null){
                return "1899-12-30 00:00:00";
            }
            else
                return $this->FQuery->getTimestamp(_AField).toString().replace(".0", "");
        }
        catch (Exception $e){
            return "1899-12-30 00:00:00";
        }
    }
    
    function clearRecords(){
        //unset($this->Records);
        //$this->Records = new array();
    }
    
    function getFieldsInsPostFieldNamesToIns(){
    	$AResult = "";
    	foreach ($this->FieldsInsPost as $rec) {
    		if ($rec["id"] > 0){
    			$AResult .= ", ";
    		}
    		$AResult .= $rec["campo"];	
    	}
    	return $AResult;
    }
    function getFieldsInsPostFieldValuesToIns(){
    	$AResult = "";
    	foreach ($this->FieldsInsPost as $rec) {
    		if ($rec["id"] > 0){
    			$AResult .= ", ";
    		}
    		$AResult .= $rec["valor"];
    	}
    	return $AResult;
    }
    
    function getFieldsInsPostFieldNameValuesToPost(){
    	$AResult = "";
    	foreach ($this->FieldsInsPost as $rec) {
    		if ($rec["id"] > 0){
    			$AResult .= ", ";
    		}
    		$AResult .= $rec["campo"] . " = " . $rec["valor"];
    	}
    	return $AResult;
    }
    
    function addInListFields($_AFieldName, $_AFieldValue, $_AType){
    	if ($_AType == "s"){
    		$_AFieldValue = "'".$_AFieldValue."'";
    	}
    	else if (($_AType == "d") || ($_AType == "dt")){
    		if (($_AFieldValue != 'current_date') && ($_AFieldValue != 'current_timestamp'))
    			$_AFieldValue = "'".$_AFieldValue."'";
    	}
    	$ANV = [];
    	$ANV["id"] = sizeof($this->FieldsInsPost);
    	$ANV["campo"] = $_AFieldName;
    	$ANV["valor"] = $_AFieldValue;
    	$ANV["tipo"] = $_AType;
    	array_push($this->FieldsInsPost, $ANV); 
    }
    
    function addInListFieldsFromParam($_AFieldName, $_AType){
    	$AFieldValue = "";
    	if (($_AType == "d") || ($_AType == "dt")){
    		$AFieldValue = $this->getParameterDateTime($_AFieldName);
    	}
    	else if ($_AType == "f"){
    		$AFieldValue = $this->getParameterFloat($_AFieldName);
    	}
    	else if ($_AType == "i"){
    		$AFieldValue = $this->getParameterInt($_AFieldName);
    	}
    	else {
    		$AFieldValue = $this->getParameter($_AFieldName);
    	}
    	$this->addInListFields($_AFieldName, $AFieldValue, $_AType);
    }
    
    function setParametersToFieldList(){
    }
    
    function AddRecord($_ARec){
       array_push($this->Records, $_ARec);
    }
    
    function getParameter($_APar){
    	$AResult = "";
    	if (isset( $_GET[strtolower($_APar)] ) ) {
    		$AResult = $_GET[strtolower($_APar)];
    	}
        if (($AResult == null) || ($AResult == "null"))
            $AResult = "";
        return $AResult;
    }
    
    function getParameterInt($_APar){
    	$AResult = trim($_GET[strtolower($_APar)]);
    	if ((strcmp($AResult, null)==0) || (strcmp($AResult, '') == 0))
    		$AResult = "0";
        return $AResult;
    }
    
    function getParameterDateTime($_APar){
    	$AResult = trim($_GET[strtolower($_APar)]);
    	
    	if ((strcmp($AResult, null)==0) || (strcmp($AResult, '') == 0) || (strcmp($AResult, 'null') == 0)){
    		$AResult = "1900-01-01";
    	}
    	return $AResult;
    }
    
    function getParameterFloat($_APar){
    	$AResult = trim($_GET[strtolower($_APar)]);
    	if ((strcmp($AResult, null)==0) || (strcmp($AResult, '') == 0))
    		$AResult = "0";
        return str_replace(",", ".", $AResult);
    }
    
    function getJSONRecords(){
    	$AResult = json_encode($this->Records, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE);
        return $AResult;
    }
    
    function getJSONMsgRetorno(MensagemRetorno $_AObjRetorno){
    	$AResult = "[{\"retorno\":". $_AObjRetorno->retorno ."," .
      				"\"chave\":". $_AObjRetorno->chave."," .
      			   "\"mensagem\":\"" . $_AObjRetorno->mensagem . "\"}]";
    	return $AResult;
    }
    
    function getJSONFromObj($_AObj){
        try {
        	$AStr = json_encode($_AObj, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        } catch (Exception $e) {
        	$this->logMe("erro json_encode: ".$e->getMessage());
        	echo $e->getMessage();
            if (json_last_error() != 0) {
                echo 'Erro!</br>';
                switch (json_last_error()) {

                    case JSON_ERROR_DEPTH:
                        echo ' - profundidade maxima excedida';
                        break;
                    case JSON_ERROR_STATE_MISMATCH:
                        echo ' - state mismatch';
                        break;
                    case JSON_ERROR_CTRL_CHAR:
                        echo ' - Caracter de controle encontrado';
                        break;
                    case JSON_ERROR_SYNTAX:
                        echo ' - Erro de sintaxe! String JSON mal-formada!';
                        break;
                    case JSON_ERROR_UTF8:
                        echo ' - Erro na codificação UTF-8';
                        break;
                    default:
                        echo '  Erro desconhecido';
                        break;
                }
            }
        }
        
        return $AStr;
    }
    
    function FillDataCons($_AQuery){
        try {
            $this->clearRecords();
            while ($row = $_AQuery->fetch(PDO::FETCH_ASSOC)) {
                $this->AddRecord($row);
            }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }
    
    function ehProducao(){
    	if ($this->FConObj != null){
    		return $this->FConObj->producao;
    	}
    	else  
    	  return true;
    }
    
    function OpenSQLCons($_ASql) {
        $AResult = false;
        try {
        	$this->logMe(strtolower($_ASql));
        	$this->FQuery = $this->FCon->prepare( strtolower($_ASql) );
        	
            $this->FQuery->execute();

            $this->FillDataCons($this->FQuery);
        } catch (Exception $e) {
            $AResult = false;
        }
        return $AResult;
    }
    
    function OpenSQLToResultSet($_ASql) {
        $AQuery;
        try {
        	$this->logMe("OpenSQLToResultSet: " . strtolower($_ASql));
        	$AQuery = $this->FCon->prepare( strtolower($_ASql) );
            $AQuery->execute();
        } catch (Exception $e) {
            $AQuery = null;
        }
        return $AQuery;
    }
    
    function logGlobalExec_Con($_ALocal){
  		$this->logMe($_ALocal);
    }
    
    function SetExecuting($AGUID) {
    	$ASql = "update tabexecuting set state=1, guid='".$AGUID."' where codexec=1 and guid=''";
    	$this->FCon->beginTransaction();
    	$ANum = $this->FCon->exec( $ASql );
    	$this->FCon->commit();
    	return $ANum > 0 ;
    }
    
    function SetNotExecuting() {
    	$ASql = "update tabexecuting set state=0, guid='' where codexec=1";
    	$this->FCon->beginTransaction();
    	$ANum = $this->FCon->exec($ASql);
    	$this->FCon->commit();
    	return $ANum > 0 ;
    }
    
    function GUIDv4 ($trim = true)
    {
    	$lbrace = chr(123);    // "{"
    	$rbrace = chr(125);    // "}"
    	
    	// Windows
    	if (function_exists('com_create_guid') === true)
    	{   // extension=php_com_dotnet.dll
    		if ($trim === true)
    		{
    			return trim(com_create_guid(), '{}');
    		}
    		else
    		{
    			return com_create_guid();
    		}
    	}
    	
    	
    	// OSX/Linux and Windows with OpenSSL but without com classes loaded (extension=php_com_dotnet.dll loaded in php.ini)
    	if (function_exists('openssl_random_pseudo_bytes') === true)
    	{
    		
    		$data = openssl_random_pseudo_bytes(16);
    		$data[6] = chr(ord($data[6]) & 0x0f | 0x40);    // set version to 0100
    		$data[8] = chr(ord($data[8]) & 0x3f | 0x80);    // set bits 6-7 to 10
    		if ($trim === true)
    		{
    			return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    		}
    		else
    		{
    			return $lbrace.vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4)).$rbrace;
    		}
    	}
    	
    	// Fallback (PHP 4.2+)
    	mt_srand((double)microtime() * 10000);
    	$charid = strtolower(md5(uniqid(rand(), true)));
    	$hyphen = chr(45);                  // "-"
    	$guidv4 = substr($charid,  0,  8).$hyphen.
    	substr($charid,  8,  4).$hyphen.
    	substr($charid, 12,  4).$hyphen.
    	substr($charid, 16,  4).$hyphen.
    	substr($charid, 20, 12);
    	
    	if ($trim === true)
    	{
    		return $guidv4;
    	}
    	else
    	{
    		return $lbrace.$guidv4.$rbrace;
    	} 
    }
    
    function bindParams($AQuery){
    	
    }
    
    function ExecSQL($_ASql, $_ABind=false) {
        $AResult = false;
        $AGUID = $this->GUIDv4();//com_create_guid();
        
        //$this->logGlobalExec_Con($_ASql);
        while (!$this->SetExecuting($AGUID) ){
        	sleep(0.050);}
        	
        $ACount = 0;
        $this->FCon->beginTransaction();
        try {
        	$this->logGlobalExec_Con("before prepare");
        	$AQuery = $this->FCon->prepare( $_ASql );

        	if ($_ABind){
	        	$this->logGlobalExec_Con("before bindparams");
	            $this->bindParams($AQuery);
	            $this->logGlobalExec_Con("after bindparams");
        	}
            while (($ACount < 5) && (!$AResult)){
              $AResult = $AQuery->execute();
              if (!$AResult){
              	$AErr = $AQuery->errorInfo();
              	$this->logGlobalExec_Con("erro ao executar :" . $AQuery->errorCode() . " - " . $AErr[2]);
              }
              	
              $this->logGlobalExec_Con("Tentativa: ".$ACount." : ".$_ASql);
              $this->logGlobalExec_Con("after execute");
              $ACount += 1;
            }
            $this->FCon->commit();
        } catch (Exception $e) {
        	$this->logMe($e->getMessage());
        	$this->FCon->rollBack();
        	$this->FLastMessage = $e->getMessage();
            $AResult = false;
        }
        !$this->SetNotExecuting();
        return $AResult;
    }
    
    function ExecSQLSimple($_ASql) {
    	$AResult = false;
   		try {
   			$AQuery = $this->FCon->prepare( $_ASql );
   			$AResult = $AQuery->execute();
   			if (!$AResult) {
   				$this->FLastMessage = "Erro ao executar sql ". $_ASql;
   				$this->logMe($this->FLastMessage);
   			}
   		} catch (Exception $e) {
   			$this->logMe($e.getMessage());
   			$this->FLastMessage = $e.getMessage();
   			$AResult = false;
   		}
   		return $AResult;
    }
    
    function getTabela(){
        return "";
    }
    
    function getCampoChave(){
        return "";
    }
    
    function FormatarFiltros($_AFiltro) {
        $AResult = "";
        $AFiltro = $_AFiltro;
        $ALine;
        $AField;
        $AComp;
        $AValue;
        
        while ($AFiltro != "") {            
            $APosLine = strpos($AFiltro, ";");
            
            if ($APosLine == -1) {
                $ALine = $AFiltro;
                $AFiltro = "";
            }
            else {
                $ALine = substr($AFiltro, 0, $APosLine);
                $AFiltro = substr($AFiltro, $APosLine+1);
            }
            
            $APos = strpos($ALine, constCads::FILTER_SEP);
            $AField = substr($ALine, 0, $APos);
            $ALine = substr($ALine, $APos+1);
            
            $APos = strpos($ALine, constCads::FILTER_SEP); 
            $AComp = substr($ALine, 0, $APos);
            $ALine = substr($ALine, $APos+1);
            
            $APos = strpos($ALine, constCads::FILTER_SEP);
            $AValue = substr($ALine, 0, $APos);
            $ALine = substr($ALine, $APos+1);
            
            $AFieldNew = $this->getFieldNameDefToCons($AField);
            //$AComp = $this->getFieldCompDefToCons($AField, $AComp);
            $AValue = $this->getFieldValueDefToCons($AField, $AValue, $AComp);
            
            if ($AResult != ""){
                $AResult = $AResult . " and ";
            }
            $AResult = $AResult . "(" . $AFieldNew . " " . $AComp . $AValue . " )";
        }
        
        return $AResult;
    }
    
    function getCons() {
    	if (isset($_GET["filtro"])){
          $AFiltro = $_GET["filtro"];
    	}else{
          $AFiltro = "";
    	}
    	$this->logMe( $AFiltro);
          
    	while (strpos($AFiltro, "[")){
            $AFiltro = str_replace("[", ";", $AFiltro);
    	}
        $AFiltro = $this->FormatarFiltros($AFiltro);
        if ($AFiltro != ""){
                if ($this->FWhere)
                    $AFiltro = " where " . $AFiltro;
                else
                    $AFiltro = " and " . $AFiltro;
        }
        $this->OpenSQLCons($this->FSqlInitial . " " .
                            $AFiltro . " " .
                            $this->FOrderBy . " " .
        					$this->FLimitInCons);
        
        $this->logMe( $this->getJSONRecords());
        return $this->getJSONRecords();
    }
    
    function getConsLkp() {
    	if (isset($_GET["filtro"]))
    		$AFiltro = $_GET["filtro"];
    		else
    			$AFiltro = "";
    			
    			while (strpos($AFiltro, "["))
    				$AFiltro = str_replace("[", ";", $AFiltro);
    				$AFiltro = $this->FormatarFiltros($AFiltro);
    				if ($AFiltro != "")
    					if ($this->FWhere)
    						$AFiltro = " where " . $AFiltro;
    						else
    							$AFiltro = " and " . $AFiltro;
    							$this->OpenSQLCons($this->FSqlInitial . " " .
    									$AFiltro .
    									$this->FOrderBy);
    							return $this->getJSONRecords();
    }
    
    function getPost(){
    	$ACod = $this->getParameterInt( $this->getCampoChave() );
    	$this->setParametersToFieldList();
    	
    	$ASql = "Update ".$this->getTabela() ." set " .
      	$this->getFieldsInsPostFieldNameValuesToPost() .
      			" where ".$this->getCampoChave()." = " . $ACod;
      	
      	$ObjRet = new MensagemRetorno();
      	if ($this->ExecSQL($ASql)) {
      		$ObjRet->retorno = 1;
      		$ObjRet->chave = $ACod;
      		$ObjRet->mensagem = "";
      	}
      	else {
      		$ObjRet->retorno = 0;
      		$ObjRet->chave = -1;
      		$ObjRet->mensagem = $this->getLastMessage();
      	}
      	return $this->getJSONFromObj($ObjRet);
      	
      	/*if ($this->ExecSQL($ASql))
      		return '[{"retorno":1, "chave":'. $ACod .'}]';
      	else
      		return '[{"retorno":0, "chave":'. $ACod . ','.
      				'"mensagem": "' . $this->getLastMessage() . '"}]';*/
    }
    
    function getInsert(){
    	return $this->getInsertStm(false);
    }
    
    function GetNewCod(){
    	$ASql = "Select Coalesce(Max(talias.". $this->getCampoChave() . "), 0) as codigo" .
      			"  from " . $this->getTabela() . " talias";
    	$AQuery = $this->OpenSQLToResultSet($ASql);
    	$row = $AQuery->fetch(PDO::FETCH_ASSOC);
    	return $row["codigo"] + 1;
    	
    }
    function getInsertStm($_AInTrans = false){
    	$this->logMe( "3");
    	$ANewCod = $this->GetNewCod();
    	//$this->addInListFields($this->getCampoChave(), "(" . $this->getFieldKeyMaxInSQL() . ")+1 ", "i");
    	$this->addInListFields($this->getCampoChave(), $ANewCod, "i");
    	$this->setParametersToFieldList();
    	
    	$ASql = "insert into ".$this->getTabela()." (" .
		      	$this->getFieldsInsPostFieldNamesToIns() .
		      	") Values (" .
		      	$this->getFieldsInsPostFieldValuesToIns() .
		      	")";
		$AExec = false;
		if ($_AInTrans) {
			$AExec = $this->ExecSQL($ASql);
		}
		else {
			$AExec = $this->ExecSQL($ASql);
		}
		$ObjRet = new MensagemRetorno();
		if ($AExec) {
			$ObjRet->retorno = $ANewCod;
			$ObjRet->chave = $ANewCod;
			$ObjRet->mensagem = "";
      	}
      	else {
      		$ObjRet->retorno = 0;
      		$ObjRet->chave = -1;
      		$ObjRet->mensagem = $this->getLastMessage();
      	}
      	return $this->getJSONFromObj($ObjRet);
      	
    }
    
    function keyExists($_ACod) {
    	$AResult = false;
    	try {
    		$AQuery = $this->OpenSQLToResultSet(strtolower("Select Count(*) as NumRec ".
    				"  from " . $this->getTabela() .
    				" where " . $this->getCampoChave() . " = " . $_ACod));
    		if ( $dados = $AQuery->fetch() ){
    			$AResult = ($dados["NumRec"] > 0);
    		}
    		else
    			$AResult = false;
    	}
    	catch (Exception $e) {
    		$AResult = false;
    	}
    	return $AResult;
    }
    
    function getFieldKeyMaxInSQL(){
    	$ASql = strtolower("Select Coalesce(Max(talias.". $this->getCampoChave() . "), 0)" .
    			           "  from " . $this->getTabela() . " talias");
    	return $ASql;
    }
    
    function getDel(){
        $ACodigo = $_GET[strtolower($this->getCampoChave())];
        $ASql = strtolower("Delete from " . $this->getTabela() .
                           " where " . $this->getCampoChave() . " = " . $ACodigo );
        
        $ObjRet = new MensagemRetorno();
        
        $AExec = $this->ExecSQL($ASql);
        if ($AExec) {
            $ObjRet->retorno = 1;
            $ObjRet->mensagem = "";
        }
        else {
            $ObjRet->retorno = 0;
            $ObjRet->mensagem = $this->getLastMessage();
        }
        return $this->getJSONMsgRetorno($ObjRet);
    }
    
    function process($_AAction){
        $AResult = "";
        if (strcasecmp($_AAction, constCads::ACTION_CONS) == 0) {
            $AResult = $this->getCons();
        }
        else if (strcasecmp($_AAction, constCads::ACTION_POST) == 0) {
            $AResult = $this->getPost();
        }
        else if (strcasecmp($_AAction, constCads::ACTION_INSERT) == 0) {
            $AResult = $this->getInsert();
        }
        else if (strcasecmp($_AAction, constCads::ACTION_DEL) == 0) {
            $AResult = $this->getDel();
        }
        else if (strcasecmp($_AAction, constCads::ACTION_LKP) == 0) {
        	$AResult = $this->getConsLkp();
        }
        return $AResult;
    }
    
    function truncate($val, $f="0")
    {
    	if(($p = strpos($val, '.')) !== false) {
    		$val = floatval(substr($val, 0, $p + 1 + $f));
    	}
    	return $val;
    }
}
