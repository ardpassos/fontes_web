<?php

class cadDespFixas extends cadBase {
	
	
	function getCampoChave(){
		return "CodDespesa";
	}
	
	function getCons() {
		$this->FSqlInitial = "Select * from tabDespFixas";
		$this->addFieldDef("CodEmp", "C�d. Empresa", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("CodDespesa", "C�d. Despesa", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("descricao", "Descri��o", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("ValorPadrao", "Valor Padr�o", constCads::FIELD_FLOAT, "", "");
		$this->addFieldDef("EhLuz", "� Luz", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("TipoRateioLuz", "Rateio Luz", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("EhAgua", "� �gua", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("TipoRateioAgua", "Rateio �gua", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("EhGas", "� G�s", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("TipoRateioGas", "Rateio G�s", constCads::FIELD_STRING, "", "");
		return parent::getCons();
	}
	
	function keyExists($_ACod) {
		$AResult = false;
		try {
			$AQuery = $this->OpenSQLToResultSet(strtolower("Select Count(*) as NumRec from TabDespFixas where CodDespesa = ") . $_ACod);
			if ( $dados = $AQuery->fetch() ){
				$AResult = ($dados["NumRec"] > 0);
			}
			else
				$AResult = false;
		}
		catch (Exception $e) {
			$AResult = false;
		}
		return $AResult;
	}
	
	function getPost(){
		$ACodEmp = $this->getParameter( "CodEmp");
		$ACodDespesa = $this->getParameter( "CodDespesa");
		$ADescricao = $this->getParameter( "Descricao");
		
		$AValorPadrao = $this->getParameter( "ValorPadrao");
		
		$AEhLuz = $this->getParameter( "EhLuz");
		$ATipoRateioLuz = $this->getParameter( "TipoRateioLuz");
		
		$AEhAgua = $this->getParameter( "EhAgua");
		$ATipoRateioAgua = $this->getParameter( "TipoRateioAgua");
		
		$AEhGas = $this->getParameter( "EhGas");
		$ATipoRateioGas = $this->getParameter( "TipoRateioGas");
		

		$ASql = strtolower("Update TabDespFixas set Descricao = '") . $ADescricao . "', " .
				" ValorPadrao = " . $AValorPadrao . ", " .
				" EhLuz = '" . $AEhLuz . "', " .
				" TipoRateioLuz = " . $ATipoRateioLuz . ", " .
				" EhAgua = '" . $AEhAgua . "', " .
				" TipoRateioAgua = " . $ATipoRateioAgua . ", " .
				" EhGas = '" . $AEhGas . "', " .
				" TipoRateioGas = " . $ATipoRateioGas . ", " .
				" CodEmp = " . $ACodEmp . " " .
				" where CodDespesa = " . $ACodDespesa;
		
		if ($this->ExecSQL($ASql))
			return "[{\"retorno\":1}]";
			else
				return "[{\"retorno\":0," .
				"\"mensagem\":\"" . $this->getLastMessage() . "\"}]";
	}
	
	function getInsert(){
		
		$ACodEmp = $this->getParameter( "CodEmp");
		$ADescricao = $this->getParameter( "Descricao");
		
		$AValorPadrao = $this->getParameter( "ValorPadrao");
		
		$AEhLuz = $this->getParameter( "EhLuz");
		$ATipoRateioLuz = $this->getParameter( "TipoRateioLuz");
		
		$AEhAgua = $this->getParameter( "EhAgua");
		$ATipoRateioAgua = $this->getParameter( "TipoRateioAgua");
		
		$AEhGas = $this->getParameter( "EhGas");
		$ATipoRateioGas = $this->getParameter( "TipoRateioGas");
		
		$ASql = strtolower("Insert into TabDespFixas (CodDespesa, CodEmp, Descricao, ValorPadrao, EhLuz, TipoRateioLuz, EhGas, TipoRateioGas, EhAgua, TipoRateioAgua) " .
				"Values (" .
				"(Select Coalesce(Max(tdf.CodDespesa), 0) from TabDespFixas tdf)+1, ") .
				" " . $ACodEmp . "," .
				" '" . $ADescricao . "'," .
				" " . $AValorPadrao . ", " .
				" '" . $AEhLuz . "', " .
				" '" . $ATipoRateioLuz . "', " .
				" '" . $AEhAgua . "', " .
				" '" . $ATipoRateioAgua . "', " .
				" '" . $AEhGas . "', " .
				" '" . $ATipoRateioGas . "' " .
				")";
		
		$ObjRet = new MensagemRetorno();
		if ($this->ExecSQL($ASql)) {
			$ObjRet->retorno = 1;
			$ObjRet->mensagem = "";
		}
		else {
			$ObjRet->retorno = 0;
			$ObjRet->mensagem = $this->getLastMessage();
		}
		return $this->getJSONFromObj($ObjRet);
	}
}
