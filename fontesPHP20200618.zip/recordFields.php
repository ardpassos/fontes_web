<?php

class recordFields {
    public $CodFunc;
    public $NomeFunc;
    public $UserName;
    public $Password;
}