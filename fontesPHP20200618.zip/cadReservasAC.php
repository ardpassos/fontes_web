<?php

class cadReservasAC extends cadBase {
	
	
	function getTabela(){
		return "tabreservasac";
	}
	
	function getCampoChave(){
		return "codreservaac";
	}
	
	function getConsPadrao() {
		$this->FOrderBy = "order by data, codperiodoac";
		$this->FSqlInitial = "Select * from tabreservasac";
		$this->addFieldDef(strtolower("codreservaac"), "C�d. Reserva AC", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("usuario", "Usu�rio", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("codac", "C�d AC", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("data", "Descri��o", constCads::FIELD_DATE, "", "");
		$this->addFieldDef("codacperiodo", "C�d AC", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("valorreserva", "Valor Reserva", constCads::FIELD_FLOAT, "", "");
		return parent::getCons();
	}
	
	function getConsPeriodosAC() {
		$ACodAC = $this->getParameter("codac");
		$AData = $this->getParameter("data");
		
		$this->FOrderBy = "order by tacp.descricao";
		$this->FSqlInitial = "Select tacp.codacperiodo, tacp.codac, tacp.descricao, tacp.horaini, tacp.horafim, tacp.valorreserva, ".
				             "       tr.codreservaac as codreservaac_r, tr.usuario as usuario_r, tr.codac as codac_r, tr.data as data_r, tr.codacperiodo as codacperiodo_r, tr.valorreserva as valorreserva_r, " .
				             "       case ".
				             "          when tr.usuario is null then 'l' " .
				             "          else 'r' " .
				             "       end as status " .
				             "  from tabacperiodos tacp " .
							 "  left join tabreservasac tr  " .
							 "    on tr.codacperiodo = tacp.codacperiodo " . 
		                     "   and tr.data = '" . $AData . "'".
		                     "  where tacp.codac = " . $ACodAC;
		//$this->addFieldDef("codac", "C�d AC", constCads::FIELD_INTEGER, "tacp", "codac");
		$AReturn = parent::getCons();
		$this->logMe($AReturn); 
		return $AReturn;
	}

	function getConsReservasACnoMes() {
		$ACodEmp = $this->getParameter("codemp");
		$ACodAC = $this->getParameter("codac");
		$ADataIni = $this->getParameter("dataini");
		$ADataFim = $this->getParameter("datafim");
		
		$this->FOrderBy = "order by tacp.descricao, tacp.horaini";
		$this->FSqlInitial = "Select tacp.codacperiodo, tacp.codac, tacp.descricao, tacp.horaini, tacp.horafim, tacp.valorreserva, ".
				"       tr.codreservaac as codreservaac_r, tr.usuario as usuario_r, tr.codac as codac_r, tr.data as data_r, tr.codacperiodo as codacperiodo_r, tr.valorreserva as valorreserva_r, " .
				"       case ".
				"          when tr.usuario is null then 'l' " .
				"          else 'r' " .
				"       end as status " .
				"  from tabacperiodos tacp " .
				"  join tabareacomum tac  " .
				"    on tac.codac = tacp.codac " .
				"   and tac.codemp = " . $ACodEmp .
				"  left join tabreservasac tr  " .
				"    on tr.codacperiodo = tacp.codacperiodo " .
				"   and tr.data >= '" . $ADataIni . "'" .
				"   and tr.data <= '" . $ADataFim . "'" .
				" where tacp.codac = " . $ACodAC;
		
		$this->addFieldDef("codac", "C�d AC", constCads::FIELD_INTEGER, "tacp", "codac");
		return parent::getCons();
	}
	
	function getCons() {
		$AConsType = $this->getParameter("constype");
		if ($AConsType == constCads::CAD_RESERVAS_AC_CONS_PADRAO)
			return $this->getConsPadrao();
		else if ($AConsType == constCads::CAD_RESERVAS_AC_CONS_AREAS_COMUNS)
			return $this->getConsPeriodosAC();
		else if ($AConsType == constCads::CAD_RESERVAS_AC_CONS_RESERVAS_MES)
			return $this->getConsReservasACnoMes();				
	}
	
	function keyExists($_ACod) {
		$AResult = false;
		try {
			$AQuery = $this->OpenSQLToResultSet(strtolower("Select Count(*) as NumRec from tabreservasac where codreservaac = ") . $_ACod);
			if ( $dados = $AQuery->fetch() ){
				$AResult = ($dados["NumRec"] > 0);
			}
			else
				$AResult = false;
		}
		catch (Exception $e) {
			$AResult = false;
		}
		return $AResult;
	}
	
	function getPost(){
		$ACodReservaAC = $this->getParameter( "codreservaac");
		$AUsuario = $this->getParameter("usuario");
		$ACodAC = $this->getParameter( "codac");
		$AData = $this->getParameter( "data");
		$ACodACPeriodo = $this->getParameter( "codacperiodo");
		$AValorReserva = $this->getParameter( "valorreserva");
		
		$ASql = "update tabreservasac set " .
				" usuario = '" . $AUsuario . "', " .
				" codac = " . $ACodAC . ", " .
				" data = '" . $AData . "', " .
				" codacperiodo = " . $ACodACPeriodo . ", " .
				" valorreserva = " . $AValorReserva .
				" where codreservaac = " . $ACodReservaAC;
		
		if ($this->ExecSQL($ASql))
			return "[{\"retorno\":1}]";
			else
				return "[{\"retorno\":0," .
				"\"mensagem\":\"" . $this->getLastMessage() . "\"}]";
	}
	
	function getDel(){
		$ACodAC = $_GET["codac"];
		$AData = $_GET["data"];
		$ACodACPeriodo = $_GET["codacperiodo"];
		$AUsuario = $_GET["usuario"];
		$ASql = "delete from tabreservasac " .
				" where codac = ". $ACodAC .
				"   and data = '". $AData . "' " .
				"   and codacperiodo = " . $ACodACPeriodo .
		        "   and usuario = '" . $AUsuario . "'";
		
		$ObjRet = new MensagemRetorno();
		
		if ($this->ExecSQL($ASql)) {
			$ObjRet->retorno = 1;
			$ObjRet->mensagem = "";
		}
		else {
			$ObjRet->retorno = 0;
			$ObjRet->mensagem = $this->getLastMessage();
		}
		return $this->getJSONMsgRetorno($ObjRet);
	}
	
	function getPodeInserirReserva($ACodAC, $AData, $ACodACPeriodo){
		$AResult = false;
		$ASql = "Select count(*) as numres from tabreservasac " .
				" where codac = ". $ACodAC .
				"   and data = '". $AData . "' " .
				"   and codacperiodo = " . $ACodACPeriodo;
		$AQuery = $this->OpenSQLToResultSet($ASql);
		while ($row = $AQuery->fetch(PDO::FETCH_ASSOC)) {
			$AResult = ($row["numres"] == 0);
		}
		return $AResult;
	}
	
	function getInsert(){
		$AUsuario = $this->getParameter("usuario");
		$ACodAC = $this->getParameter( "codac");
		$AData = $this->getParameter( "data");
		$ACodACPeriodo = $this->getParameter( "codacperiodo");
		$AValorReserva = $this->getParameter( "valorreserva");
		
		$APodeInserirReserva = $this->getPodeInserirReserva($ACodAC, $AData, $ACodACPeriodo);
		if ($APodeInserirReserva) {
			$ASql = strtolower("Insert into tabreservasac (codreservaac, usuario, codac, data, codacperiodo, valorreserva) " .
					"Values (" .
					"(Select Coalesce(Max(tra.codreservaac), 0) from tabreservasac tra)+1, ") .
					" '" . $AUsuario . "', " .
					"  " . $ACodAC . ", " .
					" '" . $AData . "', " .
					"  " . $ACodACPeriodo . ", " .
					"  " . $AValorReserva .
					")";
		}
		else 
			$this->FLastMessage = "Reservado!";
		
		$ObjRet = new MensagemRetorno();
		if ($APodeInserirReserva && $this->ExecSQL($ASql)) {
			$ObjRet->retorno = 1;
			$ObjRet->mensagem = "";
		}
		else {
			$this->logMe($this->getLastMessage());
			$ObjRet->retorno = 0;
			$ObjRet->mensagem = $this->getLastMessage();
		}
		return $this->getJSONMsgRetorno($ObjRet);
	}
}
