<?php

class cadUH extends cadBase {

	
	function getTabela(){
		return "TabUHs";
	}
	
	function getCampoChave(){
		return "CodUH";
	}
	
	function getCons() {
		$this->FOrderBy = "order by descricao";
		$this->FSqlInitial = "Select * from tabuhs";
		$this->addFieldDef(strtolower("CodUH"), "C�d. UH", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("descricao", "Descri��o", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("EhAluguel", "� Aluguel", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("ValorAluguel", "Valor Aluguel", constCads::FIELD_FLOAT, "", "");
		$this->addFieldDef("EhCond", "� Condom�nio", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("ValorCond", "Valor Condom�nio", constCads::FIELD_FLOAT, "", "");
		$this->addFieldDef("NumPessoasUH", "N�m. Pessoas UH", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("Senha", "Senha", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("DataInicio", "Data In�cio", constCads::FIELD_DATE, "", "");
		$this->addFieldDef("nomecontato", "Nome Contato", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("emailcontato", "Email Contato", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("fonecontato", "Fone Contato", constCads::FIELD_STRING, "", "");
		return parent::getCons();
	}
	
	function keyExists($_ACod) {
		$AResult = false;
		try {
			$AQuery = $this->OpenSQLToResultSet(strtolower("Select Count(*) as NumRec from TabUHs where CodUH = ") . $_ACod);
			if ( $dados = $AQuery->fetch() ){
				$AResult = ($dados["NumRec"] > 0);
			}
			else
				$AResult = false;
		}
		catch (Exception $e) {
			$AResult = false;
		}
		return $AResult;
	}
	
	function getPost(){
		$ACodEmp = $this->getParameter( "CodEmp");
		$ACodUH = $this->getParameter( "CodUH");
		$ADescricao = $this->getParameter( "Descricao");
		
		$AEhAluguel = $this->getParameter( "EhAluguel");
		$AValorAluguel = $this->getParameter( "ValorAluguel");
		
		$AEhCond = $this->getParameter( "EhCond");
		$AValorCond = $this->getParameter( "ValorCond");
		
		$ASenha = $this->getParameter("Senha");
		$ANumPessoasUH = $this->getParameter( "NumPessoasUH");
		$ADataInicio = $this->getParameterDateTime("DataInicio");
		
		$ANomeContato = $this->getParameter("nomecontato");
		$AEmailContato = $this->getParameter("emailcontato");
		$AFoneContato = $this->getParameter("fonecontato");
		
		$ASql = strtolower("Update TabUHs set Descricao = '") . $ADescricao . "', " .
				" EhAluguel = '" . $AEhAluguel . "', " .
				" ValorAluguel = " . $AValorAluguel . ", " .
				" EhCond = '" . $AEhCond . "', " .
				" ValorCond = " . $AValorCond . ", " .
				" NumPessoasUH = " . $ANumPessoasUH . ", " .
				" Senha = '" . $ASenha . "', " .
				" DataInicio = '" . $ADataInicio . "', " .
				" CodEmp = " . $ACodEmp . ", " .
				" nomecontato = '" . $ANomeContato . "', " .
				" emailcontato = '" . $AEmailContato . "', " .
				" fonecontato = '" . $AFoneContato . "' " .
				" where CodUH = " . $ACodUH;
		
		if ($this->ExecSQL($ASql))
			return "[{\"retorno\":1}]";
			else
				return "[{\"retorno\":0," .
				"\"mensagem\":\"" . $this->getLastMessage() . "\"}]";
	}
	
	function getInsert(){
		
		$ACodEmp = $this->getParameter( "CodEmp");
		$ADescricao = $this->getParameter( "Descricao");
		
		$AEhAluguel = $this->getParameter("EhAluguel");
		$AValorAluguel = $this->getParameter( "ValorAluguel");
		
		$AEhCond = $this->getParameter( "EhCond");
		$AValorCond = $this->getParameter( "ValorCond");
		
		$ASenha = $this->getParameter( "Senha");
		$ANumPessoasUH = $this->getParameterInt( "NumPessoasUH");
		$ADataInicio = $this->getParameterDateTime("DataInicio");
		
		$ANomeContato = $this->getParameter("nomecontato");
		$AEmailContato = $this->getParameter("emailcontato");
		$AFoneContato = $this->getParameter("fonecontato");
		
		$ASql = strtolower("Insert into TabUHs (CodUH, CodEmp, Descricao, EhAluguel, ValorAluguel, EhCond, ValorCond, Senha, DataInicio, NumPessoasUH, nomecontato, emailcontato, fonecontato) " .
				"Values (" .
				"(Select Coalesce(Max(tuh.CodUH), 0) from TabUHs tuh)+1, ") .
				" " . $ACodEmp . "," .
				" '" . $ADescricao . "'," .
				" '" . $AEhAluguel . "', " .
				" " . $AValorAluguel . ", " .
				" '" . $AEhCond . "', " .
				" " . $AValorCond . ", " .
				" '" . $ASenha . "', " .
				" '" . $ADataInicio . "', " .
				" " . $ANumPessoasUH . ", " .
				" '" . $ANomeContato . "', " .
				" '" . $AEmailContato . "', " .
				" '" . $AFoneContato . "' " .
				")";
		
		$ObjRet = new MensagemRetorno();
		if ($this->ExecSQL($ASql)) {
			$ObjRet->retorno = 1;
			$ObjRet->mensagem = "";
		}
		else {
			$ObjRet->retorno = 0;
			$ObjRet->mensagem = $this->getLastMessage();
		}
		return $this->getJSONMsgRetorno($ObjRet);
	}
	
	function openUH($ACodUH){
		$ASql = " select tuh.*, te.nomefantasia from tabuhs tuh " .
				"   join tabempresa te " .
				"	  on te.codempresa = tuh.codemp" .	
				"  where tuh.coduh = " . $ACodUH .
				"    and (lower(tuh.ehcond) <> 's' || lower(tuh.ehcond) is null) ".
				"  order by tuh.descricao";
		
		$this->logMe($ASql);
		$AQueryUHs = $this->OpenSQLToResultSet(strtolower($ASql));
		$this->FillDataCons($AQueryUHs);
	}
	
	function senEmailToUH(){
		$ACodUH = $this->getParameterInt( "coduh");
		$this->openUH($ACodUH);
		
		for ($i = 0; $i<count($this->Records); $i++){
			$ARec = $this->Records[$i];
			
			$AEmail = $ARec["emailcontato"];
			if ($AEmail != ""){
				$AAssunto = "Usu�rio para acesso ao sistema do condom�nio";
				$AHeaders = implode("\n", array("Content-Type: text/html"));
				$ANomeFantasia = utf8_decode($ARec["nomefantasia"]);
				$AText ="<html>".
						"<meta charset='UTF-8'>".
						"<body>".
						"Condom�nio: " . $ANomeFantasia . "<br>".
						"UH: " . $ARec["descricao"] . "<br>" .
						"Nome: " . $ARec["nomecontato"] . "<br>" .
						"Para acessar seus dados no condom�nio (".$ANomeFantasia."), acesse o site http://www.passosti.com.br<br>".
						"Acesse a �rea de login com os seguintes dados: <br>".
						"Empresa:". $ARec["codemp"] ." <br>".
						"Usu�rio:". $ARec["descricao"] ." <br>".
						"Senha:". $ARec["senha"] ." <br>".
						"</body></html>";
				
				$AURL = "http://www.passosti.com.br/demo/enviar_email.php?email=". $AEmail .
				"&assunto=$AAssunto".
				"&msg=". $AText .
				"&headers=". $AHeaders;
				$AURL = preg_replace("/ /", "%20", $AURL);
				$this->logMe($AURL);
				$array = file($AURL);
				$AStr = "";
				foreach($array as $line){
					$AStr = $AStr.$line;
				}
			}
		}
		$ObjRet = new MensagemRetorno();
		$ObjRet->retorno = 1;
		$ObjRet->mensagem = "";
		return $this->getJSONMsgRetorno($ObjRet);
	}
	
	function process($_AAction){
		$AResult = "";
		if (strcasecmp($_AAction, constCads::CAD_UHS_SEN_EMAIL) == 0) {
			$AResult = $this->senEmailToUH();
		}
		else 
			$AResult = parent::process($_AAction);
		return $AResult;
	}
}
