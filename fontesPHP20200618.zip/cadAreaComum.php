<?php

class cadAreaComum extends cadBase {
	
	
	function getTabela(){
		return "tabareacomum";
	}
	
	function getCampoChave(){
		return "codac";
	}
	
	function getCons() {
		$this->FOrderBy = "order by descricao";
		$this->FSqlInitial = "Select * from tabareacomum";
		$this->addFieldDef(strtolower("CodAC"), "C�d. �rea Comum", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("descricao", "Descri��o", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("obsaoreservar", "Obs ao Reservar", constCads::FIELD_STRING, "", "");
		return parent::getCons();
	}
	
	function keyExists($_ACod) {
		$AResult = false;
		try {
			$AQuery = $this->OpenSQLToResultSet(strtolower("Select Count(*) as NumRec from tabareacomum where codac = ") . $_ACod);
			if ( $dados = $AQuery->fetch() ){
				$AResult = ($dados["NumRec"] > 0);
			}
			else
				$AResult = false;
		}
		catch (Exception $e) {
			$AResult = false;
		}
		return $AResult;
	}
	
	function getPost(){
		$ACodAC = $this->getParameter( "codac");
		$ACodEmp = $this->getParameter( "codemp");
		$ADescricao = $this->getParameter( "Descricao");
		$AObsAoReservar = $this->getParameter( "obsaoreservar");
		
		$ASql = strtolower("Update tabareacomum set Descricao = '") . $ADescricao . "', " .
				" CodEmp = " . $ACodEmp . ", " .
				" obsaoreservar = '" . $AObsAoReservar . "' " .
				" where codac = " . $ACodAC;
		
		if ($this->ExecSQL($ASql))
			return "[{\"retorno\":1}]";
			else
				return "[{\"retorno\":0," .
				"\"mensagem\":\"" . $this->getLastMessage() . "\"}]";
	}
	
	function getInsert(){
		
		$ACodEmp = $this->getParameter( "codemp");
		$ADescricao = $this->getParameter( "Descricao");
		$AObsAoReservar = $this->getParameter( "obsaoreservar");
		
		$ASql = strtolower("Insert into tabareacomum (codac, CodEmp, Descricao, obsaoreservar) " .
				"Values (" .
				"(Select Coalesce(Max(tac.codac), 0) from tabareacomum tac)+1, ") .
				" " . $ACodEmp . "," .
				" '" . $ADescricao . "'," .
				" '" . $AObsAoReservar . "'" .
				")";
		
		$ObjRet = new MensagemRetorno();
		if ($this->ExecSQL($ASql)) {
			$ObjRet->retorno = 1;
			$ObjRet->mensagem = "";
		}
		else {
			$ObjRet->retorno = 0;
			$ObjRet->mensagem = $this->getLastMessage();
		}
		return $this->getJSONFromObj($ObjRet);
	}
}
