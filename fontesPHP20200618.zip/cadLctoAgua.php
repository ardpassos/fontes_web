<?php

class cadLctoAgua extends cadBase {
	
	function getTabela(){
		return "TabLctoAgua";
	}
	
	function getCampoChave(){
		return "CodLctoAgua";
	}
	
	
	function getCons() {
		$this->FOrderBy = "order by CodPeriodo, CodUH";
		$this->FSqlInitial = "Select * from tabLctoAgua";
		$this->addFieldDef("CodEmp", "C�d. Empresa", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("CodLctoAgua", "C�d. Per�odo", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("CodPeriodo", "Descri��o", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("DataLeitura", "Data ini", constCads::FIELD_DATE, "", "");
		$this->addFieldDef("CodUH", "Data fim", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("ValorLeitura", "Qtde consumo luz", constCads::FIELD_FLOAT, "", "");
		$this->addFieldDef("ValorUltimaLeitura", "Valor luz", constCads::FIELD_FLOAT, "", "");
		return parent::getCons();
	}
	
	function keyExists($_ACod) {
		$AResult = false;
		try {
			$AQuery = $this->OpenSQLToResultSet(strtolower("Select Count(*) as NumRec from TabLctoAgua where CodLctoAgua = ") . $_ACod);
			if ( $dados = $AQuery->fetch() ){
				$AResult = ($dados["NumRec"] > 0);
			}
			else
				$AResult = false;
		}
		catch (Exception $e) {
			$AResult = false;
		}
		return $AResult;
	}
	
	function getPost(){
		$ACodLctoAgua = $this->getParameterInt( "CodLctoAgua");
		$ACodEmp = $this->getParameterInt( "CodEmp");
		$ACodPeriodo = $this->getParameterInt( "CodPeriodo");
		
		$ADataLeitura = $this->getParameterDateTime( "DataLeitura");
		$ACodUH = $this->getParameterInt( "CodUH");
		
		$AValorLeitura = $this->getParameterFloat( "ValorLeitura");
		$AValorUltimaLeitura = $this->getParameterFloat( "ValorUltimaLeitura");
		
		$ASql = strtolower("Update TabLctoAgua set CodPeriodo = '") . $ACodPeriodo . "', " .
				" DataLeitura = '" . $ADataLeitura . "', " .
				" CodUH = " . $ACodUH. ", " .
				" ValorLeitura = " . $AValorLeitura . ", " .
				" ValorUltimaLeitura = " . $AValorUltimaLeitura . ", " .
				" CodEmp = " . $ACodEmp .
				" where CodLctoAgua = " . $ACodLctoAgua;
		
		if ($this->ExecSQL($ASql))
			return "[{\"retorno\":1}]";
			else
				return "[{\"retorno\":0," .
				"\"mensagem\":\"" . $this->getLastMessage() . "\"}]";
	}
	 
	
	function getInsert(){
		$ACodEmp = $this->getParameterInt( "CodEmp");
		$ACodPeriodo = $this->getParameterInt( "CodPeriodo");
		
		$ADataLeitura = $this->getParameterDateTime( "DataLeitura");
		$ACodUH = $this->getParameterInt( "CodUH");
		
		$AValorLeitura = $this->getParameterFloat( "ValorLeitura");
		$AValorUltimaLeitura = $this->getParameterFloat( "ValorUltimaLeitura");
		
		$ASql = strtolower("Insert into TabLctoAgua (CodLctoAgua, CodEmp, CodPeriodo, DataLeitura, CodUH, ValorLeitura, ValorUltimaLeitura) " .
				"Values (" .
				"(Select Coalesce(Max(tla.CodLctoAgua), 0) from TabLctoAgua tla)+1, ") .
				"  " . $ACodEmp . "," .
				" " . $ACodPeriodo . "," .
				" '" . $ADataLeitura . "', " .
				" " . $ACodUH . ", " .
				" " . $AValorLeitura . ", " .
				" " . $AValorUltimaLeitura . " " .
				")";
		
		$ObjRet = new MensagemRetorno();
		if ($this->ExecSQL($ASql)) {
			$ObjRet->retorno = 1;
			$ObjRet->mensagem = "";
		}
		else {
			$ObjRet->retorno = 0;
			$ObjRet->mensagem = $this->getLastMessage();
		}
		return $this->getJSONFromObj($ObjRet);
	}
}
