<?php

class MensagemRetorno{
    public $retorno;
    public $mensagem;
    public $chave = -1;
    
    function __construct(){
        $this->retorno = 0;
        $this->mensagem = "";
    }
    
    function setRetornoOK(){
    	$this->retorno = 1;
    	$this->mensagem = "";
    }
    function setRetornoErro($_AMsg){
    	$this->retorno = 2;
    	$this->mensagem = $_AMsg;
    }
}
