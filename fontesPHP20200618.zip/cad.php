<?php

include_once("br/com/passos/dao/conDB.php");
include_once("br/com/passos/dao/constCads.php");
include_once("br/com/passos/dao/FieldDef.php");
include_once("dbConnection.php");
include_once("conStm.php");
//sistema de condom�nio
include_once("cadUpdateDB.php");
include_once("cadUpdEstruturaDB.php");
include_once("cadLogin.php");
include_once("cadFunc.php");
include_once("cadEmpresa.php");
include_once("cadUH.php");
include_once("cadDespFixas.php");
include_once("cadPeriodoApuracao.php");
include_once("cadLctoGas.php");
include_once("cadLctoLuz.php");
include_once("cadLctoAgua.php");
include_once("cadDespesasUH.php");
include_once ("relCobrancasCliente.php");
include_once ("relPeriodoApuracao.php");
include_once ("cadSolicitaContato.php");
include_once ("cadAreaComum.php");
include_once ("cadACPeriodos.php");
include_once ("cadReservasAC.php");
include_once ("painelUHPeriodosApuracao.php");
//sistema de varejo
include_once ("varejo/cadFuncionarios.php");
include_once ("varejo/cadPessoas.php");
include_once ("varejo/cadCidades.php");
include_once ("varejo/cadUnMedidas.php");
include_once ("varejo/cadMarcas.php");
include_once ("varejo/cadLocalAmox.php");
include_once ("varejo/cadGruposProdutos.php");
include_once ("varejo/cadProdutos.php");
include_once ("varejo/cadInventario.php");
include_once ("varejo/cadCategoria.php");
include_once ("varejo/cadSubCategoria.php");
include_once ("varejo/cadFaixaEtaria.php");
include_once ("varejo/cadEntradaNF.php");
include_once ("varejo/cadEntradaNFItens.php");
include_once ("varejo/cadSaidaNF.php");
include_once ("varejo/cadSaidaNFItens.php");
include_once ("varejo/cadProdutoImgs.php");
include_once ("varejo/cadMovFinanc.php");
include_once ("varejo/cadContasReceber.php");
include_once ("varejo/cadContasPagar.php");
include_once ("varejo/cadContasReceberLctos.php");
include_once ("varejo/cadContasPagarLctos.php");
include_once ("varejo/cadEntradaNFParcelas.php");
include_once ("varejo/cadSaidaNFParcelas.php");
include_once ("varejo/resumoVarejo.php");
include_once ("varejo/ecommerce/consprodutos.php");
include_once ("varejo/ecommerce/consmenufiltros.php");
include_once ("varejo/ecommerce/cadUsuarioV.php");
include_once ("varejo/ecommerce/cadUsuarioVEnd.php");
include_once ("varejo/ecommerce/cadItensCarrinho.php");
include_once ("varejo/cadUpdateDBVarejo.php");
include_once ("varejo/cadProdutosGrade.php");
include_once ("varejo/cadCores.php");
include_once ("varejo/cadCRD.php");
include_once ("varejo/cadConfigVarejo.php");

$ACad = new cad();
$ACad->processaDisp();

class cad {
    
    private $serialVersionUID = 1145727360505885022;
    private $FConnections;
//    private Semaphore semaforo;
    public $FLogger;
    
    function __construct()
    {
        $this->FConnections = new ArrayObject();
       // $this->createConnections();
    }
     
    function createConnections(){
        for ($i = 0; $i < constCads::MAX_CONNECTIONS; $i++) {
            $ADBCon = new dbConnection();
            $this->FConnections->append($ADBCon);
        }
    }
    
    function createLogger(){
       $this->FLogger = fopen("CadLog.log", "a");
    }
    
    function getConnectionDisp(){
        return new dbConnection();
/*        if (semaforo == null)
            semaforo = new Semaphore(1);
            try {
                semaforo.acquire();
                try{
                    boolean AFind = false;
                    int ACount = 1;
                    
                   
                    while ((!AFind) & (ACount <= 5)){
                        for (int i = 0; i < FConnections.size(); i++) {
                            if (!FConnections.get(i).locked){
                                FConnections.get(i).locked = true;
                                AResult = FConnections.get(i);
                                AFind = true;
                                break;
                            }
                        }
                        if (AFind){
                            break;
                        }
                        else {
                            try {
                                ACount += 1;
                                Thread.currentThread().sleep(300);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
                finally {
                    semaforo.release();
                }
            } catch (InterruptedException e1) {
                e1.printStackTrace();
            }
            return AResult;*/
    }
    
    function processaCondominio(dbConnection $_AConDisp)  {
    	header("Content-type: text/html; charset=utf-8");
    	
        $AConDB = $_AConDisp->FConDB;
        $ASchemaName = $_GET[constCads::SCHEMA_NAME];
        $AConDB->setToSchema($ASchemaName);
        
        $AOp = $_GET[constCads::CAD];
        $AAction = $_GET[constCads::ACTION];
        $AResult = "";
        if (strcasecmp($AOp, constCads::CAD_RECREATE_DB) == 0) {
            $aUpd = new cadUpdateDB($AConDB);
            $AResult = $aUpd->updateDB();
        }        
        else if (strcasecmp($AOp, constCads::CAD_LOGIN) == 0) {
            $aCad = new cadLogin($AConDB);
            $AResult = $aCad->process($AAction);
        }
        else if (strcasecmp($AOp, constCads::CAD_FUNC) == 0) {
            $aCad = new cadFunc($AConDB);
            $AResult = $aCad->process($AAction);
        }
        else if (strcasecmp($AOp, constCads::CAD_EMPRESA) == 0) {
        	$aCad = new cadEmpresa($AConDB);
        	$AResult = $aCad->process($AAction);
        }
        else if (strcasecmp($AOp, constCads::CAD_UHS) == 0) {
        	$aCad = new cadUH($AConDB);
        	$AResult = $aCad->process($AAction);
        }
        else if (strcasecmp($AOp, constCads::CAD_DESPFIXAS) == 0) {
        	$aCad = new cadDespFixas($AConDB);
        	$AResult = $aCad->process($AAction);
        }
        else if (strcasecmp($AOp, constCads::CAD_PERIODOAPURACAO) == 0) {
        	$aCad = new cadPeriodoApuracao($AConDB);
        	$AResult = $aCad->process($AAction);
        }
        else if (strcasecmp($AOp, constCads::CAD_LCTOGAS) == 0) {
        	$aCad = new cadLctoGas($AConDB);
        	$AResult = $aCad->process($AAction);
        }
        else if (strcasecmp($AOp, constCads::CAD_LCTOLUZ) == 0) {
        	$aCad = new cadLctoLuz($AConDB);
        	$AResult = $aCad->process($AAction);
        }
        else if (strcasecmp($AOp, constCads::CAD_LCTOAGUA) == 0) {
        	$aCad = new cadLctoAgua($AConDB);
        	$AResult = $aCad->process($AAction);
        }
        else if (strcasecmp($AOp, constCads::CAD_DESPESASUH) == 0) {
        	$aCad = new cadDespesasUH($AConDB);
        	$AResult = $aCad->process($AAction);
        }
        else if (strcasecmp($AOp, constCads::CAD_UPD_ESTRUTURA_DB) == 0) {
        	$aUpd = new cadUpdEstruturaDB($AConDB);
        	$AResult = $aUpd->executaDDL();
        }
        else if (strcasecmp($AOp, constCads::REL_COBRANCAS_CLIENTE) == 0) {
        	$aUpd = new relCobrancasCliente($AConDB->getConEspelho());
        	$AResult = $aUpd->getConsPM();
        }
        else if (strcasecmp($AOp, constCads::REL_LISTAGEM_PERIODO_APURACAO) == 0) {
        	$aUpd = new relPeriodoApuracao($AConDB);
        	$AResult = $aUpd->getCons();
        }
        else if (strcasecmp($AOp, constCads::CAD_SOLICITACONTATO) == 0) {
        	$aCad = new cadSolicitaContato($AConDB);
        	$AResult = $aCad->process($AAction);
        }
        else if (strcasecmp($AOp, constCads::CAD_AREACOMUM) == 0) {
        	$aCad = new cadAreaComum($AConDB);
        	$AResult = $aCad->process($AAction);
        }
        else if (strcasecmp($AOp, constCads::CAD_AC_PERIODOS) == 0) {
        	$aCad = new cadACPeriodos($AConDB);
        	$AResult = $aCad->process($AAction);
        }
        else if (strcasecmp($AOp, constCads::CAD_RESERVAS_AC) == 0) {
        	$aCad = new cadReservasAC($AConDB);
        	$AResult = $aCad->process($AAction);
        }
        else if (strcasecmp($AOp, constCads::REL_PAINEL_UH_PERIODOS_APURACAO) == 0) {
        	$aUpd = new painelUHPeriodosApuracao($AConDB);
        	$AResult = $aUpd->getCons();
        }            
        return $AResult;
    }
    
    function processaVarejo(dbConnection $_AConDisp)  {
    	header("Content-type: text/html; charset=utf-8");
    	
    	$AConDB = $_AConDisp->FConDB;
    	$ASchemaName = $_GET[constCads::SCHEMA_NAME];
    	$AConDB->setToSchema($ASchemaName);
    	
    	$AOp = $_GET[constCads::CAD];
    	$AAction = $_GET[constCads::ACTION];
    	$AResult = "";
    	if (strcasecmp($AOp, constCads::CAD_LOGIN) == 0) {
    		$aCad = new cadLogin($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_FUNCIONARIOS) == 0) {
    		$aCad = new cadFuncionarios($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_PESSOAS) == 0) {
    		$aCad = new cadPessoas($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_CIDADES) == 0) {
    		$aCad = new cadCidades($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_UNMEDIDAS) == 0) {
    		$aCad = new cadUnMedidas($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_GRUPOSPRODUTOS) == 0) {
    		$aCad = new cadGruposProdutos($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_LOCALALMOX) == 0) {
    		$aCad = new cadLocalAmox($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_MARCAS) == 0) {
    		$aCad = new cadMarcas($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_PRODUTOS) == 0) {
    		$aCad = new cadProdutos($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_CATEGORIAS) == 0) {
    		$aCad = new cadCategorias($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_FAIXASETARIAS) == 0) {
    		$aCad = new cadFaixasEtarias($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_ENTRADANF) == 0) {
    		$aCad = new cadEntradaNF($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_ENTRADANF_ITENS) == 0) {
    		$aCad = new cadEntradaNFItens($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_SAIDANF) == 0) {
    		$aCad = new cadSaidaNF($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_SAIDANF_ITENS) == 0) {
    		$aCad = new cadSaidaNFItens($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_PRODUTOIMGS) == 0) {
    		$aCad = new cadProdutoImgs($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_MOVFINANC) == 0) {
    		$aCad = new cadMovFinanc($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_CONTASRECEBER) == 0) {
    		$aCad = new cadContasReceber($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_CONTASPAGAR) == 0) {
    		$aCad = new cadContasPagar($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_CONTASRECEBER_LCTOS) == 0) {
    		$aCad = new cadContasReceberLctos($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_CONTASPAGAR_LCTOS) == 0) {
    		$aCad = new cadContasPagarLctos($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_ENTRADANF_PARCELAS) == 0) {
    		$aCad = new cadEntradaNFParcelas($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_SAIDANF_PARCELAS) == 0) {
    		$aCad = new cadSaidaNFParcelas($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_RESUMO_VAREJO) == 0) {
    		$aCad = new resumoVarejo($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_CONSPRODUTOS) == 0) {
    		$aCad = new consprodutos($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_CONSMENUFILTROS) == 0) {
    		$aCad = new consmenufiltros($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_CADUSUARIO_VAREJO) == 0) {
    		$aCad = new cadUsuarioV($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_CADUSUARIOEND_VAREJO) == 0) {
    		$aCad = new cadUsuarioVEnd($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_CADITENSCARRINHO) == 0) {
    		$aCad = new cadItensCarrinho($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_PRODUTOS_GRADE) == 0) {
    		$aCad = new cadProdutosGrade($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_CORES) == 0) {
    		$aCad = new cadCores($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_SUBCATEGORIA) == 0) {
    		$aCad = new cadSubCategoria($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_INVENTARIO) == 0) {
    		$aCad = new cadInventario($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_CRD) == 0) {
    		$aCad = new cadCRD($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	else if (strcasecmp($AOp, constCads::CADV_CONFIG_VAREJO) == 0) {
    		$aCad = new cadConfigVarejo($AConDB);
    		$AResult = $aCad->process($AAction);
    	}
    	
    	if (strcasecmp($AOp, constCads::CAD_RECREATE_DB_VAREJO) == 0) {
    		$aUpd = new cadUpdateDBVarejo($AConDB);
    		$AResult = $aUpd->updateDB();
    	}
    	return $AResult;
    }
    
    function processa(dbConnection $_AConDisp)  {
    	header("Content-type: text/html; charset=utf-8");
    	if (isset($_GET[constCads::SISTEMA]))
    	  $ASys = $_GET[constCads::SISTEMA];
    	else
    	  $ASys = 'c';
    	$AResult = "";
    	    	
    	if (strcasecmp($ASys, constCads::SISTEMA_VAREJO) == 0) {
    		$AResult = $this->processaVarejo($_AConDisp);
    	}
    	else {
    		$AResult = $this->processaCondominio($_AConDisp);
    	}    
    	
    	if ($AResult != ""){
    		echo $AResult;
    	}
    }
    
    function processaDisp() {
    	if (!isset($_SESSION))
    		session_start();
        $AConDisp = $this->getConnectionDisp();
        try{
            $this->processa($AConDisp);
        }
        finally{
            $AConDisp->locked = false;
        }
    }

}
    