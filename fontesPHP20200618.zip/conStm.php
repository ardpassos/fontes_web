<?php

class ConStm {
    public $PrefixoEmp = "";
    public $User = "";
    public $Pass = "";
    public $IPCon = "";
    public $DBName = "";
    public $Session = "";
}
