<?php

class cadSolicitaContato extends cadBase {
	
	function getTabela(){
		return "tabsolicitacontato";
	}
	
	function getCampoChave(){
		return "codsolicitacontato";
	}
	
	function getCons() {
		$this->FSqlInitial = "Select * from tabsolicitacontato";
		$this->addFieldDef(strtolower("codsolicitacontato"), "C�d. Solicita��o", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("Nome", "Nome", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("email", "Email", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("ddd", "ddd", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("fone", "Fone", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("obs", "Obs", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("datahora", "Data/Hora", constCads::FIELD_DATE_TIME, "", "");
		return parent::getCons();
	}
	
	function keyExists($_ACod) {
		$AResult = false;
		try {
			$AQuery = $this->OpenSQLToResultSet(strtolower("Select Count(*) as NumRec from tabsolicitacontato where codsolicitacontato = ") . $_ACod);
			if ( $dados = $AQuery->fetch() ){
				$AResult = ($dados["NumRec"] > 0);
			}
			else
				$AResult = false;
		}
		catch (Exception $e) {
			$AResult = false;
		}
		return $AResult;
	}
	
	function getPost(){
		$ACod = $this->getParameter( "codsolicitacontato");
		$ANome = $this->getParameter( "nome");
		$AEmail = $this->getParameter( "Email");
		$Addd = $this->getParameter( "ddd");
		$AFone = $this->getParameter( "fone");
		$AObs = $this->getParameter( "obs");
		
		$ASql = strtolower("Update tabsolicitacontato set nome = '") . $ANome . "', " .
				" email = '" . $AEmail . "', " .
				" ddd = '" . $Addd . "', " .
				" fone = '" . $AFone . "', " .
				" obs = '" . $AObs . "', " .
				" datahora = now() " .
				" where codsolicitacontato = " . $ACod;
		
		if ($this->ExecSQL($ASql))
			return "[{\"retorno\":1}]";
			else
				return "[{\"retorno\":0," .
				"\"mensagem\":\"" . $this->getLastMessage() . "\"}]";
	}
	
	function enviaEmail($message){
		if (!$this->ehProducao()){
			$from = "passosti@passosti.com.br";
			
			$to = "ard.passos@gmail.com";
			
			$subject = "eCondo - Contato";
			
			$headers = "De:". $from;
			
			mail($to, $subject, $message, $headers);
		}
	}
	
	function getInsert(){
		
		$ANome = $this->getParameter( "nome");
		$AEmail = $this->getParameter( "Email");
		$Addd = $this->getParameter( "ddd");
		$AFone = $this->getParameter( "fone");
		$AObs = $this->getParameter( "obs");
		
		$ASql = strtolower("Insert into tabsolicitacontato (codsolicitacontato, nome, email, ddd, fone, obs, datahora) " .
				"Values (" .
				"(Select Coalesce(Max(tsc.codsolicitacontato), 0) from tabsolicitacontato tsc)+1, ") .
				"'" . $ANome . "'," .
				" '" . $AEmail . "', " .
				" '" . $Addd . "', " .
				" '" . $AFone . "', " .
				" '" . $AObs . "', " .
				" now() " .
		        ")";
		
		$ObjRet = new MensagemRetorno();
		if ($this->ExecSQL($ASql)) {
			$ObjRet->retorno = 1;
			$ObjRet->mensagem = "";
		}	
		else {
			$ObjRet->retorno = 0;
			$ObjRet->mensagem = $this->getLastMessage();
		}
		$AMsg = "Nome: " . $ANome  . "<br>" .
		            "Email: " . $AEmail . "<br>" .
		            "ddd: " . $Addd . "<br>" .
		            "Fone: " . $AFone . "<br>" .
		            "Obs: " . $AObs ;
		
		$this->enviaEmail($AMsg);
		return $this->getJSONFromObj($ObjRet);
	}
}
