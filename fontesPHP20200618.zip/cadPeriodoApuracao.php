<?php

class cadPeriodoApuracao extends cadBase {
	
	function getTabela(){
		return strtolower("TabPeriodoApuracao");
	}
	
	function getCampoChave(){
		return strtolower("CodPeriodo");
	}
	
	function ExecDelDetalhePeriodoApuracao($ATabela, $ACampoChave, $ACodigo, $ACodEmp){
		$ASql = strtolower("Delete from " . $ATabela . 
				           " where " . $ACampoChave . " = " . $ACodigo . 
				           "   and codemp = " . $ACodEmp);
		
		$ObjRet = new MensagemRetorno();
		
		if ($this->ExecSQL($ASql)) {
			$ObjRet->retorno = 1;
			$ObjRet->mensagem = "";
		}
		else {
			$ObjRet->retorno = 0;
			$ObjRet->mensagem = $this->getLastMessage();
		}
		return $this->getJSONFromObj($ObjRet);
	}
	
	function getDel(){
		$ACodigo = $this->getParameter( $this->getCampoChave());
		$ACodEmp = $this->getParameter( "CodEmp");
		
		$this->ExecDelDetalhePeriodoApuracao("tabDespesasUH", "CodPeriodo", $ACodigo, $ACodEmp);
		$this->ExecDelDetalhePeriodoApuracao("TabLctoLuz", "CodPeriodo", $ACodigo, $ACodEmp);
		$this->ExecDelDetalhePeriodoApuracao("TabLctoAgua", "CodPeriodo", $ACodigo, $ACodEmp);
		$this->ExecDelDetalhePeriodoApuracao("TabLctoGas", "CodPeriodo", $ACodigo, $ACodEmp);
		return $this->ExecDelDetalhePeriodoApuracao("tabPeriodoApuracao", "CodPeriodo", $ACodigo, $ACodEmp);
	}
	
	function getCons() {
		$this->FOrderBy = "order by datainicio desc limit 24";
		$this->FSqlInitial = strtolower("Select * from tabPeriodoApuracao");
		$this->addFieldDef("CodEmp", "C�d. Empresa", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("CodPeriodo", "C�d. Per�odo", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("descricao", "Descri��o", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("DataInicio", "Data ini", constCads::FIELD_DATE, "", "");
		$this->addFieldDef("DataFim", "Data fim", constCads::FIELD_DATE, "", "");
		$this->addFieldDef("QtdeConsumoLuz", "Qtde consumo luz", constCads::FIELD_FLOAT, "", "");
		$this->addFieldDef("ValorTotalLuz", "Valor luz", constCads::FIELD_FLOAT, "", "");
		$this->addFieldDef("ValorUnLuz", "Valor un. luz", constCads::FIELD_FLOAT, "", "");
		$this->addFieldDef("ValorAdBandAmarela", "V. B. Amarela", constCads::FIELD_FLOAT, "", "");
		$this->addFieldDef("ValorAdBandVermelha", "V. B. Vermelha", constCads::FIELD_FLOAT, "", "");
		$this->addFieldDef("ValorCosip", "V. Cosip", constCads::FIELD_FLOAT, "", "");
		$this->addFieldDef("QtdeConsumoAgua", "Qtde consumo �gua", constCads::FIELD_FLOAT, "", "");
		$this->addFieldDef("ValorTotalAgua", "Valor �gua", constCads::FIELD_FLOAT, "", "");
		$this->addFieldDef("ValorRateioGas", "Valor rateio g�s", constCads::FIELD_FLOAT, "", "");
		return parent::getCons();
	}
	
	function keyExists($_ACod) {
		$AResult = false;
		try {
			$AQuery = $this->OpenSQLToResultSet(strtolower("Select Count(*) as NumRec from TabPeriodoApuracao where CodPeriodo = ") . $_ACod);
			if ( $dados = $AQuery->fetch() ){
				$AResult = ($dados["NumRec"] > 0);
			}
			else
				$AResult = false;
		}
		catch (Exception $e) {
			$AResult = false;
		}
		return $AResult;
	}
	
	function getPost(){
		$ACodEmp = $this->getParameter( "CodEmp");
		$ACodPeriodo = $this->getParameter( "CodPeriodo");
		$ADescricao = $this->getParameter( "Descricao");
		
		$ADataInicio = $this->getParameterDateTime( "DataInicio");
		$ADataFim = $this->getParameterDateTime( "DataFim");
		
		$AQtdeConsumoLuz = $this->getParameterFloat( "QtdeConsumoLuz");
		$AValorTotalLuz = $this->getParameterFloat( "ValorTotalLuz");
		$AValorUnLuz = $this->getParameterFloat( "ValorUnLuz");
		$AValorAdBandAmarela = $this->getParameterFloat( "ValorAdBandAmarela");
		$AValorAdBandVermelha = $this->getParameterFloat( "ValorAdBandVermelha");
		$AValorCosip = $this->getParameterFloat( "ValorCosip");
		
		$AQtdeConsumoAgua = $this->getParameterFloat( "QtdeConsumoAgua");
		$AValorTotalAgua = $this->getParameterFloat( "ValorTotalAgua");
		
		$AValorRateioGas = $this->getParameterFloat( "ValorRateioGas");
		
		$ASql = strtolower("Update TabPeriodoApuracao set Descricao = '") . $ADescricao . "', " .
				" DataInicio = '" . $ADataInicio . "', " .
				" DataFim = '" . $ADataFim. "', " .
				" QtdeConsumoLuz = " . $AQtdeConsumoLuz . ", " .
				" ValorTotalLuz = " . $AValorTotalLuz . ", " .
				" ValorUnLuz = " . $AValorUnLuz . ", " .
				" ValorAdBandAmarela = " . $AValorAdBandAmarela . ", " .
				" ValorAdBandVermelha = " . $AValorAdBandVermelha . ", " .
				" ValorCosip = " . $AValorCosip . ", " .
				" QtdeConsumoAgua = " . $AQtdeConsumoAgua . ", " .
				" ValorTotalAgua = " . $AValorTotalAgua . ", " .
				" ValorRateioGas = " . $AValorRateioGas . ", " .
				" CodEmp = " . $ACodEmp . " " .
				" where CodPeriodo = " . $ACodPeriodo;
		
		if ($this->ExecSQL($ASql))
			return "[{\"retorno\":1}]";
			else
				return "[{\"retorno\":0," .
				"\"mensagem\":\"" . $this->getLastMessage() . "\"}]";
	}
	
	function getInsert(){
		
		$ACodEmp = $this->getParameter( "CodEmp");
		$ADescricao = $this->getParameter( "Descricao");
		
		$ADataInicio = $this->getParameterDateTime( "DataInicio");
		$ADataFim = $this->getParameterDateTime( "DataFim");
		
		$AQtdeConsumoLuz = $this->getParameterFloat( "QtdeConsumoLuz");
		$AValorTotalLuz = $this->getParameterFloat( "ValorTotalLuz");
		$AValorUnLuz = $this->getParameterFloat( "ValorUnLuz");
		$AValorAdBandAmarela = $this->getParameterFloat( "ValorAdBandAmarela");
		$AValorAdBandVermelha = $this->getParameterFloat( "ValorAdBandVermelha");
		$AValorCosip = $this->getParameterFloat( "ValorCosip");
		
		$AQtdeConsumoAgua = $this->getParameterFloat( "QtdeConsumoAgua");
		$AValorTotalAgua = $this->getParameterFloat( "ValorTotalAgua");
		
		$AValorRateioGas = $this->getParameterFloat( "ValorRateioGas");
		
		
		$ASql = strtolower("Insert into TabPeriodoApuracao (CodPeriodo, CodEmp, Descricao, DataInicio, DataFim, QtdeConsumoLuz, ValorTotalLuz, ValorUnLuz, ValorAdBandAmarela, ValorAdBandVermelha, ValorCosip, QtdeConsumoAgua, ValorTotalAgua, ValorRateioGas) " .
				"Values (" .
				"(Select Coalesce(Max(tpa.CodPeriodo), 0) from TabPeriodoApuracao tpa)+1, ") .
				"  " . $ACodEmp . "," .
				" '" . $ADescricao . "'," .
				" '" . $ADataInicio . "', " .
				" '" . $ADataFim . "', " .
				" " . $AQtdeConsumoLuz . ", " .
				" " . $AValorTotalLuz . ", " .
				" " . $AValorUnLuz . ", " .
				" " . $AValorAdBandAmarela . ", " .
				" " . $AValorAdBandVermelha . ", " .
				" " . $AValorCosip . ", " .
				" " . $AQtdeConsumoAgua . ", " .
				" " . $AValorTotalAgua . ", " .
				" " . $AValorRateioGas . " " .
				")";
		
		$ObjRet = new MensagemRetorno();
		if ($this->ExecSQL($ASql)) {
			$ObjRet->retorno = 1;
			$ObjRet->mensagem = "";
		}
		else {
			$ObjRet->retorno = 0;
			$ObjRet->mensagem = $this->getLastMessage();
		}
		return $this->getJSONFromObj($ObjRet);
	}
}
