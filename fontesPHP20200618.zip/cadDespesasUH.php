<?php

class cadDespesasUH extends cadBase {
	
	function getTabela(){
		return "TabDespesasUH";
	}
	
	function getCampoChave(){
		return "CodDespesaUH";
	}
	
	function getCons() {
		$this->FOrderBy = "order by CodPeriodo, CodUH";
		$this->FSqlInitial = "Select * from tabDespesasUH";
		$this->addFieldDef("CodEmp", "C�d. Empresa", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("CodDespesaUH", "C�d. Despesa", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("CodPeriodo", "C�d. Per�odo", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("DataLcto", "Data Lcto", constCads::FIELD_DATE, "", "");
		$this->addFieldDef("CodUH", "C�d UH", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("DescricaoDespesa", "Descri��op", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("DataDespesa", "Data Despesa", constCads::FIELD_DATE, "", "");
		$this->addFieldDef("Valor", "Valor", constCads::FIELD_FLOAT, "", "");
		return parent::getCons();
	}
	
	function keyExists($_ACod) {
		$AResult = false;
		try {
			$AQuery = $this->OpenSQLToResultSet(strtolower("Select Count(*) as NumRec from TabDespesasUH where CodDespesaUH = ") . $_ACod);
			if ( $dados = $AQuery->fetch() ){
				$AResult = ($dados["NumRec"] > 0);
			}
			else
				$AResult = false;
		}
		catch (Exception $e) {
			$AResult = false;
		}
		return $AResult;
	}
	
	function getPost(){
		$ACodEmp = $this->getParameter( "CodEmp");
		$ACodDespesaUH = $this->getParameter( "CodDespesaUH");
		$ACodPeriodo = $this->getParameter( "CodPeriodo");
		
		$ADataLcto = $this->getParameter( "DataLcto");
		$ACodUH = $this->getParameter( "CodUH");
		$ADescricaoDespesa = $this->getParameter( "DescricaoDespesa");
		
		$ADataDespesa = $this->getParameter( "DataDespesa");
		$AValor = $this->getParameter( "Valor");
		
		$ASql = strtolower("Update TabDespesasUH set CodDespesaUH = ") . $ACodDespesaUH . ", " .
				" CodPeriodo = " . $ACodPeriodo. ", " .
				" DataLcto = current_date, " .
				" CodUH = " . $ACodUH. ", " .
				" DescricaoDespesa = '" . $ADescricaoDespesa . "', " .
				" DataDespesa = '" . $ADataDespesa . "', " .
				" Valor = " . $AValor . ", " .
				" CodEmp = " . $ACodEmp .
				" where CodDespesaUH = " . $ACodDespesaUH;
		
		if ($this->ExecSQL($ASql))
			return "[{\"retorno\":1}]";
			else
				return "[{\"retorno\":0," .
				"\"mensagem\":\"" . $this->getLastMessage() . "\"}]";
	}
	
	
	function getInsert(){
		$ACodEmp = $this->getParameter( "CodEmp");
		$ACodPeriodo = $this->getParameter( "CodPeriodo");
		
		$ADataLcto = $this->getParameter( "DataLcto");
		$ACodUH = $this->getParameter( "CodUH");
		$ADescricaoDespesa = $this->getParameter( "DescricaoDespesa");
		
		$ADataDespesa = $this->getParameter( "DataDespesa");
		$AValor = $this->getParameter( "Valor");
		
		
		$ASql = strtolower("Insert into TabDespesasUH (CodDespesaUH, CodEmp, CodPeriodo, DataLcto, CodUH, DescricaoDespesa, DataDespesa, Valor) " .
				"Values (" .
				"(Select Coalesce(Max(tlg.CodDespesaUH), 0) from TabDespesasUH tlg)+1, ") .
				"  " . $ACodEmp . "," .
				" " . $ACodPeriodo . "," .
				" current_date, " .
				" " . $ACodUH . ", " .
				" '" . $ADescricaoDespesa . "', " .
				" '" . $ADataDespesa . "', " .
				" " . $AValor . " " .
				")";
		
		$ObjRet = new MensagemRetorno();
		if ($this->ExecSQL($ASql)) {
			$ObjRet->retorno = 1;
			$ObjRet->mensagem = "";
		}
		else {
			$ObjRet->retorno = 0;
			$ObjRet->mensagem = $this->getLastMessage();
		}
		return $this->getJSONFromObj($ObjRet);
	}
}
