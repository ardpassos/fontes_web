<?php

class cadLctoLuz extends cadBase {
	
	
	function getTabela(){
		return "TabLctoLuz";
	}
	
	function getCampoChave(){
		return "CodLctoLuz";
	}
	
	
	function getCons() {
		$this->FOrderBy = "order by CodPeriodo, CodUH, CodMedidor";
		$this->FSqlInitial = "Select * from tabLctoLuz";
		$this->addFieldDef("CodEmp", "C�d. Empresa", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("CodLctoLuz", "C�d. Per�odo", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("CodPeriodo", "Descri��o", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("CodMedidor", "Medidor", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("DataLeitura", "Data ini", constCads::FIELD_DATE, "", "");
		$this->addFieldDef("CodUH", "Data fim", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("ValorLeitura", "Qtde consumo luz", constCads::FIELD_FLOAT, "", "");
		$this->addFieldDef("ValorUltimaLeitura", "Valor luz", constCads::FIELD_FLOAT, "", "");
		return parent::getCons();
	}
	
	function keyExists($_ACod) {
		$AResult = false;
		try {
			$AQuery = $this->OpenSQLToResultSet(strtolower("Select Count(*) as NumRec from TabLctoLuz where CodLctoLuz = ") . $_ACod);
			if ( $dados = $AQuery->fetch() ){
				$AResult = ($dados["NumRec"] > 0);
			}
			else
				$AResult = false;
		}
		catch (Exception $e) {
			$AResult = false;
		}
		return $AResult;
	}
	
	function getPost(){
		$ACodEmp = $this->getParameterInt( "CodEmp");
		$ACodLctoLuz = $this->getParameterInt( "CodLctoLuz");
		$ACodPeriodo = $this->getParameterInt( "CodPeriodo");
		
		$ACodMedidor = $this->getParameterInt( "CodMedidor");
		$ADataLeitura = $this->getParameterDateTime("DataLeitura");
		$ACodUH = $this->getParameterInt( "CodUH");
		
		$AValorLeitura = $this->getParameterFloat("ValorLeitura");
		$AValorUltimaLeitura = $this->getParameterFloat( "ValorUltimaLeitura");
		
		$ASql = strtolower("Update TabLctoLuz set CodPeriodo = '") . $ACodPeriodo . "', " .
				" CodMedidor = '" . $ACodMedidor . "', " .
				" DataLeitura = '" . $ADataLeitura . "', " .
				" CodUH = " . $ACodUH. ", " .
				" ValorLeitura = " . $AValorLeitura . ", " .
				" ValorUltimaLeitura = " . $AValorUltimaLeitura . ", " .
				" CodEmp = " . $ACodEmp .
				" where CodLctoLuz = " . $ACodLctoLuz;
		
		if ($this->ExecSQL($ASql))
			return "[{\"retorno\":1}]";
			else
				return "[{\"retorno\":0," .
				"\"mensagem\":\"" . $this->getLastMessage() . "\"}]";
	}
	
	function getInsert(){
		$ACodEmp = $this->getParameterInt( "CodEmp");
		$ACodPeriodo = $this->getParameterInt( "CodPeriodo");
		
		$ACodMedidor = $this->getParameterInt( "CodMedidor");
		$ADataLeitura = $this->getParameterDateTime("DataLeitura");
		$ACodUH = $this->getParameterInt( "CodUH");
		
		$AValorLeitura = $this->getParameterFloat("ValorLeitura");
		$AValorUltimaLeitura = $this->getParameterFloat( "ValorUltimaLeitura");
		
		$ASql = strtolower("Insert into TabLctoLuz (CodLctoLuz, CodEmp, CodPeriodo, CodMedidor, DataLeitura, CodUH, ValorLeitura, ValorUltimaLeitura) " .
				"Values (" .
				"(Select Coalesce(Max(tll.CodLctoLuz), 0) from TabLctoLuz tll)+1, ") .
				"  " . $ACodEmp . "," .
				" " . $ACodPeriodo . "," .
				" " . $ACodMedidor . "," .
				" '" . $ADataLeitura . "', " .
				" " . $ACodUH . ", " .
				" " . $AValorLeitura . ", " .
				" " . $AValorUltimaLeitura . " " .
				")";
		
		$ObjRet = new MensagemRetorno();
		if ($this->ExecSQL($ASql)) {
			$ObjRet->retorno = 1;
			$ObjRet->mensagem = "";
		}
		else {
			$ObjRet->retorno = 0;
			$ObjRet->mensagem = $this->getLastMessage();
		}
		return $this->getJSONFromObj($ObjRet);
	}
}