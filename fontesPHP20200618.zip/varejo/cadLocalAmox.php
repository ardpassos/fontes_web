<?php

class cadLocalAmox extends cadBase {
	
	function getTabela(){
		return "tablocalalmox";
	}
	
	function getCampoChave(){
		return "codlocalalm";
	}
	
	function getCons() {
		$this->FSqlInitial = "Select * from ". $this->getTabela();
		$this->addFieldDef($this->getCampoChave(), "C�d. local", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("localalm", "Local Alm.", constCads::FIELD_STRING, "", "");
		return parent::getCons();
	}
	
	function getConsLkp() {
		$this->FOrderBy = "  order by localalm";
		$this->FSqlInitial = "select codlocalalm as codigo, localalm as descricao ".
				"  from tablocalalmox ";
		$this->addFieldDef($this->getCampoChave(), "C�d. local", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("localalm", "Local Alm.", constCads::FIELD_STRING, "", "");
		return parent::getConsLkp();
	}
	
	function getPost(){
		$ACodLocalAlm = $this->getParameterInt( "codlocalalm");
		$ALocalAlm = $this->getParameter( "localalm");
		
		$ASql = "Update tablocalalmox set localalm = '" . $ALocalAlm . "' " .
				" where codlocalalm = " . $ACodLocalAlm;
		
		if ($this->ExecSQL($ASql))
			return "[{\"retorno\":1}]";
		else
			return "[{\"retorno\":0," .
					"\"mensagem\":\"" . $this->getLastMessage() . "\"}]";
	}
	
	function getInsert(){
		$ALocalAlm = $this->getParameter( "localalm");
		
		$ASql = "insert into tablocalalmox " .
				" (codlocalalm, localalm) " .
				"Values (" .
				"(" . $this->getFieldKeyMaxInSQL() . ")+1, " .
				"'" . $ALocalAlm . "'" .
				")";
		
		$ObjRet = new MensagemRetorno();
		if ($this->ExecSQL($ASql)) {
			$ObjRet->retorno = 1;
			$ObjRet->mensagem = "";
		}
		else {
			$ObjRet->retorno = 0;
			$ObjRet->mensagem = $this->getLastMessage();
		}
		return $this->getJSONFromObj($ObjRet);
	}
}