<?php
// http://localhost/demo/cad.php?-2=passos_teste&-3=4&sys=v&cad=v100123&act=0

class cadUpdateDBVarejo extends cadBase {
    
    private $FLastMessageError = "";
    private $FLastCodVersao = 0;
    private $FLastCodUpdate = 0;
    
    private $FLastCodVersaoUpdated = 0;
    private $FLastCodUpdateUpdated = 0;
    
    
    function setLastDBVersion(){
        try {       
            $stmt = $this->FCon->prepare(strtolower("Select * from tabversao ".
                " where CodVersao = (Select Max(CodVersao) ".
                "order by CodUpdate desc "));
            $stmt->execute();
            while ( $dados = $stmt->fetch() ){
              $this->FLastCodVersao = $dados["CodVersao"];
              $this->FLastCodUpdate = $dados["CodUpdate"];
            }
        }
        catch  (Exception $e) {
            $this->FLastCodVersao = 0;
            $this->FLastCodUpdate = 0;
        }
    }
    
    function updateVersao($_ACodVersao, $_ACodUpdate){
        $this->ExecDDLinDB(" insert into TabVersao (CodVersao, CodUpdate)".
            " Values (" . $_ACodVersao . ", " . $_ACodUpdate .")", 0, 0);
        $this->FLastCodVersaoUpdated = $_ACodVersao;
        $this->FLastCodUpdateUpdated = $_ACodUpdate;
        return true;
    }
    
    function ExecDDLinDB($_ASql, $_ACodVersao, $_ACodUpdate) {
        $AResult = false;
        try {
            $stmt = $this->FCon->prepare(strtolower($_ASql));
            $stmt->execute();
            
            if ($_ACodVersao > 0)
                $this->updateVersao($_ACodVersao, $_ACodUpdate);
                $AResult = true;
        }
        catch (Exception $e) {
            $this->FLastMessageError = $e->getMessage();
        }
        return $AResult;
    }
    
    function createTableVersao(){
        $ACodVersao = 1;
        $ACodUpdate = 1;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                $this->ExecDDLinDB("Create Table TabVersao ".
                    "(".
                    "  CodVersao Integer not null,".
                    "  CodUpdate Integer,".
                    "  constraint pk_Versao primary key(CodVersao, CodUpdate) ".
                    ")", $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function createTabUsersSite() {
        $ACodVersao = 1;
        $ACodUpdate = 2;
        if (($ACodVersao >= $this->FLastCodVersao) &&
            ($ACodUpdate > $this->FLastCodUpdate)) {
                if ($this->createTableVersao())
                    $this->ExecDDLinDB("Create table tabusuariov" .
	                        "(" .
	                        "  codusuario integer not null," .
	                        "  nomeusuario VarChar(255)," .
	                    	"  usuario VarChar(255)," .
	                    	"  senha VarChar(255)," .
	                    	"  celular VarChar(40)," .
	                    	"  cep VarChar(40)," .
                    		"  cidade VarChar(255)," .
                    		"  rua VarChar(255)," .
                    		"  numero VarChar(10)," .
                    		"  complemento VarChar(40)," .
                    		"  bairro VarChar(255)," .
                    		"  constraint pk_usersv primary key(codusuario)" .
                        ")", $ACodVersao, $ACodUpdate);
            }
            return ($this->FLastMessageError == "");
    }
    
    function createTabItensCarrinho() {
    	$ACodVersao = 1;
    	$ACodUpdate = 3;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->createTabUsersSite())
    					$this->ExecDDLinDB("create table tabitenscarrinho " .
											" ( " .
											"  coditem integer not null, " .
											"  codusuario integer, " .
											"  codproduto integer, " .
											"  qtde integer, " .
											"  datahora timestamp, " .
											"  pedidogerado varchar(1), " .
											"  codpedido integer, " .
											"  constraint pk_itenscarrinho primary key (coditem) " .
											")", $ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function alterTabSaidaNF() {
    	$ACodVersao = 1;
    	$ACodUpdate = 4;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->createTabItensCarrinho())
    					$this->ExecDDLinDB("alter table tabsaidanf " .
    							" add codusuariosite integer ", $ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function createTableInsumosGrade() {
    	$ACodVersao = 1;
    	$ACodUpdate = 5;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->alterTabSaidaNF())
    					$this->ExecDDLinDB("create table tabinsumosgrade " .
											"( " .
											"  coditem integer not null, " .
											"  codinsumo integer, " .
											"  codlocalalm integer, " .
											"  codcor integer, " .
											"  tamanho varchar(10), " .
											"  valorde float, " .
											"  valorvenda float, " .
											"  mostrarvalorsite varchar(1), " .
											"  itemempromocao varchar(1), " .
											"  qtdemin integer, " .
											"  qtdemax integer, " .
											"  qtdeestoque integer, " .
											"  constraint pk_insumosgrade primary key (coditem) " .
											")" , $ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function alterTabCorRefHexa() {
    	$ACodVersao = 1;
    	$ACodUpdate = 6;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->createTableInsumosGrade())
    					$this->ExecDDLinDB("alter table tabcores " .
    							" add refhexa varchar(10) ", $ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function createTableSubCategoria() {
    	$ACodVersao = 1;
    	$ACodUpdate = 7;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->alterTabCorRefHexa())
    					$this->ExecDDLinDB("create table tabsubcategoria " .
											" ( " .
											"  codsubcategoria integer not null, " .
											"  subcategoria varchar (255), " .
											"  constraint pk_subcategoria primary key (codsubcategoria) " .
											" )" , $ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function alterTabInsumosSubCateg() {
    	$ACodVersao = 1;
    	$ACodUpdate = 8;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->createTableSubCategoria())
    					$this->ExecDDLinDB("alter table tabinsumos " .
    							" add codsubcategoria integer ", $ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function alterTabCarrinhoItemGrade() {
    	$ACodVersao = 1;
    	$ACodUpdate = 9;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->alterTabInsumosSubCateg())
    					$this->ExecDDLinDB("alter table tabitenscarrinho " .
    							" add coditemgrade integer, ".
    							" drop codproduto ", $ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function alterTabNFSaidaItemGrade() {
    	$ACodVersao = 1;
    	$ACodUpdate = 10;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->alterTabCarrinhoItemGrade())
    					$this->ExecDDLinDB("alter table tabsaidanfitens " .
    							" add coditemgrade integer, ".
    							" drop codinsumo ", $ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function alterTabNFEntradaItemGrade() {
    	$ACodVersao = 1;
    	$ACodUpdate = 11;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->alterTabNFSaidaItemGrade())
    					$this->ExecDDLinDB("alter table tabentradanfitens " .
    							" add coditemgrade integer, ".
    							" drop codinsumo ", $ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function alterTabInsumosGradeCodBarras() {
    	$ACodVersao = 1;
    	$ACodUpdate = 12;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->alterTabNFEntradaItemGrade())
    					$this->ExecDDLinDB("alter table tabinsumosgrade " .
    							" add codbarras varchar(255) ", $ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function createTableCRD() {
    	$ACodVersao = 1;
    	$ACodUpdate = 13;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->alterTabInsumosGradeCodBarras())
    					$this->ExecDDLinDB("create table tabcrd ( ".
											"  codcrd integer not null, ".
											"  crd varchar (255), ".
											"  debcred varchar (1), ".
											"  mascara varchar(255), ".
											"  constraint pk_crd primary key(codcrd) ".
											") ", $ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function alterTabContasReceber() {
    	$ACodVersao = 1;
    	$ACodUpdate = 14;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->createTableCRD())
    					$this->ExecDDLinDB("alter table tabcontasreceber " .
    							" add codcrd integer ", $ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function alterTabContasPagar() {
    	$ACodVersao = 1;
    	$ACodUpdate = 15;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->alterTabContasReceber())
    					$this->ExecDDLinDB("alter table tabcontaspagar " .
    							" add codcrd integer ", $ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function alterTabMovFinanc() {
    	$ACodVersao = 1;
    	$ACodUpdate = 16;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->alterTabContasPagar())
    					$this->ExecDDLinDB("alter table tabmovfinanc " .
    							" add codcrd integer ", $ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function alterTabConfigVarejo() {
    	$ACodVersao = 1;
    	$ACodUpdate = 17;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->alterTabMovFinanc())
    					$this->ExecDDLinDB("create table tabconfigvarejo " .
											"( " .
											"  codconfig integer not null, " .
											"  codcrdcompras integer, " .
											"  codcrdvendas integer, " .
											"  constraint pk_configvarejo primary key(codconfig) " .
											") ", $ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function insertTabConfigVarejo() {
    	$ACodVersao = 1;
    	$ACodUpdate = 18;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->alterTabConfigVarejo())
    					$this->ExecDDLinDB("insert into tabconfigvarejo (codconfig) values (1)", $ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function CreateTableUsuarioVEndereco() {
    	$ACodVersao = 1;
    	$ACodUpdate = 19;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->insertTabConfigVarejo())
    					$this->ExecDDLinDB("create table tabusuariovend ".
											" ( ".
											"   codend integer not null, ".
											"   codusuariov integer, ".
											"   cep varchar(20), ".
											"   cidade varchar(255), ".
											"   uf varchar(2), ".
											"   rua varchar(255), ".
											"   numero integer, ".
											"   complemento varchar(255), ".
											"   bairro varchar(255), ".
											"   constraint pk_usuariovend primary key(codend) ".
											" )", $ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function alterTabSaidaNFCodEnd() {
    	$ACodVersao = 1;
    	$ACodUpdate = 20;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->CreateTableUsuarioVEndereco())
    					$this->ExecDDLinDB("alter table tabsaidanf " .
    							" add codend integer ", $ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function alterTabSaidaNFDataEmissaoNF() {
    	$ACodVersao = 1;
    	$ACodUpdate = 21;
    	if (($ACodVersao >= $this->FLastCodVersao) &&
    			($ACodUpdate > $this->FLastCodUpdate)) {
    				if ($this->alterTabSaidaNFCodEnd())
    					$this->ExecDDLinDB("alter table tabsaidanf " .
    							" add dataemissaonf date ", $ACodVersao, $ACodUpdate);
    			}
    			return ($this->FLastMessageError == "");
    }
    
    function dropTables(){
        $this->ExecDDLinDB("drop table TabVersao",0,0);

        $this->FLastMessageError = "";
    }
    
    function executaTrocaVersao() {
    	return $this->alterTabSaidaNFDataEmissaoNF();
    }
    
    function setToSchema($_ASchemaName){
        $this->FLastMessage = "";
        //$ASql =  " SET search_path TO \"" . _ASchemaName.toLowerCase() . "\"";
        $ASql =  " use '". strtolower($_ASchemaName) ."'";
        try {
            $stmt = $this->FCon->prepare($ASql);
            $stmt->execute();
        }
        catch (Exception $e) {
            $this->FLastMessage = $e.getMessage();
        }
        return $this->getLastMessage();
    }
    
    function updateDBSchema(){
        $AResult = "";
        try{
            $this->setLastDBVersion();
            
            //    dropTables();
            if ($this->executaTrocaVersao())
                $AResult = "";
            else
                $AResult = "[{\"retorno\":0,\"mensagem\":" . $this->FLastMessageError . "}]";
        }
        finally{
            $this->setToSchema("public");
        }
        return $AResult;
    }
    
    function updateDB(){
        $this->FLastMessage = $this->updateDBSchema();
        
        if ($this->FLastMessage == ""){
            $ObjRet = new MensagemRetorno();
            $ObjRet->retorno = 1;
            $ObjRet->mensagem = " - Versao Atual: " . $this->FLastCodVersao .
            " - Update Atual: " . $this->FLastCodUpdate .
            " - Versao Atualizada: " . $this->FLastCodVersaoUpdated .
            " - Update Atualizado: " . $this->FLastCodUpdateUpdated;
            $this->FLastMessage = $this->getJSONFromObj($ObjRet);
        }
        return $this->getLastMessage();
    }
}
