<?php

class cadUnMedidas extends cadBase {
	
	function getTabela(){
		return "tabunmedidas";
	}
	
	function getCampoChave(){
		return "codunmedida";
	}
	
	function getCons() {
		$this->FSqlInitial = "Select * from ". $this->getTabela();
		$this->addFieldDef($this->getCampoChave(), "C�d. Un. Medida", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("unmedida", "Un. Medida", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("tipounmedida", "Tipo de Un. de Medida", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("simbolo", "S�mbolo", constCads::FIELD_STRING, "", "");
		return parent::getCons();
	}
	
	function getConsLkp() {
		$this->FOrderBy = "  order by unmedida";
		$this->FSqlInitial = "select codunmedida as codigo, unmedida as descricao ".
				"  from tabunmedidas ";
		$this->addFieldDef($this->getCampoChave(), "C�d. Un. Medida", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("unmedida", "Un. Medida", constCads::FIELD_STRING, "", "");
		return parent::getConsLkp();
	}
	
	function getPost(){
		$ACodUnMedida = $this->getParameterInt( "codunmedida");
		$AUnMedida = $this->getParameter( "unmedida");
		$ATipoUnMedida = $this->getParameter( "tipounmedida");
		$ASimbolo = $this->getParameter( "simbolo");
		
				
		$ASql = "Update tabunmedidas set unmedida = '" . $AUnMedida . "', " .
				" tipounmedida = '" . $ATipoUnMedida . "', " .
				" simbolo = '" . $ASimbolo . 
				" where codunmedida = " . $ACodUnMedida;
					
		if ($this->ExecSQL($ASql))
			return "[{\"retorno\":1}]";
		else
			return "[{\"retorno\":0," .
			"\"mensagem\":\"" . $this->getLastMessage() . "\"}]";
	}
	
	function getInsert(){
		
		$AUnMedida = $this->getParameter( "unmedida");
		$ATipoUnMedida = $this->getParameter( "tipounmedida");
		$ASimbolo = $this->getParameter( "simbolo");
		
		$ASql = "insert into tabunmedidas " .
				" (codunmedida, unmedida, tipounmedida, simbolo) " .
				"Values (" .
				"(" . $this->getFieldKeyMaxInSQL() . ")+1, " .
				"'" . $AUnMedida . "'," .
				      $ATipoUnMedida . "," .
				"'" . $ASimbolo . "'" .
				")";
		
		$ObjRet = new MensagemRetorno();
		if ($this->ExecSQL($ASql)) {
			$ObjRet->retorno = 1;
			$ObjRet->mensagem = "";
		}
		else {
			$ObjRet->retorno = 0;
			$ObjRet->mensagem = $this->getLastMessage();
		}
		return $this->getJSONFromObj($ObjRet);
	}
}
