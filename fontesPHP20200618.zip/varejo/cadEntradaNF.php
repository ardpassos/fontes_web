<?php

class cadEntradaNF extends cadBase {
	
	public $RowConfigGeral = [];
	
	
	function getTabela(){
		return "tabentradanf";
	}
	
	function getCampoChave(){
		return "codnf";
	}
	
	function getCampoValorParaFinanc(){
	  return "( ".
	 	  	 "   coalesce(tabentradanf.valorentrada, 0) + ".
	 	  	 "	 ( select sum(tnfp.valor) ". 
	 	  	 "  	 from tabnfentradaparcelas as tnfp ".
	 	  	 " 	    where tnfp.codnf = tabentradanf.codnf )" .
	 	  	 ")";	
	}
	
	function getCons() {
		$this->FSqlInitial = "Select tabentradanf.*, ".
							"  (select sum(ti.valortotal) ".
							"	  from tabentradanfitens ti " .
							"	 where ti.codnf = tabentradanf.codnf) as valoritens, ".
							"  case tabentradanf.tipopgto ".
							"      when 'V' then tabentradanf.valornf  " .
							"      else " . $this->getCampoValorParaFinanc() . 
							"  end as valorfinanc ".
							" from " . $this->getTabela();
		$this->addFieldDef($this->getCampoChave(), "C�d. NF", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("numnf", "N�m. NF", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("serienf", "S�rie NF", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("dataemissao", "Data Emiss�o", constCads::FIELD_DATE, "", "");
		$this->addFieldDef("dataentrada", "Data entrada", constCads::FIELD_DATE, "", "");
		$this->addFieldDef("valornf", "Valor NF", constCads::FIELD_FLOAT, "", "");
		$this->addFieldDef("tipopgto", "Tipo pgto", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("valorentrada", "Valor entrada", constCads::FIELD_FLOAT, "", "");
		$this->addFieldDef("numparcelas", "N�m. parcelas", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("statusnf", "Status", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("tiponf", "Tipo NF", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("codfornecedor", "C�d. fornecedor", constCads::FIELD_INTEGER, "", "");
		
		return parent::getCons();
	}
	
	function getConsLkp() {
		$this->FOrderBy = "  order by numnf";
		$this->FSqlInitial = "select codnf as codigo, numnf as descricao ".
				"  from tabentradanf ";
		$this->addFieldDef($this->getCampoChave(), "C�d. NF", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("numnf", "NF", constCads::FIELD_STRING, "", "");
		return parent::getConsLkp();
	}
	
	
	function getQueryItensNF($_ACodNF){
		$ASql = "select * from tabentradanfitens " .
				" where codnf = " . $_ACodNF . 
		        " order by codlcto ";
		$AQuery = $this->OpenSQLToResultSet($ASql);
		return $AQuery;
	}
	
	function ajustarEstoqueInsumo($_ACodItemGrade, $_AQtde){
		$ASql = "update tabinsumosgrade set qtdeestoque = coalesce(qtdeestoque, 0) + " . $_AQtde .
				" where coditem = " . $_ACodItemGrade;
		$this->ExecSQLSimple($ASql);
	} 
	
	function ajustarEstoqueTodosItens($_AQuery, $_AMult){ //$_AMult = 1 para adicionar no estoque, $_AMult=-1 para retirar do estoque
		while ($row = $_AQuery->fetch(PDO::FETCH_ASSOC)) {
			$this->ajustarEstoqueInsumo($row["coditemgrade"], $row["qtde"]*$_AMult);
		}
	}	
	
//integra��o com financeiro
	function getQueryParc($_ACodNF){
		$ASql = "select tp.*, tnf.codfornecedor, tnf.numnf, tnf.serienf ".
				"  from tabnfentradaparcelas tp " .
				"  join tabentradanf tnf " .
				"    on tnf.codnf = tp.codnf ".
				" where tp.codnf = " . $_ACodNF .
				" order by tp.codlcto ";
		$AQuery = $this->OpenSQLToResultSet($ASql);
		return $AQuery;
	}
	function gerarParcelaCP($_ARec, $_AParcNum){
		$ACad = new cadContasPagar($this->FConObj);
		$ACad->addFieldToInsert("numdoc", $_ARec["numnf"], "s");
		$ACad->addFieldToInsert("codpessoaconta", $_ARec["codfornecedor"], "i");
		$ACad->addFieldToInsert("datahoralcto", "current_date" , "d");
		$ACad->addFieldToInsert("datavcto", $_ARec["datavcto"], "d");
		$ACad->addFieldToInsert("valor", $_ARec["valor"], "f");
		$ACad->addFieldToInsert("obs", "Parcela " . $_AParcNum, "s");
		$ACad->addFieldToInsert("lancmanual", "N", "s");
		$ACad->addFieldToInsert("status", "A", "s");
		$ACad->addFieldToInsert("codnf", $_ARec["codnf"], "i");
		$ACad->addFieldToInsert("codcrd", $this->RowConfigGeral["codcrdcompras"], "i");
		return $ACad->insertFromIntegracao();
	}
	function gerarCP($_ACodNF){
		$AQueryParc = $this->getQueryParc($_ACodNF);
		$i = 0;
		while ($row = $AQueryParc->fetch(PDO::FETCH_ASSOC)) {
			$i += 1;
			$this->gerarParcelaCP($row, $i);
		}
	}

	
	function getQueryNF($_ACodNF){
		$ASql = "select tnf.* ".
				"  from tabentradanf tnf " .
				" where tnf.codnf = " . $_ACodNF;
		$AQuery = $this->OpenSQLToResultSet($ASql);
		return $AQuery;
	}
	
	function gerarLctoMovFinanc($_ARec){
		$ACad = new cadMovFinanc($this->FConObj);
		$ACad->addFieldToInsert("numdoc", $_ARec["numnf"], "s");
		$ACad->addFieldToInsert("codpessoaconta", $_ARec["codfornecedor"], "i");
		$ACad->addFieldToInsert("datahoralcto", "current_date" , "d");
		$ACad->addFieldToInsert("dataaprop", $_ARec["dataemissao"], "d");
		$ACad->addFieldToInsert("valor", $_ARec["valorentrada"], "f");
		$ACad->addFieldToInsert("obs", "Valor de entrada da NF: " . $_ARec["numnf"] . " - Parcelas restantes: " .  $_ARec["numparcelas"], "s");
		$ACad->addFieldToInsert("lancmanual", "N", "s");
		$ACad->addFieldToInsert("codnfentrada", $_ARec["codnf"], "i");
		$ACad->addFieldToInsert("entsai", "S", "s");
		$ACad->addFieldToInsert("codcrd", $this->RowConfigGeral["codcrdcompras"], "i");
		
		return $ACad->insertFromCRCP();
	}
	function gerarMovFinanc($_ACodNF){
		$AQueryParc = $this->getQueryNF($_ACodNF);
		while ($row = $AQueryParc->fetch(PDO::FETCH_ASSOC)) {
			$this->gerarLctoMovFinanc($row);
		}
	}	
	function setConfigGeralFinanc(){
		$ASql = "select * ".
				"  from tabconfigvarejo limit 1";
		$AQuery = $this->OpenSQLToResultSet($ASql);
		$this->RowConfigGeral = $AQuery->fetch(PDO::FETCH_ASSOC);
	}
	function gerarFinanceiro($_ACodNF){
		$this->setConfigGeralFinanc();
		$this->gerarMovFinanc($_ACodNF);
		$this->gerarCP($_ACodNF);
	}


	function zerarCP($_ACodNF){
		$ASql = "delete from tabcontaspagar ".
				"  where codnf = " . $_ACodNF;
		$AQuery = $this->ExecSQLSimple($ASql);
		return $AQuery;
	}
	function zerarMovFinanc($_ACodNF){
		$ASql = "delete from tabmovfinanc ".
				"  where codnfentrada = " . $_ACodNF;
		$AQuery = $this->ExecSQLSimple($ASql);
		return $AQuery;
	}
	function zerarFinanceiro($_ACodNF){
		$this->zerarMovFinanc($_ACodNF);
		$this->zerarCP($_ACodNF);
	}
	//fim da integra��o com financeiro
	
	function setStatusNF($_ACodNF, $_AStatusNF){
		$ASql = "update tabentradanf set statusnf = '" . $_AStatusNF . "'".
				" where codnf = " . $_ACodNF;
		$this->ExecSQLSimple($ASql);
	}
	
	function finalizaNF() {
		$ACodNF = $this->getParameterInt( "codnf");
		$AQueryItens = $this->getQueryItensNF($ACodNF);
		
		$this->FCon->beginTransaction();
		try {
			$this->ajustarEstoqueTodosItens($AQueryItens, 1);
			$this->gerarFinanceiro($ACodNF);
			$this->setStatusNF($ACodNF, constCads::CADV_ENTRADANF_STATUS_FECHADA);
			
			$this->FCon->commit();
			return $this->getReturnOk();
		} catch (Exception $e) {
			$this->logMe($e.getMessage());
			$this->FCon->rollBack();
			$this->FLastMessage = $e.getMessage();
			return $this->getReturnError($this->FLastMessage);
		}		
	}
	
	function reabrirNF() {
		$ACodNF = $this->getParameterInt( "codnf");
		$AQueryItens = $this->getQueryItensNF($ACodNF);
		
		$this->FCon->beginTransaction();
		try {
			$this->ajustarEstoqueTodosItens($AQueryItens, -1);
			$this->zerarFinanceiro($ACodNF);
			$this->setStatusNF($ACodNF, constCads::CADV_ENTRADANF_STATUS_ABERTA);
			
			$this->FCon->commit();
			return $this->getReturnOk();
		} catch (Exception $e) {
			$this->logMe($e.getMessage());
			$this->FCon->rollBack();
			$this->FLastMessage = $e.getMessage();
			return $this->getReturnError($this->FLastMessage);
		}
	}
	

	function getListStatusNF() {
		$this->Records = [];
		$ARec = [];
		$ARec["codigo"] = "A";
		$ARec["descricao"] = "Aberto";
		array_push($this->Records, $ARec);
		$ARec["codigo"] = "F";
		$ARec["descricao"] = "Fechado";
		array_push($this->Records, $ARec);
		$ARec["codigo"] = "C";
		$ARec["descricao"] = "Cancelado";
		array_push($this->Records, $ARec);
		return $this->getJSONRecords();
	}
	
	function getListTipoPgto() {
		$this->Records = [];
		$ARec = [];
		$ARec["codigo"] = constCads::CADV_FINANC_STATUS_AVISTA;
		$ARec["descricao"] = constCads::CADV_FINANC_STATUS_AVISTA_D;
		array_push($this->Records, $ARec);
		$ARec["codigo"] = constCads::CADV_FINANC_STATUS_APRAZO;
		$ARec["descricao"] = constCads::CADV_FINANC_STATUS_APRAZO_D;
		array_push($this->Records, $ARec);
		return $this->getJSONRecords();
	}
	
	function setParametersToFieldList(){
		$this->addInListFields("numnf", $this->getParameter( "numnf"), "s");
		$this->addInListFields("serienf", $this->getParameter( "serienf"), "s");
		$this->addInListFields("dataemissao", $this->getParameterDateTime( "dataemissao"), "d");
		$this->addInListFields("dataentrada", $this->getParameterDateTime( "dataentrada"), "d");
		$this->addInListFields("valornf", $this->getParameterFloat( "valornf"), "f");
		$this->addInListFields("tipopgto", $this->getParameter( "tipopgto"), "s");
		$this->addInListFields("valorentrada", $this->getParameterFloat( "valorentrada"), "f");
		$this->addInListFields("numparcelas", $this->getParameterInt( "numparcelas"), "i");
		$this->addInListFields("statusnf", $this->getParameter( "statusnf"), "s");
		$this->addInListFields("tiponf", $this->getParameter( "tiponf"), "s");
		$this->addInListFieldsFromParam("codfornecedor", "i");
	}
	
	function process($_AAction){
		$AResult = "";
		if (strcasecmp($_AAction, constCads::ACTION_ENTRADANF_LKP_STATUSNF) == 0) {
			$AResult = $this->getListStatusNF();
		}
		else if (strcasecmp($_AAction, constCads::ACTION_FINANC_LKP_TIPOPGTO) == 0) {
			$AResult = $this->getListTipoPgto();
		}
		else if (strcasecmp($_AAction, constCads::ACTION_ENTRADANF_FINALIZANF) == 0) {
			$AResult = $this->finalizaNF();
		}
		else if (strcasecmp($_AAction, constCads::ACTION_ENTRADANF_REABRIRNF) == 0) {
			$AResult = $this->reabrirNF();
		}
		else
			$AResult = parent::process($_AAction);
		return $AResult;
	}
	
}