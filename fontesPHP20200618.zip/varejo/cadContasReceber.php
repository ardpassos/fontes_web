<?php

class cadContasReceber extends cadBase {
	
	function getTabela(){
		return "tabcontasreceber";
	}
	
	function getCampoChave(){
		return "codcontareceber";
	}
	
	function getCons() {
		$this->FOrderBy = " order by datavcto";
		$this->FSqlInitial = "Select codcontareceber, numdoc, codpessoaconta, datahoralcto, datavcto, valor, obs, lancmanual, status, codcrd ".
				" from ". $this->getTabela();
		$this->addFieldDef($this->getCampoChave(), "C�d. conta receber", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("numdoc", "N�m doc.", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("codpessoaconta", "C�d. cliente", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("datahoralcto", "Data hora lcto", constCads::FIELD_DATE_TIME, "", "");
		$this->addFieldDef("datavcto", "Data vcto", constCads::FIELD_DATE, "", "");
		$this->addFieldDef("valor", "Valor", constCads::FIELD_FLOAT, "", "");
		$this->addFieldDef("obs", "Obs", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("lancmanual", "Lan. manual", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("status", "Status", constCads::FIELD_STRING, "", "");
		return parent::getCons();
	}
	
	function setParametersToFieldList(){
		$this->addInListFieldsFromParam("numdoc", "s");
		$this->addInListFieldsFromParam("codpessoaconta", "i");
		$this->addInListFieldsFromParam("datahoralcto", "dt");
		$this->addInListFieldsFromParam("datavcto", "d");
		$this->addInListFieldsFromParam("valor", "f");
		$this->addInListFieldsFromParam("obs", "s");
		$this->addInListFieldsFromParam("lancmanual", "s");
		$this->addInListFieldsFromParam("status", "s");
		$this->addInListFieldsFromParam("codcrd", "i");
	}
	
	function addFieldToInsert($_AFieldName, $_AFieldValue, $_AFieldType){
		$this->addInListFields($_AFieldName, $_AFieldValue, $_AFieldType);
	}
	
	function insertFromIntegracao(){
		$this->addInListFields($this->getCampoChave(), "(" . $this->getFieldKeyMaxInSQL() . ")+1 ", "i");
		
		$ASql = "insert into ".$this->getTabela()." (" .
				$this->getFieldsInsPostFieldNamesToIns() .
				") Values (" .
				$this->getFieldsInsPostFieldValuesToIns() .
				")";
				$this->logMe($ASql);
				$AExec = $this->ExecSQLSimple($ASql);
				$ObjRet = new MensagemRetorno();
				if ($AExec) {
					$ObjRet->setRetornoOK();
				}
				else {
					$ObjRet->setRetornoErro($this->getLastMessage());
				}
				$AResult = $this->getJSONMsgRetorno($ObjRet);
				return $AResult;
	}
	
	function getListStatus() {
		$this->Records = [];
		$ARec = [];
		$ARec["codigo"] = "A";
		$ARec["descricao"] = "Aberto";
		array_push($this->Records, $ARec);
		$ARec["codigo"] = "B";
		$ARec["descricao"] = "Baixado";
		array_push($this->Records, $ARec);
		$ARec["codigo"] = "I";
		$ARec["descricao"] = "Baixa iniciada";
		array_push($this->Records, $ARec);
		return $this->getJSONRecords();
	}
	
	function process($_AAction){
		$AResult = "";
		if (strcasecmp($_AAction, constCads::ACTION_CONTASRECEBER_LIST_STATUS) == 0) {
			$AResult = $this->getListStatus();
		}
		else
			$AResult = parent::process($_AAction);
		return $AResult;
	}
}