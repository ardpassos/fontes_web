<?php

class cadContasPagarLctos extends cadBase {
	
	function getTabela(){
		return "tabcontaspagarlctos";
	}
	
	function getCampoChave(){
		return "codlcto";
	}
	
	function getCons() {
		$this->FOrderBy = " order by codlcto";
		$this->FSqlInitial = "Select * ".
				" from ". $this->getTabela();
		$this->addFieldDef($this->getCampoChave(), "C�d. lcto", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("codcontapagar", "C�d. conta pagar", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("tipolcto", "Tipo lcto", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("datalcto", "Data vcto", constCads::FIELD_DATE, "", "");
		$this->addFieldDef("valor", "Valor", constCads::FIELD_FLOAT, "", "");
		return parent::getCons();
	}
	
	function setParametersToFieldList(){
		$this->addInListFieldsFromParam("codcontapagar", "i");
		$this->addInListFieldsFromParam("tipolcto", "s");
		$this->addInListFieldsFromParam("datalcto", "d");
		$this->addInListFieldsFromParam("valor", "f");
	}
	
	function getRecCR(){
		$ACodContaPagar = $this->getParameterInt("codcontapagar");
		$ASql = "Select * from tabcontaspagar ".
				" where codcontapagar = " . $ACodContaPagar;
		$AQuery = $this->OpenSQLToResultSet($ASql);
		return $AQuery->fetch(PDO::FETCH_ASSOC);
	}
	function efetuaLctoMovFinanc(){
		$ACodContaPagar = $this->getParameterInt("codcontapagar");
		$ACodLcto = $this->getParameterInt("codlcto");
		$ADataLcto = $this->getParameterDateTime("datalcto");
		$AValor = $this->getParameterFloat("valor");
		$ACR = $this->getRecCR();
		$ACad = new cadMovFinanc($this->FConObj);
		$ACad->addFieldToInsert("numdoc", $ACR["numdoc"], "s");
		$ACad->addFieldToInsert("codpessoaconta", $ACR["codpessoaconta"], "i");
		$ACad->addFieldToInsert("datahoralcto", $ADataLcto, "d");
		$ACad->addFieldToInsert("dataaprop", $ACR["datavcto"], "d");
		$ACad->addFieldToInsert("valor", $AValor, "f");
		$ACad->addFieldToInsert("obs", $ACR["obs"], "s");
		$ACad->addFieldToInsert("lancmanual", "N", "s");
		$ACad->addFieldToInsert("entsai", "S", "s");
		$ACad->addFieldToInsert("codcontapagar", $ACodContaPagar, "i");
		$ACad->addFieldToInsert("codlctocr", $ACodLcto, "i");
		$ACad->addFieldToInsert("codnfentrada", $ACR["codnf"], "i");
		return $ACad->insertFromCRCP();
	}
	function setStatusContaPagar($_AStatus){
		$ACodContaPagar = $this->getParameterInt("codcontapagar");
		$ASql = "update tabcontaspagar set status = '" . $_AStatus . "'" .
				" where codcontapagar = " . $ACodContaPagar;
		$this->ExecSQLSimple($ASql);
	}
	function setStatusContaPagarLcto($_AStatus){
		$ACodLcto = $this->getParameterInt("codlcto");
		$ASql = "update tabcontaspagarlctos set tipolcto = '" . $_AStatus . "'" .
				" where codlcto = " . $ACodLcto;
		$this->ExecSQLSimple($ASql);
	}
	function efetuaBaixaCR(){
		$AResult = "";
		$ObjRet = new MensagemRetorno();
		
		$this->FCon->beginTransaction();
		try {
			$this->efetuaLctoMovFinanc();
			$this->setStatusContaPagar("B");
			$this->setStatusContaPagarLcto("B");
			$ObjRet->setRetornoOK();
			
			$this->FCon->commit();
		} catch (Exception $e) {
			$this->logMe($e.getMessage());
			$this->FCon->rollBack();
			$this->FLastMessage = $e.getMessage();
			$ObjRet->setRetornoErro($this->FLastMessage);
		}
		$AResult = $this->getJSONMsgRetorno($ObjRet);
		return $AResult;
	}
	
	function excluirMovFinanc(){
		$ACodLcto = $this->getParameterInt("codlcto");
		$ASql = "delete from tabmovfinanc " .
				" where codlctocr = " . $ACodLcto;
		$this->ExecSQLSimple($ASql);
	}
	function efetuaEstornoCR(){
		$AResult = "";
		$ObjRet = new MensagemRetorno();
		
		$this->FCon->beginTransaction();
		try {
			$this->excluirMovFinanc();
			$this->setStatusContaPagar("A");
			$this->setStatusContaPagarLcto("E");
			$ObjRet->setRetornoOK();
			
			$this->FCon->commit();
		} catch (Exception $e) {
			$this->logMe($e.getMessage());
			$this->FCon->rollBack();
			$this->FLastMessage = $e.getMessage();
			$ObjRet->setRetornoErro($this->FLastMessage);
		}
		$AResult = $this->getJSONMsgRetorno($ObjRet);
		return $AResult;
	}
	
	function ultimoLctoEhBaixa($_ACodContaPagar){
		$ASql = "Select count(*) as numrec from tabcontaspagarlctos ".
				" where codcontapagar = " . $_ACodContaPagar .
				"   and tipolcto in ('I', 'B')  " . //se tiver estorno, o B se tornar� E
				" order by codlcto desc ";
		$AQuery = $this->OpenSQLToResultSet($ASql);
		$AResult = false;
		$row = $AQuery->fetch(PDO::FETCH_ASSOC);
		if (isset($row)){
			$AResult = $row["numrec"] > 0;
		}
		return $AResult;
	}
	
	function getValorAbertoConta(){
		$ACodContaPagar = $this->getParameterInt("codcontapagar");
		$ASql = "Select * from tabcontaspagar ".
				" where codcontapagar = " . $ACodContaPagar;
		$AQuery = $this->OpenSQLToResultSet($ASql);
		$AResult = 0.00;
		$row = $AQuery->fetch(PDO::FETCH_ASSOC);
		if (isset($row)){
			$AResult = $row["valor"];
		}
		return $AResult;
	}
	
	function getInsertStm($_AInTrans = false){
		$ACodContaPagar = $this->getParameterInt("codcontapagar");
		$ASql = "insert into ".$this->getTabela()." (" .
				" codlcto, codcontapagar, datalcto, tipolcto, valor " .
				") Values ((" .
				$this->getFieldKeyMaxInSQL() . ")+1, " .
				$ACodContaPagar . ", " .
				"current_date, " .
				"'I', " .
				$this->getValorAbertoConta() .
				")";
				
				$AExec = $this->ExecSQLSimple($ASql);
				$ObjRet = new MensagemRetorno();
				if ($AExec) {
					$ObjRet->setRetornoOK();
				}
				else {
					$ObjRet->setRetornoErro($this->getLastMessage());
				}
				$AResult = $this->getJSONMsgRetorno($ObjRet);
				return $AResult;
	}
	
	function comecarBaixaCR(){
		$ACodContaPagar = $this->getParameterInt("codcontapagar");
		$AResult = "";
		
		if ($this->ultimoLctoEhBaixa($ACodContaPagar)) {
			$this->FLastMessage = "Existe uma baixa pendente para ser finalizada!";
			$AResult = $this->getMsgReturnLastError(2);
		}
		else {
			$this->FCon->beginTransaction();
			try {
				$AResult = $this->getInsertStm(true);
				$this->setStatusContaPagar("I");
				
				$this->FCon->commit();
			} catch (Exception $e) {
				$this->logMe($e.getMessage());
				$this->FCon->rollBack();
				$this->FLastMessage = $e.getMessage();
				$AResult = $this->getMsgReturnLastError();
			}
		}
		return $AResult;
	}
	
	function getListStatus() {
		$this->Records = [];
		$ARec = [];
		$ARec["codigo"] = "I";
		$ARec["descricao"] = "Baixa inicializada";
		array_push($this->Records, $ARec);
		$ARec["codigo"] = "B";
		$ARec["descricao"] = "Baixado";
		array_push($this->Records, $ARec);
		$ARec["codigo"] = "E";
		$ARec["descricao"] = "Estornado";
		array_push($this->Records, $ARec);
		return $this->getJSONRecords();
	}
	
	function process($_AAction){
		$AResult = "";
		if (strcasecmp($_AAction, constCads::ACTION_CONTASPAGARLCTOS_LIST_TIPO) == 0) {
			$AResult = $this->getListStatus();
		}
		else if (strcasecmp($_AAction, constCads::ACTION_CONTASPAGARLCTOS_COMECAR_BAIXA) == 0) {
			$AResult = $this->comecarBaixaCR();
		}
		else if (strcasecmp($_AAction, constCads::ACTION_CONTASPAGARLCTOS_ESTORNO_BAIXA) == 0) {
			$AResult = $this->efetuaEstornoCR();
		}
		else if (strcasecmp($_AAction, constCads::ACTION_CONTASPAGARLCTOS_BAIXA) == 0) {
			$AResult = $this->efetuaBaixaCR();
		}
		else
			$AResult = parent::process($_AAction);
			return $AResult;
	}
}