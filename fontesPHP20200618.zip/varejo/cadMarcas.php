<?php

class cadMarcas extends cadBase {
	
	function getTabela(){
		return "tabmarcas";
	}
	
	function getCampoChave(){
		return "codmarca";
	}
	
	function getCons() {
		$this->FSqlInitial = "Select * from ". $this->getTabela();
		$this->addFieldDef($this->getCampoChave(), "C�d. Marca", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("marca", "marca", constCads::FIELD_STRING, "", "");
		return parent::getCons();
	}
	
	function getConsLkp() {
		$this->FOrderBy = "  order by marca";
		$this->FSqlInitial = "select codmarca as codigo, marca as descricao ".
				"  from tabmarcas ";
		$this->addFieldDef($this->getCampoChave(), "C�d. Marca", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("marca", "Marca", constCads::FIELD_STRING, "", "");
		return parent::getConsLkp();
	}
	
	function getPost(){
		$ACodMarca = $this->getParameterInt( "codmarca");
		$AMarca = $this->getParameter( "marca");
		
		$ASql = "Update tabmarcas set marca = '" . $AMarca . "' " .
				" where codmarca = " . $ACodMarca;
		
		if ($this->ExecSQL($ASql))
			return "[{\"retorno\":1}]";
		else
			return "[{\"retorno\":0," .
			    	"\"mensagem\":\"" . $this->getLastMessage() . "\"}]";
	}
	
	function getInsert(){
		$AMarca = $this->getParameter( "marca");
		
		$ASql = "insert into tabmarcas " .
				" (codmarca, marca) " .
				"Values (" .
				"(" . $this->getFieldKeyMaxInSQL() . ")+1, " .
				"'" . $AMarca . "'" .
				")";
				
		$ObjRet = new MensagemRetorno();
		if ($this->ExecSQL($ASql)) {
			$ObjRet->retorno = 1;
			$ObjRet->mensagem = "";
		}
		else {
			$ObjRet->retorno = 0;
			$ObjRet->mensagem = $this->getLastMessage();
		}
		return $this->getJSONFromObj($ObjRet);
	}
}