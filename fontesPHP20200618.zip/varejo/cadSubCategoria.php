<?php

class cadSubCategoria extends cadBase {
	
	function getTabela(){
		return "tabsubcategoria";
	}
	
	function getCampoChave(){
		return "codsubcategoria";
	}
	
	function getCons() {
		$this->FSqlInitial = "Select * from ". $this->getTabela();
		$this->addFieldDef($this->getCampoChave(), "C�d. Sub Categoria", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("categoria", "Sub Categoria", constCads::FIELD_STRING, "", "");
		return parent::getCons();
	}
	
	function getConsLkp() {
		$this->FOrderBy = "  order by subcategoria";
		$this->FSqlInitial = "select codsubcategoria as codigo, subcategoria as descricao ".
				"  from tabsubcategoria ";
		return parent::getConsLkp();
	}
	
	function setParametersToFieldList(){
		$this->addInListFieldsFromParam("subcategoria", "s");
	}
	
}