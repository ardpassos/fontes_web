<?php
class cadProdutoImgs extends cadBase {
	
	function getTabela(){
		return "tabprodutoimgs";
	}
	
	function getCampoChave(){
		return "codimg";
	}
	
	function getCons() {
		// n�o pode retornar o img nesta consulta, pois � um longblob, n�o suportado no array dos dados
		$this->FOrderBy = "order by codproduto, codimg";
		$this->FSqlInitial = "Select codimg, codproduto, '' as img, '' as selectedfile from ". $this->getTabela();
		$this->addFieldDef($this->getCampoChave(), "C�d. Img", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("codprogudo", "C�d. Produto", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("img", "Img", constCads::FIELD_BLOB, "", "");
		return parent::getCons();
	}
	
	function getImg() {
		$ACodImg =  $this->getParameterInt("codimg");
		$this->FSqlInitial = "Select codimg, codproduto, img from ". $this->getTabela() .
		                     " where codimg = " . $ACodImg;
		$AQuery = $this->OpenSQLToResultSet($this->FSqlInitial);
		if ($row = $AQuery->fetch(PDO::FETCH_ASSOC)) {
			header('Content-Type: jpg');
			echo $row["img"];
		}		 
	}
	
	function setParametersToFieldList(){
		$this->addInListFieldsFromParam("codimg", "i");
		$this->addInListFieldsFromParam("codproduto", "i");
		$this->addInListFieldsFromParam("img", "b");
	}
	
	function bindParams($AQuery){// chamado pelo ExecSQL()
	
		$ACodProduto = $_POST["codproduto"];
		$this->logGlobalExec_Con("cod produto " . $ACodProduto);
		$AImg = $_FILES["img"];
		$AFileName = $AImg['tmp_name'] . '.jpg';
		
		$this->logGlobalExec_Con($AFileName);
		
		if (move_uploaded_file($AImg['tmp_name'], $AFileName)) {
			$this->logGlobalExec_Con("Arquivo v�lido e enviado com sucesso.\n");
			
		
			$this->logGlobalExec_Con($AImg['tmp_name']);
			$AImgBlob = file_get_contents($AFileName);
			$this->logGlobalExec_Con("chamou bindparams 2 ");
			
			
			$AQuery->bindParam(':codproduto', $ACodProduto, PDO::PARAM_INT);
			$AQuery->bindParam(':img', $AImgBlob, PDO::PARAM_LOB);
		}
		

	}
	
	function getInsert(){		
		$ASql = "insert into ".$this->getTabela()." (codimg, codproduto, img) Values (" .
				"(" . $this->getFieldKeyMaxInSQL() . ")+1, " .
				":codproduto, " .
				":img " .
				")";
		
		$ObjRet = new MensagemRetorno();
		if ($this->ExecSQL($ASql, true)) {
			$ObjRet->retorno = 1;
			$ObjRet->mensagem = "";
		}
		else {
			$ObjRet->retorno = 0;
			$ObjRet->mensagem = $this->getLastMessage();
		}
		return $this->getJSONFromObj($ObjRet);
	}
	
	function process($_AAction){
		$AResult = "";
		if (strcasecmp($_AAction, constCads::ACTION_PRODUTOIMGS_LKP_GET_IMG) == 0) {
			$AResult = $this->getImg();
		}
		else
			$AResult = parent::process($_AAction);
		return $AResult;
	}
	
}