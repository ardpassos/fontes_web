<?php

class cadUsuarioVEnd extends cadBase {
	
	function getTabela(){
		return "tabusuariovend";
	}
	
	function getCampoChave(){
		return "codend";
	}
	
	function getCons() {
		$this->FOrderBy = " order by codend";
		$this->FSqlInitial = "Select codend, cep, cidade, uf, rua, numero, complemento, bairro ".
				" from tabusuariovend ";
		return parent::getCons();
	}
	
	function setParametersToFieldList(){
		$this->addInListFieldsFromParam("cep", "s");
		$this->addInListFieldsFromParam("cidade", "s");
		$AUF = $this->getParameter("uf");
		if (strlen($AUF) > 2){
		  $AUF = substr($AUF, 1, 2);
		}
		$this->addInListFields("uf", $AUF, "s");
	
		$this->addInListFieldsFromParam("rua", "s");
		$this->addInListFieldsFromParam("numero", "i");
		$this->addInListFieldsFromParam("complemento", "s");
		$this->addInListFieldsFromParam("bairro", "s");
	}

}