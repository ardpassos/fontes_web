<?php

class consprodutos extends cadBase {
	
	function getTabela(){
		return "tabinsumos";
	}
	
	function getCampoChave(){
		return "codinsumo";
	}
	
	function getSubSelectQtdeEstoque(){
		return "(select Coalesce(sum(tig.qtdeestoque), 0) from tabinsumosgrade tig " .
				" where tig.codinsumo = ti.codinsumo " .
		       ")";
	}
	
	function getArrayGrade($_ACodInsumo){
		$ASql = "select tig.*, tc.cor, tc.refhexa ".
				"  from tabinsumosgrade tig " .
				"  left join tabcores tc " .
				"    on tc.codcor = tig.codcor " .
				" where tig.codinsumo = " . $_ACodInsumo .
				" order by tc.cor ";
		$AQuery = $this->OpenSQLToResultSet($ASql);
		$ARecords = [];
		$i = 0;
		while ($row = $AQuery->fetch(PDO::FETCH_ASSOC)) {
			if ($i == 0){
				$row['qtdeadd'] = 1;
			}
			else{
				$row['qtdeadd'] = 0;
			}
			array_push($ARecords, $row);
			$i += 1;
		}
		
		return $ARecords;
	}
	
	function getArrayImgs($_ACodInsumo){
		$ASql = "select tpi.codimg, tpi.codproduto ".
				"  from tabprodutoimgs tpi " .
				" where tpi.codproduto = " . $_ACodInsumo .
				" order by tpi.codimg ";
		$AQuery = $this->OpenSQLToResultSet($ASql);
		$ARecords = [];
		$i = 0;
		while ($row = $AQuery->fetch(PDO::FETCH_ASSOC)) {
			array_push($ARecords, $row);
			$i += 1;
		}
		
		return $ARecords;
	}
	
	
	function FillProdutosComGrades($_AQuery){
		try {
			$this->clearRecords();
			while ($row = $_AQuery->fetch(PDO::FETCH_ASSOC)) {
				$row["mostrargrade"] = "N";
				$row["grade"] = $this->getArrayGrade($row["codinsumo"]);
				$row["imgs"] = $this->getArrayImgs($row["codinsumo"]);
				$this->AddRecord($row);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}
	
	function getCons() {
		$this->FSqlInitial = "Select " .
									 $this->getSubSelectQtdeEstoque() . " as qtdeestoque, " .
							 "       ti.codinsumo, ti.insumo, ti.obs, " . 
							 "       ti.codgrupo, tg.grupo, " . 
							 "       ti.codmarca, tm.marca, " . 
							 "       ti.codbarras, ti.genero, ti.tamanho, " .
							 "       ti.codfaixaetaria, tfe.faixaetaria, ".
							 "       ti.codcategoria, tcat.categoria, ".
							 "       ti.codsubcategoria, tsubcat.subcategoria, " . 
							 "       1 as qtdeadd " .
							 " from tabinsumos ti " . 

							 " left join tabgrupos tg " .
							 "   on tg.codgrupo = ti.codgrupo " .
							 " left join tabmarcas tm " .
							 "   on tm.codmarca = ti.codmarca " .
							 " left join tabfaixasetarias tfe " .
							 "   on tfe.codfaixaetaria = ti.codfaixaetaria " .
							 " left join tabcategorias tcat " .
							 "   on tcat.codcategoria = ti.codcategoria " .
							 " left join tabsubcategoria tsubcat " .
							 "   on tsubcat.codsubcategoria = ti.codcategoria " .
							 " where ti.codinsumo > 0 " .
							 "   and " . $this->getSubSelectQtdeEstoque() . "  > 0 ";
		 if (isset($_GET["codinsumo"])){
		 	$this->FSqlInitial .= " and ti.codinsumo = " . $_GET["codinsumo"];
		 }
		 if (isset($_GET["codcategoria"])){
			$this->FSqlInitial .= " and ti.codcategoria = " . $_GET["codcategoria"];
		}
		if (isset($_GET["codsubcategoria"])){
			$this->FSqlInitial .= " and ti.codsubcategoria = " . $_GET["codsubcategoria"];
		}
		if (isset($_GET["filtrotext"])){
			$this->FSqlInitial .= " and ((ti.insumo like '%" . $_GET["filtrotext"] . "%') " .
								  "      or (ti.obs like '%" . $_GET["filtrotext"] . "%') )";
		}
		if (isset($_GET["genero"])){
			$this->FSqlInitial .= " and ti.genero = '" . $_GET["genero"] . "' " ;
		}
		if (isset($_GET["promocao"])){
			$this->FSqlInitial .= " and (Select sum(1) " .
								"          from tabinsumosgrade tig " .
								"         where tig.codinsumo = ti.codinsumo " .
								"           and tig.itemempromocao = 's' " .
								"           and tig.qtdeestoque > 0 ) > 0 ";
		}
		
		if (isset($_GET["ordem"])){
			if ($_GET["ordem"] == "va") {
				$this->FSqlInitial .= " order by 1 ";
			} 
			else {
				$this->FSqlInitial .= " order by 1 desc ";
			}
		}
		$AQuery = $this->OpenSQLToResultSet($this->FSqlInitial);
		$this->FillProdutosComGrades($AQuery);
		return $this->getJSONRecords();
	}
	
	function getConsLkp() {
		$this->FOrderBy = "  order by insumo";
		$this->FSqlInitial = "select codinsumo as codigo, insumo as descricao ".
				"  from tabinsumos ";
		$this->addFieldDef($this->getCampoChave(), "C�d. Produto", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("insumo", "Produto", constCads::FIELD_STRING, "", "");
		return parent::getConsLkp();
	}
	
	function getImg(){
		$ACodImg =  $this->getParameterInt("codimg");
		$this->FSqlInitial = "Select codimg, codproduto, img  from tabprodutoimgs " . 
							 " where codimg = " . $ACodImg;
		$AQuery = $this->OpenSQLToResultSet($this->FSqlInitial);
		if ($row = $AQuery->fetch(PDO::FETCH_ASSOC)) {
			header('Content-Type: jpg');
			echo $row["img"];
		}	
	}
	
	function process($_AAction){
		$AResult = "";
		if (strcasecmp($_AAction, constCads::ACTION_CONSPRODUTOS_GETIMG) == 0) {
			$AResult = $this->getImg();
		}
		else {
			$AResult = parent::process($_AAction);
			return $AResult;
		}
	}
	
}