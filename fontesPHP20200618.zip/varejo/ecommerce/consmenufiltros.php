<?php

class consmenufiltros extends cadBase {
	
	function getTabela(){
		return "tabcategorias";
	}
	
	function getCampoChave(){
		return "codcategoria";
	}
	
	function getCons() {
		$this->FSqlInitial = "Select * from ". $this->getTabela();
		$this->addFieldDef($this->getCampoChave(), "C�d. Categoria", constCads::FIELD_INTEGER, "", "");
		return parent::getCons();
	}
	
	function getSubCategorias(){
		$ACodCateg =  $this->getParameterInt("codcategoria");
		$this->FSqlInitial = "select distinct tsc.codsubcategoria, tsc.subcategoria ".
							"  from tabinsumos ti " .
							"  join tabcategorias tc " .
							"    on tc.codcategoria = ti.codcategoria " .
							"  join tabsubcategoria tsc " .
							"    on tsc.codsubcategoria = ti.codsubcategoria " .
							" where ti.codcategoria = " . $ACodCateg .
							" order by tsc.subcategoria";
		
		$AQuery = $this->OpenSQLToResultSet($this->FSqlInitial);
		$this->FillDataCons($AQuery);
		
		return $this->getJSONRecords();
	}
	
	function getCategPromocoes($_AMF){
		$this->FSqlInitial = "select distinct tc.codcategoria, tc.categoria ".
				"  from tabinsumos ti " .
				"  join tabcategorias tc " .
				"    on tc.codcategoria = ti.codcategoria " .
				" where ti.genero = '" . $_AMF . "' " .
				"	and (Select sum(1) " . 
				"          from tabinsumosgrade tig " .
				"         where tig.codinsumo = ti.codinsumo " .
				"           and tig.itemempromocao = 's' " .
				"           and tig.qtdeestoque > 0 ) > 0 " .
				" order by tc.categoria";
		
		$AQuery = $this->OpenSQLToResultSet($this->FSqlInitial);
		$this->FillDataCons($AQuery);
		
		return $this->getJSONRecords();
	}
	
	function getCategGenero($_AMF){
		$this->FSqlInitial = "select distinct tc.codcategoria, tc.categoria ".
				"  from tabinsumos ti " .
				"  join tabcategorias tc " .
				"    on tc.codcategoria = ti.codcategoria " .
				" where ti.genero = '" . $_AMF . "' " .
				" order by tc.categoria";
		
		$AQuery = $this->OpenSQLToResultSet($this->FSqlInitial);
		$this->FillDataCons($AQuery);
		
		return $this->getJSONRecords();
	}
	
	function process($_AAction){
		$AResult = "";
		if (strcasecmp($_AAction, constCads::ACTION_CONSMENUFILTROS_GETCATEGORIAS) == 0) {
			$AResult = parent::process($_AAction);
		}
		else if (strcasecmp($_AAction, constCads::ACTION_CONSMENUFILTROS_GETSUBCATEGORIAS) == 0) {
			$AResult = $this->getSubCategorias();
		}
		else if (strcasecmp($_AAction, constCads::ACTION_CONSMENUFILTROS_GETCATEGPROMOCOESHOMEM) == 0) {
			$AResult = $this->getCategPromocoes("M");
		}
		else if (strcasecmp($_AAction, constCads::ACTION_CONSMENUFILTROS_GETCATEGPROMOCOESMULHER) == 0) {
			$AResult = $this->getCategPromocoes("F");
		}
		else if (strcasecmp($_AAction, constCads::ACTION_CONSMENUFILTROS_GETCATEGHOMEM) == 0) {
			$AResult = $this->getCategGenero("M");
		}
		else if (strcasecmp($_AAction, constCads::ACTION_CONSMENUFILTROS_GETCATEGMULHER) == 0) {
			$AResult = $this->getCategGenero("F");
		}
		else {
			$AResult = parent::process($_AAction);
		}
		return $AResult;
	}
}