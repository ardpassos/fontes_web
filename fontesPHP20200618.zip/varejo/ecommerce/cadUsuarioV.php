<?php

class cadUsuarioV extends cadBase {
	
	function getTabela(){
		return "tabusuariov";
	}
	
	function getCampoChave(){
		return "codusuario";
	}
	
	function getCons() {
		$this->FOrderBy = " order by nomeusuario";
		$this->FSqlInitial = "Select codusuario, nomeusuario, usuario, senha, celular, cep, cidade, rua, numero, complemento, bairro ".
				" from tabusuariov ";
		return parent::getCons();
	}
	
	function setParametersToFieldList(){
		$this->addInListFieldsFromParam("nomeusuario", "s");
		$this->addInListFieldsFromParam("usuario", "s");
		$this->addInListFieldsFromParam("senha", "s");
		$this->addInListFieldsFromParam("celular", "s");
		$this->addInListFieldsFromParam("cep", "s");
		$this->addInListFieldsFromParam("cidade", "s");
		$this->addInListFieldsFromParam("rua", "s");
		$this->addInListFieldsFromParam("numero", "s");
		$this->addInListFieldsFromParam("complemento", "s");
		$this->addInListFieldsFromParam("bairro", "s");
	}
	
	function getQtdeCarrinhoAtualizada($_ACodUsusario){
		
		$ASql = "select sum(tic.qtde) as qtde " .
				"    from tabitenscarrinho tic " .
				"   where tic.codusuario = " . $_ACodUsusario .
				"     and (tic.pedidogerado is null or tic.pedidogerado = 'n') ";
		$AQuery = $this->OpenSQLToResultSet($ASql);
		$AQtde = 0;
		while ($row = $AQuery->fetch(PDO::FETCH_ASSOC)) {
			$AQtde = $row['qtde'];
		}
		return $AQtde;
	}
	
	function setSessionLogin($_ARec){
		if ($_ARec != null) {
			if (!isset($_SESSION)){
				session_start();
			}
			$_SESSION['codfuncionario'] = $_ARec["codfuncionario"];
			$_SESSION['nomefuncionario'] = $_ARec["nomefuncionario"];
			$_SESSION['codusuario_site'] = $_ARec["codusuario"];
			$_SESSION['nomeusuario_site'] = $_ARec["nomeusuario"];
			$_SESSION['usuario_site'] = $_ARec["usuario"];
			$_SESSION['senha_site'] = $_ARec["senha"];
			/*$_SESSION['celular_site'] = $_ARec["celular"];
			$_SESSION['cep_site'] = $_ARec["cep"];
			$_SESSION['cidade_site'] = $_ARec["cidade"];
			$_SESSION['rua_site'] = $_ARec["rua"];
			$_SESSION['numero_site'] = $_ARec["numero"];
			$_SESSION['complemento_site'] = $_ARec["complemento"];
			$_SESSION['bairro_site'] = $_ARec["bairro"];*/
			$_SESSION['qtde_carrinho'] = $_ARec["qtdecarrinho"];
		}
	}    
	
	function limparSessao($_ALimparVendedor = false){
		if ($_ALimparVendedor){
			$_SESSION['codfuncionario'] = -1;
			$_SESSION['nomefuncionario'] = "";
		}
		$_SESSION['codusuario_site'] = 0;
		$_SESSION['nomeusuario_site'] = "";
		$_SESSION['usuario_site'] = "";
		$_SESSION['senha_site'] = "";
		/*$_SESSION['celular_site'] = "";
		$_SESSION['cep_site'] = "";
		$_SESSION['cidade_site'] = "";
		$_SESSION['rua_site'] = "";
		$_SESSION['numero_site'] = "";
		$_SESSION['complemento_site'] = "";
		$_SESSION['bairro_site'] = "";*/
		$_SESSION['qtde_carrinho'] = 0;
	}
	function getSessionLogado($_ALimparSessao = false, $_ALimparSessaoVendedor = false){
		$ARec = [];
		if (!isset($_SESSION)){
			session_start();
		}
		if (isset($_SESSION['codusuario_site'])){
			if ($_ALimparSessao){
				$this->limparSessao($_ALimparSessaoVendedor);
			}
			$ARec['codfuncionario'] = $_SESSION['codfuncionario'];
			$ARec['nomefuncionario'] = $_SESSION['nomefuncionario'];
			
			$ARec['codusuario'] = $_SESSION['codusuario_site'];
			$ARec['nomeusuario'] = $_SESSION['nomeusuario_site'];
			$ARec['usuario'] = $_SESSION['usuario_site'];
			$ARec['senha'] = $_SESSION['senha_site'];
/*			$ARec['celular'] = $_SESSION['celular_site'];
			$ARec['cep'] = $_SESSION['cep_site'];
			$ARec['cidade'] = $_SESSION['cidade_site'];
			$ARec['rua'] = $_SESSION['rua_site'];
			$ARec['numero'] = $_SESSION['numero_site'];
			$ARec['complemento'] = $_SESSION['complemento_site'];
			$ARec['bairro'] = $_SESSION['bairro_site'];*/
			$_SESSION['qtde_carrinho'] = $this->getQtdeCarrinhoAtualizada($ARec['codusuario']);
			$ARec['qtdecarrinho'] = $_SESSION['qtde_carrinho'];
		}
		$this->clearRecords();
		$this->AddRecord($ARec);
		return $this->getJSONRecords();
	}
	
	function getFieldSessionValue($_AFieldSession, $_AType="s"){
		if (!isset($_SESSION)){
			session_start();
		}
		if ($_AType == "i"){
			$AValor = "-1";
		}
		else{
			$AValor = '';
		}
		
		if (isset($_SESSION[$_AFieldSession])){
			$AValor = $_SESSION[$_AFieldSession];
		}
		
		return $AValor;
	}
	function getSqlVendedor($AUser, $ASenha){
		$ASql = "Select tf.codfuncionario, " .
				"       tf.nome as nomefuncionario, " .
						$this->getFieldSessionValue('codusuario', 'i') . " as codusuario, " .
				"		'".	$this->getFieldSessionValue('nomeusuario') . "' as nomeusuario, " .
				"		'".	$this->getFieldSessionValue('suario') . "' as usuario, " .
				"		'".	$this->getFieldSessionValue('senha') . "' as senha, " .
				" (select sum(tic.qtde) " .
				"    from tabitenscarrinho tic " .
				"   where tic.codusuario = " . $this->getFieldSessionValue('codusuario', "i") .
				"     and (tic.pedidogerado is null or tic.pedidogerado = 'n') ".
				" ) as qtdecarrinho " .
				"  from tabfuncionarios tf " .
				" where tf.apelidofunc = '" . $AUser . "' " .
				"   and tf.senha = '" . $ASenha . "' " .
				" limit 1";
		return $ASql;
	}
	
	function getSqlUserSite($AUser, $ASenha){
		$ASql = "Select " . $this->getFieldSessionValue('codfuncionario', "i") . " as codfuncionario, " .
				"		'".	$this->getFieldSessionValue('nomefuncionario') . "' as nomefuncionario, " .
				"       tu.*, " .
				" (select sum(tic.qtde) " .
				"    from tabitenscarrinho tic " .
				"   where tic.codusuario = tu.codusuario " .
				"     and (tic.pedidogerado is null or tic.pedidogerado = 'n') ".
				" ) as qtdecarrinho " .
				"  from tabusuariov tu " .
				" where tu.usuario = '" . $AUser . "' " .
				"   and tu.senha = '" . $ASenha . "' " .
				" limit 1";
		return $ASql;
	}
	function getLoginSite(){
		$AUsuario = $this->getParameter("usuario");
		$ASenha = $this->getParameter("senha");
		$ASql = "";
		$AStm = "";
		if (strlen($AUsuario)>=2){
			$AStm = strtolower(substr($AUsuario, 0, 2));
		}
		if ($AStm == "v:"){
			$AUser = substr($AUsuario, 2, strlen($AUsuario)-2);
			$ASql = $this->getSqlVendedor($AUser, $ASenha);
		}
		else {
			$ASql = $this->getSqlUserSite($AUsuario, $ASenha);
		}
		
		$AQuery = $this->OpenSQLToResultSet($ASql);
		$this->clearRecords();
		while ($row = $AQuery->fetch(PDO::FETCH_ASSOC)) {
			$this->setSessionLogin($row);			
			$this->AddRecord($row);
		}
		return $this->getJSONRecords();
	}
	
	function getUsuariosSite() {
		$this->FSqlInitial = "Select * from tabusuariov " .
							 " order by nomeusuario ";
		
		return parent::getCons();
	}
	
	function process($_AAction){
		$AResult = "";
		if (strcasecmp($_AAction, constCads::CADV_CADUSUARIO_VAREJO_LOGIN_SITE) == 0) {
			$AResult = $this->getLoginSite();
		}
		else if (strcasecmp($_AAction, constCads::CADV_CADUSUARIO_VAREJO_SESSION_LOGADO) == 0) {
			$AResult = $this->getSessionLogado();
		}
		else if (strcasecmp($_AAction, constCads::CADV_CADUSUARIO_VAREJO_EXIT_SESSION_LOGADO) == 0) {
			$AResult = $this->getSessionLogado(true, false);
		}
		else if (strcasecmp($_AAction, constCads::CADV_CADUSUARIO_VAREJO_EXIT_SESSION_LOGADO_VENDEDOR) == 0) {
			$AResult = $this->getSessionLogado(true, true);
		}
		else if (strcasecmp($_AAction, constCads::CADV_CADUSUARIO_VAREJO_USUARIOS_SITE) == 0) {
			$AResult = $this->getUsuariosSite();
		}
		else
			$AResult = parent::process($_AAction);
			return $AResult;
	}
}