<?php

class cadItensCarrinho extends cadBase {
	
	function getTabela(){
		return "tabitenscarrinho";
	}
	
	function getCampoChave(){
		return "coditem";
	}
	
	function getSqlFirsImage(){
		return "(select min(tpimg.codimg) from tabprodutoimgs tpimg " .
				" where tpimg.codproduto = ti.codinsumo ) as codimg ";
	}
	
	function getCons() {
		$this->FSqlInitial = "Select tic.*, tig.*, tc.*, ti.genero, " . $this->getSqlFirsImage() . 
							 " from tabitenscarrinho tic " .
							 "  join tabinsumosgrade tig " .
							 "    on tig.coditem = tic.coditemgrade " .
							 "  join tabinsumos ti " .
							 "    on ti.codinsumo = tig.codinsumo " .
							 "  join tabcores tc " .
							 "    on tc.codcor = tig.codcor " .
							 " where tic.coditemgrade > 0 " .
							 "   and tic.qtde > 0 ".
							 "   and (tic.pedidogerado is null or tic.pedidogerado = 'n') ";
		if (isset($_GET["codusuario"])){
			$this->FSqlInitial .= " and tic.codusuario = " . $_GET["codusuario"];
		}
		else{
			$this->FSqlInitial .= " and tic.coditemgrade < 0"; // for�a a n�o trazer nada
		}
		$this->FOrderBy = " order by tic.coditemgrade, tic.datahora ";
		
		return parent::getCons();
	}
	
	function getSqlCaseValorVenda(){
		return  " case ".
				"    when tig.mostrarvalorsite = 's' then tig.valorvenda " .
				"    else 0.0 " .
				" end ";
	}
	
	function getConsResumo() {
		$this->FSqlInitial = "Select sum(coalesce(tic.qtde,0) * coalesce(" . $this->getSqlCaseValorVenda() . ", 0) ) as valortotal, ". 
							"        coalesce(sum(tic.qtde), 0) as qtde ".
							"  from tabitenscarrinho tic " .
							"  join tabinsumosgrade tig " .
							"    on tig.coditem = tic.coditemgrade " .
							"  join tabinsumos ti " .
							"    on ti.codinsumo = tig.codinsumo " .
							" where tic.coditemgrade > 0 " .
							"   and tic.qtde > 0 ".
							"   and (tic.pedidogerado is null or tic.pedidogerado = 'n') ";
		if (isset($_GET["codusuario"])){
			$this->FSqlInitial .= " and tic.codusuario = " . $_GET["codusuario"];
		}
		else{
			$this->FSqlInitial .= " and tic.coditemgrade < 0"; // for�a a n�o trazer nada
		}
		$this->FOrderBy = " order by tic.coditemgrade, tic.datahora ";
		
		return parent::getCons();
	}
	
	function setParametersToFieldList(){
		$this->addInListFieldsFromParam("codusuario", "i");
		$this->addInListFieldsFromParam("coditemgrade", "i");
		$this->addInListFieldsFromParam("qtde", "i");
		$this->addInListFields("datahora", "current_timestamp", "dt");
	}
	
	function getQtdeCarrinhoByItem($_ACodUsuario, $_ACodItemGrade){		
		$ASql = "select sum(tic.qtde) as qtde " .
				"    from tabitenscarrinho tic " .
				"   where tic.codusuario = " . $_ACodUsuario;
		if ($_ACodItemGrade > 0) {
			$ASql = $ASql . "     and tic.coditemgrade = " . $_ACodItemGrade;
		}
		$ASql = $ASql . "     and (tic.pedidogerado is null or tic.pedidogerado = 'n') ";
		$AQuery = $this->OpenSQLToResultSet($ASql);
		$AQtde = 0;
		while ($row = $AQuery->fetch(PDO::FETCH_ASSOC)) {
			$AQtde = $row['qtde'];
		}
		return $AQtde;
	}
	
	
	function getInsertNewItem(){
		$ANewCod = $this->GetNewCod();
		//$this->addInListFields($this->getCampoChave(), "(" . $this->getFieldKeyMaxInSQL() . ")+1 ", "i");
		$this->addInListFields($this->getCampoChave(), $ANewCod, "i");
		$this->setParametersToFieldList();
		
		$ASql = "insert into ".$this->getTabela()." (" .
				$this->getFieldsInsPostFieldNamesToIns() .
				") Values (" .
				$this->getFieldsInsPostFieldValuesToIns() .
				")";
				
		$AExec = $this->ExecSQL($ASql);
		$AReturn = "";
		if ($AExec) {
			$AReturn = $this->getReturnOk();
		}
		else {
			$AReturn = $this->getReturnError($this->getLastMessage());
		}
		return $AReturn;
				
	}
	
	function getAtualizaQtdeCarrinho($ACodUsuario, $ACodItemGrade){
		$AQtde = $this->getParameterInt("qtde");
		$ASql = "update tabitenscarrinho set qtde = qtde + " . $AQtde .
				" where codusuario = " . $ACodUsuario .
				"   and coditemgrade = " . $ACodItemGrade .
				"   and qtde > 0 ";
		$this->ExecSQL($ASql);
		return $this->getReturnOk();
	}
	
	function addCarrinho(){
		$ACodUsuario = $this->getParameterInt("codusuario");
		$ACodItemGrade = $this->getParameterInt("coditemgrade");
		$AResult = "";
		if ($this->getQtdeCarrinhoByItem($ACodUsuario, $ACodItemGrade) == 0){
			$AResult = $this->getInsertNewItem();
		}
		else {
			$AResult = $this->getAtualizaQtdeCarrinho($ACodUsuario, $ACodItemGrade);
		}
		return $AResult;
	}
	
	function tirarDoCarrinho(){
		$ACodUsuario = $this->getParameterInt("codusuario");
		$ACodItemGrade = $this->getParameterInt("coditemgrade");
		
		$ASql = "update tabitenscarrinho set qtde = 0 " .
				" where codusuario = " . $ACodUsuario .
				"   and coditemgrade = " . $ACodItemGrade .
				"   and (pedidogerado is null or pedidogerado = 'n') ";
		$this->ExecSQL($ASql);
		return $this->getReturnOk();
	}
	
//gerar pedido
	
	function gerarSqlCodigo(){
		return "( select Coalesce(max(tnf.codnf), 0) as codigo from tabsaidanf tnf)+1 ";
/*		$AQuery = $this->OpenSQLToResultSet($ASql);
		$ACod = 0;
		while ($row = $AQuery->fetch(PDO::FETCH_ASSOC)) {
			$ACod = $row['codigo'];
		}
		return $ACod + 1;*/
	}				
	
	function getCodigoNFGerado($_ACodUsuario){
		$ASql = " select max(tnf.codnf) as codigo from tabsaidanf tnf where tnf.codusuariosite = " . $_ACodUsuario;
		$AQuery = $this->OpenSQLToResultSet($ASql);
		$ACod = 0;
		while ($row = $AQuery->fetch(PDO::FETCH_ASSOC)) {
		   $ACod = $row['codigo'];
		}
		return $ACod;
	}		
	
	function getSubSelectValorPedido($_ACodUsuario){
		$ASql = "(" . 
				"select sum(tig.valorvenda * tic.qtde) " .
				"    from tabitenscarrinho tic " .
				"  join tabinsumosgrade tig " .
				"    on tig.coditem = tic.coditemgrade " .
				"   where tic.codusuario = " . $_ACodUsuario .
				"     and (tic.pedidogerado is null or tic.pedidogerado = 'n') " .
		        ")";
		return $ASql;
	}
	
	function updateEstoqueProduto($_ACodItemGrade, $_AQtde){
		$ASqlUpd = "update tabinsumosgrade set qtdeestoque = qtdeestoque - :qtde " .
					" where coditem = :coditemgrade ";
		$AQueryUpd = $this->FCon->prepare( $ASqlUpd );
		$AQueryUpd->bindParam(':coditemgrade', $_ACodItemGrade, PDO::PARAM_INT);
		$AQueryUpd->bindParam(':qtde', $_AQtde, PDO::PARAM_INT);
		$AQueryUpd->execute();
	}
	
	function gerarIntensPedido($_ACodUsuario, $_ACodNF){
		$ASql = " select tc.coditem, tc.codusuario, tc.coditemgrade, tig.valorvenda, tc.qtde, tc.qtde*tig.valorvenda as valortotal " . 
				"	from tabitenscarrinho tc " .
			    "		join tabinsumosgrade tig " .
				"	  on tig.coditem = tc.coditemgrade " .
				"	where tc.codusuario = " . $_ACodUsuario .
				"	  and (tc.pedidogerado is null or tc.pedidogerado = 'n') ";
		$AQuery = $this->OpenSQLToResultSet($ASql);
		
		$ASqlKey = "( select Coalesce(max(tnfi.codlcto), 0) as codigo from tabsaidanfitens tnfi )+1";
		$ASqlInsert = "insert into tabsaidanfitens (codlcto, codnf, coditemgrade, valorunit, qtde, valortotal) " .
					  " values ( " . $ASqlKey . ", :codnf, :coditemgrade, :valorunit, :qtde, :valortotal) ";
		$AQueryIns = $this->FCon->prepare( $ASqlInsert );
		
		while ($row = $AQuery->fetch(PDO::FETCH_ASSOC)) {
			$AQueryIns->bindParam(':codnf', $_ACodNF, PDO::PARAM_INT);
			$AQueryIns->bindParam(':coditemgrade', $row["coditemgrade"], PDO::PARAM_INT);
			$AQueryIns->bindParam(':valorunit', $row["valorvenda"], PDO::PARAM_STR);
			$AQueryIns->bindParam(':qtde', $row["qtde"], PDO::PARAM_INT);
			$AQueryIns->bindParam(':valortotal', $row["valortotal"], PDO::PARAM_STR);
			$AQueryIns->execute();
			
			$this->updateEstoqueProduto($row["coditemgrade"], $row["qtde"]);
		}
	}
	
	function gerarPedidoPeloCarrinho($_ACodUsuario){
		$ASqlCod = $this->gerarSqlCodigo();
		$ACodEnd = $this->getParameterInt("codend");
		$ASql = "insert into tabsaidanf (codnf, dataemissao, valornf, tiponf, codusuariosite, codend)" .
				" values ( " .
				   $ASqlCod . ", " .
				   "current_date, " .
				   $this->getSubSelectValorPedido($_ACodUsuario) . ", ".
				   "'p', " .
				   $_ACodUsuario . ", " .
				   $ACodEnd .
				   ") ";
		$this->ExecSQLSimple($ASql);
		$ACodNF = $this->getCodigoNFGerado($_ACodUsuario);
		$this->gerarIntensPedido($_ACodUsuario, $ACodNF);
		return $ACodNF;
	}
	
	function gerarPedido(){
		$ACodUsuario = $this->getParameterInt("codusuario");
		$AResult = "";
		$AQtdeCarrinho = $this->getQtdeCarrinhoByItem($ACodUsuario, 0);
		if ($AQtdeCarrinho > 0) {
			$this->FCon->beginTransaction();
			try {
				$ACodPedido = $this->gerarPedidoPeloCarrinho($ACodUsuario);
			
				$ASql = "update tabitenscarrinho set pedidogerado = 'S', codpedido = " . $ACodPedido .
						" where codusuario = " . $ACodUsuario .
						"   and (pedidogerado is null or pedidogerado = 'n') ";
				$this->ExecSQLSimple($ASql);
				$AResult = $this->getReturnOk();
				$this->FCon->commit();
			} catch (Exception $e) {
				$this->logMe($e->getMessage());
				$this->FCon->rollBack();
				$this->FLastMessage = $e->getMessage();
				$AResult = $this->getReturnError($this->FLastMessage);
			}
		}
		else {
			$AResult = $this->getReturnOk();
		}
		return $AResult;		
	}
	
	function process($_AAction){
		$AResult = "";
		if (strcasecmp($_AAction, constCads::CADV_CADITENSCARRINHO_ADD_CARRINHO) == 0) {
			$AResult = $this->addCarrinho();
		}
		else if (strcasecmp($_AAction, constCads::CADV_CADITENSCARRINHO_DEL_CARRINHO) == 0) {
			$AResult = $this->tirarDoCarrinho();
		}
		else if (strcasecmp($_AAction, constCads::CADV_CADITENSCARRINHO_CONS_RESUMO) == 0) {
			$AResult = $this->getConsResumo();
		}
		else if (strcasecmp($_AAction, constCads::CADV_CADITENSCARRINHO_GERAR_PEDIDO) == 0) {
			$AResult = $this->gerarPedido();
		}
		else {
			$AResult = parent::process($_AAction);
		}
		return $AResult;
	}
	
}