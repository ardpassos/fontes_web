<?php

class resumoVarejo extends cadBase {
	
	function getTabela(){
		return "";
	}
	
	function getCampoChave(){
		return "";
	}
	
	function getPedidos() {
		$this->FSqlInitial = "select tu.nomeusuario, tsnf.* from tabsaidanf tsnf " .
							 "  left join tabusuariov tu " . 
							 "    on tu.codusuario = tsnf.codusuariosite " .
							 " where tsnf.tiponf= 'p' " .
							 " order by tsnf.dataemissao";
		$this->addFieldDef($this->getCampoChave(), "C�d. Produto", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("insumo", "Produto", constCads::FIELD_STRING, "", "");
		$AQuery = $this->OpenSQLToResultSet($this->FSqlInitial);
		$this->FillDataCons($AQuery);
		return $this->getJSONRecords();
	}
	function getItensPedidos() {
		$ACodNF =  $this->getParameterInt("codnf");
		$this->FSqlInitial = "select tip.* from tabsaidanfitens tip " .
							 " where tip.codnf = " . $ACodNF;
		$AQuery = $this->OpenSQLToResultSet($this->FSqlInitial);
		$this->FillDataCons($AQuery);
		return $this->getJSONRecords();
	}
	
	function getCRAteHoje() {
		$this->FSqlInitial = "select tcr.datavcto, sum(tcr.valor) valordia " .
							 "  from tabcontasreceber tcr " .
							 " where tcr.datavcto < current_date+1 " .
							 "   and tcr.status = 'A' " .
							 " group by tcr.datavcto " .
							 " order by tcr.datavcto ";
		$AQuery = $this->OpenSQLToResultSet($this->FSqlInitial);
		$this->FillDataCons($AQuery);
		return $this->getJSONRecords();
	}
	
	function getCRDetDia() {
		$AData =  $this->getParameterDateTime("data");
		$this->FSqlInitial = "select tp.nome, tcr.numdoc, tcr.datavcto, tcr.valor from tabcontasreceber tcr " .
							"   join tabpessoas tp " .
							"     on tp.codpessoa = tcr.codpessoaconta " .
							"  where tcr.status = 'A' " .
							"    and tcr.datavcto = '". $AData . "' " .
							"  order by tp.nome ";
		$AQuery = $this->OpenSQLToResultSet($this->FSqlInitial);
		$this->FillDataCons($AQuery);
		return $this->getJSONRecords();
	}
	
	function getCPAteHoje() {
		$this->FSqlInitial = "select tcp.datavcto, sum(tcp.valor) valordia " .
				"  from tabcontaspagar tcp " .
				" where tcp.datavcto < current_date+1 " .
				"   and tcp.status = 'A' " .
				" group by tcp.datavcto " .
				" order by tcp.datavcto ";
		$AQuery = $this->OpenSQLToResultSet($this->FSqlInitial);
		$this->FillDataCons($AQuery);
		return $this->getJSONRecords();
	}
	
	function getCPDetDia() {
		$AData =  $this->getParameterDateTime("data");
		$this->FSqlInitial = "select tp.nome, tcp.numdoc, tcp.datavcto, tcp.valor from tabcontaspagar tcp " .
				"   join tabpessoas tp " .
				"     on tp.codpessoa = tcp.codpessoaconta " .
				"  where tcp.status = 'A' " .
				"    and tcp.datavcto = '". $AData . "' " .
				"  order by tp.nome ";
		$AQuery = $this->OpenSQLToResultSet($this->FSqlInitial);
		$this->FillDataCons($AQuery);
		return $this->getJSONRecords();
	}
	
	function getImg(){
		$ACodInsumo =  $this->getParameterInt("codinsumo");
		$this->FSqlInitial = "Select codimg, codproduto, img  from tabprodutoimgs " .
				" where codproduto = " . $ACodInsumo .
				" order by codimg " .
				" limit 1";
		$AQuery = $this->OpenSQLToResultSet($this->FSqlInitial);
		if ($row = $AQuery->fetch(PDO::FETCH_ASSOC)) {
			header('Content-Type: jpg');
			echo $row["img"];
		}
	}
	
	function process($_AAction){
		$AResult = "";
		if (strcasecmp($_AAction, constCads::CADV_RESUMO_VAREJO_PEDIDOS) == 0) {
			$AResult = $this->getPedidos();
		}
		else if (strcasecmp($_AAction, constCads::CADV_RESUMO_VAREJO_ITENS_PEDIDOS) == 0) {
			$AResult = $this->getItensPedidos();
		}
		else if (strcasecmp($_AAction, constCads::CADV_RESUMO_VAREJO_CR_ATE_HOJE) == 0) {
			$AResult = $this->getCRAteHoje();
		}
		else if (strcasecmp($_AAction, constCads::CADV_RESUMO_VAREJO_CR_DIA) == 0) {
			$AResult = $this->getCRDetDia();
		}
		else if (strcasecmp($_AAction, constCads::CADV_RESUMO_VAREJO_CP_ATE_HOJE) == 0) {
			$AResult = $this->getCPAteHoje();
		}
		else if (strcasecmp($_AAction, constCads::CADV_RESUMO_VAREJO_CP_DIA) == 0) {
			$AResult = $this->getCPDetDia();
		}
		return $AResult;
	}
	
}