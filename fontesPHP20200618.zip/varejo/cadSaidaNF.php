<?php

class cadSaidaNF extends cadBase {
	
	public $RowConfigGeral = [];
	
	function getTabela(){
		return "tabsaidanf";
	}
	
	function getCampoChave(){
		return "codnf";
	}
	
	function getCampoValorParaFinanc(){
		return "( ".
				"   coalesce(tsn.valorentrada, 0) + ".
				"	 ( select sum(tnfp.valor) ".
				"  	     from tabnfsaidaparcelas as tnfp ".
				" 	    where tnfp.codnf = tsn.codnf )" .
				")";
	}
	
	function getCons() {
		$this->FSqlInitial ="Select tsn.*, tuv.nomeusuario, ".
							"   (select sum(ti.valortotal) ".
							"	   from tabsaidanfitens ti " .
							"	  where ti.codnf = tsn.codnf) as ValorItens, ".
							"  case tsn.tipopgto ".
							"      when 'V' then tsn.valornf  " .
							"      else " . $this->getCampoValorParaFinanc() . 
							"  end as valorfinanc ".
							" from tabsaidanf tsn " . 
							" left join tabusuariov tuv " .
							"   on tuv.codusuario = tsn.codusuariosite ";
					
		$this->addFieldDef($this->getCampoChave(), "C�d. NF", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("numnf", "N�m. NF", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("serienf", "S�rie NF", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("dataemissao", "Data Emiss�o", constCads::FIELD_DATE, "", "");
		$this->addFieldDef("datasaida", "Data entrada", constCads::FIELD_DATE, "", "");
		$this->addFieldDef("valornf", "Valor NF", constCads::FIELD_FLOAT, "", "");
		$this->addFieldDef("tipopgto", "Tipo pgto", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("valorentrada", "Valor entrada", constCads::FIELD_FLOAT, "", "");
		$this->addFieldDef("numparcelas", "N�m. parcelas", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("statusnf", "Status", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("tiponf", "Tipo NF", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("codcliente", "C�d. cliente", constCads::FIELD_INTEGER, "", "");
		
		return parent::getCons();
	}
	
	function getConsLkp() {
		$this->FOrderBy = "  order by numnf";
		$this->FSqlInitial = "select codnf as codigo, numnf as descricao ".
				"  from tabsaidanf ";
		$this->addFieldDef($this->getCampoChave(), "C�d. NF", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("numnf", "NF", constCads::FIELD_STRING, "", "");
		return parent::getConsLkp();
	}
	
	function getDel(){
		$AResult = ""; 
		$this->FCon->beginTransaction();
		try {
			$ACodNF = $this->getParameterInt("codnf");
			$this->ExecSQLSimple("delete from tabsaidanfitens where codnf=".$ACodNF);
			$this->ExecSQLSimple("delete from tabsaidanf where codnf=".$ACodNF);
			$this->FCon->commit();
			$AResult = $this->getReturnOk();
		} catch (Exception $e) {
			$this->logMe($e->getMessage());
			$this->FCon->rollBack();
			$this->FLastMessage = $e->getMessage();
			$AResult = $this->getReturnError($this->FLastMessage);
		}
		return $AResult;
	}
	
	function getQueryItensNF($_ACodNF){
		$ASql = "select tsi.*, " .
				"		ti.insumo, ti.obs, " .	
				"		tig.tamanho, tig.valorvenda, tc.cor, tc.refhexa, ".
				"       tla.localalm, " .
				"  from tabsaidanfitens tsi " .
				"  join tabinsumosgrade tig " .
				"    on tig.coditem = tsi.coditemgrade " .
				"  join tabinsumos ti " .
				"    on ti.codinsumo = tig.codinsumo " .
				"  left join tabcores tc " .
				"    on tc.codcor = tig.codcor " .
				"  left join tablocalalmox tla " .
				"    on tla.codlocalalm = tig.codlocalalm " .
				" where tsi.codnf = " . $_ACodNF .
				" order by tsi.codlcto ";
		$AQuery = $this->OpenSQLToResultSet($ASql);
		return $AQuery;
	}
	
	function ajustarEstoqueInsumo($_ACodItemGrade, $_AQtde){
		$ASql = "update tabinsumosgrade set qtdeestoque = coalesce(qtdeestoque, 0) + " . $_AQtde .
		" where coditem = " . $_ACodItemGrade;
		$this->logMe($ASql);
		$this->ExecSQLSimple($ASql);
	}
	
	function ajustarEstoqueTodosItens($_AQuery, $_AMult){ //$_AMult = 1 para adicionar no estoque, $_AMult=-1 para retirar do estoque
		while ($row = $_AQuery->fetch(PDO::FETCH_ASSOC)) {
			$this->ajustarEstoqueInsumo($row["coditemgrade"], $row["qtde"]*$_AMult);
		}
	}
	
	//integra��o com financeiro
	function getQueryParc($_ACodNF){
		$ASql = "select tp.*, tnf.codcliente, tnf.numnf, tnf.serienf ".
				"  from tabnfsaidaparcelas tp " .
				"  join tabsaidanf tnf " .
				"    on tnf.codnf = tp.codnf ".
				" where tp.codnf = " . $_ACodNF .
				" order by tp.codlcto ";
		$AQuery = $this->OpenSQLToResultSet($ASql);
		return $AQuery;
	}
	function gerarParcelaCR($_ARec, $_AParcNum){
		$ACad = new cadContasReceber($this->FConObj);
		$ACad->addFieldToInsert("numdoc", $_ARec["numnf"], "s");
		$ACad->addFieldToInsert("codpessoaconta", $_ARec["codcliente"], "i");
		$ACad->addFieldToInsert("datahoralcto", "current_date" , "d");
		$ACad->addFieldToInsert("datavcto", $_ARec["datavcto"], "d");
		$ACad->addFieldToInsert("valor", $_ARec["valor"], "f");
		$ACad->addFieldToInsert("obs", "Parcela " . $_AParcNum, "s");
		$ACad->addFieldToInsert("lancmanual", "N", "s");
		$ACad->addFieldToInsert("status", "A", "s");
		$ACad->addFieldToInsert("codnf", $_ARec["codnf"], "i");
		$ACad->addFieldToInsert("codcrd", $this->RowConfigGeral["codcrdvendas"], "i");
		return $ACad->insertFromIntegracao();
	}
	function gerarCR($_ACodNF){
		$AQueryParc = $this->getQueryParc($_ACodNF);
		$i = 0;
		while ($row = $AQueryParc->fetch(PDO::FETCH_ASSOC)) {
			$i += 1;
			$this->gerarParcelaCR($row, $i);
		}
	}	
	
	function getQueryNF($_ACodNF){
		$ASql = "select tnf.* ".
				"  from tabsaidanf tnf " .
				" where tnf.codnf = " . $_ACodNF;
		$AQuery = $this->OpenSQLToResultSet($ASql);
		return $AQuery;
	}
	function gerarLctoMovFinanc($_ARec){
		$ACad = new cadMovFinanc($this->FConObj);
		$ACad->addFieldToInsert("numdoc", $_ARec["numnf"], "s");
		$ACad->addFieldToInsert("codpessoaconta", $_ARec["codcliente"], "i");
		$ACad->addFieldToInsert("datahoralcto", "current_date" , "d");
		$ACad->addFieldToInsert("dataaprop", $_ARec["dataemissao"], "d");
		$ACad->addFieldToInsert("valor", $_ARec["valorentrada"], "f");
		$ACad->addFieldToInsert("obs", "Valor de entrada da NF: " . $_ARec["numnf"] . " - Parcelas restantes: " .  $_ARec["numparcelas"], "s");
		$ACad->addFieldToInsert("lancmanual", "N", "s");
		$ACad->addFieldToInsert("codnfsaida", $_ARec["codnf"], "i");
		$ACad->addFieldToInsert("entsai", "E", "s");
		$ACad->addFieldToInsert("codcrd", $this->RowConfigGeral["codcrdvendas"], "i");
		
		return $ACad->insertFromCRCP();
	}
	function gerarMovFinanc($_ACodNF){
		$AQueryParc = $this->getQueryNF($_ACodNF);
		while ($row = $AQueryParc->fetch(PDO::FETCH_ASSOC)) {
			$this->gerarLctoMovFinanc($row);
		}
	}
	function setConfigGeralFinanc(){
		$ASql = "select * ".
				"  from tabconfigvarejo limit 1";
		$AQuery = $this->OpenSQLToResultSet($ASql);
		$this->RowConfigGeral = $AQuery->fetch(PDO::FETCH_ASSOC);
	}
	function gerarFinanceiro($_ACodNF){
		$this->setConfigGeralFinanc();
		$this->gerarMovFinanc($_ACodNF);
		$this->gerarCR($_ACodNF);
	}
	
	
	function zerarCP($_ACodNF){
		$ASql = "delete from tabcontasreceber ".
				"  where codnf = " . $_ACodNF;
		$AQuery = $this->ExecSQLSimple($ASql);
		return $AQuery;
	}
	function zerarMovFinanc($_ACodNF){
		$ASql = "delete from tabmovfinanc ".
				"  where codnfsaida = " . $_ACodNF;
		$AQuery = $this->ExecSQLSimple($ASql);
		return $AQuery;
	}
	function zerarFinanceiro($_ACodNF){
		$this->zerarMovFinanc($_ACodNF);
		$this->zerarCP($_ACodNF);
	}
	//fim da integra��o com financeiro
	
	
	function setStatusNF($_ACodNF, $_AStatusNF){
		$ASql = "update tabsaidanf set statusnf = '" . $_AStatusNF . "'".
				" where codnf = " . $_ACodNF;
		$this->ExecSQLSimple($ASql);
	}
	
	function finalizaNF() {
		$ACodNF = $this->getParameterInt( "codnf");
		$AQueryItens = $this->getQueryItensNF($ACodNF);
		
		$this->FCon->beginTransaction();
		try {
			$this->ajustarEstoqueTodosItens($AQueryItens, -1);
			$this->gerarFinanceiro($ACodNF);
			$this->setStatusNF($ACodNF, constCads::CADV_SAIDANF_STATUS_FECHADA);
			
			$this->FCon->commit();
			return $this->getReturnOk();
		} catch (Exception $e) {
			$this->logMe($e.getMessage());
			$this->FCon->rollBack();
			$this->FLastMessage = $e.getMessage();
			return $this->getReturnError($this->FLastMessage);
		}
	}
	
	function reabrirNF() {
		$ACodNF = $this->getParameterInt( "codnf");
		$AQueryItens = $this->getQueryItensNF($ACodNF);
		
		$this->FCon->beginTransaction();
		try {
			$this->ajustarEstoqueTodosItens($AQueryItens, 1);
			$this->zerarFinanceiro($ACodNF);
			$this->setStatusNF($ACodNF, constCads::CADV_SAIDANF_STATUS_ABERTA);
			
			$this->FCon->commit();
			return $this->getReturnOk();
		} catch (Exception $e) {
			$this->logMe($e.getMessage());
			$this->FCon->rollBack();
			$this->FLastMessage = $e.getMessage();
			return $this->getReturnError($this->FLastMessage);
		}
	}
	
	function geraCondicional(){
		$ACodNF = $this->getParameterInt( "codnf");
		$ASqlValItens = "   (select sum(ti.valortotal) ".
						"	   from tabsaidanfitens ti " .
						"	  where ti.codnf = " . $ACodNF . ")";
		$ASql = "update tabsaidanf set tiponf='c', datasaida=current_date, valornf= ". $ASqlValItens .
				" where codnf=" . $ACodNF;
		if ($this->ExecSQL($ASql)){
			return $this->getReturnOk();
		}
		else {
			return $this->getReturnError("Erro ao gerar condicional!");
		}
	}
	
	function getListStatusNF() {
		$this->Records = [];
		$ARec = [];
		$ARec["codigo"] = "A";
		$ARec["descricao"] = "Aberto";
		array_push($this->Records, $ARec);
		$ARec["codigo"] = "F";
		$ARec["descricao"] = "Fechado";
		array_push($this->Records, $ARec);
		$ARec["codigo"] = "C";
		$ARec["descricao"] = "Cancelado";
		array_push($this->Records, $ARec);
		return $this->getJSONRecords();
	}
	
	function getListTipoNF() {
		$this->Records = [];
		$ARec = [];
		$ARec["codigo"] = "n";
		$ARec["descricao"] = "NF";
		array_push($this->Records, $ARec);
		$ARec["codigo"] = "p";
		$ARec["descricao"] = "Pedido";
		array_push($this->Records, $ARec);
		$ARec["codigo"] = "c";
		$ARec["descricao"] = "Condicional";
		array_push($this->Records, $ARec);
		return $this->getJSONRecords();
	}
	
	function getListTipoPgto() {
		$this->Records = [];
		$ARec = [];
		$ARec["codigo"] = constCads::CADV_FINANC_STATUS_AVISTA;
		$ARec["descricao"] = constCads::CADV_FINANC_STATUS_AVISTA_D;
		array_push($this->Records, $ARec);
		$ARec["codigo"] = constCads::CADV_FINANC_STATUS_APRAZO;
		$ARec["descricao"] = constCads::CADV_FINANC_STATUS_APRAZO_D;
		array_push($this->Records, $ARec);
		return $this->getJSONRecords();
	}
	
	function setParametersToFieldList(){
		$this->addInListFields("numnf", $this->getParameter( "numnf"), "s");
		$this->addInListFields("serienf", $this->getParameter( "serienf"), "s");
		$this->addInListFields("dataemissao", $this->getParameterDateTime( "dataemissao"), "d");
		$this->addInListFields("datasaida", $this->getParameterDateTime( "datasaida"), "d");
		$this->addInListFields("valornf", $this->getParameterFloat( "valornf"), "f");
		$this->addInListFields("tipopgto", $this->getParameter( "tipopgto"), "s");
		$this->addInListFields("valorentrada", $this->getParameterFloat( "valorentrada"), "f");
		$this->addInListFields("numparcelas", $this->getParameterInt( "numparcelas"), "i");
		$this->addInListFields("statusnf", $this->getParameter( "statusnf"), "s");
		$this->addInListFields("tiponf", $this->getParameter( "tiponf"), "s");
		$this->addInListFieldsFromParam("codcliente", "i");
	}
	
	function process($_AAction){
		$AResult = "";
		if (strcasecmp($_AAction, constCads::ACTION_SAIDANF_GERACONDICIONAL) == 0) {
			$AResult = $this->geraCondicional();
		}
		else if (strcasecmp($_AAction, constCads::ACTION_SAIDANF_LKP_STATUSNF) == 0) {
			$AResult = $this->getListStatusNF();
		}
		else if (strcasecmp($_AAction, constCads::ACTION_SAIDANF_LKP_TIPONF) == 0) {
			$AResult = $this->getListTipoNF();
		}
		else if (strcasecmp($_AAction, constCads::ACTION_FINANC_LKP_TIPOPGTO) == 0) {
			$AResult = $this->getListTipoPgto();
		}
		else if (strcasecmp($_AAction, constCads::ACTION_SAIDANF_FINALIZANF) == 0) {
			$AResult = $this->finalizaNF();
		}
		else if (strcasecmp($_AAction, constCads::ACTION_SAIDANF_REABRIRNF) == 0) {
			$AResult = $this->reabrirNF();
		}
		else
			$AResult = parent::process($_AAction);
			return $AResult;
	}
	
}