<?php

class cadCores extends cadBase {
	
	function getTabela(){
		return "tabcores";
	}
	
	function getCampoChave(){
		return "codcor";
	}
	
	function getCons() {
		$this->FSqlInitial = "Select * from ". $this->getTabela();
		$this->addFieldDef($this->getCampoChave(), "C�d. Cor", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("cor", "Cor", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("refhexa", "Refer�ncia", constCads::FIELD_STRING, "", "");
		return parent::getCons();
	}
	
	function getConsLkp() {
		$this->FOrderBy = "  order by cor ";
		$this->FSqlInitial = "select codcor as codigo, cor as descricao ".
				"  from tabcores ";
		return parent::getConsLkp();
	}
	
	function setParametersToFieldList(){
		$this->addInListFieldsFromParam("cor", "s");

		$ARefHexa = $this->getParameter("refhexa");
		$this->addInListFields("refhexa", "#".$ARefHexa, "s");
	}
	
}