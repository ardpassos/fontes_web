<?php

class cadEntradaNFItens extends cadBase {
	
	function getTabela(){
		return "tabentradanfitens";
	}
	
	function getCampoChave(){
		return "codlcto";
	}
	
	function getCons() {
		$this->FSqlInitial = "Select * from ". $this->getTabela();
		return parent::getCons();
	}
	
	function setParametersToFieldList(){
		$this->addInListFieldsFromParam("codnf", "i");
		$this->addInListFieldsFromParam("coditemgrade", "i");
		$this->addInListFieldsFromParam("valorunit", "f");
		$this->addInListFieldsFromParam("qtde", "f");
		$this->addInListFieldsFromParam("valortotal", "f");
	}
	
}