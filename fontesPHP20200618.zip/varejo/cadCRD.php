<?php

class cadCRD extends cadBase {
	
	function getTabela(){
		return "tabcrd";
	}
	
	function getCampoChave(){
		return "codcrd";
	}
	
	function getCons() {
		$this->FOrderBy = " order by debcred, crd ";
		$this->FSqlInitial = "Select * " .
							 "  from tabcrd ";
		$this->addFieldDef($this->getCampoChave(), "C�d. CRD", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("crd", "CRD", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("debcred", "C�b./Cr�d.", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("mascara", "M�scara", constCads::FIELD_STRING, "", "");
		
		return parent::getCons();
	}
	
	function getDebCred() {
		$this->Records = [];
		$ARec = [];
		$ARec["codigo"] = "C";
		$ARec["descricao"] =  utf8_encode("Cr�dito");
		array_push($this->Records, $ARec);
		$ARec["codigo"] = "D";
		$ARec["descricao"] =  utf8_encode("D�bito");
		array_push($this->Records, $ARec);
		//echo 
		return $this->getJSONRecords();
	}
	
	function setParametersToFieldList(){
		$this->addInListFieldsFromParam("crd", "s");
		$this->addInListFieldsFromParam("debcred", "s");
	}
	
	function getDebitos() {
		$this->FSqlInitial = "Select codcrd as codigo, crd as descricao " .
				"  from tabcrd " .
				" where debcred = 'D' ".
				" order by debcred, crd ";
	
		return parent::getCons();
	}
	
	function getCreditos() {
		$this->FSqlInitial = "Select codcrd as codigo, crd as descricao " .
				"  from tabcrd " .
				" where debcred = 'C' ".
				" order by debcred, crd ";
		
		return parent::getCons();
	}
	
	function process($_AAction){
		$AResult = "";
		if (strcasecmp($_AAction, constCads::ACTION_CRD_GETDEBCRED) == 0) {
			$AResult = $this->getDebCred();
		}
		else if (strcasecmp($_AAction, constCads::ACTION_CRD_GETDEBITOS) == 0) {
			$AResult = $this->getDebitos();
		}
		else if (strcasecmp($_AAction, constCads::ACTION_CRD_GETCREDITOS) == 0) {
			$AResult = $this->getCreditos();
		}
		else
			$AResult = parent::process($_AAction);
		return $AResult;
	}
	
}