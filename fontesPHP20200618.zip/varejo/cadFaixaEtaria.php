<?php

class cadFaixasEtarias extends cadBase {
	
	function getTabela(){
		return "tabfaixasetarias";
	}
	
	function getCampoChave(){
		return "codfaixaetaria";
	}
	
	function getCons() {
		$this->FSqlInitial = "Select * from ". $this->getTabela();
		$this->addFieldDef($this->getCampoChave(), "C�d. FaixaEtaria", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("faixaetaria", "faixaetaria", constCads::FIELD_STRING, "", "");
		return parent::getCons();
	}
	
	function getConsLkp() {
		$this->FOrderBy = "  order by faixaetaria";
		$this->FSqlInitial = "select codfaixaetaria as codigo, faixaetaria as descricao ".
				"  from tabfaixasetarias ";
		$this->addFieldDef($this->getCampoChave(), "C�d. FaixaEtaria", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("faixaetaria", "FaixaEtaria", constCads::FIELD_STRING, "", "");
		return parent::getConsLkp();
	}
	
	function getPost(){
		$ACodFaixaEtaria = $this->getParameterInt( "codfaixaetaria");
		$AFaixaEtaria = $this->getParameter( "faixaetaria");
		
		$ASql = "Update tabfaixasetarias set faixaetaria = '" . $AFaixaEtaria . "' " .
				" where codfaixaetaria = " . $ACodFaixaEtaria;
		
		if ($this->ExecSQL($ASql))
			return "[{\"retorno\":1}]";
			else
				return "[{\"retorno\":0," .
				"\"mensagem\":\"" . $this->getLastMessage() . "\"}]";
	}
	
	function getInsert(){
		$AFaixaEtaria = $this->getParameter( "faixaetaria");
		
		$ASql = "insert into tabfaixasetarias " .
				" (codfaixaetaria, faixaetaria) " .
				"Values (" .
				"(" . $this->getFieldKeyMaxInSQL() . ")+1, " .
				"'" . $AFaixaEtaria . "'" .
				")";
		
		$ObjRet = new MensagemRetorno();
		if ($this->ExecSQL($ASql)) {
			$ObjRet->retorno = 1;
			$ObjRet->mensagem = "";
		}
		else {
			$ObjRet->retorno = 0;
			$ObjRet->mensagem = $this->getLastMessage();
		}
		return $this->getJSONFromObj($ObjRet);
	}
}