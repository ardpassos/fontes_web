<?php

class cadMovFinanc extends cadBase {
	
	function getTabela(){
		return "tabmovfinanc";
	}
	
	function getCampoChave(){
		return "codmovfinanc";
	}
	
	function getCons() {
		$this->FSqlInitial = "Select codmovfinanc, numdoc, ". 
							 "codpessoaconta as codcliente, codpessoaconta as codfornecedor, ".
							 "codcrd as codcrdcredito, codcrd as codcrddebito, ".
							 "datahoralcto, dataaprop, valor, obs, lancmanual, entsai, codcrd ".
							 " from ". $this->getTabela();
		$this->addFieldDef($this->getCampoChave(), "C�d. mov. financ.", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("numdoc", "N�m doc.", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("codpessoaconta", "C�d. Pesoa", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("datahoralcto", "Data hora lcto", constCads::FIELD_DATE_TIME, "", "");
		$this->addFieldDef("dataaprop", "Data aprop.", constCads::FIELD_DATE, "", "");
		$this->addFieldDef("valor", "Valor", constCads::FIELD_FLOAT, "", "");
		$this->addFieldDef("obs", "Obs", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("lancmanual", "Lan. manual", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("entsai", "Entrada/Sa�da", constCads::FIELD_STRING, "", "");
		return parent::getCons();
	}
	
	function setParametersToFieldList(){
		$AEntSai = $this->getParameter("entsai");
		
		$this->addInListFieldsFromParam("numdoc", "s");
		$this->addInListFieldsFromParam("entsai", "s");
		if ($AEntSai == "E"){
			$ACodPessoa = $this->getParameter("codcliente");
		}else{
			$ACodPessoa = $this->getParameter("codfornecedor");
		}
		$this->addInListFields("codpessoaconta", $ACodPessoa, "i");
		$this->addInListFieldsFromParam("datahoralcto", "dt");
		$this->addInListFieldsFromParam("dataaprop", "d");
		$this->addInListFieldsFromParam("valor", "d");
		$this->addInListFieldsFromParam("obs", "s");
		$this->addInListFieldsFromParam("lancmanual", "s");
		if ($AEntSai == "E"){
			$ACodCRD = $this->getParameter("codcrdcredito");
		}else{
			$ACodCRD = $this->getParameter("codcrddebito");
		}
		$this->addInListFields("codcrd", $ACodCRD, "i");
	}
	
	function addFieldToInsert($_AFieldName, $_AFieldValue, $_AFieldType){
		$this->addInListFields($_AFieldName, $_AFieldValue, $_AFieldType);
	}
	
	function insertFromCRCP(){
		$this->addInListFields($this->getCampoChave(), "(" . $this->getFieldKeyMaxInSQL() . ")+1 ", "i");
		
		$ASql = "insert into ".$this->getTabela()." (" .
				$this->getFieldsInsPostFieldNamesToIns() .
				") Values (" .
				$this->getFieldsInsPostFieldValuesToIns() .
				")";
		$this->logMe($ASql);
		$AExec = $this->ExecSQLSimple($ASql);
		$ObjRet = new MensagemRetorno();
		if ($AExec) {
			$ObjRet->setRetornoOK();
		}
		else {
			$ObjRet->setRetornoErro($this->getLastMessage());
		}
		$AResult = $this->getJSONMsgRetorno($ObjRet);
		return $AResult;		
	}
	
	function getListEntSai() {
		$this->Records = [];
		$ARec = [];
		$ARec["codigo"] = "E";
		$ARec["descricao"] = "Entrada";
		array_push($this->Records, $ARec);
		
		$ARec["codigo"] = "S";
		$ARec["descricao"] = "Saida";
		array_push($this->Records, $ARec);
		
		return $this->getJSONRecords();
	}
	
	function process($_AAction){
		$AResult = "";
		if (strcasecmp($_AAction, constCads::ACTION_MOVFINANC_LKP_ENTSAI) == 0) {
			$AResult = $this->getListEntSai();
		}
		else{
			$AResult = parent::process($_AAction);
		}
		return $AResult;
	}
}