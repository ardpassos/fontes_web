<?php

class cadProdutos extends cadBase {
	
	function getTabela(){
		return "tabinsumos";
	}
	
	function getCampoChave(){
		return "codinsumo";
	}
	
	function getCons() {
		$this->FSqlInitial = "Select * from ". $this->getTabela();
		$this->addFieldDef($this->getCampoChave(), "C�d. Produto", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("insumo", "Produto", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("obs", "Obs", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("codgrupo", "C�d. Grupo", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("codlocalalm", "C�d. Local Alm.", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("codunmedida", "C�d. Un. Medida", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("codmarca", "C�d. Marca", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("codcategoria", "C�d. Categoria", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("codsubcategoria", "C�d. Sub Categoria", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("codfaixaetaria", "C�d. Faixa Et�ria", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("genero", "G�nero", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("status", "Status", constCads::FIELD_STRING, "", "");

		return parent::getCons();
	}
	
	function getDel(){
		$AResult = false;
		$ACodigo = $_GET[strtolower($this->getCampoChave())];
		
		$this->FCon->beginTransaction();
		try {
			$ASql = "Delete from tabprodutoimgs " . 
					" where codproduto = " . $ACodigo;
			$this->ExecSQLSimple($ASql);
			$ASql = "Delete from tabinsumosgrade " .
					" where codinsumo = " . $ACodigo;
			$this->ExecSQLSimple($ASql);
			$ASql = "Delete from tabinsumos " .
					" where codinsumo = " . $ACodigo;
			$this->ExecSQLSimple($ASql);
			$this->FCon->commit();
			$AResult = true;
		} catch (Exception $e) {
			$this->logMe($e->getMessage());
			$this->FCon->rollBack();
			$this->FLastMessage = $e->getMessage();
			$AResult = false;
		}
		
		$ObjRet = new MensagemRetorno();
		if ($AResult) {
			$ObjRet->retorno = 1;
			$ObjRet->chave = $ACodigo;
			$ObjRet->mensagem = "";
		}
		else {
			$ObjRet->retorno = 0;
			$ObjRet->chave = $ACodigo;
			$ObjRet->mensagem = $this->getLastMessage();
		}
		return $this->getJSONMsgRetorno($ObjRet);
	}
	
	function getConsLkp() {
		$this->FOrderBy = "  order by insumo";
		$this->FSqlInitial = "select codinsumo as codigo, insumo as descricao ".
				"  from tabinsumos ";
		$this->addFieldDef($this->getCampoChave(), "C�d. Produto", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("insumo", "Produto", constCads::FIELD_STRING, "", "");
		return parent::getConsLkp();
	}
	
	function setParametersToFieldList(){
		$this->addInListFieldsFromParam("insumo", "s");
		$this->addInListFieldsFromParam("obs", "s");
		$this->addInListFieldsFromParam("codgrupo", "i");
		$this->addInListFieldsFromParam("codlocalalm", "i");
		$this->addInListFieldsFromParam("codunmedida", "i");
		$this->addInListFieldsFromParam("codmarca", "i");
		$this->addInListFieldsFromParam("codcategoria", "i");
		$this->addInListFieldsFromParam("codsubcategoria", "i");
		$this->addInListFieldsFromParam("codfaixaetaria", "i");
		$this->addInListFieldsFromParam("genero", "s");
		$this->addInListFieldsFromParam("status", "s");
	}
	
	function getListStatus() {
		$this->Records = [];
		$ARec = [];
		$ARec["codigo"] = "1";
		$ARec["descricao"] = "Ativo";
		array_push($this->Records, $ARec); 
		$ARec["codigo"] = "2";
		$ARec["descricao"] = "Inativo";
		array_push($this->Records, $ARec);
		return $this->getJSONRecords();
	}
	
	function getListGenero() {
		$this->Records = [];
		$ARec = [];
		$ARec["codigo"] = "M";
		$ARec["descricao"] = "Masculino";
		array_push($this->Records, $ARec);
		$ARec["codigo"] = "F";
		$ARec["descricao"] = "Feminino";
		array_push($this->Records, $ARec);
		return $this->getJSONRecords();
	}
	
	
	
	function getChaveByInsumo(){
		$ASql = "select max(codinsumo) as codinsumo " .
				"  from tabinsumos " .
				" where insumo = '" . $this->getParameter("insumo") . "'";
		$AQuery = $this->OpenSQLToResultSet($ASql);
		$ACod = "-1";
		if ($row = $AQuery->fetch(PDO::FETCH_ASSOC)) {
			$ACod = $row["codinsumo"];
		}
		return $ACod;
	}
	

	function process($_AAction){
		$AResult = "";
		if (strcasecmp($_AAction, constCads::ACTION_PROCUTOS_LKP_STATUS) == 0) {
			$AResult = $this->getListStatus();
		}
		else if (strcasecmp($_AAction, constCads::ACTION_PROCUTOS_LKP_GENERO) == 0) {
			$AResult = $this->getListGenero();
		}
		else
			$AResult = parent::process($_AAction);
		return $AResult;
	}
	
}