<?php


class cadFuncionarios extends cadBase {
	
	function getTabela(){
		return "tabfuncionarios";
	}
	
	function getCampoChave(){
		return "codfuncionario";
	}
	
	function getCons() {
		$this->FSqlInitial = "Select * from ". $this->getTabela();
		$this->addFieldDef($this->getCampoChave(), "C�d. Func.", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("nome", "Nome", constCads::FIELD_STRING, "", "");

		$this->addFieldDef("apelidofunc", "Usu�rio", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("senha", "Senha", constCads::FIELD_DATE, "", "");
		
		$this->addFieldDef("datanasc", "Data Nasc", constCads::FIELD_DATE, "", "");
		$this->addFieldDef("CPF", "CPF", constCads::FIELD_STRING, "", "");
		$this->addFieldDef("Email", "Email", constCads::FIELD_STRING, "", "");
		
		$this->addFieldDef("dataadmissao", "Data Admiss�o", constCads::FIELD_DATE, "", "");
		$this->addFieldDef("datademissao", "Data Demiss�o", constCads::FIELD_DATE, "", "");
		
		$this->addFieldDef("codempresa", "C�d. Empresa", constCads::FIELD_INTEGER, "", "");
		return parent::getCons();
	}
	
	function keyExists($_ACod) {
		$AResult = false;
		try {
			$AQuery = $this->OpenSQLToResultSet(strtolower("Select Count(*) as NumRec ".
					                                       "  from " . $this->getTabela() . 
					                                       " where " . $this->getCampoChave() . " = " . $_ACod));
			if ( $dados = $AQuery->fetch() ){
				$AResult = ($dados["NumRec"] > 0);
			}
			else
				$AResult = false;
		}
		catch (Exception $e) {
			$AResult = false;
		}
		return $AResult;
	}
	
	function getPost(){
		$ACodFuncionario = $this->getParameterInt( "CodFuncionario");
		$ANome = $this->getParameter( "Nome");
		$AApelidoFunc = $this->getParameter( "ApelidoFunc");
		$ASenha = $this->getParameter( "Senha");
		$ADataNasc = $this->getParameterDateTime( "DataNasc");
		$ACPF = $this->getParameter( "CPF");
		$AEmail = $this->getParameter( "Email");
		$ADataAdmissao = $this->getParameterDateTime( "DataAdmissao");
		$ADataDemissao = $this->getParameterDateTime( "DataDemissao");
		$ACodEmpresa = $this->getParameterInt( "CodEmpresa");
	
		if ($ADataNasc != 'null')
			$ADataNasc = "'".$ADataNasc."'";
		if ($ADataAdmissao != 'null')
			$ADataAdmissao = "'".$ADataAdmissao."'";
		if ($ADataDemissao != 'null')
			$ADataDemissao = "'".$ADataDemissao."'";
					
		$ASql = strtolower("Update tabfuncionarios set nome = '") . $ANome . "', " .
				" apelidofunc = '" . $AApelidoFunc . "', " .
				" senha = '" . $ASenha . "', " .
				" datanasc = " . $ADataNasc . ", " .
				" cpf = '" . $ACPF . "', " .
				" email = '" . $AEmail . "', " .
				" dataadmissao = " . $ADataAdmissao . ", " .
				" datademissao = " . $ADataDemissao . ", " .
				" codempresa = " . $ACodEmpresa . 
				" where codfuncionario = " . $ACodFuncionario;
		
		if ($this->ExecSQL($ASql))
			return "[{\"retorno\":1}]";
			else
				return "[{\"retorno\":0," .
				"\"mensagem\":\"" . $this->getLastMessage() . "\"}]";
	}
	
	function getInsert(){
		
		$ANome = $this->getParameter( "Nome");
		$AApelidoFunc = $this->getParameter( "ApelidoFunc");
		$ASenha = $this->getParameter( "Senha");
		$ADataNasc = $this->getParameterDateTime( "DataNasc");
		$ACPF = $this->getParameter( "CPF");
		$AEmail = $this->getParameter( "Email");
		$ADataAdmissao = $this->getParameterDateTime( "DataAdmissao");
		$ADataDemissao = $this->getParameterDateTime( "DataDemissao");
		$ACodEmpresa = $this->getParameterInt( "CodEmpresa");
		
		$ASql = strtolower("Insert into TabFuncionarios " . 
				" (CodFuncionario, Nome, ApelidoFunc, Senha, DataNasc, CPF, Email, DataAdmissao, DataDemissao, CodEmpresa) " .
				"Values (" .
				"(" . $this->getFieldKeyMaxInSQL() . ")+1, ") .
				"'" . $ANome . "'," .
				"'" . $AApelidoFunc . "'," .
				"'" . $ASenha . "'," .
				" '" . $ADataNasc . "', " .
				" '" . $ACPF . "', " .
				" '" . $AEmail . "', " .
				" '" . $ADataAdmissao . "', " .
				" '" . $ADataDemissao . "', " .
				" " . $ACodEmpresa . 
				")";
		
		$ObjRet = new MensagemRetorno();
		if ($this->ExecSQL($ASql)) {
			$ObjRet->retorno = 1;
			$ObjRet->mensagem = "";
		}
		else {
			$ObjRet->retorno = 0;
			$ObjRet->mensagem = $this->getLastMessage();
		}
		return $this->getJSONFromObj($ObjRet);
	}
}
