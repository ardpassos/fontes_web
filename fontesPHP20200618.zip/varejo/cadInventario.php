<?php

class cadInventario extends cadBase {
	
	function getTabela(){
		return "tabinsumosgrade";
	}
	
	function getCampoChave(){
		return "coditem";
	}
	
	function getCons() {
		$this->FSqlInitial = "Select tig.coditem, tig.codbarras, ti.insumo, tig.tamanho, tc.cor, tc.refhexa, tig.qtdeestoque, '' as statusalt " . 
				"from tabinsumosgrade tig " . 
				" join tabinsumos ti " .
				"   on ti.codinsumo = tig.codinsumo " .
				" join tabcores tc " .
				"   on tc.codcor = tig.codcor " .
				" order by ti.insumo ";
		return parent::getCons();
	}
	
	function setParametersToFieldList(){
		$this->addInListFieldsFromParam("qtdeestoque", "i");
	}
	
}