<?php

class cadProdutosGrade extends cadBase {
	
	function getTabela(){
		return "tabinsumosgrade";
	}
	
	function getCampoChave(){
		return "coditem";
	}
	
	function getCons() {
		$this->FSqlInitial = "Select * from ". $this->getTabela();
		return parent::getCons();
	}
	
	function getConsLkp() {
		$this->FOrderBy = "  order by 2";
		$this->FSqlInitial = "select tig.coditem as codigo, " . 
				"					CONCAT (coalesce(ti.insumo, ''), ' - ', coalesce(tc.cor, '') , ' - ' , coalesce(tig.tamanho, '')) as descricao ".
				"  from tabinsumosgrade tig " . 
				"  join tabinsumos ti " .
				"    on ti.codinsumo = tig.codinsumo " .
				"  join tabcores tc " . 
				"    on tc.codcor = tig.codcor ";
		$this->addFieldDef($this->getCampoChave(), "C�d. Produto", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("insumo", "Produto", constCads::FIELD_STRING, "", "");
		return parent::getConsLkp();
	}
	
	function setParametersToFieldList(){
		$this->addInListFieldsFromParam("codinsumo", "i");
		$this->addInListFieldsFromParam("codlocalalm", "i");
		$this->addInListFieldsFromParam("codcor", "i");
		$this->addInListFieldsFromParam("tamanho", "s");
		$this->addInListFieldsFromParam("valorde", "f");
		$this->addInListFieldsFromParam("valorvenda", "f");
		$this->addInListFieldsFromParam("mostrarvalorsite", "s");
		$this->addInListFieldsFromParam("itemempromocao", "s");
		$this->addInListFieldsFromParam("qtdemin", "i");
		$this->addInListFieldsFromParam("qtdemax", "i");
		$this->addInListFieldsFromParam("codbarras", "s");
	}
	
}