<?php

class cadSaidaNFItens extends cadBase {
	
	function getTabela(){
		return "tabsaidanfitens";
	}
	
	function getCampoChave(){
		return "codlcto";
	}
	
	function getCons() {
		$this->FOrderBy = " order by tsi.codlcto ";
		$this->FSqlInitial ="select tsi.*, " .
							"		ti.insumo, ti.obs, " .
							"		tig.tamanho, tig.valorvenda, tig.codbarras, ". 
							"		tc.cor, tc.refhexa, ".
							"       tla.localalm " .
							"  from tabsaidanfitens tsi " .
							"  join tabinsumosgrade tig " .
							"    on tig.coditem = tsi.coditemgrade " .
							"  join tabinsumos ti " .
							"    on ti.codinsumo = tig.codinsumo " .
							"  left join tabcores tc " .
							"    on tc.codcor = tig.codcor " .
							"  left join tablocalalmox tla " .
							"    on tla.codlocalalm = tig.codlocalalm ";
		
		return parent::getCons();
	}
	
	function setParametersToFieldList(){
		$this->addInListFieldsFromParam("codnf", "i");
		$this->addInListFieldsFromParam("coditemgrade", "i");
		$this->addInListFieldsFromParam("valorunit", "f");
		$this->addInListFieldsFromParam("qtde", "f");
		$this->addInListFieldsFromParam("valortotal", "f");
	}
	
}