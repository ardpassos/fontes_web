<?php

class cadGruposProdutos extends cadBase {
	
	function getTabela(){
		return "tabgrupos";
	}
	
	function getCampoChave(){
		return "codgrupo";
	}
	
	function getCons() {
		$this->FSqlInitial = "Select * from ". $this->getTabela();
		$this->addFieldDef($this->getCampoChave(), "C�d. Grupo", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("grupo", "Grupo", constCads::FIELD_STRING, "", "");
		return parent::getCons();
	}
	
	function getConsLkp() {
		$this->FOrderBy = "  order by grupo";
		$this->FSqlInitial = "select codgrupo as codigo, grupo as descricao ".
				"  from tabgrupos ";
		$this->addFieldDef($this->getCampoChave(), "C�d. Grupo", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("grupo", "Grupo", constCads::FIELD_STRING, "", "");
		return parent::getConsLkp();
	}
	
	function getPost(){
		$ACodGrupo = $this->getParameterInt( "codgrupo");
		$AGrupo = $this->getParameter( "grupo");
		
		$ASql = "Update tabgrupos set grupo = '" . $AGrupo . "' " .
				" where codgrupo = " . $ACodGrupo;
		
		if ($this->ExecSQL($ASql))
			return "[{\"retorno\":1}]";
		else
			return "[{\"retorno\":0," .
					"\"mensagem\":\"" . $this->getLastMessage() . "\"}]";
	}
	
	function getInsert(){
		$AGrupo = $this->getParameter( "grupo");
		
		$ASql = "insert into tabgrupos " .
				" (codgrupo, grupo) " .
				"Values (" .
				"(" . $this->getFieldKeyMaxInSQL() . ")+1, " .
				"'" . $AGrupo . "'" .
				")";
		
		$ObjRet = new MensagemRetorno();
		if ($this->ExecSQL($ASql)) {
			$ObjRet->retorno = 1;
			$ObjRet->mensagem = "";
		}
		else {
			$ObjRet->retorno = 0;
			$ObjRet->mensagem = $this->getLastMessage();
		}
		return $this->getJSONFromObj($ObjRet);
	}
}