<?php

class cadConfigVarejo extends cadBase {
	
	function getTabela(){
		return "tabconfigvarejo";
	}
	
	function getCampoChave(){
		return "codconfig";
	}
	
	function getCons() {
		$this->FSqlInitial = "Select * from ". $this->getTabela();
		$this->addFieldDef($this->getCampoChave(), "C�d. Config", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("codcrdvendas", "C�d. CRD Vendas", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("codcrdcompras", "C�d. CRD Compras", constCads::FIELD_INTEGER, "", "");
		return parent::getCons();
	}
	
	function setParametersToFieldList(){
		$this->addInListFieldsFromParam("codcrdvendas", "i");
		$this->addInListFieldsFromParam("codcrdcompras", "i");
	}
	
}