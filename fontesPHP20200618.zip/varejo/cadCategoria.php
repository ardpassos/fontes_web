<?php

class cadCategorias extends cadBase {
	
	function getTabela(){
		return "tabcategorias";
	}
	
	function getCampoChave(){
		return "codcategoria";
	}
	
	function getCons() {
		$this->FSqlInitial = "Select * from ". $this->getTabela();
		$this->addFieldDef($this->getCampoChave(), "C�d. Categoria", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("categoria", "Categoria", constCads::FIELD_STRING, "", "");
		return parent::getCons();
	}
	
	function getConsLkp() {
		$this->FOrderBy = "  order by categoria";
		$this->FSqlInitial = "select codcategoria as codigo, categoria as descricao ".
				"  from tabcategorias ";
		$this->addFieldDef($this->getCampoChave(), "C�d. Categoria", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("categoria", "Categoria", constCads::FIELD_STRING, "", "");
		return parent::getConsLkp();
	}
	
	function getPost(){
		$ACodCategoria = $this->getParameterInt( "codCategoria");
		$ACategoria = $this->getParameter( "Categoria");
		
		$ASql = "Update tabcategorias set categoria = '" . $ACategoria . "' " .
				" where codcategoria = " . $ACodCategoria;
		
		if ($this->ExecSQL($ASql))
			return "[{\"retorno\":1}]";
			else
				return "[{\"retorno\":0," .
				"\"mensagem\":\"" . $this->getLastMessage() . "\"}]";
	}
	
	function getInsert(){
		$ACategoria = $this->getParameter( "categoria");
		
		$ASql = "insert into tabcategorias " .
				" (codcategoria, categoria) " .
				"Values (" .
				"(" . $this->getFieldKeyMaxInSQL() . ")+1, " .
				"'" . $ACategoria . "'" .
				")";
		
		$ObjRet = new MensagemRetorno();
		if ($this->ExecSQL($ASql)) {
			$ObjRet->retorno = 1;
			$ObjRet->mensagem = "";
		}
		else {
			$ObjRet->retorno = 0;
			$ObjRet->mensagem = $this->getLastMessage();
		}
		return $this->getJSONFromObj($ObjRet);
	}
}