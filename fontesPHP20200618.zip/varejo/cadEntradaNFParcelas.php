<?php

class cadEntradaNFParcelas extends cadBase {
	
	function getTabela(){
		return "tabnfentradaparcelas";
	}
	
	function getCampoChave(){
		return "codlcto";
	}
	
	function getCons() {
		$this->FSqlInitial = "Select * from ". $this->getTabela();
		$this->addFieldDef($this->getCampoChave(), "C�d. Lcto", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("codnf", "C�d. NF.", constCads::FIELD_INTEGER, "", "");
		$this->addFieldDef("valor", "Valor", constCads::FIELD_FLOAT, "", "");
		$this->addFieldDef("datavcto", "Data vcto", constCads::FIELD_FLOAT, "", "");
		return parent::getCons();
	}
	
	function setParametersToFieldList(){
		$this->addInListFieldsFromParam("codnf", "i");
		$this->addInListFieldsFromParam("valor", "f");
		$this->addInListFieldsFromParam("datavcto", "d");
	}
	
	
	function excluirTodasParcelas($_ACodNF){
		$ASql = "delete from tabnfentradaparcelas ".
				" where codnf = " . $_ACodNF;
		$this->ExecSQLSimple($ASql);
	}
	function gerarParcela($_ACodNF, $_ADataVcto, $_AValor){
		$ASql = "insert into tabnfentradaparcelas (codlcto, codnf, datavcto, valor) ".
				" values ( " . 
							"(" . $this->getFieldKeyMaxInSQL() . ")+1, ".
							$_ACodNF . ", " . 
							"'" . $_ADataVcto . "', " .
							$_AValor . 
						")";
		$this->ExecSQLSimple($ASql);
	}
	function getGerarParcelas() {
		$ACodNF = $this->getParameterInt( "codnf");
		$AValorNF = $this->getParameterFloat( "valornf");
		$AValorEntrada = $this->getParameterFloat( "valorentrada");
		$ANumParcelas = $this->getParameterInt( "numparcelas");
		$AValorParcelas = $AValorNF - $AValorEntrada;
		
		$AValorParc = 0;
		$ADif = 0;
		if (($AValorNF > 0) && ($ANumParcelas > 0)){
			$AValorParc = $AValorParcelas / $ANumParcelas;
			$AValorParc = $this->truncate($AValorParc, 2);
			if ($AValorParcelas != ($AValorParc * $ANumParcelas)){
				$ADif = $AValorParcelas - ($AValorParc * $ANumParcelas);
			}
		}
		
		
		$this->excluirTodasParcelas($ACodNF);
		if ($AValorParc > 0) {
			$this->FCon->beginTransaction();
			try {
				for ($i=1; $i < $ANumParcelas+1; $i++){
					if ($i == $ANumParcelas){
						$AValorParc = $AValorParc + $ADif;
					}
					$ADataVcto = new DateTime("+". $i ." month");
					$this->gerarParcela($ACodNF, $ADataVcto->format("Y-m-d"), $AValorParc);
				}
				$this->FCon->commit();
			} catch (Exception $e) {
				$this->logMe($e.getMessage());
				$this->FCon->rollBack();
				$this->FLastMessage = $e.getMessage();
			}
		}
	}
	
	function process($_AAction){
		$AResult = "";
		if (strcasecmp($_AAction, constCads::ACTION_ENTRADANF_PARCELAS_GERAR) == 0) {
			$AResult = $this->getGerarParcelas();
		}
		else
			$AResult = parent::process($_AAction);
			return $AResult;
	}
	
}